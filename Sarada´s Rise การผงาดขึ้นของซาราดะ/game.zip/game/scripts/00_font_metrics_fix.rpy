# Per-game Thai shaping fix. Ren'Py compatibility for this 8.1-era game selects
# the legacy FreeType shaper, which does not position stacked Thai marks in
# Athiti correctly. HarfBuzz preserves the second and third mark levels.


init 100 python:
    style.default.shaper = "harfbuzz"
    style.say_dialogue.shaper = "harfbuzz"
    style.say_label.shaper = "harfbuzz"
    style.input.shaper = "harfbuzz"

    # The imported gui.rpy has a missing final "f" in this optional font name.
    if getattr(gui, "system_font", None) == "Athiti-Bold.ttf":
        gui.system_font = "Athiti-Bold.ttf"

    renpy.display.log.write(
        "RenPy Runner: HarfBuzz Thai stacked-mark fix active."
    )
