﻿################################################################################
## Inicialización
################################################################################

init offset = -1


################################################################################
## Estilos
################################################################################



style default:
    outlines [(2,"#131313")]
    properties gui.text_properties()
    language gui.language

style input:
    outlines [(2,"#131313")]
    properties gui.text_properties("input", accent=True)
    adjust_spacing False

style hyperlink_text:
    outlines [(2,"#131313")]
    properties gui.text_properties("hyperlink", accent=True)
    hover_underline True

style gui_text:
    outlines [(2,"#131313")]
    properties gui.text_properties("interface")


style button:
    outlines [(2,"#131313")]
    properties gui.button_properties("button")

style button_text is gui_text:
    outlines [(2,"#131313")]
    properties gui.text_properties("button")
    yalign 0.5


style label_text is gui_text:
    outlines [(2,"#131313")]
    properties gui.text_properties("label", accent=True)

style prompt_text is gui_text:
    outlines [(2,"#131313")]
    properties gui.text_properties("prompt")


style bar:
    ysize gui.bar_size
    left_bar Frame("gui/bar/left.png", gui.bar_borders, tile=gui.bar_tile)
    right_bar Frame("gui/bar/right.png", gui.bar_borders, tile=gui.bar_tile)

style vbar:
    xsize gui.bar_size
    top_bar Frame("gui/bar/top.png", gui.vbar_borders, tile=gui.bar_tile)
    bottom_bar Frame("gui/bar/bottom.png", gui.vbar_borders, tile=gui.bar_tile)

style scrollbar:
    ysize gui.scrollbar_size
    base_bar Frame("gui/scrollbar/horizontal_[prefix_]bar.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/scrollbar/horizontal_[prefix_]thumb.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)

style vscrollbar:
    xsize gui.scrollbar_size
    base_bar Frame("gui/scrollbar/vertical_[prefix_]bar.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/scrollbar/vertical_[prefix_]thumb.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)

style slider:
    ysize gui.slider_size
    left_bar Frame("gui/bar/left.png", gui.bar_borders, tile=gui.bar_tile)
    right_bar Frame("gui/bar/right.png", gui.bar_borders, tile=gui.bar_tile)

style vslider:
    xsize gui.slider_size
    base_bar Frame("gui/slider/vertical_[prefix_]bar.png", gui.vslider_borders, tile=gui.slider_tile)
    thumb "gui/slider/vertical_[prefix_]thumb.png"


style frame:
    padding gui.frame_borders.padding
    background Frame("gui/frame.png", gui.frame_borders, tile=gui.frame_tile)
    hover_background Frame("frame_hover", gui.frame_borders, tile=gui.frame_tile)
style frame_dark:
    padding gui.frame_borders.padding
    background Frame("gui/frame_dark.png", gui.frame_borders, tile=gui.frame_tile)
    hover_background Frame("frame_dark_hover", gui.frame_borders, tile=gui.frame_tile)

style ach_frame:
    padding gui.frame_borders.padding
    background Frame("gui/frame.png", gui.frame_borders, tile=gui.frame_tile)

style overlay_style is text:
    size 30
    outlines [(2,"#131313")]
    font label_font
    xalign 0.5
    yalign 0.5

style brush_style is text:
    size 30
    outlines [(2,"#131313")]
    font "Athiti-Bold.ttf"
    xalign 0.5
    yalign 0.5

style button1:
    background "button1"
    hover_background "button1_hover"
    selected_background "button1_hover"
    focus_mask True

style button_black:
    background "button_black"
    hover_background "button_black_hover"
    selected_background "button_black_hover"
    focus_mask True

style black_button:
    background "button_black"
    hover_background "button_black_hover"
    focus_mask True

style circle_button:
    background "circle_button"
    hover_background "circle_button_hover"
    selected_background "circle_button_hover"

style st_mm_button_cs:
    background "button2"
    hover_background "button2_hover"
    focus_mask True



################################################################################
## Pantallas internas a juego
################################################################################


## Pantalla de diálogo #########################################################
##
## La pantalla de diálogo muestra el diálogo al jugador. Acepta dos parámetros,
## 'who' y 'what', es decir, el nombre del personaje que habla y el texto que ha
## de ser mostrado respectivamente. (El parámetro 'who' puede ser 'None' si no
## se da ningún nombre.)
##
## Esta pantalla debe crear un texto visualizable con id "what" que Ren'Py usa
## para gestionar la visualización del texto. Puede crear también visualizables
## con id "who" y id "window" para aplicar propiedades de estilo.
##
## https://www.renpy.org/doc/html/screen_special.html#say

screen say(who, what):
    zorder 101
    style_prefix "say"

    window:
        id "window"
        xpos gui.textbox_xalign
        ypos gui.textbox_yalign  # Añadir ypos aquí
        xsize gui.dialogue_width  # Añadir xsize si es necesario
        ysize gui.textbox_height  # Añadir ysize si es necesario
        background Frame("gui/say/saybox_[saybox_visible].png", xalign=0.5, yalign=1.0, ysize=427, xsize=1920)

        if who is not None:
            window:
                xpos gui.name_xpos
                ypos gui.name_ypos
                id "namebox"
                style "namebox"
                text who id "who"

        #vbox xpos gui.dialogue_xpos ypos gui.dialogue_ypos:
        text what id "what" xpos gui.dialogue_xpos ypos gui.dialogue_ypos

    if saybox_visible=="visible":
        vbox xalign 0.995 ypos 0.8 spacing 10:
            button style "circle_button" action HideInterface() xysize 55,55:
                text "X" style "overlay_style" size 35 align .5,.5
            button style "circle_button" action ShowMenu("save") xysize 55,55:
                add "gui/say/save_icon.png" align .5,.5
            button style "circle_button" action ShowMenu("load") xysize 55,55:
                add "gui/say/load_icon.png" align .5,.5
        vbox xalign 0.005 ypos 0.8 spacing 10:
            button style "circle_button" action Rollback() xysize 60,60:
                add "gui/say/back.png" align .5,.5
            button style "circle_button" action ShowMenu('history') xysize 60,60:
                add "gui/say/history.png" align .5,.5
            button style "circle_button" action Skip() alternate Skip(fast=True, confirm=True) xysize 60,60:
                add "gui/say/skip.png" align .5,.5
    elif saybox_visible=="invisible":
        vbox xalign 0.995 ypos 0.88 spacing 10:
            button style "circle_button" action HideInterface() xysize 50,50:
                text "X" style "overlay_style" size 35 align .5,.5
            button style "circle_button" action ShowMenu("save") xysize 50,50:
                add "gui/say/save_icon.png" align .5,.5
        vbox xalign 0.005 ypos 0.88 spacing 10:
            button style "circle_button" action Rollback() xysize 50,50:
                add "gui/say/back.png" align .5,.5
            button style "circle_button" action ShowMenu('history') xysize 50,50:
                add "gui/say/history.png" align .5,.5



## Permite que el 'namebox' pueda ser estilizado en el objeto 'Character'.
init python:
    config.character_id_prefixes.append('namebox')
    saybox_visible="visible"


style window:
    xalign gui.textbox_xalign
    xfill True
    yalign gui.textbox_yalign
    ysize gui.textbox_height
    background Frame("gui/say/saybox_[saybox_visible].png", xalign=0.5, yalign=1.0, ysize=427, xsize=1920)

style window is default
style say_label is default
style say_dialogue is default
style say_thought is say_dialogue

style namebox is default
style namebox_label is say_label


style namebox:
    xpos gui.name_xpos
    xanchor gui.name_xalign
    xsize gui.namebox_width
    ypos gui.name_ypos
    ysize gui.namebox_height

    background Frame("gui/namebox.png", gui.namebox_borders, tile=gui.namebox_tile, xalign=gui.name_xalign)
    padding gui.namebox_borders.padding

style say_label:
    properties gui.text_properties("name", accent=True)
    outlines [(4,"#131313")]
    xalign gui.name_xalign
    yalign 1.0

style say_dialogue:
    properties gui.text_properties("dialogue")
    outlines [(3,"#131313")]
    xpos gui.dialogue_xpos
    ypos gui.dialogue_ypos
    xsize gui.dialogue_width


## Pantalla de introducción de texto ###########################################
##
## Pantalla usada para visualizar 'renpy.input'. El parámetro 'prompt' se usa
## para pasar el texto presentado.
##
## Esta pantalla debe crear un displayable 'input' con id "input" para aceptar
## diversos parámetros de entrada.
##
## https://www.renpy.org/doc/html/screen_special.html#input

screen input(prompt):
    style_prefix "input"

    window:

        vbox:
            xalign gui.dialogue_text_xalign
            xpos gui.dialogue_xpos
            xsize gui.dialogue_width
            ypos gui.dialogue_ypos

            text prompt style "input_prompt"
            input id "input"

style input_prompt is default

style input_prompt:
    xalign gui.dialogue_text_xalign
    properties gui.text_properties("input_prompt")

style input:
    xalign gui.dialogue_text_xalign
    xmaximum gui.dialogue_width


## Pantalla de menú ############################################################
##
## Esta pantallla presenta las opciones internas al juego de la sentencia
## 'menu'. El parámetro único, 'items', es una lista de objetos, cada uno los
## campos 'caption' y 'action'.
##
## https://www.renpy.org/doc/html/screen_special.html#choice
init python:
    style.menu_choice_talk_button.set_parent(style.menu_choice_button)
    style.menu_choice_talk_button.background = "#f00"

screen choice(items):
    zorder 100
    if talk_menu==True:
        frame align .03,.5 ymaximum 1000 padding (40,40,40,40):
            has vbox
            spacing 15
            hbox xalign .5 spacing 5:
                if not talk_logo=="":
                    add "talk_logo" xysize 50,50 yalign .4
                text "[talk_name]" font "Athiti-Bold.ttf" size 60
            if talk_humor=="Happy":
                text _("Humor: {color=#87e887}Feliz{/a}") font "Athiti-Bold.ttf" size 35 xalign .5
            elif talk_humor=="Normal":
                text _("Humor: Normal") font "Athiti-Bold.ttf" size 35 xalign .5
            elif talk_humor=="Bad":
                text _("Humor: {color=#ebd967}Irritada{/a}") font "Athiti-Bold.ttf" size 35 xalign .5
            elif talk_humor=="Angry":
                text _("Humor: {color=#eb6363}Molesta{/a}") font "Athiti-Bold.ttf" size 35 xalign .5
            elif talk_humor=="Hot":
                text _("Humor: {color=#fc608f}Caliente{/a}") font "Athiti-Bold.ttf" size 35 xalign .5
            add "gui/mainmenu/tint_line.png" xalign .5 xsize 600
            vbox  spacing 15:
                for i in items:
                    $ badge = i.kwargs.get("badge", None)
                    button style "st_mm_button_cs" xysize 680,80 focus_mask True padding(30,0,0,0) action i.action:
                        text i.caption style 'overlay_style' size 30
                        if badge:
                            foreground Transform("badge_" + badge, xpos=05, yalign=.5, xsize=70, ysize=70)
    else:
        add "gui/mainmenu/choice_fade.png"
        vbox align .5,.5 spacing 15:
            for i in items:
                $ badge = i.kwargs.get("badge", None)
                button style "frame" xysize 680,85 focus_mask True action i.action:
                    text i.caption style 'overlay_style'
                    if badge:
                        foreground Transform("badge_" + badge, xpos=20, yalign=.5, xsize=80, ysize=80)


## Cuando es 'True', el encabezamiento será dicho por el narrador. Si es
## 'False', será presentado como un botón inactivo.
define config.narrator_menu = True

style choice_vbox is vbox
style choice_button:
    background "choice_button_idle"
    hover_background "choice_button_hover"
    selected_background "choice_button_selected"
    focus_mask True
style choice_button_text is button_text

style choice_vbox:
    xalign 0.5
    ypos 405
    yanchor 0.5

    spacing gui.choice_spacing



################################################################################
## Principal y Pantalla de menu del juego.
################################################################################

## Pantalla de navegación ######################################################
##
## Esta pantalla está incluída en el menú principal y los menús del juego y
## ofrece navegación a los otros menús y al inicio del juego.

screen navigation():

    vbox:
        style_prefix "navigation"

        xpos gui.navigation_xpos
        yalign 0.5

        spacing gui.navigation_spacing


        textbutton _("Historial") action ShowMenu("history")

        textbutton _("Guardar") action ShowMenu("save")

        textbutton _("Cargar") action ShowMenu("load")

        textbutton _("Opciones") action ShowMenu("preferences")

        if _in_replay:

            textbutton _("Finaliza repetición") action EndReplay(confirm=True)

        elif not main_menu:

            textbutton _("Menú principal") action MainMenu()

        textbutton _("Acerca de") action ShowMenu("about")

        if renpy.variant("pc") or (renpy.variant("web") and not renpy.variant("mobile")):

            ## La ayuda no es necesaria ni relevante en dispositivos móviles.
            textbutton _("Ayuda") action ShowMenu("help")

        if renpy.variant("pc"):

            ## El botón de salida está prohibido en iOS y no es necesario en
            ## Android y Web.
            textbutton _("Salir") action Quit(confirm=not main_menu)


style navigation_button is gui_button
style navigation_button_text is gui_button_text

style navigation_button:
    size_group "navigation"
    properties gui.button_properties("navigation_button")

style navigation_button_text:
    properties gui.button_text_properties("navigation_button")


## Pantalla del menú del juego #################################################
##
## Esto distribuye la estructura de base del menú del juego. Es llamado con el
## título de la pantalla y presenta el fondo, el título y la navegación.
##
## El parámetro 'scroll' puede ser 'None', "viewport" o "vpgrid". Cuando se usa
## esta pantalla con uno o más elementos, que son transcluídos (situados) en su
## interior.

screen game_menu(title, scroll=None, yinitial=1.0):
    tag menu
    modal True
    add "gui/mainmenu/bg3.png"
    use menu_nav
    add "nubes"
    add "leaf_frame"
    text (_("Historial")):
        font "Athiti-Bold.ttf"
        xalign 0.2  yalign 0.045 size 100
    frame xalign 0.65 ypos 180 ymaximum 800 xmaximum 1200 padding (70,50,70,50):
        viewport id "vpgrid":
            yinitial 1.0
            draggable True
            mousewheel True
            yfill True
            vbox spacing 10:

                for h in _history_list:

                    $ what = renpy.filter_text_tags(h.what, allow=gui.history_allow_tags)
                    text what:
                        substitute False style "overlay_style"

                    if h.who:
                        text "- " + h.who xalign .8 text_align 1.0 style "overlay_style"
                    add "gui/mainmenu/separator.png" xalign .5
                if not _history_list:
                    label _("The dialogue history is empty.")

    if main_menu:
        key "game_menu" action ShowMenu("main_menu")


style game_menu_outer_frame is empty
style game_menu_navigation_frame is empty
style game_menu_content_frame is empty
style game_menu_viewport is gui_viewport
style game_menu_side is gui_side
style game_menu_scrollbar is gui_vscrollbar

style game_menu_label is gui_label
style game_menu_label_text is gui_label_text

style return_button is navigation_button
style return_button_text is navigation_button_text

style game_menu_outer_frame:
    bottom_padding 45
    top_padding 180

    background "gui/overlay/game_menu.png"

style game_menu_navigation_frame:
    xsize 420
    yfill True

style game_menu_content_frame:
    left_margin 60
    right_margin 30
    top_margin 15

style game_menu_viewport:
    xsize 1380

style game_menu_vscrollbar:
    unscrollable gui.unscrollable

style game_menu_side:
    spacing 15

style game_menu_label:
    xpos 75
    ysize 180

style game_menu_label_text:
    size gui.title_text_size
    color gui.accent_color
    yalign 0.5

style return_button:
    xpos gui.navigation_xpos
    yalign 1.0
    yoffset -45



## Pantallas de carga y grabación ##############################################
##
## Estas pantallas permiten al jugador grabar el juego y cargarlo de nuevo. Como
## comparten casi todos los elementos, ambas están implementadas en una tercera
## pantalla: 'file_slots'.
##
## https://www.renpy.org/doc/html/screen_special.html#save https://
## www.renpy.org/doc/html/screen_special.html#load

screen menu_nav():
    button:
        background "gui/transparent_bg.png" action Return()
    vbox ypos 320 xpos 0 spacing 20:
        if not main_menu:
            button style 'button_gold' xysize 350,80 action Return():
                text _("Reanudar") size 45 xalign 0.5 yalign 0.5 style "overlay_style"
        if not main_menu:
            button style 'button_gold' xysize 350,80 action ShowMenu("save"):
                text _("Guardar") size 45 xalign 0.5 yalign 0.5 style "overlay_style"
        button style 'button_gold' xysize 350,80 action ShowMenu("load"):
            text _("Cargar") size 45 xalign 0.5 yalign 0.5 style "overlay_style"
        button style 'button_gold' xysize 350,80 action ShowMenu("preferences"):
            text _("Opciones") size 45 xalign 0.5 yalign 0.5 style "overlay_style"
        button style 'button_gold' xysize 350,80 action ShowMenu("gallery"):
            text _("Galería") size 45 xalign 0.5 yalign 0.5 style "overlay_style"
        button style 'button_gold' xysize 350,80 action ShowMenu("achievement_menu"):
            text _("Logros") size 45 xalign 0.5 yalign 0.5 style "overlay_style"
        if main_menu:
            button style 'button_gold' xysize 350,80 action ShowMenu("about"):
                text _("Créditos") size 45 xalign 0.5 yalign 0.5 style "overlay_style"
    if not main_menu:
        button style 'button_gold' action MainMenu() xysize 450,80 yalign 0.98:
            text _("Menú Principal") size 45 xalign 0.5 yalign 0.5 style "overlay_style"
    else:
        button style 'button_gold' xysize 350,80 action Return() yalign 0.98:
            text "Exit" size 45 xalign 0.5 yalign 0.5 style "overlay_style"

screen save():
    tag menu
    modal True
    add "konoha_gate_day"
    add "gui/mainmenu/bg3.png"
    use menu_nav
    add "nubes"
    #add "gui/overlay/game_menu.png":
        #xalign 0.65 yalign 0.63
    add "leaf_frame"
    text (_("Guardar")):
        font "Athiti-Bold.ttf"
        xalign 0.2  yalign 0.045 size 100
    use file_slots(_("Guardar"))


screen load():
    tag menu
    modal True
    add "konoha_gate_day"
    add "gui/mainmenu/bg3.png"
    use menu_nav
    add "nubes"
    #add "gui/overlay/game_menu.png":
        #xalign 0.65 yalign 0.63
    add "leaf_frame"
    text (_("Cargar")):
        font "Athiti-Bold.ttf"
        xalign 0.2  yalign 0.045 size 100
    use file_slots(_("Cargar"))


screen file_slots(title):
    key 'game_menu' action Return()
    fixed:
        ## Esto asegura que 'input' recibe el evento 'enter' antes que otros
        ## botones.
        order_reverse True
        ## El nombre de la pagina, se puede editar haciendo clic en el
        ## botón.
        button:
            style "page_label"
            key_events True
            xalign 0.55
            yalign 0.82
            action page_name_value.Toggle()

            input:
                color "#505050"
                value page_name_value

        ## La cuadrícula de huecos de guardado.
        frame padding (30,30,30,120) xalign .83 yalign 0.58:
            grid gui.file_slot_cols gui.file_slot_rows:
                style_prefix "slot"
                spacing gui.slot_spacing
                for i in range(gui.file_slot_cols * gui.file_slot_rows):
                    $ slot = i + 1
                    frame style "button_black" padding(5,5,5,5):
                        has hbox
                        button:
                            action FileAction(slot)
                            has vbox

                            add FileScreenshot(slot) xalign 0.5 zpos -.8

                            text FileTime(slot, format=_("{#file_time}%A, %d de %B %Y, %H:%M"), empty=_("vacío")):
                                style "slot_time_text"

                            #text FileSaveName(slot):
                                #style "slot_name_text"

                        # Botón con una X para eliminar la partida guardada
                        textbutton "X" action FileDelete(slot) style "slot_delete_button"

        ## Botones de acceso a otras páginas
    hbox:
        style_prefix "overlay_style"

        xalign 0.55
        yalign 0.86

        spacing gui.page_spacing

        textbutton _("<") action FilePagePrevious()

        if config.has_autosave:
            textbutton _("{#auto_page}A") action FilePage("auto")

        if config.has_quicksave:
            textbutton _("{#quick_page}R") action FilePage("quick")

        ## range(1, 10) da los numeros del 1 al 9.
        for page in range(1, 10):
            textbutton "[page]" action FilePage(page)

        textbutton _(">") action FilePageNext()

style slot_delete_button:
    #size (30, 30)
    background None
    #foreground "#ff0000"
    size 35
style page_label is gui_label
style page_label_text is gui_label_text
style page_button is gui_button
style page_button_text is gui_button_text

style slot_button is gui_button
style slot_button_text is gui_button_text
style slot_time_text is slot_button_text
style slot_name_text is slot_button_text

style page_label:
    xpadding 75
    ypadding 5

style page_label_text:
    text_align 0.5
    layout "subtitle"
    hover_color gui.hover_color

style page_button:
    properties gui.button_properties("page_button")

style page_button_text:
    properties gui.button_text_properties("page_button")

style slot_button:
    properties gui.button_properties("slot_button")

style slot_button_text:
    properties gui.button_text_properties("slot_button")


## Pantalla de preferencias ####################################################
##
## La pantalla de preferencias permite al jugador configurar el juego a su
## gusto.
##
## https://www.renpy.org/doc/html/screen_special.html#preferences

screen preferences():
    tag menu
    modal True
    add "konoha_gate_day"
    add "gui/mainmenu/bg3.png"
    use menu_nav
    add "nubes"
    add "leaf_frame"
    text (_("Opciones")):
        font "Athiti-Bold.ttf"
        xalign 0.2  yalign 0.045 size 100
    add "gui/overlay/game_menu.png":
        xalign 0.65 yalign 0.63
    hbox xalign 0.6 yalign 0.3 spacing 20:
        vbox spacing 5:
            text (_("Pantalla")):
                style "menu_text"
            add "gui/mainmenu/tint_line.png"
            button style "button_gold" action Preference("display", "window") xsize 350 ysize 60:
                text _("Ventana") xalign 0.5 yalign 0.4 style "overlay_style"
            button style "button_gold" action Preference("display", "fullscreen") xsize 350 ysize 60:
                text _("Pant. completa") xalign 0.5 yalign 0.4 style "overlay_style"

        vbox :
            text (_("Saltar")):
                style "menu_text"
            add "gui/mainmenu/tint_line.png"
            button style "button_gold" action Preference("skip", "toggle") xsize 350 ysize 60:
                text _("Texto no visto") xalign 0.5 yalign 0.4 style "overlay_style"
            button style "button_gold" action Preference("after choices", "toggle") xsize 350 ysize 60:
                text _("Tras opciones") xalign 0.5 yalign 0.4 style "overlay_style"
            button style "button_gold" action InvertSelected(Preference("transitions", "toggle")) xsize 350 ysize 60:
                text _("Transiciones") xalign 0.5 yalign 0.4 style "overlay_style"

        vbox :
            text (_("Idioma")):
                style "menu_text"
            add "gui/mainmenu/tint_line.png"
            button style "button_gold" action Language("english") xsize 350 ysize 60:
                text _("English") xalign 0.5 yalign 0.4 style "overlay_style"
            button style "button_gold" action Language(None) xsize 350 ysize 60:
                text _("Español") xalign 0.5 yalign 0.4 style "overlay_style"

        ## Aquí se pueden añadir 'vboxes' adicionales del tipo
        ## "radio_pref" o "check_pref" para nuevas preferencias.
    hbox xalign 0.75 yalign 0.7:
        hbox:
            style_prefix "slider"
            box_wrap True
            vbox:
                text (_("Texto")):
                    style "menu_text"
                add "gui/mainmenu/tint_line.png"
                text _("Veloc. texto") style "overlay_style" xalign 0.0
                bar value Preference("text speed")
                text _("Veloc. auto-avance") style "overlay_style" xalign 0.0
                bar value Preference("auto-forward time")

            vbox:
                text (_("Volumen")):
                    style "menu_text"
                add "gui/mainmenu/tint_line.png"
                if config.has_music:
                    text _("Volumen música") style "overlay_style" xalign 0.0
                    bar value Preference("music volume")

                if config.has_sound:
                    text _("Volumen sonido") style "overlay_style" xalign 0.0
                    bar value Preference("sound volume")
                    if config.sample_sound:
                        textbutton _("Prueba") action Play("sound", config.sample_sound)

style button_gold:
    background "button"
    hover_background "button_hover"
    selected_background "button_selected"
    focus_mask True
style button_gold2:
    background "button2"
    hover_background "button2_hover"
    selected_background "button2_selected"
    focus_mask True
style button3:
    background "button3"
    hover_background "button3_hover"
    selected_background "button3_selected"
    focus_mask True


style menu_text:
    font "Athiti-Bold.ttf"
    color "#fff"
    size 50
style pref_label is gui_label
style pref_label_text is gui_label_text
style pref_vbox is vbox

style radio_label is pref_label
style radio_label_text is pref_label_text
style radio_button is gui_button
style radio_button_text is gui_button_text
style radio_vbox is pref_vbox

style check_label is pref_label
style check_label_text is pref_label_text
style check_button is gui_button
style check_button_text is gui_button_text
style check_vbox is pref_vbox

style slider_label is pref_label
style slider_label_text is pref_label_text
style slider_slider is gui_slider
style slider_button is gui_button
style slider_button_text is gui_button_text
style slider_pref_vbox is pref_vbox

style mute_all_button is check_button
style mute_all_button_text is check_button_text

style pref_label:
    top_margin gui.pref_spacing
    bottom_margin 3

style pref_label_text:
    yalign 1.0

style pref_vbox:
    xsize 338

style radio_vbox:
    spacing gui.pref_button_spacing

style radio_button:
    properties gui.button_properties("radio_button")
    foreground "gui/button/radio_[prefix_]foreground.png"

style radio_button_text:
    properties gui.button_text_properties("radio_button")

style check_vbox:
    spacing gui.pref_button_spacing

style check_button:
    properties gui.button_properties("check_button")
    foreground "gui/button/check_[prefix_]foreground.png"

style check_button_text:
    properties gui.button_text_properties("check_button")

style slider_slider:
    xsize 525

style slider_button:
    properties gui.button_properties("slider_button")
    yalign 0.5
    left_margin 15

style slider_button_text:
    properties gui.button_text_properties("slider_button")

style slider_vbox:
    xsize 675


## Pantalla de historial #######################################################
##
## Esta pantalla presenta el historial de diálogo al jugador, almacenado en
## '_history_list'.
##
## https://www.renpy.org/doc/html/history.html

screen history():

    tag menu

    ## Evita la predicción de esta pantalla, que podría ser demasiado grande.
    predict False

    use game_menu(_("Historial"), scroll=("vpgrid" if gui.history_height else "viewport"), yinitial=1.0):

        style_prefix "history"

        for h in _history_list:

            window:

                ## Esto distribuye los elementos apropiadamente si
                ## 'history_height' es 'None'.
                has fixed:
                    yfit True

                if h.who:

                    label h.who:
                        style "history_name"
                        substitute False

                        ## Toma el color del texto 'who' de 'Character', si ha
                        ## sido establecido.
                        if "color" in h.who_args:
                            text_color h.who_args["color"]

                $ what = renpy.filter_text_tags(h.what, allow=gui.history_allow_tags)
                text what:
                    substitute False

        if not _history_list:
            label _("El historial está vacío.")


## Esto determina qué etiquetas se permiten en la pantalla de historial.

define gui.history_allow_tags = { "alt", "noalt" }


style history_window is empty

style history_name is gui_label
style history_name_text is gui_label_text
style history_text is gui_text

style history_text is gui_text

style history_label is gui_label
style history_label_text is gui_label_text

style history_window:
    xfill True
    ysize gui.history_height

style history_name:
    xpos gui.history_name_xpos
    xanchor gui.history_name_xalign
    ypos gui.history_name_ypos
    xsize gui.history_name_width

style history_name_text:
    min_width gui.history_name_width
    text_align gui.history_name_xalign

style history_text:
    xpos gui.history_text_xpos
    ypos gui.history_text_ypos
    xanchor gui.history_text_xalign
    xsize gui.history_text_width
    min_width gui.history_text_width
    text_align gui.history_text_xalign
    layout ("subtitle" if gui.history_text_xalign else "tex")

style history_label:
    xfill True

style history_label_text:
    xalign 0.5


## Pantalla de ayuda ###########################################################
##
## Una pantalla que da información sobre el uso del teclado y el ratón. Usa
## otras pantallas con el contenido de la ayuda ('keyboard_help', 'mouse_help',
## y 'gamepad_help').

screen help():

    tag menu

    default device = "keyboard"

    use game_menu(_("Ayuda"), scroll="viewport"):

        style_prefix "help"

        vbox:
            spacing 23

            hbox:

                textbutton _("Teclado") action SetScreenVariable("device", "keyboard")
                textbutton _("Ratón") action SetScreenVariable("device", "mouse")

                if GamepadExists():
                    textbutton _("Mando") action SetScreenVariable("device", "gamepad")

            if device == "keyboard":
                use keyboard_help
            elif device == "mouse":
                use mouse_help
            elif device == "gamepad":
                use gamepad_help


screen keyboard_help():

    hbox:
        label _("Enter")
        text _("Avanza el diálogo y activa la interfaz.")

    hbox:
        label _("Espacio")
        text _("Avanza el diálogo sin seleccionar opciones.")

    hbox:
        label _("Teclas de flecha")
        text _("Navega la interfaz.")

    hbox:
        label _("Escape")
        text _("Accede al menú del juego.")

    hbox:
        label _("Ctrl")
        text _("Salta el diálogo mientras se presiona.")

    hbox:
        label _("Tabulador")
        text _("Activa/desactiva el salto de diálogo.")

    hbox:
        label _("Av. pág.")
        text _("Retrocede al diálogo anterior.")

    hbox:
        label _("Re. pág.")
        text _("Avanza hacia el diálogo siguiente.")

    hbox:
        label "H"
        text _("Oculta la interfaz.")

    hbox:
        label "S"
        text _("Captura la pantalla.")

    hbox:
        label "V"
        text _("Activa/desactiva la asistencia por {a=https://www.renpy.org/l/voicing}voz-automática{/a}.")

    hbox:
        label "Shift+A"
        text _("Abre el menú de accesibilidad.")


screen mouse_help():

    hbox:
        label _("Clic izquierdo")
        text _("Avanza el diálogo y activa la interfaz.")

    hbox:
        label _("Clic medio")
        text _("Oculta la interfaz.")

    hbox:
        label _("Clic derecho")
        text _("Accede al menú del juego.")

    hbox:
        label _("Rueda del ratón arriba\nClic en lado de retroceso")
        text _("Retrocede al diálogo anterior.")

    hbox:
        label _("Rueda del ratón abajo")
        text _("Avanza hacia el diálogo siguiente.")


screen gamepad_help():

    hbox:
        label _("Gatillo derecho\nA/Botón inferior")
        text _("Avanza el diálogo y activa la interfaz.")

    hbox:
        label _("Gatillo izquierdo\nBotón sup. frontal izq.")
        text _("Retrocede al diálogo anterior.")

    hbox:
        label _("Botón sup. frontal der.")
        text _("Avanza hacia el diálogo siguiente.")


    hbox:
        label _("D-Pad, Sticks")
        text _("Navega la interfaz.")

    hbox:
        label _("Comenzar, Guía")
        text _("Accede al menú del juego.")

    hbox:
        label _("Y/Botón superior")
        text _("Oculta la interfaz.")

    textbutton _("Calibrar") action GamepadCalibrate()


style help_button is gui_button
style help_button_text is gui_button_text
style help_label is gui_label
style help_label_text is gui_label_text
style help_text is gui_text

style help_button:
    properties gui.button_properties("help_button")
    xmargin 12

style help_button_text:
    properties gui.button_text_properties("help_button")

style help_label:
    xsize 375
    right_padding 30

style help_label_text:
    size gui.text_size
    xalign 1.0
    text_align 1.0



################################################################################
## Pantallas adicionales
################################################################################


## Pantalla de confirmación ####################################################
##
## Ren'Py llama la pantalla de confirmación para presentar al jugador preguntas
## de sí o no.
##
## https://www.renpy.org/doc/html/screen_special.html#confirm

screen confirm(message, yes_action, no_action):

    ## Asegura que otras pantallas no reciban entrada mientras se muestra esta
    ## pantalla.
    modal True

    zorder 600

    style_prefix "confirm"

    add "gui/overlay/confirm.png"

    frame:

        vbox:
            xalign .5
            yalign .5
            spacing 45

            label _(message):
                text_style "overlay_style"
                style "overlay_style"
                xalign 0.5

            hbox:
                xalign 0.5
                spacing 150

                textbutton _("Sí") action yes_action
                textbutton _("No") action no_action

    ## Clic derecho o escape responden "no".
    key "game_menu" action no_action


style confirm_frame is gui_frame
style confirm_prompt is gui_prompt
style confirm_prompt_text is gui_prompt_text
style confirm_button is gui_medium_button
style confirm_button_text is gui_medium_button_text

style confirm_frame:
    background Frame([ "gui/confirm_frame.png", "gui/frame.png"], gui.confirm_frame_borders, tile=gui.frame_tile)
    padding gui.confirm_frame_borders.padding
    xalign .5
    yalign .5

style confirm_prompt_text:
    text_align 0.5
    outlines [(2,"#131313")]
    layout "subtitle"


style confirm_button:
    outlines [(2,"#131313")]
    properties gui.button_properties("confirm_button")

style confirm_button_text:
    outlines [(2,"#131313")]
    properties gui.button_text_properties("confirm_button")


## Pantalla del indicador de salto #############################################
##
## La pantalla de indicador de salto se muestra para indicar que se está
## realizando el salto.
##
## https://www.renpy.org/doc/html/screen_special.html#skip-indicator

screen skip_indicator():

    zorder 100
    style_prefix "skip"

    frame:

        hbox:
            spacing 9

            text _("Saltando")

            text "▸" at delayed_blink(0.0, 1.0) style "skip_triangle"
            text "▸" at delayed_blink(0.2, 1.0) style "skip_triangle"
            text "▸" at delayed_blink(0.4, 1.0) style "skip_triangle"


## Esta transformación provoca el parpadeo de las flechas una tras otra.
transform delayed_blink(delay, cycle):
    alpha .5

    pause delay

    block:
        ease .2 alpha 1.0
        pause .2
        ease .2 alpha 0.5
        pause (cycle - .4)
        repeat


style skip_frame is empty
style skip_text is gui_text
style skip_triangle is skip_text

style skip_frame:
    ypos gui.skip_ypos
    background Frame("gui/skip.png", gui.skip_frame_borders, tile=gui.frame_tile)
    padding gui.skip_frame_borders.padding

style skip_text:
    size gui.notify_text_size

style skip_triangle:
    ## Es necesario usar un tipo de letra que contenga el glifo BLACK RIGHT-
    ## POINTING SMALL TRIANGLE.
    font "Athiti-Bold.ttf"


## Pantalla de notificación ####################################################
##
## La pantalla de notificación muestra al jugador un mensaje. (Por ejemplo, con
## un guardado rápido o una captura de pantalla.)
##
## https://www.renpy.org/doc/html/screen_special.html#notify-screen

screen notify(message):

    zorder 100
    style_prefix "notify"

    frame at notify_appear:
        text "[message!tq]"

    timer 3.25 action Hide('notify')


transform notify_appear:
    on show:
        alpha 0
        ease .25 alpha 1.0
    on hide:
        ease .5 alpha 0.0


style notify_frame is empty
style notify_text is gui_text

style notify_frame:
    ypos gui.notify_ypos

    background Frame("gui/notify.png", gui.notify_frame_borders, tile=gui.frame_tile)
    padding gui.notify_frame_borders.padding

style notify_text:
    properties gui.text_properties("notify")


## Pantalla NVL ################################################################
##
## Esta pantalla se usa para el diálogo y los menús en modo NVL.
##
## https://www.renpy.org/doc/html/screen_special.html#nvl


screen nvl(dialogue, items=None):

    window:
        style "nvl_window"

        has vbox:
            spacing gui.nvl_spacing

        ## Presenta el diálogo en una 'vpgrid' o una 'vbox'.
        if gui.nvl_height:

            vpgrid:
                cols 1
                yinitial 1.0

                use nvl_dialogue(dialogue)

        else:

            use nvl_dialogue(dialogue)

        ## Presenta el menú, si lo hay. El menú puede ser presentado
        ## incorrectamente si 'config.narrator_menu' está ajustado a 'True',
        ## como lo es más arriba.
        for i in items:

            textbutton i.caption:
                action i.action
                style "nvl_button"

    add SideImage() xalign 0.0 yalign 1.0


screen nvl_dialogue(dialogue):

    for d in dialogue:

        window:
            id d.window_id

            fixed:
                yfit gui.nvl_height is None

                if d.who is not None:

                    text d.who:
                        id d.who_id

                text d.what:
                    id d.what_id


## Esto controla el número máximo de entradas en modo NVL que pueden ser
## mostradas de una vez.
define config.nvl_list_length = gui.nvl_list_length

style nvl_window is default
style nvl_entry is default

style nvl_label is say_label
style nvl_dialogue is say_dialogue

style nvl_button is button
style nvl_button_text is button_text

style nvl_window:
    xfill True
    yfill True

    background "gui/nvl.png"
    padding gui.nvl_borders.padding

style nvl_entry:
    xfill True
    ysize gui.nvl_height

style nvl_label:
    xpos gui.nvl_name_xpos
    xanchor gui.nvl_name_xalign
    ypos gui.nvl_name_ypos
    yanchor 0.0
    xsize gui.nvl_name_width
    min_width gui.nvl_name_width
    text_align gui.nvl_name_xalign

style nvl_dialogue:
    xpos gui.nvl_text_xpos
    xanchor gui.nvl_text_xalign
    ypos gui.nvl_text_ypos
    xsize gui.nvl_text_width
    min_width gui.nvl_text_width
    text_align gui.nvl_text_xalign
    layout ("subtitle" if gui.nvl_text_xalign else "tex")

style nvl_thought:
    xpos gui.nvl_thought_xpos
    xanchor gui.nvl_thought_xalign
    ypos gui.nvl_thought_ypos
    xsize gui.nvl_thought_width
    min_width gui.nvl_thought_width
    text_align gui.nvl_thought_xalign
    layout ("subtitle" if gui.nvl_text_xalign else "tex")

style nvl_button:
    properties gui.button_properties("nvl_button")
    xpos gui.nvl_button_xpos
    xanchor gui.nvl_button_xalign

style nvl_button_text:
    properties gui.button_text_properties("nvl_button")



################################################################################
## Variantes móviles
################################################################################

style pref_vbox:
    variant "medium"
    xsize 675

## Ya que puede carecer de ratón, se reempleza el menú rápido con una versión
## con menos botones y más grandes, más fáciles de tocar.



style window:
    variant "small"
    background "gui/phone/textbox.png"

style radio_button:
    variant "small"
    foreground "gui/phone/button/radio_[prefix_]foreground.png"

style check_button:
    variant "small"
    foreground "gui/phone/button/check_[prefix_]foreground.png"

style nvl_window:
    variant "small"
    background "gui/phone/nvl.png"

style main_menu_frame:
    variant "small"
    background "gui/phone/overlay/main_menu.png"

style game_menu_outer_frame:
    variant "small"
    background "gui/phone/overlay/game_menu.png"

style game_menu_navigation_frame:
    variant "small"
    xsize 510

style game_menu_content_frame:
    variant "small"
    top_margin 0

style pref_vbox:
    variant "small"
    xsize 600

style bar:
    variant "small"
    ysize gui.bar_size
    left_bar Frame("gui/bar/left.png", gui.bar_borders, tile=gui.bar_tile)
    right_bar Frame("gui/bar/right.png", gui.bar_borders, tile=gui.bar_tile)

style vbar:
    variant "small"
    xsize gui.bar_size
    top_bar Frame("gui/phone/bar/top.png", gui.vbar_borders, tile=gui.bar_tile)
    bottom_bar Frame("gui/phone/bar/bottom.png", gui.vbar_borders, tile=gui.bar_tile)

style scrollbar:
    variant "small"
    ysize gui.scrollbar_size
    base_bar Frame("gui/phone/scrollbar/horizontal_[prefix_]bar.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/phone/scrollbar/horizontal_[prefix_]thumb.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)

style vscrollbar:
    variant "small"
    xsize gui.scrollbar_size
    base_bar Frame("gui/phone/scrollbar/vertical_[prefix_]bar.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/phone/scrollbar/vertical_[prefix_]thumb.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)

style slider:
    variant "small"
    ysize gui.slider_size
    left_bar Frame("gui/bar/left.png", gui.bar_borders, tile=gui.bar_tile)
    right_bar Frame("gui/bar/right.png", gui.bar_borders, tile=gui.bar_tile)

style vslider:
    variant "small"
    xsize gui.slider_size
    base_bar Frame("gui/phone/slider/vertical_[prefix_]bar.png", gui.vslider_borders, tile=gui.slider_tile)
    thumb "gui/phone/slider/vertical_[prefix_]thumb.png"

style slider_vbox:
    variant "small"
    xsize 675

style slider_slider:
    variant "small"
    xsize 525
