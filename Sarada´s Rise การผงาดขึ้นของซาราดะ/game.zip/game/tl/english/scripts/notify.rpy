

translate english strings:

    # game/scripts/notify.rpy:11
    old "Nueva Misión Principal"
    new "เควสต์หลักใหม่"

    # game/scripts/notify.rpy:23
    old "Nueva Misión con Ayame"
    new "เควสต์ใหม่กับอายาเมะ"

    # game/scripts/notify.rpy:35
    old "Nueva Misión con Ino"
    new "เควสต์ใหม่กับอิโนะ"

    # game/scripts/notify.rpy:59
    old "Residencia del Hokage Desbloqueada"
    new "ปลดล็อกบ้านพักโฮคาเงะแล้ว"

    # game/scripts/notify.rpy:71
    old "Academia Ninja Desbloqueada"
    new "ปลดล็อกสถาบันนินจาแล้ว"

    # game/scripts/notify.rpy:83
    old "Tienda de Ropa Desbloqueada"
    new "ปลดล็อกร้านขายเสื้อผ้าแล้ว"

    # game/scripts/notify.rpy:95
    old "Nuevo Jutsu Desbloqueado"
    new "ปลดล็อกวิชานินจาใหม่แล้ว"

    # game/scripts/notify.rpy:107
    old "Nueva Misión con Sakura"
    new "เควสต์ใหม่กับซากุระ"

    # game/scripts/notify.rpy:155
    old "Hospital Desbloqueado"
    new "ปลดล็อกโรงพยาบาลแล้ว"

    # game/scripts/notify.rpy:169
    old "¡Misiónes Completas!"
    new "ทำเควสต์สำเร็จทั้งหมดแล้ว!"

    # game/scripts/notify.rpy:170
    old "¿Más en Próximas Versiones?"
    new "มีเพิ่มเติมในเวอร์ชันถัดไป?"

    # game/scripts/notify.rpy:184
    old "¡Misiónes de este Arco Completas!"
    new "ทำเควสต์ของบทนี้สำเร็จแล้ว!"

    # game/scripts/notify.rpy:196
    old "Río Desbloqueado"
    new "ปลดล็อกแม่น้ำแล้ว"

    # game/scripts/notify.rpy:207
    old "Los personajes femeninos tienen un medidor de {b}Humor{/a}, este medidor es muy importante, porque si un personaje está de mal humor, y tienes una misión con el, no podrás hacerla."
    new "ตัวละครหญิงจะมีแถบ {b}อารมณ์{/a} ซึ่งแถบนี้มีความสำคัญมาก เพราะหากตัวละครอารมณ์ไม่ดีและคุณมีเควสต์กับเธอ คุณจะไม่สามารถทำมันได้"

    # game/scripts/notify.rpy:208
    old "Puedes darles regalos, esto hará que su humor mejore el día siguiente, pero tén cuidado, algunos regalos pueden no funcionar o incluso ponerlos peor, así que investiga con sus conocidos lo que les gusta."
    new "คุณสามารถมอบของขวัญให้พวกเธอได้ ซึ่งจะทำให้อารมณ์ของพวกเธอดีขึ้นในวันถัดไป แต่ระวังให้ดี ของขวัญบางชิ้นอาจไม่ได้ผลหรือทำให้อารมณ์แย่ลงกว่าเดิมด้วยซ้ำ ดังนั้นลองสืบจากคนรู้จักของพวกเธอว่าชอบอะไร"

    # game/scripts/notify.rpy:221
    old "Aunque puedes ayudar a un personaje a desahogarse si tienes un nivel de amistad alto, o esperar a que su humor mejore."
    new "แม้ว่าคุณจะสามารถช่วยให้ตัวละครระบายความรู้สึกได้หากมีระดับความสัมพันธ์ที่สูง หรือจะรอให้อารมณ์ของพวกเธอดีขึ้นเองก็ได้เช่นกัน"

    # game/scripts/notify.rpy:234
    old "Tienda de Tenten Desbloqueada"
    new "ปลดล็อกร้านค้าของเท็นเท็นแล้ว"

    # game/scripts/notify.rpy:244
    old "¡Has dominado un nuevo Jutsu!"
    new "คุณได้เรียนรู้วิชานินจาใหม่แล้ว!"

    # game/scripts/notify.rpy:245
    old "El Jutsu {b}Karugan: Ataque Sorpresa{/a} hace que el Usuario se vueva invisible y ataque a su enemigo con un ataque sorpresa."
    new "วิชานินจา {b}คารูกัน: โจมตีประหลาดใจ{/a} ทำให้ผู้ใช้ล่องหนและเข้าโจมตีศัตรูด้วยการโจมตีแบบไม่ทันตั้งตัว"

    # game/scripts/notify.rpy:246
    old "Este jutsu es de tipo físico, y tiene la capacidad de {b}Aturdir{/a} al enemigo por {b}1{/a} turno."
    new "วิชานินจานี้เป็นประเภทกายภาพ และมีความสามารถในการ {b}ทำให้มึนงง{/a} ศัตรูเป็นเวลา {b}1{/a} เทิร์น"

    # game/scripts/notify.rpy:247
    old "Es muy efectivo contra enemigos con ataques poderosos o ataques incapacitantes."
    new "มันมีประสิทธิภาพมากในการต่อสู้กับศัตรูที่มีการโจมตีรุนแรงหรือการโจมตีที่ทำให้เป็นอัมพาต"

    # game/scripts/notify.rpy:248
    old "¡Pero ten cuidado! Este jutsu consume salud y chakra, así que úsalo con sabiduría."
    new "แต่ระวังให้ดี! วิชานินจานี้ต้องใช้พลังชีวิตและจักระ ดังนั้นจงใช้มันอย่างชาญฉลาด"

    # game/scripts/notify.rpy:258
    old "El momento ha llegado, es hora de que Yuna y Hideo se unan a tí y juntos luchen contra Zubon"
    new "เวลามาถึงแล้ว ถึงเวลาที่ยูนะและฮิเดโอะจะมาร่วมมือกับคุณเพื่อต่อสู้กับซูบงด้วยกัน"

    # game/scripts/notify.rpy:259
    old "No debes tomarte a Zubon a la ligera, es un oponente formidable, es capaz de Usar su {b}Estilo de Viento{/a} para que no te puedas mover y es inmune al {b}Aturdimiento{/a}."
    new "คุณไม่ควรประมาทซูบงเด็ดขาด เขาเป็นคู่ต่อสู้ที่น่ากลัวมาก เขาสามารถใช้ {b}คาถาธาตุลม{/a} เพื่อตรึงให้คุณเคลื่อนไหวไม่ได้ และยังมีภูมิคุ้มกันต่อสถานะ {b}มึนงง{/a} อีกด้วย"

    # game/scripts/notify.rpy:260
    old "Aprovecha la ayuda de tus compañeros Yuna y Hideo"
    new "ใช้ประโยชน์จากความช่วยเหลือของพ้องเพื่อนอย่างยูนะและฮิเดโอะให้เต็มที่"

    # game/scripts/notify.rpy:262
    old "Yuna es capaz de usar su {b}Estilo de Acero{/a} para protegerte de cualquier ataque."
    new "ยูนะสามารถใช้ {b}คาถาธาตุเหล็ก{/a} ของเธอเพื่อปกป้องคุณจากการโจมตีทุกรูปแบบ"

    # game/scripts/notify.rpy:263
    old "Y Hideo es capaz de usar ataques de {b}Estilo de Rayo{/a} para atacar a Zubon, ya que Zubon es débil a ese elemento."
    new "และฮิเดโอะก็สามารถใช้การโจมตีด้วย {b}คาถาธาตุสายฟ้า{/a} เพื่อเล่นงานซูบงได้ เนื่องจากซูบงแพ้ทางธาตุนั้น"

    # game/scripts/notify.rpy:265
    old "Sin más que decir, buena suerte."
    new "ไม่มีอะไรจะพูดมากแล้ว ขอให้โชคดี"

    # game/scripts/notify.rpy:275
    old "¿Quieres jugar la misión de {b}La Prueba de Zubon{/a}?"
    new "คุณต้องการเล่นภารกิจ {b}การทดสอบของซูบง{/a} หรือไม่?"

    # game/scripts/notify.rpy:276
    old "Es recomendabe llevar curaciones y pergaminos antes de hacer esta misión"
    new "ขอแนะนำให้เตรียมไอเทมฟื้นฟูและคัมภีร์ให้พร้อมก่อนทำภารกิจนี้"

    # game/scripts/notify.rpy:278
    old "¿Quieres jugar {b}La Prueba de Zubon{/a}?"
    new "คุณต้องการเล่น {b}การทดสอบของซูบง{/a} หรือไม่?"

    # game/scripts/notify.rpy:281
    old "Voy a prepararme primero"
    new "ฉันขอเตรียมตัวให้พร้อมก่อนดีกว่า"

    # game/scripts/notify.rpy:283
    old "Quiero jugar la misión"
    new "ฉันต้องการเล่นภารกิจนี้"

    # game/scripts/notify.rpy:293
    old "Zubon tiene un ataque que no deja mover al enemigo, intenta derrotarlo con la ayuda de tus compañeros."
    new "ซูบงมีท่าโจมตีที่ทำให้ขยับตัวไม่ได้ จงพยายามเอาชนะเขาโดยอาศัยความช่วยเหลือจากพ้องเพื่อน"

    # game/scripts/notify.rpy:294
    old "¿Quieres volver a intentar {b}La Prueba de Zubon{/a}?"
    new "คุณต้องการลองเล่น {b}การทดสอบของซูบง{/a} อีกครั้งหรือไม่?"

    # game/scripts/notify.rpy:297
    old "Voy a prepararme mejor"
    new "ฉันขอเตรียมตัวให้ดีกว่านี้ก่อน"

    # game/scripts/notify.rpy:299
    old "¡REINTENTAR!"
    new "ลองใหม่อีกครั้ง!"

    # game/scripts/notify.rpy:313
    old "Continuará en el Arco del Exámen Chunnin..."
    new "โปรดติดตามตอนต่อไปในบทสอบจู๋นิน..."

    # game/scripts/notify.rpy:320
    old "Arco 1: La Prueba de Zubon"
    new "บทที่ 1: การทดสอบของซูบง"

    # game/scripts/notify.rpy:328
    old "{color=#ebbc57}Misiones{/a}"
    new "{color=#ebbc57}ภารกิจ{/a}"

    # game/scripts/notify.rpy:330
    old "Puedes aceptar misiones con Naruto para ganar algo de dinero"
    new "คุณสามารถรับภารกิจกับนารูโตะเพื่อหาเงินได้"

    # game/scripts/notify.rpy:331
    old "Ya sean misiones de acabar con un enemigo, o de encontrar algo que está perdido"
    new "ไม่ว่าจะเป็นภารกิจกำจัดศัตรู หรือภารกิจตามหาของที่หายไป"

    # game/scripts/notify.rpy:332
    old "No dudes en aceptar misiones si quieres algo de dinero extra"
    new "อย่าลังเลที่จะรับภารกิจหากคุณต้องการเงินพิเศษ"


translate english strings:

    # game/scripts/notify.rpy:313
    old "Continuará en el Arco del Exámen Chunin..."
    new "โปรดติดตามตอนต่อไปในบทสอบจู๋นิน..."

    # game/scripts/notify.rpy:346
    old "Misiones de este Arco Completas!"
    new "ภารกิจทั้งหมดในบทนี้เสร็จสิ้นแล้ว!"

    # game/scripts/notify.rpy:354
    old "Arco 2: Los Exámenes Chunin"
    new "บทที่ 2: การสอบจู๋นิน"

    # game/scripts/notify.rpy:364
    old "¿Quieres comenzar a jugar el Segundo Arco?"
    new "คุณต้องการเริ่มเล่นบทที่สองเลยหรือไม่?"

    # game/scripts/notify.rpy:365
    old "Esto eliminará todas las misiones que tengas pendientes"
    new "การกระทำนี้จะลบภารกิจที่ค้างอยู่ทั้งหมดของคุณ"

    # game/scripts/notify.rpy:367
    old "¿Quieres jugar {b}El Segundo Arco{/a}?"
    new "คุณต้องการเล่น {b}บทที่ 2{/a} หรือไม่?"

    # game/scripts/notify.rpy:372
    old "Quiero jugar el Arco 2"
    new "ฉันต้องการเล่นบทที่ 2"

    # game/scripts/notify.rpy:384
    old "Nueva Misión con Tenten"
    new "ภารกิจใหม่กับเท็นเท็น"

    # game/scripts/notify.rpy:396
    old "Nueva Misión con Hanna"
    new "ภารกิจใหม่กับฮันนะ"

    # game/scripts/notify.rpy:406
    old "El bandido es resistente a ataques de estilo de fuego, pero su resistencia física es baja, procura atacarlo con ataques físicos."
    new "โจรป่ามีความต้านทานต่อการโจมตีด้วยคาถาธาตุไฟ แต่ความทนทานทางกายภาพต่ำ ให้พยายามโจมตีด้วยการโจมตีทางกายภาพแทน"

    # game/scripts/notify.rpy:407
    old "¿Quieres volver a intentar?"
    new "คุณต้องการลองใหม่อีกครั้งหรือไม่?"

    # game/scripts/notify.rpy:436
    old "Nueva Misión con Yuli"
    new "ภารกิจใหม่กับยูริ"

    # game/scripts/notify.rpy:473
    old "{b}Más misiones con Tenten al completar el Examen Chunin{/a}"
    new "{b}จะมีภารกิจกับเท็นเท็นเพิ่มขึ้นเมื่อทำข้อสอบจู๋นินเสร็จสิ้น{/a}"

    # game/scripts/notify.rpy:522
    old "{b}Más misiones con Sakura al completar el Exámen Chunin{/a}"
    new "{b}จะมีภารกิจกับซากุระเพิ่มขึ้นเมื่อทำข้อสอบจู๋นินเสร็จสิ้น{/a}"

    # game/scripts/notify.rpy:571
    old "Centro de Investigación Desbloqueado"
    new "ปลดล็อกศูนย์วิจัยแล้ว"

    # game/scripts/notify.rpy:585
    old "{b}Más misiones con Ino al completar el Exámen Chunin{/a}"
    new "{b}จะมีภารกิจกับอิโนะเพิ่มขึ้นเมื่อทำข้อสอบจู๋นินเสร็จสิ้น{/a}"

    # game/scripts/notify.rpy:599
    old "¡Continuación en la próxima versión!"
    new "โปรดติดตามตอนต่อไปในเวอร์ชันหน้า!"

    # game/scripts/notify.rpy:613
    old "{b}Parte 1 del Arco 2 Completa!{/a}"
    new "{b}พาร์ทที่ 1 ของบทที่ 2 เสร็จสิ้นแล้ว!{/a}"

    # game/scripts/notify.rpy:614
    old "Más misiones en la Próxima Versión!"
    new "จะมีภารกิจเพิ่มเติมในเวอร์ชันหน้า!"

    # game/scripts/notify.rpy:626
    old "Nueva Misión con Hinata"
    new "ภารกิจใหม่กับฮินาตะ"

    # game/scripts/notify.rpy:640
    old "{b}Más misiones con Hinata al completar el Exámen Chunin{/a}"
    new "{b}จะมีภารกิจกับฮินาตะเพิ่มขึ้นเมื่อทำข้อสอบจู๋นินเสร็จสิ้น{/a}"

    # game/scripts/notify.rpy:652
    old "Residencia Uzumaki Desbloqueada"
    new "ปลดล็อกบ้านพักตระกูลอุซูมากิแล้ว"

    # game/scripts/notify.rpy:664
    old "Aguas Termales y Sauna Desbloqueada"
    new "ปลดล็อกบ่อน้ำพุร้อนและห้องซาวน่าแล้ว"


translate english strings:

    # game/scripts/notify.rpy:672
    old "{color=#ebbc57}Jutsu Definitivo: Tutorial{/a}"
    new "{color=#ebbc57}สุดยอดวิชานินจา: บทแนะนำ{/a}"

    # game/scripts/notify.rpy:674
    old "Para poder utilizar un {b}Jutsu Definitivo{/a}, necesitas ganar {b}Carga Shinobi{/a}"
    new "ในการใช้ {b}สุดยอดวิชานินจา{/a} คุณจำเป็นต้องสะสม {b}เกจชิโนบิ{/a}"

    # game/scripts/notify.rpy:676
    old "La {b}Carga Shinobi{/a} son las barras rojas debajo del medidor de {b}Chakra{/a}"
    new "{b}เกจชิโนบิ{/a} คือแถบสีแดงที่อยู่ใต้หลอด {b}จักระ{/a}"

    # game/scripts/notify.rpy:677
    old "La {b}Carga Shinobi{/a} se gana utilizando {b}Jutsus Ofensivos{/a} como el {b}Jutsu Bola de Fuego{/a}"
    new "คุณจะได้รับ {b}เกจชิโนบิ{/a} จากการใช้ {b}วิชานินจาโจมตี{/a} เช่น {b}คาถาแยกเงา / คาถาไฟลูกบอลเพลิง{/a}"

    # game/scripts/notify.rpy:678
    old "Habilidades pasivas como el {b}Sharingan{/a} no dan cargas de {b}Carga Shinobi{/a}."
    new "ความสามารถติดตัวอย่าง {b}เนตรวงแหวน{/a} จะไม่ได้รับ {b}เกจชิโนบิ{/a}"
