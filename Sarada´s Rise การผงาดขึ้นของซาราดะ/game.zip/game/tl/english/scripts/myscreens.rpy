
translate english strings:

    # game/scripts/myscreens.rpy:5
    old "¿Cómo te llamas?"
    new "คุณชื่ออะไร?"

    # game/scripts/myscreens.rpy:20
    old "Ingresar"
    new "เข้าสู่ระบบ"

    # game/scripts/myscreens.rpy:34
    old "Experiment #107"
    new "การทดลองที่ #107"

    # game/scripts/myscreens.rpy:144
    old "Lo haré cuando pueda."
    new "ฉันจะทำเมื่อมีโอกาส"

    # game/scripts/myscreens.rpy:155
    old "¡GRACIAS POR JUGAR!"
    new "ขอบคุณที่เล่นเกม!"

    # game/scripts/myscreens.rpy:156
    old "Este juego aún está en desarrollo"
    new "เกมนี้ยังอยู่ในระหว่างพัฒนา"

    # game/scripts/myscreens.rpy:157
    old "¿Quieres ayudar a que el juego siga con su desarrollo?"
    new "คุณต้องการช่วยสนับสนุนการพัฒนาเกมต่อไหม?"

    # game/scripts/myscreens.rpy:158
    old "No dudes en apoyarnos en Patreon y unirte al Discord"
    new "อย่าลังเลที่จะสนับสนุนพวกเราบน Patreon และเข้าร่วม Discord"

translate english strings:

    # game/scripts/myscreens.rpy:27
    old "Nombre Rápido"
    new "ตั้งชื่อด่วน"


translate english strings:

    # game/scripts/myscreens.rpy:204
    old "Mañana"
    new "เช้า"

    # game/scripts/myscreens.rpy:212
    old "Tarde"
    new "บ่าย"

    # game/scripts/myscreens.rpy:216
    old "Noche"
    new "กลางคืน"


translate english strings:

    # game/scripts/myscreens.rpy:208
    old "M.Día"
    new "เที่ยง"

    # game/scripts/myscreens.rpy:220
    old "M.Noche"
    new "เที่ยงคืน"


translate english strings:

    # game/scripts/myscreens.rpy:50
    old "Nombre: Ryuta"
    new "ชื่อ: รยูตะ"

    # game/scripts/myscreens.rpy:51
    old "Clan: Karui"
    new "แคลน: คารุย"

    # game/scripts/myscreens.rpy:52
    old "Edad: 12"
    new "อายุ: 12"

    # game/scripts/myscreens.rpy:53
    old "Aldea: Desconocido"
    new "หมู่บ้าน: ไม่ทราบ"

    # game/scripts/myscreens.rpy:54
    old "Usuario de Dojutsu: Positivo"
    new "ผู้ใช้เนตร: ใช่"

    # game/scripts/myscreens.rpy:55
    old "Dojutsu: Karugan"
    new "เนตร: คารูกัน"

    # game/scripts/myscreens.rpy:56
    old "Estado del Karugan: Inmaduro"
    new "สถานะเนตรคารูกัน: ยังไม่สมบูรณ์"

    # game/scripts/myscreens.rpy:57
    old "Compatibilidad: Alta"
    new "ความเข้ากันได้: สูง"

    # game/scripts/myscreens.rpy:58
    old "Estado del Sujeto: Estable"
    new "สถานะของตัวทดลอง: คงที่"

    # game/scripts/myscreens.rpy:59
    old "Progreso del Experimento: Avanzado"
    new "ความคืบหน้าการทดลอง: ขั้นสูง"
