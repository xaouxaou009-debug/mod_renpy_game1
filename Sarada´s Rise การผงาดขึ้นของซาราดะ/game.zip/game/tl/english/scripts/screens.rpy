
translate english strings:

    # game/scripts/screens.rpy:278
    old "Historial"
    new "ประวัติการสนทนา"

    # game/scripts/screens.rpy:280
    old "Guardar"
    new "บันทึกเกม"

    # game/scripts/screens.rpy:282
    old "Cargar"
    new "โหลดเกม"

    # game/scripts/screens.rpy:288
    old "Finaliza repetición"
    new "สิ้นสุดการเล่นซ้ำ"

    # game/scripts/screens.rpy:292
    old "Menú principal"
    new "เมนูหลัก"

    # game/scripts/screens.rpy:294
    old "Acerca de"
    new "เกี่ยวกับ"

    # game/scripts/screens.rpy:299
    old "Ayuda"
    new "ช่วยเหลือ"

    # game/scripts/screens.rpy:305
    old "Salir"
    new "ออก"

    # game/scripts/screens.rpy:384
    old "Volver"
    new "ย้อนกลับ"

    # game/scripts/screens.rpy:463
    old "Créditos"
    new "เครดิต"

    # game/scripts/screens.rpy:515
    old "Reanudar"
    new "เล่นต่อ"

    # game/scripts/screens.rpy:524
    old "Galería"
    new "แกลเลอรี"

    # game/scripts/screens.rpy:529
    old "Menú Principal"
    new "เมนูหลัก"

    # game/scripts/screens.rpy:609
    old "{#file_time}%A, %d de %B %Y, %H:%M"
    new "{#file_time}%A, %d จาก %B %Y, %H:%M"

    # game/scripts/screens.rpy:609
    old "vacío"
    new "ว่างเปล่า"

    # game/scripts/screens.rpy:626
    old "<"
    new "<"

    # game/scripts/screens.rpy:629
    old "{#auto_page}A"
    new "{#auto_page}A"

    # game/scripts/screens.rpy:632
    old "{#quick_page}R"
    new "{#quick_page}R"

    # game/scripts/screens.rpy:638
    old ">"
    new ">"

    # game/scripts/screens.rpy:695
    old "Pantalla"
    new "หน้าจอ"

    # game/scripts/screens.rpy:699
    old "Ventana"
    new "หน้าต่าง"

    # game/scripts/screens.rpy:701
    old "Pant. completa"
    new "เต็มจอ"

    # game/scripts/screens.rpy:704
    old "Saltar"
    new "ข้าม"

    # game/scripts/screens.rpy:708
    old "Texto no visto"
    new "ข้อความที่ยังไม่ได้อ่าน"

    # game/scripts/screens.rpy:710
    old "Tras opciones"
    new "หลังตัวเลือก"

    # game/scripts/screens.rpy:712
    old "Transiciones"
    new "เอฟเฟกต์เปลี่ยนฉาก"

    # game/scripts/screens.rpy:715
    old "Idioma"
    new "ภาษา"

    # game/scripts/screens.rpy:719
    old "English"
    new "English"

    # game/scripts/screens.rpy:721
    old "Español"
    new "Español"

    # game/scripts/screens.rpy:731
    old "Texto"
    new "ข้อความ"

    # game/scripts/screens.rpy:734
    old "Veloc. texto"
    new "ความเร็วข้อความ"

    # game/scripts/screens.rpy:736
    old "Veloc. auto-avance"
    new "ความเร็วข้อความอัตโนมัติ"

    # game/scripts/screens.rpy:740
    old "Volumen"
    new "ระดับเสียง"

    # game/scripts/screens.rpy:744
    old "Volumen música"
    new "ระดับเสียงเพลง"

    # game/scripts/screens.rpy:748
    old "Volumen sonido"
    new "ระดับเสียงเอฟเฟกต์"

    # game/scripts/screens.rpy:751
    old "Prueba"
    new "ทดสอบ"

    # game/scripts/screens.rpy:878
    old "El historial está vacío."
    new "ประวัติการสนทนาว่างเปล่า"

    # game/scripts/screens.rpy:948
    old "Teclado"
    new "คีย์บอร์ด"

    # game/scripts/screens.rpy:949
    old "Ratón"
    new "เมาส์"

    # game/scripts/screens.rpy:952
    old "Mando"
    new "คอนโทรลเลอร์"

    # game/scripts/screens.rpy:965
    old "Enter"
    new "Enter"

    # game/scripts/screens.rpy:966
    old "Avanza el diálogo y activa la interfaz."
    new "ข้ามบทสนทนาและเปิดใช้งานอินเทอร์เฟซ"

    # game/scripts/screens.rpy:969
    old "Espacio"
    new "เคาะเว้นวรรค"

    # game/scripts/screens.rpy:970
    old "Avanza el diálogo sin seleccionar opciones."
    new "ข้ามบทสนทนาโดยไม่ต้องเลือกตัวเลือก"

    # game/scripts/screens.rpy:973
    old "Teclas de flecha"
    new "ปุ่มลูกศร"

    # game/scripts/screens.rpy:974
    old "Navega la interfaz."
    new "นำทางในอินเทอร์เฟซ"

    # game/scripts/screens.rpy:977
    old "Escape"
    new "Esc"

    # game/scripts/screens.rpy:978
    old "Accede al menú del juego."
    new "เข้าสู่เมนูเกม"

    # game/scripts/screens.rpy:981
    old "Ctrl"
    new "Ctrl"

    # game/scripts/screens.rpy:982
    old "Salta el diálogo mientras se presiona."
    new "ข้ามบทสนทนาค้างไว้ขณะกด"

    # game/scripts/screens.rpy:985
    old "Tabulador"
    new "Tab"

    # game/scripts/screens.rpy:986
    old "Activa/desactiva el salto de diálogo."
    new "เปิด/ปิดการข้ามบทสนทนา"

    # game/scripts/screens.rpy:989
    old "Av. pág."
    new "Page Down"

    # game/scripts/screens.rpy:990
    old "Retrocede al diálogo anterior."
    new "ย้อนกลับไปยังบทสนทนาก่อนหน้า"

    # game/scripts/screens.rpy:993
    old "Re. pág."
    new "Page Up"

    # game/scripts/screens.rpy:994
    old "Avanza hacia el diálogo siguiente."
    new "ไปยังบทสนทนาถัดไป"

    # game/scripts/screens.rpy:998
    old "Oculta la interfaz."
    new "ซ่อนอินเทอร์เฟซ"

    # game/scripts/screens.rpy:1002
    old "Captura la pantalla."
    new "บันทึกภาพหน้าจอ"

    # game/scripts/screens.rpy:1006
    old "Activa/desactiva la asistencia por {a=https://www.renpy.org/l/voicing}voz-automática{/a}."
    new "เปิด/ปิดระบบช่วยเหลือ {a=https://www.renpy.org/l/voicing}เสียงพากย์อัตโนมัติ{/a}"

    # game/scripts/screens.rpy:1010
    old "Abre el menú de accesibilidad."
    new "เปิดเมนูการช่วยการเข้าถึง"

    # game/scripts/screens.rpy:1016
    old "Clic izquierdo"
    new "คลิกซ้าย"

    # game/scripts/screens.rpy:1020
    old "Clic medio"
    new "คลิกกลาง"

    # game/scripts/screens.rpy:1024
    old "Clic derecho"
    new "คลิกขวา"

    # game/scripts/screens.rpy:1028
    old "Rueda del ratón arriba\nClic en lado de retroceso"
    new "เลื่อนล้อเมาส์ขึ้น\nคลิกที่ปุ่มย้อนกลับ"

    # game/scripts/screens.rpy:1032
    old "Rueda del ratón abajo"
    new "เลื่อนล้อเมาส์ลง"

    # game/scripts/screens.rpy:1039
    old "Gatillo derecho\nA/Botón inferior"
    new "ทริกเกอร์ขวา\nปุ่ม A / ปุ่มด้านล่าง"

    # game/scripts/screens.rpy:1043
    old "Gatillo izquierdo\nBotón sup. frontal izq."
    new "ทริกเกอร์ซ้าย\nปุ่มกันชนซ้าย"

    # game/scripts/screens.rpy:1047
    old "Botón sup. frontal der."
    new "ปุ่มกันชนขวา"

    # game/scripts/screens.rpy:1052
    old "D-Pad, Sticks"
    new "D-Pad, อะนาล็อกสติ๊ก"

    # game/scripts/screens.rpy:1056
    old "Comenzar, Guía"
    new "เริ่มเกม, คู่มือ"

    # game/scripts/screens.rpy:1060
    old "Y/Botón superior"
    new "Y / ปุ่มด้านบน"

    # game/scripts/screens.rpy:1063
    old "Calibrar"
    new "ปรับเทียบ"

    # game/scripts/screens.rpy:1130
    old "Sí"
    new "ใช่"

    # game/scripts/screens.rpy:1179
    old "Saltando"
    new "กำลังข้าม"

translate english strings:

    # game/scripts/screens.rpy:460
    old "The dialogue history is empty."
    new "ประวัติบทสนทนาว่างเปล่า"


translate english strings:

    # game/scripts/screens.rpy:313
    old "Humor: {color=#87e887}Feliz{/a}"
    new "อารมณ์: {color=#87e887}มีความสุข{/a}"

    # game/scripts/screens.rpy:315
    old "Humor: Normal"
    new "อารมณ์: ปกติ"

    # game/scripts/screens.rpy:317
    old "Humor: {color=#ebd967}Irritada{/a}"
    new "อารมณ์: {color=#ebd967}หงุดหงิด{/a}"

    # game/scripts/screens.rpy:319
    old "Humor: {color=#eb6363}Molesta{/a}"
    new "อารมณ์: {color=#eb6363}โกรธ{/a}"

    # game/scripts/screens.rpy:321
    old "Humor: {color=#fc608f}Caliente{/a}"
    new "อารมณ์: {color=#fc608f}เร่าร้อน{/a}"
