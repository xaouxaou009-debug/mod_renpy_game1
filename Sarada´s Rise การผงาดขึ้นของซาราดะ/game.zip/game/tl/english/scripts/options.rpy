
translate english strings:

    # game/scripts/options.rpy:16
    old "Saradas Rise"
    new "การผงาดขึ้นของซาราดะ"


translate english strings:

    # game/scripts/options.rpy:17
    old "Sarada´s Rise"
    new "การผงาดขึ้นของซาราดะ"
