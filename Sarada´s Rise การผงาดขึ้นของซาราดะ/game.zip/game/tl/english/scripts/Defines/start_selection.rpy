
translate english strings:

    # game/scripts/Defines/start_selection.rpy:4
    old "Comenzar contenido desde..."
    new "เริ่มเนื้อหาจาก..."

    # game/scripts/Defines/start_selection.rpy:9
    old "Prologo"
    new "บทนำ"

    # game/scripts/Defines/start_selection.rpy:12
    old "(Arco1) Prueba de Zubon"
    new "(บทที่ 1) การทดสอบของซูบง"

translate english strings:

    # game/scripts/Defines/start_selection.rpy:15
    old "(Arco2) Exámenes Chunin"
    new "(บทที่ 2) การสอบจูนิน"
