
translate english strings:

    # game/scripts/Defines/Variables.rpy:5
    old "Página {}"
    new "หน้า {}"

    # game/scripts/Defines/Variables.rpy:5
    old "Guardado automático"
    new "บันทึกอัตโนมัติ"

    # game/scripts/Defines/Variables.rpy:5
    old "Guardado rápido"
    new "บันทึกด่วน"

translate english strings:

    # game/scripts/Defines/Variables.rpy:3
    old "Lunes"
    new "วันจันทร์"

    # game/scripts/Defines/Variables.rpy:3
    old "Martes"
    new "วันอังคาร"

    # game/scripts/Defines/Variables.rpy:3
    old "Miércoles"
    new "วันพุธ"

    # game/scripts/Defines/Variables.rpy:3
    old "Jueves"
    new "วันพฤหัสบดี"

    # game/scripts/Defines/Variables.rpy:3
    old "Viernes"
    new "วันศุกร์"

    # game/scripts/Defines/Variables.rpy:3
    old "Sábado"
    new "วันเสาร์"

    # game/scripts/Defines/Variables.rpy:3
    old "Domingo"
    new "วันอาทิตย์"
