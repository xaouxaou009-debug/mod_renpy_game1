
translate english strings:

    # game/scripts/Defines/Characters.rpy:2
    old "Narrador"
    new "ผู้บรรยาย"


translate english strings:

    # game/scripts/Defines/Characters.rpy:114
    old "Chico de Cabello Rojo"
    new "เด็กหนุ่มผมแดง"

    # game/scripts/Defines/Characters.rpy:115
    old "Chica de Cabello Morado"
    new "เด็กสาวผมม่วง"

    # game/scripts/Defines/Characters.rpy:116
    old "Chica de Cabello Blanco"
    new "เด็กสาวผมขาว"

    # game/scripts/Defines/Characters.rpy:117
    old "Hinata y Himawari"
    new "ฮินาตะและฮิมาวาริ"
