# TODO: Translation updated at 2024-12-22 11:36

translate english strings:

    # game/scripts/about_screen.rpy:64
    old "Gracias a Todos los Patreons por apoyar el Proyecto!"
    new "ขอขอบคุณผู้สนับสนุน Patreon ทุกท่านที่ร่วมสนับสนุนโปรเจกต์นี้!"

    # game/scripts/about_screen.rpy:66
    old "Y un gran gracias a {b}scott collins{/a} por ser Mienbro {b}Demon King{/a}"
    new "และขอขอบคุณ {b}scott collins{/a} เป็นพิเศษสำหรับการเป็นสมาชิกในระดับ {b}Demon King{/a}"
