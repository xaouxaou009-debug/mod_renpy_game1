
translate english strings:

    # game/scripts/Systems/Shop/ichiraku_shop_screen.rpy:30
    old "Comprar : [ichiraku_selected]"
    new "ซื้อ : [ichiraku_selected]"


translate english strings:

    # game/scripts/Systems/Shop/ichiraku_shop_screen.rpy:19
    old "Ramen Curativo - 50 ryo"
    new "ราเม็งฟื้นฟูพลัง - 50 เรียว"

    # game/scripts/Systems/Shop/ichiraku_shop_screen.rpy:21
    old "Ramen Regenerativo - 50 ryo"
    new "ราเม็งฟื้นฟูต่อเนื่อง - 50 เรียว"
# TODO: Translation updated at 2024-11-29 23:49

translate english strings:

    # game/scripts/Systems/Shop/ichiraku_shop_screen.rpy:15
    old "Consumibles"
    new "ไอเทมสิ้นเปลือง"

    # game/scripts/Systems/Shop/ichiraku_shop_screen.rpy:32
    old "Carrito de Compras"
    new "ตะกร้าสินค้า"
