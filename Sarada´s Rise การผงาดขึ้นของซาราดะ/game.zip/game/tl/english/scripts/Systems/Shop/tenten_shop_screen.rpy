

translate english strings:

    # game/scripts/Systems/Shop/tenten_shop_screen.rpy:44
    old "Comprar : [tenten_selected]"
    new "ซื้อ : [tenten_selected]"

    # game/scripts/Systems/Shop/tenten_shop_screen.rpy:20
    old "Poderoso pergamino, aumenta {b}{color=#f3c271}20{/a}{/a} puntos el {b}{color=#e13131}Ataque{/a}{/a}."
    new "คัมภีร์ทรงพลัง เพิ่มพลัง {b}{color=#f3c271}20{/a}{/a} ให้กับ {b}{color=#e13131}โจมตี{/a}{/a}"

    # game/scripts/Systems/Shop/tenten_shop_screen.rpy:22
    old "Poderoso pergamino, aumenta {b}{color=#f3c271}50{/a}{/a} puntos el {b}{color=#e13131}Ataque{/a}{/a}."
    new "คัมภีร์ทรงพลัง เพิ่มพลัง {b}{color=#f3c271}50{/a}{/a} ให้กับ {b}{color=#e13131}โจมตี{/a}{/a}"

    # game/scripts/Systems/Shop/tenten_shop_screen.rpy:24
    old "Poderoso pergamino, aumenta {b}{color=#f3c271}100{/a}{/a} puntos el {b}{color=#e13131}Ataque{/a}{/a}."
    new "คัมภีร์ทรงพลัง เพิ่มพลัง {b}{color=#f3c271}100{/a}{/a} ให้กับ {b}{color=#e13131}โจมตี{/a}{/a}"

    # game/scripts/Systems/Shop/tenten_shop_screen.rpy:26
    old "Poderoso pergamino, aumenta {b}{color=#f3c271}50{/a}{/a} puntos la {b}{color=#33ca3c}Salud{/a}{/a}."
    new "คัมภีร์ทรงพลัง เพิ่มพลัง {b}{color=#f3c271}50{/a}{/a} ให้กับ {b}{color=#33ca3c}สุขภาพ{/a}{/a}"

    # game/scripts/Systems/Shop/tenten_shop_screen.rpy:28
    old "Poderoso pergamino, aumenta {b}{color=#f3c271}100{/a}{/a} puntos la {b}{color=#33ca3c}Salud{/a}{/a}."
    new "คัมภีร์ทรงพลัง เพิ่มพลัง {b}{color=#f3c271}100{/a}{/a} ให้กับ {b}{color=#33ca3c}สุขภาพ{/a}{/a}"

    # game/scripts/Systems/Shop/tenten_shop_screen.rpy:30
    old "Poderoso pergamino, aumenta {b}{color=#f3c271}150{/a}{/a} puntos la {b}{color=#33ca3c}Salud{/a}{/a}."
    new "คัมภีร์ทรงพลัง เพิ่มพลัง {b}{color=#f3c271}150{/a}{/a} ให้กับ {b}{color=#33ca3c}สุขภาพ{/a}{/a}"

    # game/scripts/Systems/Shop/tenten_shop_screen.rpy:32
    old "Poderoso pergamino, aumenta {b}{color=#f3c271}50{/a}{/a} puntos el {b}{color=#35c0db}Chakra{/a}{/a}."
    new "คัมภีร์ทรงพลัง เพิ่มพลัง {b}{color=#f3c271}50{/a}{/a} ให้กับ {b}{color=#35c0db}จักระ{/a}{/a}"

    # game/scripts/Systems/Shop/tenten_shop_screen.rpy:34
    old "Poderoso pergamino, aumenta {b}{color=#f3c271}100{/a}{/a} puntos el {b}{color=#35c0db}Chakra{/a}{/a}."
    new "คัมภีร์ทรงพลัง เพิ่มพลัง {b}{color=#f3c271}100{/a}{/a} ให้กับ {b}{color=#35c0db}จักระ{/a}{/a}"

    # game/scripts/Systems/Shop/tenten_shop_screen.rpy:36
    old "Poderoso pergamino, aumenta {b}{color=#f3c271}150{/a}{/a} puntos el {b}{color=#35c0db}Chakra{/a}{/a}."
    new "คัมภีร์ทรงพลัง เพิ่มพลัง {b}{color=#f3c271}150{/a}{/a} ให้กับ {b}{color=#35c0db}จักระ{/a}{/a}"
# TODO: Translation updated at 2024-11-29 23:49

translate english strings:

    # game/scripts/Systems/Shop/tenten_shop_screen.rpy:11
    old "Tienda de Tenten"
    new "ร้านค้าของเท็นเท็น"

    # game/scripts/Systems/Shop/tenten_shop_screen.rpy:16
    old "Perga."
    new "คัมภีร์"
