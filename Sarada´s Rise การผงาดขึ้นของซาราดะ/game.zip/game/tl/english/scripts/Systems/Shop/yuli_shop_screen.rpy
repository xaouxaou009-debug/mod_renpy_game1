# TODO: Translation updated at 2024-11-29 23:49

translate english strings:

    # game/scripts/Systems/Shop/yuli_shop_screen.rpy:11
    old "Tienda de Yuli"
    new "ร้านของยูริ"

    # game/scripts/Systems/Shop/yuli_shop_screen.rpy:104
    old "Costo: "
    new "ราคา:"

    # game/scripts/Systems/Shop/yuli_shop_screen.rpy:148
    old "Venta por: "
    new "ขายโดย:"
