# TODO: Translation updated at 2024-12-01 23:05

translate english strings:

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Sarada Rising!"
    new "ซาราดะผงาด!"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Obtén todos los {b}Logros{/a}"
    new "ปลดล็อก {b}ความสำเร็จ{/a} ทั้งหมด"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Una nueva vida.."
    new "ชีวิตใหม่..."

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Fuiste rescatado de las garras de {b}Shin Uchiha{/a}, marcando el inicio de un nuevo capítulo en tu historia"
    new "คุณได้รับการช่วยเหลือจากเงื้อมมือของ {b}อุจิวะ ชิน{/a} นับเป็นการเริ่มต้นบทใหม่ในเรื่องราวของคุณ"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Comienza Aquí"
    new "เริ่มต้นที่นี่"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Completaste el {b}Prólogo{/a}, estableciendo las bases para tu aventura"
    new "คุณเล่น {b}บทนำ{/a} จบแล้ว เป็นการปูพื้นฐานสำหรับการผจญภัยของคุณ"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Cadenas Inquebantables"
    new "สายสัมพันธ์ที่ไม่มีวันตัดขาด"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Superaste a {b}Yuna{/a} en combate"
    new "คุณเอาชนะ {b}ยูนะ{/a} ในการต่อสู้"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Rivalidad Amistosa"
    new "การแข่งขันอันเป็นมิตร"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Derrotaste a {b}Sarada{/a} en una batalla amistosa"
    new "คุณเอาชนะ {b}ซาราดะ{/a} ในการประลองกระชับมิตร"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Equipo 11"
    new "ทีม 11"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Derrotaron a {b}Zubon{/a} en equipo, abriéndose paso hacia los Exámenes Chunin"
    new "คุณร่วมมือกันเอาชนะ {b}ซูบง{/a} ได้สำเร็จ เปิดทางสู่การสอบจูนิน"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Underwear Justice"
    new "ความยุติธรรมแห่งกางเกงใน"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Derrotaste al {b}Ladrón de Bragas{/a}, ahora las chicas pueden estar seguras... Supongo"
    new "คุณจัดการกับ {b}โจรขโมยชุดชั้นใน{/a} เรียบร้อยแล้ว ตอนนี้พวกผู้หญิงคงรู้สึกปลอดภัยขึ้น... มั้งนะ"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Rescate Felino"
    new "ปฏิบัติการช่วยเหลือแมว"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Encontraste al {b}gato perdido{/a} y demostraste que hasta las pequeñas misiones pueden ser importantes"
    new "คุณพบ {b}แมวที่หายไป{/a} และพิสูจน์ให้เห็นว่าแม้แต่มิชชันเล็กๆ ก็มีความสำคัญเช่นกัน"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Ultimate Desencadenado"
    new "อัลติเมทปลดผนึก"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Desataste tu {b}habilidad definitiva{/a} por primera vez, dejando a todos asombrados"
    new "คุณปลดปล่อย {b}สกิลไม้ตาย{/a} เป็นครั้งแรก ทำให้ทุกคนต้องทึ่ง"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Mi Mejor Jutsu!"
    new "สุดยอดวิชานินจาของฉัน!"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Llevaste uno de tus jutsus al {b}máximo nivel{/a}, alcanzando un nuevo pináculo en tu entrenamiento"
    new "คุณฝึกฝนวิชานินจาจนถึง {b}ระดับสูงสุด{/a} บรรลุจุดสูงสุดใหม่ในการฝึกฝนของคุณ"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Pergamino de Iniciación"
    new "คัมภีร์ปฐมบท"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Compraste tu primer {b}pergamino{/a}, abriendo las puertas a nuevos conocimientos y habilidades"
    new "คุณซื้อ {b}คัมภีร์{/a} เล่มแรก เปิดประตูสู่ความรู้และทักษะใหม่ๆ"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Década de Duelos"
    new "ทศวรรษแห่งการประลอง"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Luchaste {b}10 veces{/a}, enfrentando cada desafío con determinación"
    new "คุณต่อสู้ครบ {b}10 ครั้ง{/a} เผชิญหน้ากับทุกความท้าทายด้วยความมุ่งมั่น"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Lady in Red"
    new "หญิงชุดแดง"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Adquiriste tu primera pieza de {b}ropa{/a}"
    new "คุณได้รับ {b}เสื้อผ้า{/a} ชิ้นแรกมาครอบครอง"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Súper Regalo"
    new "ซูเปอร์ของขวัญ"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Compraste tu primer {b}regalo{/a}, demostrando que un gesto amable puede cambiarlo todo"
    new "คุณซื้อ {b}ของขวัญ{/a} ชิ้นแรก พิสูจน์ให้เห็นว่าความใส่ใจเล็กๆ น้อยๆ สามารถเปลี่ยนทุกอย่างได้"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Una probada de mi Banana"
    new "ชิมกล้วยของฉันหน่อยสิ"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Recibiste una Felación de {b}Ayame{/a}, experimentaste un momento inolvidable"
    new "คุณได้รับการปรนนิบัติด้วยปากจาก {b}อายาเมะ{/a} เป็นช่วงเวลาที่คุณไม่มีวันลืม"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Cortesano Culinario"
    new "พ่อครัวเอกแห่งความอร่อย"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Tuviste Sexo con {b}Ayame{/a}, llevándote a una experiencia tan cálida como sus platos"
    new "คุณมีเพศสัมพันธ์กับ {b}อายาเมะ{/a} นำพาไปสู่ประสบการณ์ที่อบอุ่นราวกับอาหารจานโปรดของเธอ"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Shorts Abajo"
    new "กางเกงขาสั้นหลุดลง"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Hiciste que Sarada dejara caer su guardia, y con ella, sus shorts. Un pequeño triunfo en una guerra de miradas"
    new "คุณทำให้ซาราดะเผลอเรอจนการป้องกันตัวหลุด และพร้อมกันนั้นกางเกงขาสั้นของเธอก็หลุดลงมา ชัยชนะเล็กๆ ในสงครามแห่งสายตา"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Boobtrap"
    new "กับดักดูมๆ"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Experimenta la estimulante sensación de llegar al clímax usando los pechos de {b}Ino{/a}"
    new "สัมผัสความรู้สึกสุดเร้าใจเมื่อไปถึงจุดสุดยอดโดยใช้หน้าอกของ {b}อิโนะ{/a}"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Mi Reina"
    new "ราชินีของฉัน"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Te has encontrado a {b}Hinata{/a}, la mujer cuya belleza y gracia trascienden generaciones"
    new "คุณได้พบกับ {b}ฮินาตะ{/a} หญิงสาวผู้มีความงดงามและสง่างามเหนือกาลเวลา"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Squirtle"
    new "สเคิเทิล"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Haz que {b}Ino{/a} se estremezca de placer usando tu hábil lengua"
    new "ทำให้ {b}อิโนะ{/a} ตัวสั่นสะท้านด้วยความเสียวซ่านโดยใช้ลิ้นอันช่ำชองของคุณ"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Probada Nocturna"
    new "รสชาติยามค่ำคืน"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Experimenta la emoción de llegar al clímax en la boca de {b}Ino{/a}"
    new "สัมผัสความเร้าใจเมื่อไปถึงจุดสุดยอดในปากของ {b}อิโนะ{/a}"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Secretos del pétalo rosa"
    new "ความลับแห่งกลีบดอกไม้สีชมพู"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Descubre los deseos ocultos de {b}Sakura{/a} mientras explora su cuerpo en la intimidad del hospital"
    new "ค้นพบความปรารถนาที่ซ่อนอยู่ของ {b}ซากุระ{/a} ในขณะที่สำรวจร่างกายของเธอในความเงียบสงบของโรงพยาบาล"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Primer Acto Completado"
    new "บทที่หนึ่งเสร็จสมบูรณ์"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Has superado todos los desafíos del primer arco y comenzado tu camino como ninja"
    new "คุณผ่านพ้นความท้าทายทั้งหมดขององก์แรกและเริ่มต้นเส้นทางในฐานะนินจาแล้ว"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Bandidos sin suerte"
    new "โจรดวงซวย"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Protegiste a Tenten al derrotar al bandido que intentó robarles en su viaje"
    new "คุณปกป้องเท็นเท็นด้วยการจัดการโจรที่พยายามจะปล้นพวกคุณระหว่างเดินทาง"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Duelo contra Naruto"
    new "ดวลเดือดกับนารูโตะ"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Te enfrentaste a Naruto Uzumaki en un duelo. ¿Cuántos pueden decir lo mismo?"
    new "คุณได้เผชิญหน้าดวลกับ อุซุมากิ นารูโตะ มีสักกี่คนกันที่จะพูดแบบนี้ได้?"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Voluntad de la Sannin"
    new "เจตจำนงแห่งซานนิน"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Sobreviviste a la prueba de Tsunade, tu resistencia ha sido puesta a prueba como nunca antes"
    new "คุณรอดพ้นจากการทดสอบของซึนาเดะมาได้ ความอึดของคุณถูกทดสอบอย่างที่ไม่เคยเป็นมาก่อน"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Espada kasairyu"
    new "ดาบคะซาริริว"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Obtén la espada kasairyu, forjada para superar tus propios límites"
    new "ได้รับดาบคะซาริริวที่ถูกตีขึ้นมาเพื่อก้าวข้ามขีดจำกัดของคุณเอง"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Vestido para la Victoria"
    new "ชุดเก่งสู่ชัยชนะ"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Estrenaste tu nuevo traje, listo para encarar cualquier desafío con estilo"
    new "คุณสวมชุดใหม่เป็นครั้งแรก พร้อมเผชิญหน้ากับทุกความท้าทายด้วยความเท่"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Testigo"
    new "ประจักษ์พยาน"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Presenciaste un robo en el Centro de Investigación de Herramientas Científicas Ninja..."
    new "คุณได้เห็นเหตุการณ์ปล้นที่ศูนย์วิจัยเครื่องมือวิทยาศาสตร์นินจา..."

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Entrenamiento Intensivo"
    new "ฝึกซ้อมอย่างเข้มข้น"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Entrenaste sin descanso bajo la guía de Sarada. La fuerza se forja con dedicación"
    new "คุณฝึกฝนอย่างไม่รู้จักเหน็ดเหนื่อยภายใต้การดูแลของซาราดะ ความแข็งแกร่งถูกสร้างขึ้นด้วยความทุ่มเท"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Paz en las Aguas"
    new "ความสงบในสายน้ำ"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Te tomaste un momento para reflexionar y sanar en las aguas termales"
    new "คุณใช้เวลาสักครู่เพื่อทบทวนตัวเองและฟื้นฟูร่างกายในบ่อน้ำพุร้อน"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Confusiones en la Embriaguez"
    new "เมามายจนสับสน"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Bajo el efecto del alcohol, compartiste un momento íntimo con Sakura"
    new "ภายใต้ฤทธิ์แอลกอฮอล์ คุณได้แบ่งปันช่วงเวลาอันแนบชิดกับซากุระ"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Un Beso Bajo el Atardecer"
    new "จุมพิตใต้แสงตะลับลับฟ้า"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "La calidez del momento los envolvió y el beso con Tenten selló el inicio de algo más profundo"
    new "ความอบอุ่นของช่วงเวลานั้นโอบล้อมพวกเขาไว้ และจูบกับเท็นเท็นก็เป็นจุดเริ่มต้นของความสัมพันธ์ที่ลึกซึ้งยิ่งขึ้น"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Sombras y Secretos en la Cueva"
    new "เงาและความลับในถ้ำ"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Una lluvia inesperada, una cueva y un vistazo furtivo a un lado oculto de Tenten"
    new "ฝนที่ตกลงมาอย่างไม่คาดคิด ถ้ำแห่งหนึ่ง และแอบมองด้านที่ซ่อนอยู่ของเท็นเท็น"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "El Jutsu Sexy"
    new "คาถายั่วยวน"

    # game/scripts/Systems/Achievements/achievements_function.rpy:55
    old "Derrotado por la astucia y el ingenio de Naruto... Quizá la estrategia fue más fuerte que la fuerza"
    new "พ่ายแพ้ให้กับความเจ้าเล่ห์และไหวพริบของนารูโตะ... บางทีกลยุทธ์อาจจะแข็งแกร่งกว่ากำลังก็ได้นะ"
