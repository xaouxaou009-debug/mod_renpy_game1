
translate english strings:

    # game/scripts/Systems/Achievements/achievement_screen.rpy:17
    old "Logros"
    new "ความสำเร็จ"

    # game/scripts/Systems/Achievements/achievement_screen.rpy:49
    old "Logro Oculto"
    new "ความสำเร็จลับ"

translate english strings:

    # game/scripts/Systems/Achievements/achievement_screen.rpy:107
    old "Logro Desbloqueado!"
    new "ปลดล็อกความสำเร็จแล้ว!"
