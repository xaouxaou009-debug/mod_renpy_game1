# TODO: Translation updated at 2024-11-29 23:49
translate english strings:

    # game/scripts/Systems/Inventory/tooltips.rpy:2
    old "Delicioso ramen que restaura {b}{color=#f9d17c}20{/a}{/a} puntos de {b}{color=#33ca3c}Salud{/a}{/a}"
    new "ราเม็งรสเลิศที่ฟื้นฟูพลัง{b}{color=#f9d17c}20{/a}{/a} {b}{color=#33ca3c}ชีวิต{/a}{/a}"

    # game/scripts/Systems/Inventory/tooltips.rpy:5
    old "Delicioso ramen que restaura {b}{color=#f9d17c}20{/a}{/a} puntos de {b}{color=#36dce9}Chakra{/a}{/a}"
    new "ราเม็งรสเลิศที่ฟื้นฟูจักระ{b}{color=#f9d17c}20{/a}{/a} {b}{color=#36dce9}จุด{/a}{/a}"

    # game/scripts/Systems/Inventory/tooltips.rpy:8
    old "Una Flor Extraña que me dió Ino, debo de llevársela a Sakura"
    new "ดอกไม้ประหลาดที่อิโนะให้มา ฉันต้องเอาไปให้ซากุระ"

    # game/scripts/Systems/Inventory/tooltips.rpy:10
    old "Pergamino de Conocimiento Básico"
    new "คัมภีร์ความรู้พื้นฐาน"

    # game/scripts/Systems/Inventory/tooltips.rpy:11
    old "Un Pergamino que brinda {b}{color=#f3c271}500{/a}{/a} puntos de {b}{color=#35c0db}Exp{/a}{/a} al usarlo"
    new "คัมภีร์ที่มอบค่า {b}{color=#35c0db}อีเอ๊กซ์พี{/a}{/a} {b}{color=#f3c271}500{/a}{/a} จุดเมื่อใช้งาน"

    # game/scripts/Systems/Inventory/tooltips.rpy:13
    old "Pergamino de Conocimiento Avanzado"
    new "คัมภีร์ความรู้ขั้นสูง"

    # game/scripts/Systems/Inventory/tooltips.rpy:14
    old "Un Pergamino que brinda {b}{color=#f3c271}1000{/a}{/a} puntos de {b}{color=#35c0db}Exp{/a}{/a} al usarlo"
    new "คัมภีร์ที่มอบค่า {b}{color=#f3c271}1000{/a}{/a} จุดเมื่อใช้งาน{b}{color=#35c0db}{/a}{/a}"

    # game/scripts/Systems/Inventory/tooltips.rpy:16
    old "Pergamino de Conocimiento Antiguo"
    new "คัมภีร์ความรู้โบราณ"

    # game/scripts/Systems/Inventory/tooltips.rpy:17
    old "Un Pergamino que brinda {b}{color=#f3c271}3000{/a}{/a} puntos de {b}{color=#35c0db}Exp{/a}{/a} al usarlo"
    new "คัมภีร์ที่มอบค่า {b}{color=#35c0db}อีเอ๊กซ์พี{/a}{/a} {b}{color=#f3c271}3000{/a}{/a} จุดเมื่อใช้งาน"

    # game/scripts/Systems/Inventory/tooltips.rpy:19
    old "Pergamino de Ataque Básico"
    new "คัมภีร์โจมตีพื้นฐาน"

    # game/scripts/Systems/Inventory/tooltips.rpy:20
    old "Un poderoso pergamino, aumenta {b}{color=#f9d17c}20{/a}{/a} puntos el {b}{color=#e13131}Ataque{/a}{/a} del portador"
    new "คัมภีร์อันทรงพลัง เพิ่ม {b}{color=#f9d17c}20{/a}{/a} จุดให้กับ {b}{color=#e13131}พลังโจมตี{/a}{/a} ของผู้ใช้"

    # game/scripts/Systems/Inventory/tooltips.rpy:22
    old "Pergamino de Ataque Intermedio"
    new "คัมภีร์โจมตีระดับกลาง"

    # game/scripts/Systems/Inventory/tooltips.rpy:23
    old "Un poderoso pergamino, aumenta {b}{color=#f9d17c}50{/a}{/a} puntos el {b}{color=#e13131}Ataque{/a}{/a} del portador"
    new "คัมภีร์อันทรงพลัง เพิ่ม {b}{color=#f9d17c}50{/a}{/a} จุดให้กับ {b}{color=#e13131}พลังโจมตี{/a}{/a} ของผู้ใช้"

    # game/scripts/Systems/Inventory/tooltips.rpy:25
    old "Pergamino de Ataque Avanzado"
    new "คัมภีร์โจมตีระดับสูง"

    # game/scripts/Systems/Inventory/tooltips.rpy:26
    old "Un poderoso pergamino, aumenta {b}{color=#f9d17c}100{/a}{/a} puntos el {b}{color=#e13131}Ataque{/a}{/a} del portador"
    new "คัมภีร์อันทรงพลัง เพิ่ม {b}{color=#f9d17c}100{/a}{/a} จุดให้กับ {b}{color=#e13131}พลังโจมตี{/a}{/a} ของผู้ใช้"

    # game/scripts/Systems/Inventory/tooltips.rpy:28
    old "Pergamino de Salud Básico"
    new "คัมภีร์ชีวิตพื้นฐาน"

    # game/scripts/Systems/Inventory/tooltips.rpy:29
    old "Un poderoso pergamino, aumenta {b}{color=#f9d17c}50{/a}{/a} puntos la {b}{color=#33ca3c}Salud{/a}{/a} del portador"
    new "คัมภีร์อันทรงพลัง เพิ่ม {b}{color=#f9d17c}50{/a}{/a} จุดให้กับ {b}{color=#33ca3c}ชีวิต{/a}{/a} ของผู้ใช้"

    # game/scripts/Systems/Inventory/tooltips.rpy:31
    old "Pergamino de Salud Intermedio"
    new "คัมภีร์ชีวิตระดับกลาง"

    # game/scripts/Systems/Inventory/tooltips.rpy:32
    old "Un poderoso pergamino, aumenta {b}{color=#f9d17c}100{/a}{/a} puntos la {b}{color=#33ca3c}Salud{/a}{/a} del portador"
    new "คัมภีร์อันทรงพลัง เพิ่ม {b}{color=#f9d17c}100{/a}{/a} จุดให้กับ {b}{color=#33ca3c}ชีวิต{/a}{/a} ของผู้ใช้"

    # game/scripts/Systems/Inventory/tooltips.rpy:34
    old "Pergamino de Salud Avanzado"
    new "คัมภีร์ชีวิตระดับสูง"

    # game/scripts/Systems/Inventory/tooltips.rpy:35
    old "Un poderoso pergamino, aumenta {b}{color=#f9d17c}150{/a}{/a} puntos la {b}{color=#33ca3c}Salud{/a}{/a} del portador"
    new "คัมภีร์อันทรงพลัง เพิ่ม {b}{color=#f9d17c}150{/a}{/a} จุดให้กับ {b}{color=#33ca3c}ชีวิต{/a}{/a} ของผู้ใช้"

    # game/scripts/Systems/Inventory/tooltips.rpy:37
    old "Pergamino de Chakra Básico"
    new "คัมภีร์จักระพื้นฐาน"

    # game/scripts/Systems/Inventory/tooltips.rpy:38
    old "Un poderoso pergamino, aumenta {b}{color=#f9d17c}50{/a}{/a} puntos el {b}{color=#35c0db}Chakra{/a}{/a} del portador"
    new "คัมภีร์อันทรงพลัง เพิ่ม {b}{color=#f9d17c}50{/a}{/a} จุดให้กับ {b}{color=#35c0db}จักระ{/a}{/a} ของผู้ใช้"

    # game/scripts/Systems/Inventory/tooltips.rpy:40
    old "Pergamino de Chakra Intermedio"
    new "คัมภีร์จักระระดับกลาง"

    # game/scripts/Systems/Inventory/tooltips.rpy:41
    old "Un poderoso pergamino, aumenta {b}{color=#f9d17c}100{/a}{/a} puntos el {b}{color=#35c0db}Chakra{/a}{/a} del portador"
    new "คัมภีร์อันทรงพลัง เพิ่ม {b}{color=#f9d17c}100{/a}{/a} จุดให้กับ {b}{color=#35c0db}จักระ{/a}{/a} ของผู้ใช้"

    # game/scripts/Systems/Inventory/tooltips.rpy:43
    old "Pergamino de Chakra Avanzado"
    new "คัมภีร์จักระระดับสูง"

    # game/scripts/Systems/Inventory/tooltips.rpy:44
    old "Un poderoso pergamino, aumenta {b}{color=#f9d17c}150{/a}{/a} puntos el {b}{color=#35c0db}Chakra{/a}{/a} del portador"
    new "คัมภีร์อันทรงพลัง เพิ่ม {b}{color=#f9d17c}150{/a}{/a} จุดให้กับ {b}{color=#35c0db}จักระ{/a}{/a} ของผู้ใช้"

    # game/scripts/Systems/Inventory/tooltips.rpy:46
    old "Inyección Curativa Básica"
    new "เข็มฉีดยารักษาพื้นฐาน"

    # game/scripts/Systems/Inventory/tooltips.rpy:47
    old "Inyección que restaura {b}{color=#f9d17c}50{/a}{/a} puntos de {b}{color=#33ca3c}Salud{/a}{/a}"
    new "เข็มฉีดยาที่ฟื้นฟู {b}{color=#f9d17c}50{/a}{/a} จุดของ {b}{color=#33ca3c}ชีวิต{/a}{/a}"

    # game/scripts/Systems/Inventory/tooltips.rpy:49
    old "Inyección Curativa Avanzada"
    new "เข็มฉีดยารักษาขั้นสูง"

    # game/scripts/Systems/Inventory/tooltips.rpy:50
    old "Inyección que restaura {b}{color=#f9d17c}100{/a}{/a} puntos de {b}{color=#33ca3c}Salud{/a}{/a}"
    new "เข็มฉีดยาที่ฟื้นฟู {b}{color=#f9d17c}100{/a}{/a} จุดของ {b}{color=#33ca3c}ชีวิต{/a}{/a}"

    # game/scripts/Systems/Inventory/tooltips.rpy:52
    old "Inyección Curativa Premium"
    new "เข็มฉีดยารักษาพรีเมียม"

    # game/scripts/Systems/Inventory/tooltips.rpy:53
    old "Inyección que restaura {b}{color=#f9d17c}200{/a}{/a} puntos de {b}{color=#33ca3c}Salud{/a}{/a}"
    new "เข็มฉีดยาที่ฟื้นฟู {b}{color=#f9d17c}200{/a}{/a} จุดของ {b}{color=#33ca3c}ชีวิต{/a}{/a}"

    # game/scripts/Systems/Inventory/tooltips.rpy:57
    old "Una rica fresa, le gusta a {b}Sakura{/a}, {b}Sarada{/a} y le encanta a {color=#ff949b}{b}Ino{/a}{/a}"
    new "สตรอว์เบอร์รี่ฉ่ำๆ ของโปรดของ {b}ซากุระ{/a} กับ {b}ซาราดะ{/a} และเป็นของโปรดสุดๆ ของ {color=#ff949b}{b}อิโนะ{/a}{/a}"

    # game/scripts/Systems/Inventory/tooltips.rpy:60
    old "Una hermosa Rosa, le gusta a {b}Sakura{/a} y le encanta a {color=#ff949b}{b}Sarada{/a}{/a}"
    new "กุหลาบแสนสวย ซากุระชอบ {b}{/a} และซาราดะหลงรักมันสุดๆ {color=#ff949b}{b}{/a}{/a}"

    # game/scripts/Systems/Inventory/tooltips.rpy:63
    old "Una hermosa flor blanca, le gusta a {b}Sarada{/a} y le encanta a {color=#ff949b}{b}Sakura{/a}{/a}"
    new "ดอกไม้สีขาวสวยงาม ซาราดะชอบ {b}{/a} และซากุระหลงรักมันสุดๆ {color=#ff949b}{b}{/a}{/a}"

    # game/scripts/Systems/Inventory/tooltips.rpy:66
    old "Un peluche de Kakashi, le gusta a {b}Sarada{/a} y a {b}Sakura{/a}"
    new "ตุ๊กตาคาคาชิ ซาราดะและซากุระชอบ {b}{/a} {b}{/a}"

    # game/scripts/Systems/Inventory/tooltips.rpy:69
    old "Un peluche de Pakkun, le gusta a {b}Sakura{/a}"
    new "ตุ๊กตาปั๊กคุง ซากุระชอบ {b}{/a}"

    # game/scripts/Systems/Inventory/tooltips.rpy:72
    old "Un peluche de Naruto, le gusta a {b}Sakura{/a} y le encanta a {color=#ff949b}{b}Sarada{/a}{/a}"
    new "ตุ๊กตานารูโตะ ซากุระชอบ {b}{/a} และซาราดะหลงรักมันสุดๆ {color=#ff949b}{b}{/a}{/a}"

    # game/scripts/Systems/Inventory/tooltips.rpy:75
    old "Un peluche de Sasuke, le gusta a {b}Ino{/a} y le encanta a {color=#ff949b}{b}Sarada{/a}{/a} y {color=#ff949b}{b}Sakura{/a}{/a}"
    new "ตุ๊กตาผ้าซาสึเกะ ของโปรดของ {b}อิโนะ{/a} และเป็นของโปรดสุดๆ ของ {color=#ff949b}{b}ซาราดะ{/a}{/a} กับ {color=#ff949b}{b}ซากุระ{/a}{/a}"

    # game/scripts/Systems/Inventory/tooltips.rpy:78
    old "Traje que usaba Sarada cuando era joven"
    new "ชุดที่ซาราดะใส่ตอนยังเด็ก"

    # game/scripts/Systems/Inventory/tooltips.rpy:81
    old "Traje que usó Sarada luego del Time Skip"
    new "ชุดที่ซาราดะใส่หลังไทม์สคิป"

    # game/scripts/Systems/Inventory/tooltips.rpy:83
    old "Vestido de Maid para Sarada"
    new "ชุดเมดสำหรับซาราดะ"

    # game/scripts/Systems/Inventory/tooltips.rpy:84
    old "Un hermoso vestido de Maid para Sarada"
    new "ชุดเมดแสนสวยสำหรับซาราดะ"

    # game/scripts/Systems/Inventory/tooltips.rpy:86
    old "Bikini de Sarada"
    new "บิกินี่ของซาราดะ"

    # game/scripts/Systems/Inventory/tooltips.rpy:87
    old "Un Bikini para Sarada, ¡Le quedaría Hermoso!"
    new "บิกินี่สำหรับซาราดะ ใส่แล้วต้องสวยมากแน่ๆ!"

    # game/scripts/Systems/Inventory/tooltips.rpy:89
    old "Traje de Navidad para Sarada"
    new "ชุดคริสต์มาสสำหรับซาราดะ"

    # game/scripts/Systems/Inventory/tooltips.rpy:90
    old "Traje de Navidad, perfecto para Sarada"
    new "ชุดคริสต์มาส เหมาะกับซาราดะสุดๆ"

    # game/scripts/Systems/Inventory/tooltips.rpy:93
    old "Traje Ninja que usó Sakura cuando era joven"
    new "ชุดนินจาที่ซากุระใส่ตอนยังเด็ก"

    # game/scripts/Systems/Inventory/tooltips.rpy:96
    old "Traje Ninja que usó Sakura antes de la Guerra"
    new "ชุดนินจาที่ซากุระใส่ก่อนสงคราม"

    # game/scripts/Systems/Inventory/tooltips.rpy:99
    old "Traje Ninja que usó Sakura después de la Guerra"
    new "ชุดนินจาที่ซากุระใส่หลังสงคราม"

    # game/scripts/Systems/Inventory/tooltips.rpy:101
    old "Bikini de Sakura"
    new "บิกินี่ของซากุระ"

    # game/scripts/Systems/Inventory/tooltips.rpy:105
    old "Traje Ninja que usó Ino después de la Guerra"
    new "ชุดนินจาที่อิโนะใส่หลังสงคราม"

    # game/scripts/Systems/Inventory/tooltips.rpy:108
    old "Traje Ninja que usó Ino antes de la Guerra"
    new "ชุดนินจาที่อิโนะใส่ก่อนสงคราม"

    # game/scripts/Systems/Inventory/tooltips.rpy:111
    old "Traje Ninja que usó Ino cuando era joven"
    new "ชุดนินจาที่อิโนะใส่ตอนยังเด็ก"

    # game/scripts/Systems/Inventory/tooltips.rpy:114
    old "Un hermoso bikini amarillo, ¡Perfecto para Ino!"
    new "บิกินี่สีเหลืองแสนสวย เหมาะกับอิโนะสุดๆ!"
# TODO: Translation updated at 2024-12-20 07:52

translate english strings:

    # game/scripts/Systems/Inventory/tooltips.rpy:1
    old "Ramen Curativo"
    new "ราเม็งรักษา"

    # game/scripts/Systems/Inventory/tooltips.rpy:4
    old "Ramen Regenerativo"
    new "ราเม็งฟื้นฟู"

    # game/scripts/Systems/Inventory/tooltips.rpy:7
    old "Flor Extraña"
    new "ดอกไม้ประหลาด"

    # game/scripts/Systems/Inventory/tooltips.rpy:56
    old "Fresa"
    new "สตรอเบอร์รี่"

    # game/scripts/Systems/Inventory/tooltips.rpy:59
    old "Rosa"
    new "กุหลาบ"

    # game/scripts/Systems/Inventory/tooltips.rpy:62
    old "Margarita"
    new "เดซี่"

    # game/scripts/Systems/Inventory/tooltips.rpy:65
    old "Peluche de Kakashi"
    new "ตุ๊กตาคาคาชิ"

    # game/scripts/Systems/Inventory/tooltips.rpy:68
    old "Peluche de Pakkun"
    new "ตุ๊กตาปั๊กคุง"

    # game/scripts/Systems/Inventory/tooltips.rpy:71
    old "Peluche de Naruto"
    new "ตุ๊กตานารูโตะ"

    # game/scripts/Systems/Inventory/tooltips.rpy:74
    old "Peluche de Sasuke"
    new "ตุ๊กตาสาสึเกะ"

    # game/scripts/Systems/Inventory/tooltips.rpy:116
    old "Espada Kasairyu"
    new "ดาบคาสึริว"

    # game/scripts/Systems/Inventory/tooltips.rpy:117
    old "Espada forjada por Tenten especialmente para tí, aumenta {b}{color=#f9d17c}150{/a}{/a} puntos el {b}{color=#e13131}Ataque{/a}{/a} del portador"
    new "ดาบที่เท็นเท็นตีขึ้นมาให้คุณโดยเฉพาะ เพิ่ม {b}{color=#f9d17c}150{/a}{/a} คะแนนให้กับ {b}{color=#e13131}พลังโจมตี{/a}{/a} ของผู้ถือครอง"
