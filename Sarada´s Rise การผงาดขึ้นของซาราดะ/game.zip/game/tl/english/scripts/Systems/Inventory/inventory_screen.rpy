
translate english strings:

    # game/scripts/Systems/Inventory/inventory_screen.rpy:85
    old "{image=gui/inventory/ryo.png} [inventory.money]"
    new "{image=gui/inventory/ryo.png} [inventory.money]"
# TODO: Translation updated at 2024-11-29 23:49

translate english strings:

    # game/scripts/Systems/Inventory/inventory_screen.rpy:11
    old "Inventario"
    new "ช่องเก็บของ"

    # game/scripts/Systems/Inventory/inventory_screen.rpy:23
    old "Todo"
    new "ทั้งหมด"

    # game/scripts/Systems/Inventory/inventory_screen.rpy:25
    old "Filtrar"
    new "ตัวกรอง"

    # game/scripts/Systems/Inventory/inventory_screen.rpy:115
    old "Regalos"
    new "ของขวัญ"

    # game/scripts/Systems/Inventory/inventory_screen.rpy:116
    old "Pergam."
    new "คัมภีร์"

    # game/scripts/Systems/Inventory/inventory_screen.rpy:117
    old "Ropa"
    new "ชุดแต่งกาย"

    # game/scripts/Systems/Inventory/inventory_screen.rpy:118
    old "Cerrar"
    new "ปิด"
