
translate english strings:

    # game/scripts/Systems/Phone/new_phone.rpy:80
    old "X"
    new "X"

    # game/scripts/Systems/Phone/new_phone.rpy:102
    old "{color=#ff506c}[quest.name]{/a} : [quest.description]"
    new "{color=#ff506c}[quest.name]{/a} : [quest.eng_description]"

    # game/scripts/Systems/Phone/new_phone.rpy:113
    old "-[quest.description]"
    new "-[quest.eng_description]"

    # game/scripts/Systems/Phone/new_phone.rpy:190
    old "[message.esp_message]"
    new "[message.eng_message]"

translate english strings:

    # game/scripts/Systems/Phone/new_phone.rpy:94
    old "{b}{color=#ebbc57}[quest.name]{/a}{/b} / [quest.description]"
    new "{b}{color=#ebbc57}[quest.eng_name]{/a}{/b} / [quest.eng_description]"

    # game/scripts/Systems/Phone/new_phone.rpy:96
    old "{b}{color=#ebbc57}Exp Gain{/a}{/b}:[quest.gain_exp]"
    new "{b}{color=#ebbc57}Exp Gain{/a}{/b}:[quest.gain_exp]"

    # game/scripts/Systems/Phone/new_phone.rpy:102
    old "{s}{color=#ebbc57}[quest.name]{color=#b9b9b9} / [quest.description]{/a}"
    new "{s}{color=#ebbc57}[quest.eng_name]{color=#b9b9b9} / [quest.eng_description]{/a}"


translate english strings:

    # game/scripts/Systems/Phone/new_phone.rpy:316
    old "De: [chat.by]"
    new "By [chat.by]"

    # game/scripts/Systems/Phone/new_phone.rpy:317
    old "Asunto: [chat.title]"
    new "Subject :[chat.eng_title]"


translate english strings:

    # game/scripts/Systems/Phone/new_phone.rpy:370
    old "[sarada_stats.description]"
    new "[sarada_stats.eng_description]"

    # game/scripts/Systems/Phone/new_phone.rpy:399
    old "[yuna_stats.description]"
    new "[yuna_stats.eng_description]"

    # game/scripts/Systems/Phone/new_phone.rpy:427
    old "[sakura_stats.description]"
    new "[sakura_stats.eng_description]"

    # game/scripts/Systems/Phone/new_phone.rpy:456
    old "[ino_stats.description]"
    new "[ino_stats.eng_description]"

    # game/scripts/Systems/Phone/new_phone.rpy:485
    old "[ayame_stats.description]"
    new "[ayame_stats.eng_description]"
# TODO: Translation updated at 2024-11-29 23:49

translate english strings:

    # game/scripts/Systems/Phone/new_phone.rpy:98
    old "Misiones Principales: Arco [acto]"
    new "Principal Quests: Arc [acto]"

    # game/scripts/Systems/Phone/new_phone.rpy:102
    old "Misiones de Ayame"
    new "Ayame Quests"

    # game/scripts/Systems/Phone/new_phone.rpy:106
    old "Misiones de Sakura"
    new "Sakura Quests"

    # game/scripts/Systems/Phone/new_phone.rpy:110
    old "Misiones de Hinata"
    new "Hinata Quests"

    # game/scripts/Systems/Phone/new_phone.rpy:114
    old "Misiones de Ino"
    new "Ino Quests"

    # game/scripts/Systems/Phone/new_phone.rpy:118
    old "Misiones de Tenten"
    new "Tenten Quests"

    # game/scripts/Systems/Phone/new_phone.rpy:122
    old "Misiones de Yuli"
    new "Yuli Quests"

    # game/scripts/Systems/Phone/new_phone.rpy:126
    old "Hanna Quests"
    new "Hanna Quests"

    # game/scripts/Systems/Phone/new_phone.rpy:130
    old "Misiones Varias"
    new "Other Quests"

    # game/scripts/Systems/Phone/new_phone.rpy:148
    old "{b}{color=#f9d17c}Exp Gain{/a}{/b}:[quest.gain_exp]"
    new "{b}{color=#f9d17c}Exp Gain{/a}{/b}:[quest.gain_exp]"

    # game/scripts/Systems/Phone/new_phone.rpy:191
    old "Selecciona un Chat"
    new "Select a Chat"

    # game/scripts/Systems/Phone/new_phone.rpy:288
    old "[chat.by]"
    new "[chat.by]"

    # game/scripts/Systems/Phone/new_phone.rpy:366
    old "{color=#87e887}Feliz{/a}"
    new "{color=#87e887}Happy{/a}"

    # game/scripts/Systems/Phone/new_phone.rpy:368
    old "Normal"
    new "Normal"

    # game/scripts/Systems/Phone/new_phone.rpy:370
    old "{color=#ebd967}Irritada{/a}"
    new "{color=#ebd967}Irritated{/a}"

    # game/scripts/Systems/Phone/new_phone.rpy:372
    old "{color=#eb6363}Molesta{/a}"
    new "{color=#eb6363}Angry{/a}"

    # game/scripts/Systems/Phone/new_phone.rpy:374
    old "{color=#fc608f}Caliente{/a}"
    new "{color=#fc608f}Hot{/a}"

# TODO: Translation updated at 2024-12-01 21:25

translate english strings:

    # game/scripts/Systems/Phone/new_phone.rpy:365
    old "Estado: "
    new "State: "
