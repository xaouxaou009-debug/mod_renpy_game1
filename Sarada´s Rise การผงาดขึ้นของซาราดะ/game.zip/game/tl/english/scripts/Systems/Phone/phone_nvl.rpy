# TODO: Translation updated at 2024-12-22 11:36

# game/scripts/Systems/Phone/phone_nvl.rpy:169
translate english nvl_239bd270:

    # mn "hola"
    mn ""

# game/scripts/Systems/Phone/phone_nvl.rpy:170
translate english nvl_9e8b13a2:

    # mn "vamos a probar esta mamada"
    mn ""

# game/scripts/Systems/Phone/phone_nvl.rpy:171
translate english nvl_08204d08:

    # nvl_narrator "[MN] entró al grupo"
    nvl_narrator ""

# game/scripts/Systems/Phone/phone_nvl.rpy:172
translate english nvl_bcc6a2f9:

    # mn_nvl "Hola Aqua, ¿Cómo estás?"
    mn_nvl ""

# game/scripts/Systems/Phone/phone_nvl.rpy:173
translate english nvl_b7530631:

    # nvl_narrator "Aqua entró al grupo"
    nvl_narrator ""

# game/scripts/Systems/Phone/phone_nvl.rpy:174
translate english nvl_2cb7f6ce:

    # aq_nvl "¿Qué quieres?"
    aq_nvl ""

# game/scripts/Systems/Phone/phone_nvl.rpy:175
translate english nvl_73fc0a0b:

    # aq_nvl "Estoy ocupada"
    aq_nvl ""

# game/scripts/Systems/Phone/phone_nvl.rpy:176
translate english nvl_c04ded96:

    # mn_nvl "¿Me mandas una foto?"
    mn_nvl ""

# game/scripts/Systems/Phone/phone_nvl.rpy:177
translate english nvl_aeda13d5:

    # aq_nvl "¿Qué? Obvio no"
    aq_nvl ""

# game/scripts/Systems/Phone/phone_nvl.rpy:178
translate english nvl_5667a827:

    # mn_nvl "Vamos, ¿Acaso no me extrañas?"
    mn_nvl ""

# game/scripts/Systems/Phone/phone_nvl.rpy:179
translate english nvl_45c96db5:

    # aq_nvl "Eso no tiene nada que ver"
    aq_nvl ""

# game/scripts/Systems/Phone/phone_nvl.rpy:180
translate english nvl_cf9132ce:

    # aq_nvl "No te enviaré una foto"
    aq_nvl ""

# game/scripts/Systems/Phone/phone_nvl.rpy:181
translate english nvl_1e793858:

    # mn_nvl "Vamos, ¿Estás segura que no quieres?"
    mn_nvl ""

# game/scripts/Systems/Phone/phone_nvl.rpy:182
translate english nvl_7af02a19:

    # aq_nvl "..."
    aq_nvl ""

# game/scripts/Systems/Phone/phone_nvl.rpy:183
translate english nvl_968f9e28:

    # aq_nvl "Bien, pero esta es la última"
    aq_nvl ""

# game/scripts/Systems/Phone/phone_nvl.rpy:184
translate english nvl_fac854cf:

    # aq_nvl "{image=gui/phone/Photos/aqua_selfie.png}"
    aq_nvl ""

# game/scripts/Systems/Phone/phone_nvl.rpy:185
translate english nvl_9fff4f6e:

    # mn_nvl "Gracias, la cuidaré muy bien"
    mn_nvl ""

# game/scripts/Systems/Phone/phone_nvl.rpy:186
translate english nvl_deffd1f8:

    # nvl_narrator "Bulma entró al grupo"
    nvl_narrator ""

# game/scripts/Systems/Phone/phone_nvl.rpy:187
translate english nvl_cde063de:

    # bu_nvl "Aqua, ¿Qué haces enviando eso?"
    bu_nvl ""

# game/scripts/Systems/Phone/phone_nvl.rpy:188
translate english nvl_75eb8fa4:

    # aq_nvl "¿TÚ QUÉ HACES AQUÍ?"
    aq_nvl ""

