# TODO: Translation updated at 2024-12-01 23:05

translate english strings:

    # game/scripts/Systems/Collection/Collection_Screen.rpy:9
    old "Colección"
    new "คอลเลกชัน"

