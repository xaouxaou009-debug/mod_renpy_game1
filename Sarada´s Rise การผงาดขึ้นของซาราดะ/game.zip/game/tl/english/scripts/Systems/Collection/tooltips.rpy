# TODO: Translation updated at 2024-12-01 23:05

translate english strings:

    # game/scripts/Systems/Collection/tooltips.rpy:1
    old "Ropa Interior de Ayame"
    new "ชุดชั้นในของอายาเมะ"

    # game/scripts/Systems/Collection/tooltips.rpy:2
    old "Ropa Interior blanca, de estilo simple, eran de Ayame y, por alguna razón me las dió..."
    new "ชุดชั้นในสีขาว ดีไซน์เรียบง่าย เป็นของอายาเมะ และด้วยเหตุผลบางอย่างเธอก็เลยมอบมันให้กับฉัน..."

    # game/scripts/Systems/Collection/tooltips.rpy:4
    old "Espada Vieja"
    new "ดาบเก่า"

    # game/scripts/Systems/Collection/tooltips.rpy:5
    old "Es la antigua espada que usaba desde hace años, fue la primer espada que fabricó Tenten para mí, pero la última que me hizo Tenten es muy superior a esta..."
    new "นี่คือดาบเล่มเก่าที่ฉันใช้มาหลายปี มันเป็นดาบเล่มแรกที่เท็นเท็นทำ​ให้ฉัน แต่เล่มล่าสุดที่เธอทำให้นั้นเหนือกว่านี้มาก..."

    # game/scripts/Systems/Collection/tooltips.rpy:7
    old "Ropa Vieja"
    new "ชุดเก่า"

    # game/scripts/Systems/Collection/tooltips.rpy:8
    old "La ropa vieja que usaba antes de que Yuli me hiciera ropa nueva, me ha servido desde que empecé este camino ninja hace unos años... Me sirvió mucho, aguantó muchos (demasiados) golpes de Yuna..."
    new "เสื้อผ้าเก่าที่ฉันใส่ก่อนที่ยูริจะตัดชุดใหม่ให้ มันอยู่รับใช้ฉันมาตั้งแต่เริ่มเดินบนเส้นทางนินจานี้เมื่อไม่กี่ปีមុន... มีประโยชน์มากทีเดียว ทนมือทนเท้า (และโดนอัดซะเละเทะเกินไปหน่อย) จากยูนะมาก็เยอะ..."

