# TODO: Translation updated at 2024-12-01 23:05

translate english strings:

    # game/scripts/Systems/Collection/PantiesCollection.rpy:19
    old "¡Nuevo Objeto a la Colección!"
    new "เพิ่มไอเทมใหม่ลงในคอลเลกชันแล้ว!"

