# TODO: Translation updated at 2024-11-29 23:49

translate english strings:

    # game/scripts/Systems/Clothes/cloth_defines/himawari_cloth_defines.rpy:11
    old "Traje de Himawari (Sarada´s Rise)"
    new "ชุดของฮิมาวาริ (การผงาดขึ้นของซาราดะ)"

    # game/scripts/Systems/Clothes/cloth_defines/himawari_cloth_defines.rpy:12
    old "Cabello de Himawari"
    new "ทรงผมของฮิมาวาริ"

    # game/scripts/Systems/Clothes/cloth_defines/himawari_cloth_defines.rpy:13
    old "Camisa Amarilla Floreada (Sarada´s Rise)"
    new "เสื้อเชิ้ตลายดอกสีเหลือง (การผงาดขึ้นของซาราดะ)"

    # game/scripts/Systems/Clothes/cloth_defines/himawari_cloth_defines.rpy:14
    old "Short Blanco"
    new "กางเกงขาสั้นสีขาว"

    # game/scripts/Systems/Clothes/cloth_defines/himawari_cloth_defines.rpy:15
    old "Medias Negras"
    new "ถุงน่องสีดำ"

    # game/scripts/Systems/Clothes/cloth_defines/himawari_cloth_defines.rpy:16
    old "Calzado Ninja"
    new "รองเท้านินจา"

    # game/scripts/Systems/Clothes/cloth_defines/himawari_cloth_defines.rpy:17
    old "Sostén Floreado"
    new "เสื้อชั้นในลายดอกไม้"

    # game/scripts/Systems/Clothes/cloth_defines/himawari_cloth_defines.rpy:18
    old "Panties Floreados"
    new "กางเกงในลายดอกไม้"

