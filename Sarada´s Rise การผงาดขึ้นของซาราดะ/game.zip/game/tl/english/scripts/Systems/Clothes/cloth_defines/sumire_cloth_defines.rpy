# TODO: Translation updated at 2024-11-29 23:49

translate english strings:

    # game/scripts/Systems/Clothes/cloth_defines/sumire_cloth_defines.rpy:11
    old "Vestido Violeta (Time Skip)"
    new "ชุดเดรสสีม่วง (ไทม์สคิป)"

    # game/scripts/Systems/Clothes/cloth_defines/sumire_cloth_defines.rpy:12
    old "Doble Trenza (Time Skip)"
    new "เปียคู่ (ไทม์สคิป)"

    # game/scripts/Systems/Clothes/cloth_defines/sumire_cloth_defines.rpy:14
    old "Short Negro (Time Skip)"
    new "กางเกงขาสั้นสีดำ (ไทม์สคิป)"

    # game/scripts/Systems/Clothes/cloth_defines/sumire_cloth_defines.rpy:15
    old "Sin Medias"
    new "ไม่ใส่ถุงน่อง"

    # game/scripts/Systems/Clothes/cloth_defines/sumire_cloth_defines.rpy:16
    old "Botas Altas (Time Skip)"
    new "รองเท้าบูทสูง (ไทม์สคิป)"

    # game/scripts/Systems/Clothes/cloth_defines/sumire_cloth_defines.rpy:17
    old "Sostén Violeta"
    new "ชุดชั้นในสีม่วง"

    # game/scripts/Systems/Clothes/cloth_defines/sumire_cloth_defines.rpy:18
    old "Panties Violetas"
    new "กางเกงในสีม่วง"

