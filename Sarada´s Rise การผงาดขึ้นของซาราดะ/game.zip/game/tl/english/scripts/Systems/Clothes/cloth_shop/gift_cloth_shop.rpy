

translate english strings:

    # game/scripts/Systems/Clothes/cloth_shop/gift_cloth_shop.rpy:16
    old "Fresa -50 ryu-"
    new "สตรอเบอร์รี่ -50 เรียว-"

    # game/scripts/Systems/Clothes/cloth_shop/gift_cloth_shop.rpy:16
    old "Una rica Fresa, quizás a alguna chica le guste."
    new "สตรอเบอร์รี่แสนอร่อย สาวๆ น่าจะชอบนะ"

    # game/scripts/Systems/Clothes/cloth_shop/gift_cloth_shop.rpy:18
    old "Rosa -50 ryu-"
    new "กุหลาบ -50 เรียว-"

    # game/scripts/Systems/Clothes/cloth_shop/gift_cloth_shop.rpy:20
    old "Margarita -50 ryu-"
    new "ดอกเดซี่ -50 เรียว-"

    # game/scripts/Systems/Clothes/cloth_shop/gift_cloth_shop.rpy:22
    old "Peluche de Naruto -150 ryu-"
    new "ตุ๊กตานารูโตะ -150 เรียว-"

    # game/scripts/Systems/Clothes/cloth_shop/gift_cloth_shop.rpy:24
    old "Peluche de Sasuke -150 ryu-"
    new "ตุ๊กตาซาสึเกะ -150 เรียว-"

    # game/scripts/Systems/Clothes/cloth_shop/gift_cloth_shop.rpy:26
    old "Peluche de Kakashi -150 ryu-"
    new "ตุ๊กตาคาคาชิ -150 เรียว-"

    # game/scripts/Systems/Clothes/cloth_shop/gift_cloth_shop.rpy:28
    old "Peluche de Pakkun -150 ryu-"
    new "ตุ๊กตาปักกุน -150 เรียว-"
