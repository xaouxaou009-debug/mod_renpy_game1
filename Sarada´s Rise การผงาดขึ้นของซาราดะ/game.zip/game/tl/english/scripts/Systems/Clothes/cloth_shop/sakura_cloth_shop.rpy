

translate english strings:

    # game/scripts/Systems/Clothes/cloth_shop/sakura_cloth_shop.rpy:17
    old "Traje Ninja de Sakura -Classic-"
    new "ชุดนินจาของซากุระ -คลาสสิก-"

    # game/scripts/Systems/Clothes/cloth_shop/sakura_cloth_shop.rpy:17
    old "Traje Ninja que usó Sakura cuando era joven."
    new "ชุดนินจาที่ซากุระสวมตอนยังเด็ก"

    # game/scripts/Systems/Clothes/cloth_shop/sakura_cloth_shop.rpy:20
    old "Traje Ninja de Sakura -Shippuden-"
    new "ชุดนินจาของซากุระ -ตำนานวายุสลาตัน-"

    # game/scripts/Systems/Clothes/cloth_shop/sakura_cloth_shop.rpy:20
    old "Traje Ninja que usó Sakura antes de la Guerra."
    new "ชุดนินจาที่ซากุระสวมก่อนเกิดสงคราม"

    # game/scripts/Systems/Clothes/cloth_shop/sakura_cloth_shop.rpy:23
    old "Traje Ninja de Sakura -The Last-"
    new "ชุดนินจาของซากุระ -เดอะ ลาสต์-"

    # game/scripts/Systems/Clothes/cloth_shop/sakura_cloth_shop.rpy:23
    old "Traje Ninja que usó Sakura después de la Guerra."
    new "ชุดนินจาที่ซากุระสวมหลังจากสงครามสิ้นสุดลง"

    # game/scripts/Systems/Clothes/cloth_shop/sakura_cloth_shop.rpy:26
    old "Bikini Rosa"
    new "บิกินี่สีชมพู"

    # game/scripts/Systems/Clothes/cloth_shop/sakura_cloth_shop.rpy:26
    old "Un hermoso bikini Rosa, ¡Perfecto para Sakura!"
    new "บิกินี่สีชมพูสุดสวย เหมาะสำหรับซากุระสุดๆ!"


translate english strings:

    # game/scripts/Systems/Clothes/cloth_shop/sakura_cloth_shop.rpy:17
    old "Traje Ninja de Sakura -Classic- 1000 ryu"
    new "ชุดนินจาของซากุระ -คลาสสิก- 1000 รู"

    # game/scripts/Systems/Clothes/cloth_shop/sakura_cloth_shop.rpy:20
    old "Traje Ninja de Sakura -Shippuden- 1000 ryu"
    new "ชุดนินจาของซากุระ -ตำนานวายุสลาตัน- 1000 รู"

    # game/scripts/Systems/Clothes/cloth_shop/sakura_cloth_shop.rpy:23
    old "Traje Ninja de Sakura -The Last- 1000 ryu"
    new "ชุดนินจาของซากุระ -เดอะ ลาสต์- 1000 รู"

    # game/scripts/Systems/Clothes/cloth_shop/sakura_cloth_shop.rpy:26
    old "Bikini Rosa -2000-"
    new "บิกินี่สีชมพู -2000 รู-"
