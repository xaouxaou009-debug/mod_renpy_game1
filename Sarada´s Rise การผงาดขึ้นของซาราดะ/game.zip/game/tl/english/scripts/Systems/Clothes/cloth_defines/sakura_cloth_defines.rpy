# TODO: Translation updated at 2024-11-29 23:49

translate english strings:

    # game/scripts/Systems/Clothes/cloth_defines/sakura_cloth_defines.rpy:10
    old "Ropa de Sakura (Boruto)"
    new "ชุดของซากุระ (โบรูโตะ)"

    # game/scripts/Systems/Clothes/cloth_defines/sakura_cloth_defines.rpy:11
    old "Cabello Corto (Boruto)"
    new "ผมสั้น (โบรูโตะ)"

    # game/scripts/Systems/Clothes/cloth_defines/sakura_cloth_defines.rpy:12
    old "Vestido Rojo (Boruto)"
    new "ชุดเดรสสีแดง (โบรูโตะ)"

    # game/scripts/Systems/Clothes/cloth_defines/sakura_cloth_defines.rpy:13
    old "Pantalones Blancos (Boruto)"
    new "กางเกงขายาวสีขาว (โบรูโตะ)"

    # game/scripts/Systems/Clothes/cloth_defines/sakura_cloth_defines.rpy:14
    old "Zapatos de Andar (Boruto)"
    new "รองเท้าเดิน (โบรูโตะ)"

    # game/scripts/Systems/Clothes/cloth_defines/sakura_cloth_defines.rpy:15
    old "Sostén Blanco"
    new "เสื้อชั้นในสีขาว"

    # game/scripts/Systems/Clothes/cloth_defines/sakura_cloth_defines.rpy:16
    old "Panties Blancos"
    new "กางเกงในสีขาว"

    # game/scripts/Systems/Clothes/cloth_defines/sakura_cloth_defines.rpy:25
    old "Cabello Corto (Clásico)"
    new "ผมสั้น (คลาสสิก)"

    # game/scripts/Systems/Clothes/cloth_defines/sakura_cloth_defines.rpy:26
    old "Vestido Ninja (Clásico)"
    new "ชุดนินจา (คลาสสิก)"

    # game/scripts/Systems/Clothes/cloth_defines/sakura_cloth_defines.rpy:27
    old "Shorts Verdes (Clásico)"
    new "กางเกงขาสั้นสีเขียว (คลาสสิก)"

    # game/scripts/Systems/Clothes/cloth_defines/sakura_cloth_defines.rpy:28
    old "Calzado Ninja (Clásico)"
    new "รองเท้านินจา (คลาสสิก)"

    # game/scripts/Systems/Clothes/cloth_defines/sakura_cloth_defines.rpy:36
    old "Traje Ninja (The Last)"
    new "ชุดนินจา (เดอะ ลาสต์)"

    # game/scripts/Systems/Clothes/cloth_defines/sakura_cloth_defines.rpy:37
    old "Cabello Corto (The Last)"
    new "ผมสั้น (เดอะ ลาสต์)"

    # game/scripts/Systems/Clothes/cloth_defines/sakura_cloth_defines.rpy:38
    old "Camisa Ninja (The Last)"
    new "เสื้อนินจา (เดอะ ลาสต์)"

    # game/scripts/Systems/Clothes/cloth_defines/sakura_cloth_defines.rpy:39
    old "Sorts Negros (The Last)"
    new "กางเกงขาสั้นสีดำ (เดอะ ลาสต์)"

    # game/scripts/Systems/Clothes/cloth_defines/sakura_cloth_defines.rpy:40
    old "Calzado Ninja (The Last)"
    new "รองเท้านินจา (เดอะ ลาสต์)"

    # game/scripts/Systems/Clothes/cloth_defines/sakura_cloth_defines.rpy:49
    old "Cabello Corto (Shippuden)"
    new "ผมสั้น (ตำนานวายุสลาตัน)"

    # game/scripts/Systems/Clothes/cloth_defines/sakura_cloth_defines.rpy:50
    old "Camisa Ninja (Shippuden)"
    new "เสื้อนินจา (ตำนานวายุสลาตัน)"

    # game/scripts/Systems/Clothes/cloth_defines/sakura_cloth_defines.rpy:51
    old "Shorts Negros (Shippuden)"
    new "กางเกงขาสั้นสีดำ (ตำนานวายุสลาตัน)"

    # game/scripts/Systems/Clothes/cloth_defines/sakura_cloth_defines.rpy:52
    old "Calzado Ninja (Shippuden)"
    new "รองเท้านินจา (ตำนานวายุสลาตัน)"

