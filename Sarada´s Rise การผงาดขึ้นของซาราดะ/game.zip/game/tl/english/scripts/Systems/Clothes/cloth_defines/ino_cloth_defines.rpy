# TODO: Translation updated at 2024-11-29 23:49

translate english strings:

    # game/scripts/Systems/Clothes/cloth_defines/ino_cloth_defines.rpy:10
    old "Traje de Ino (The Last)"
    new "ชุดของอิโนะ (เดอะ ลาสต์)"

    # game/scripts/Systems/Clothes/cloth_defines/ino_cloth_defines.rpy:11
    old "Cabello de Ino (The Last)"
    new "ทรงผมของอิโนะ (เดอะ ลาสต์)"

    # game/scripts/Systems/Clothes/cloth_defines/ino_cloth_defines.rpy:12
    old "Camisa Violeta (The Last)"
    new "เสื้อเชิ้ตสีม่วง (เดอะ ลาสต์)"

    # game/scripts/Systems/Clothes/cloth_defines/ino_cloth_defines.rpy:13
    old "Falda Larga (The Last)"
    new "กระโปรงยาว (เดอะ ลาสต์)"

    # game/scripts/Systems/Clothes/cloth_defines/ino_cloth_defines.rpy:14
    old "Botas Ninja (The Last)"
    new "รองเท้าบูตนินจา (เดอะ ลาสต์)"

    # game/scripts/Systems/Clothes/cloth_defines/ino_cloth_defines.rpy:15
    old "Sostén Violeta (The Last)"
    new "เสื้อชั้นในสีม่วง (เดอะ ลาสต์)"

    # game/scripts/Systems/Clothes/cloth_defines/ino_cloth_defines.rpy:16
    old "Zapatos Violetas (The Last)"
    new "รองเท้าสีม่วง (เดอะ ลาสต์)"

    # game/scripts/Systems/Clothes/cloth_defines/ino_cloth_defines.rpy:25
    old "Traje de Ino (Boruto)"
    new "ชุดของอิโนะ (โบรูโตะ)"

    # game/scripts/Systems/Clothes/cloth_defines/ino_cloth_defines.rpy:26
    old "Cabello de Ino (Boruto)"
    new "ทรงผมของอิโนะ (โบรูโตะ)"

    # game/scripts/Systems/Clothes/cloth_defines/ino_cloth_defines.rpy:27
    old "Camisa Violeta  (Boruto)"
    new "เสื้อเชิ้ตสีม่วง (โบรูโตะ)"

    # game/scripts/Systems/Clothes/cloth_defines/ino_cloth_defines.rpy:28
    old "Falda Larga (Boruto)"
    new "กระโปรงยาว (โบรูโตะ)"

    # game/scripts/Systems/Clothes/cloth_defines/ino_cloth_defines.rpy:29
    old "Sandalias Simples (Boruto)"
    new "รองเท้าแตะธรรมดา (โบรูโตะ)"

    # game/scripts/Systems/Clothes/cloth_defines/ino_cloth_defines.rpy:38
    old "Traje Ninja (Shippuden)"
    new "ชุดนินจา (ตำนานวายุสลาตัน)"

    # game/scripts/Systems/Clothes/cloth_defines/ino_cloth_defines.rpy:39
    old "Cabello de Ino (Shippuden)"
    new "ทรงผมของอิโนะ (ตำนานวายุสลาตัน)"

    # game/scripts/Systems/Clothes/cloth_defines/ino_cloth_defines.rpy:40
    old "Camisa Violeta  (Shippuden)"
    new "เสื้อเชิ้ตสีม่วง (ตำนานวายุสลาตัน)"

    # game/scripts/Systems/Clothes/cloth_defines/ino_cloth_defines.rpy:41
    old "Falda Corta (Shippuden)"
    new "กระโปรงสั้น (ตำนานวายุสลาตัน)"

    # game/scripts/Systems/Clothes/cloth_defines/ino_cloth_defines.rpy:42
    old "Zapatos Ninja (Shippuden)"
    new "รองเท้านินจา (ตำนานวายุสลาตัน)"

    # game/scripts/Systems/Clothes/cloth_defines/ino_cloth_defines.rpy:53
    old "Traje Ninja (Clásico)"
    new "ชุดนินจา (คลาสสิก)"

    # game/scripts/Systems/Clothes/cloth_defines/ino_cloth_defines.rpy:54
    old "Cabello de Ino (Clásico)"
    new "ทรงผมของอิโนะ (คลาสสิก)"

    # game/scripts/Systems/Clothes/cloth_defines/ino_cloth_defines.rpy:55
    old "Camisa Violeta (Clásico)"
    new "เสื้อเชิ้ตสีม่วง (คลาสสิก)"

    # game/scripts/Systems/Clothes/cloth_defines/ino_cloth_defines.rpy:56
    old "Falda Corta (Clásico)"
    new "กระโปรงสั้น (คลาสสิก)"

    # game/scripts/Systems/Clothes/cloth_defines/ino_cloth_defines.rpy:57
    old "Zapatos Ninja (Clásico)"
    new "รองเท้านินจา (คลาสสิก)"

    # game/scripts/Systems/Clothes/cloth_defines/ino_cloth_defines.rpy:58
    old "Bendajes (Clásico)"
    new "ผ้าพันแผล (คลาสสิก)"

    # game/scripts/Systems/Clothes/cloth_defines/ino_cloth_defines.rpy:66
    old "Bikini de Ino"
    new "บิกินีของอิโนะ"

    # game/scripts/Systems/Clothes/cloth_defines/ino_cloth_defines.rpy:67
    old "Bikini"
    new "บิกินี"

