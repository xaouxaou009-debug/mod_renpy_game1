

translate english strings:

    # game/scripts/Systems/Clothes/cloth_shop/sarada_cloth_shop.rpy:17
    old "Traje Clásico de Sarada"
    new "ชุดคลาสสิกของซาราดะ"

    # game/scripts/Systems/Clothes/cloth_shop/sarada_cloth_shop.rpy:17
    old "Traje que usaba Sarada cuando era joven."
    new "ชุดที่ซาราดะเคยใส่ตอนยังเด็ก"

    # game/scripts/Systems/Clothes/cloth_shop/sarada_cloth_shop.rpy:20
    old "Traje del Time Skip"
    new "ชุดหลังไทม์สคิป"

    # game/scripts/Systems/Clothes/cloth_shop/sarada_cloth_shop.rpy:20
    old "Traje que usó Sarada luego del Time Skip."
    new "ชุดที่ซาราดะสวมใส่หลังช่วงไทม์สคิป"

    # game/scripts/Systems/Clothes/cloth_shop/sarada_cloth_shop.rpy:23
    old "Vesdido de Maid"
    new "ชุดเมด"

    # game/scripts/Systems/Clothes/cloth_shop/sarada_cloth_shop.rpy:23
    old "Un hermoso vestido de Maid para Sarada."
    new "ชุดเมดสุดสวยสำหรับซาราดะ"

    # game/scripts/Systems/Clothes/cloth_shop/sarada_cloth_shop.rpy:26
    old "Bikini Rojo y Negro"
    new "บิกินีสีแดงและดำ"

    # game/scripts/Systems/Clothes/cloth_shop/sarada_cloth_shop.rpy:26
    old "Un Bikini para Sarada, ¡Le quedaría Hermoso!."
    new "ชุดบิกินีสำหรับซาราดะ ใส่แล้วต้องสวยมากแน่ๆ!"

    # game/scripts/Systems/Clothes/cloth_shop/sarada_cloth_shop.rpy:29
    old "Traje de Navidad"
    new "ชุดคริสต์มาส"

    # game/scripts/Systems/Clothes/cloth_shop/sarada_cloth_shop.rpy:29
    old "Traje de Navidad, perfecto para Sarada."
    new "ชุดคริสต์มาส เหมาะสำหรับซาราดะที่สุด"


translate english strings:

    # game/scripts/Systems/Clothes/cloth_shop/sarada_cloth_shop.rpy:17
    old "Traje Clásico de Sarada -1000 ryu-"
    new "ชุดคลาสสิกของซาราดะ -1,000 เรียว-"

    # game/scripts/Systems/Clothes/cloth_shop/sarada_cloth_shop.rpy:20
    old "Traje del Time Skip -1000 ryu-"
    new "ชุดหลังไทม์สคิป -1,000 เรียว-"

    # game/scripts/Systems/Clothes/cloth_shop/sarada_cloth_shop.rpy:23
    old "Vesdido de Maid -1000 ryu-"
    new "ชุดเมด -1,000 เรียว-"

    # game/scripts/Systems/Clothes/cloth_shop/sarada_cloth_shop.rpy:26
    old "Bikini Rojo y Negro -2000 ryu-"
    new "บิกินีสีแดงและดำ -2,000 เรียว-"

    # game/scripts/Systems/Clothes/cloth_shop/sarada_cloth_shop.rpy:29
    old "Traje de Navidad -1000 ryu-"
    new "ชุดคริสต์มาส -1,000 เรียว-"
