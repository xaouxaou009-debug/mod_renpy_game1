# TODO: Translation updated at 2024-11-29 23:49

translate english strings:

    # game/scripts/Systems/Clothes/cloth_defines/hanna_cloth_defines.rpy:11
    old "Traje de Recepcionista"
    new "ชุดต้อนรับส่วนหน้า"

    # game/scripts/Systems/Clothes/cloth_defines/hanna_cloth_defines.rpy:12
    old "Coletas"
    new "ผมแกะคู่"

    # game/scripts/Systems/Clothes/cloth_defines/hanna_cloth_defines.rpy:13
    old "Ropa de Recepcionista"
    new "ชุดพนักงานต้อนรับ"

    # game/scripts/Systems/Clothes/cloth_defines/hanna_cloth_defines.rpy:15
    old "Pantimedias"
    new "ถุงน่อง"

    # game/scripts/Systems/Clothes/cloth_defines/hanna_cloth_defines.rpy:16
    old "Zapatos de Recepcionista"
    new "รองเท้าพนักงานต้อนรับ"

    # game/scripts/Systems/Clothes/cloth_defines/hanna_cloth_defines.rpy:17
    old "Sostén Azul"
    new "ชุดชั้นในสีฟ้า"

    # game/scripts/Systems/Clothes/cloth_defines/hanna_cloth_defines.rpy:18
    old "Panties Azules"
    new "กางเกงในสีฟ้า"

# TODO: Translation updated at 2024-12-20 07:52

translate english strings:

    # game/scripts/Systems/Clothes/cloth_defines/hanna_cloth_defines.rpy:14
    old "Nada"
    new "ไม่มี"
