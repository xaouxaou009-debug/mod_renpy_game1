# TODO: Translation updated at 2024-11-29 23:49

translate english strings:

    # game/scripts/Systems/Clothes/cloth_defines/sarada_cloth_defines.rpy:13
    old "Traje Ninja (Sarada´s Rise)"
    new "ชุดนินจา (การผงาดขึ้นของซาราดะ)"

    # game/scripts/Systems/Clothes/cloth_defines/sarada_cloth_defines.rpy:14
    old "Cabello Largo"
    new "ผมยาว"

    # game/scripts/Systems/Clothes/cloth_defines/sarada_cloth_defines.rpy:15
    old "Lentes Rojos"
    new "แว่นตาสีแดง"

    # game/scripts/Systems/Clothes/cloth_defines/sarada_cloth_defines.rpy:16
    old "Camisa Ninja (Sarada´s Rise)"
    new "เสื้อนินจา (การผงาดขึ้นของซาราดะ)"

    # game/scripts/Systems/Clothes/cloth_defines/sarada_cloth_defines.rpy:17
    old "Shorts Ninja (Sarada´s Rise)"
    new "กางเกงขาสั้นนินจา (การผงาดขึ้นของซาราดะ)"

    # game/scripts/Systems/Clothes/cloth_defines/sarada_cloth_defines.rpy:18
    old "Medias Ninja (Sarada´s Rise)"
    new "ถุงเท้ายาวนินจา (การผงาดขึ้นของซาราดะ)"

    # game/scripts/Systems/Clothes/cloth_defines/sarada_cloth_defines.rpy:19
    old "Botas Ninja (Sarada´s Rise)"
    new "รองเท้าบูตินินจา (การผงาดขึ้นของซาราดะ)"

    # game/scripts/Systems/Clothes/cloth_defines/sarada_cloth_defines.rpy:33
    old "Shorts Ninja (Clásico)"
    new "กางเกงขาสั้นนินจา (คลาสสิก)"

    # game/scripts/Systems/Clothes/cloth_defines/sarada_cloth_defines.rpy:34
    old "Medias Ninja (Clásico)"
    new "ถุงเท้ายาวนินจา (คลาสสิก)"

    # game/scripts/Systems/Clothes/cloth_defines/sarada_cloth_defines.rpy:46
    old "Uniforme de Maid"
    new "ชุดเมด"

    # game/scripts/Systems/Clothes/cloth_defines/sarada_cloth_defines.rpy:47
    old "Cabello con Lazo de Maid"
    new "ผมประดับโบเมด"

    # game/scripts/Systems/Clothes/cloth_defines/sarada_cloth_defines.rpy:49
    old "Falda interior de Maid"
    new "กระโปรงซับในเมด"

    # game/scripts/Systems/Clothes/cloth_defines/sarada_cloth_defines.rpy:50
    old "Medias de Maid"
    new "ถุงเท้ายาวเมด"

    # game/scripts/Systems/Clothes/cloth_defines/sarada_cloth_defines.rpy:51
    old "Zapatos de Maid"
    new "รองเท้าเมด"

    # game/scripts/Systems/Clothes/cloth_defines/sarada_cloth_defines.rpy:52
    old "Sostén de Maid"
    new "ชุดชั้นในเมด"

    # game/scripts/Systems/Clothes/cloth_defines/sarada_cloth_defines.rpy:53
    old "Panties de Maid"
    new "กางเกงในเมด"

    # game/scripts/Systems/Clothes/cloth_defines/sarada_cloth_defines.rpy:64
    old "Lentes Plateados (TS)"
    new "แว่นตาสีเงิน (TS)"

    # game/scripts/Systems/Clothes/cloth_defines/sarada_cloth_defines.rpy:65
    old "Cabello Corto (TS)"
    new "ผมสั้น (TS)"

    # game/scripts/Systems/Clothes/cloth_defines/sarada_cloth_defines.rpy:66
    old "Sudadera Negra (TS)"
    new "เสื้อกันหนาวมีฮู้ดสีดำ (TS)"

    # game/scripts/Systems/Clothes/cloth_defines/sarada_cloth_defines.rpy:67
    old "Traje Negro (TS)"
    new "ชุดสูทสีดำ (TS)"

    # game/scripts/Systems/Clothes/cloth_defines/sarada_cloth_defines.rpy:68
    old "Porta Kunai (TS)"
    new "ซองใส่คุไน (TS)"

    # game/scripts/Systems/Clothes/cloth_defines/sarada_cloth_defines.rpy:69
    old "Zapatos con Tacón Alto (TS)"
    new "รองเท้าส้นสูง (TS)"

    # game/scripts/Systems/Clothes/cloth_defines/sarada_cloth_defines.rpy:85
    old "Gorro de Navidad"
    new "หมวกคริสต์มาส"

    # game/scripts/Systems/Clothes/cloth_defines/sarada_cloth_defines.rpy:86
    old "Vestido de Navidad"
    new "ชุดเดรสคริสต์มาส"

    # game/scripts/Systems/Clothes/cloth_defines/sarada_cloth_defines.rpy:87
    old "Shorts Negros de Licra"
    new "กางเกงขาสั้นไลคร่าสีดำ"

    # game/scripts/Systems/Clothes/cloth_defines/sarada_cloth_defines.rpy:88
    old "Zapatos de Navidad"
    new "รองเท้าคริสต์มาส"

# TODO: Translation updated at 2024-12-20 07:52

translate english strings:

    # game/scripts/Systems/Clothes/cloth_defines/sarada_cloth_defines.rpy:48
    old "Vestido de Maid"
    new "ชุดเดรสเมด"
