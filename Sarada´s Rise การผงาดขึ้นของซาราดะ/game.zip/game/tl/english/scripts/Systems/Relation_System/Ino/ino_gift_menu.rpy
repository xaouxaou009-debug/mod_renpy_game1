﻿# TODO: Translation updated at 2024-11-29 23:49

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:8
translate english ino_gift_like1_0f4fda71:

    # ino "¿Para mí?" with dissolve1
    ino "For me?" with dissolve1

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:10
translate english ino_gift_like1_c91d4c04:

    # ino "Gracias por el detalle"
    ino "Thanks for the gesture"

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:17
translate english ino_gift_like2_34d464e8:

    # ino "Esto, ¿Es para mí?" with vpunch
    ino "This, is it for me?" with vpunch

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:19
translate english ino_gift_like2_bd29a7b1:

    # ino "¿De verdad? ¡Muchísimas gracias!"
    ino "Really? Thank you so much!"

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:21
translate english ino_gift_like2_fe115a46:

    # ino "Hoy me has alegrado el día"
    ino "You've made my day today"

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:27
translate english ino_gift_nolike_d03ed502:

    # ino "Mmm, ¿Es para mí?" with dissolve1
    ino "Hmm, is it for me?" with dissolve1

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:28
translate english ino_gift_nolike_e6891ade:

    # ino "Bueno... Lo aceptaré..."
    ino "Well... I'll accept it..."

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:35
translate english ino_gift_no_friendly_level_ef25373c:

    # ino "Lo siento... Aún no puedo aceptarlo"
    ino "I'm sorry... I still can't accept it"

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:36
translate english ino_gift_no_friendly_level_138dcf6c:

    # ino "Podémos seguir conociéndonos un poco más"
    ino "We can keep getting to know each other a bit more"

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:42
translate english ino_gift_boruto_609c9348:

    # ino "Oh, pero qué observador, sabía que tenías buen ojo, este traje me gustaba mucho..." with dissolve1
    ino "Oh, how observant, I knew you had a good eye, I liked this outfit a lot..." with dissolve1

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:43
translate english ino_gift_boruto_99f48ab8:

    # ino "Es bastante cómodo para andar"
    ino "It's quite comfortable to wear"

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:45
translate english ino_gift_boruto_68e13956:

    # ino "Ahora... ¿Vas a regalarme más trajes como este sólo para verme con ellos?"
    ino "Now... are you going to give me more outfits like this just to see me in them?"

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:46
translate english ino_gift_boruto_bc2130d2:

    # ino "Porque no me quejaría... Siempre que estés aquí para disfrutarlos conmigo"
    ino "Because I wouldn't complain... As long as you're here to enjoy them with me"

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:52
translate english ino_gift_shippuden_ffd04c78:

    # ino "Oh Dios! Este traje..."
    ino "Oh God! This outfit..."

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:54
translate english ino_gift_shippuden_df6e01c2:

    # ino "Es de cuando estaba en mis años dorados, cuando todo era peleas, misiones y era la más hermosa de la Aldea..."
    ino "It's from when I was in my golden years, when it was all about fights, missions, and I was the most beautiful in the village..."

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:56
translate english ino_gift_shippuden_bf65bc8d:

    # ino "Bueno, no todo cambia, sigo siendo la más hermosa, ¿Verdad?"
    ino "Well, not everything changes, I'm still the most beautiful, right?"

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:58
translate english ino_gift_shippuden_f345bb56:

    # mn "Por supuesto, eres una mujer muy hermosa jaja"
    mn "Of course, you're a very beautiful woman haha"

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:59
translate english ino_gift_shippuden_70cecbc6:

    # ino "¿Sabes? No estaría mal revivir esos días por un rato"
    ino "You know? It wouldn't be bad to relive those days for a while"

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:61
translate english ino_gift_shippuden_09bed29c:

    # ino "Ahora me vería aún mejor con este atuendo, tal vez debería ponérmelo y hacer que veas cómo lucía la chica más hermosa de Konoha"
    ino "Now I'd look even better in this outfit, maybe I should put it on and show you how the most beautiful girl in Konoha looked"

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:67
translate english ino_gift_classic_afa8132b:

    # ino "Vaya, no puedo creer que aún exista este conjunto, es de cuando era una Genin"
    ino "Wow, I can't believe this outfit still exists, it's from when I was a Genin"

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:69
translate english ino_gift_classic_569747f5:

    # ino "¿Sabes? Las vendas debajo siempre eran un reto"
    ino "You know? The bandages underneath were always a challenge"

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:71
translate english ino_gift_classic_46337d5c:

    # ino "¿Sabes lo difícil que era mantenerlas en su sitio? Aunque, claro, no me importaba mucho"
    ino "Do you know how hard it was to keep them in place? Although, of course, I didn't care much"

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:72
translate english ino_gift_classic_eaccfd50:

    # mn "Me imagino jaja... Espero te haya gustado"
    mn "I imagine haha... I hope you liked it"

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:74
translate english ino_gift_classic_f323ba0f:

    # ino "Así que, [MN]..."
    ino "So, [MN]..."

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:75
translate english ino_gift_classic_351bfcbd:

    # ino "¿Esto era solo un detalle, o estás esperando algo más cuando me lo pruebe?"
    ino "Was this just a gesture, or are you expecting something more when I try it on?"

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:76
translate english ino_gift_classic_054d0505:

    # ino "Porque ya te advierto, puedo hacer que este traje parezca mucho menos inocente..."
    ino "Because I'll warn you, I can make this outfit look much less innocent..."

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:77
translate english ino_gift_classic_5aaaf07a:

    # ino "Supongo que no te decepcionará, aunque no prometo que el resto de la ropa dure mucho cuando lo lleve puesto..."
    ino "I guess it won't disappoint you, although I can't promise the rest of the clothes will last long when I'm wearing it..."

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:83
translate english ino_gift_bikini_ab03f173:

    # ino "Vaya... [MN]..."
    ino "Wow... [MN]..."

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:84
translate english ino_gift_bikini_5d3d8c6a:

    # ino "¿Esta es tu forma de decirme que quieres verme más... Cómoda?"
    ino "Is this your way of telling me you want to see me more... Comfortable?"

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:85
translate english ino_gift_bikini_d8bb1079:

    # mn "No, este... Jaja..."
    mn "No, uh... Haha..."

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:88
translate english ino_gift_bikini_e1650e26:

    # ino "Si querías verme así podrías haberlo dicho antes..."
    ino "If you wanted to see me like this, you could've just said so earlier..."

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:91
translate english ino_gift_bikini_6a229462:

    # ino "Pero ya te aviso..."
    ino "But I'm warning you..."

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:92
translate english ino_gift_bikini_e5c2affc:

    # ino "Si lo hago, espero que seas capaz de manejar lo que vas a ver"
    ino "If I do it, I hope you can handle what you'll see."

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:93
translate english ino_gift_bikini_a9b50da4:

    # mn "C-Claro..."
    mn "O-Of course..."

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:95
translate english ino_gift_bikini_cfe47fd3:

    # ino "Supongo que esto significa que deberemos buscar una playa o un lugar tranquilo..."
    ino "I guess this means we need to find a beach or a quiet spot..."

# game/scripts/Systems/Relation_System/Ino/ino_gift_menu.rpy:97
translate english ino_gift_bikini_a4da186b:

    # ino "Cuando quieras solo dímelo"
    ino "Whenever you're ready, just let me know"

