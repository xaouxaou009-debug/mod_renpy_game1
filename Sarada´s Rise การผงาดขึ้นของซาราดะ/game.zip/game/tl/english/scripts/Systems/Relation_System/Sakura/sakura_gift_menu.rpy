# TODO: Translation updated at 2024-11-29 23:49

# game/scripts/Systems/Relation_System/Sakura/sakura_gift_menu.rpy:8
translate english sakura_gift_like1_d91ab96e:

    # sk "¿Para mí?" with dissolve1
    sk "ให้ฉันเหรอ?" with dissolve1

# game/scripts/Systems/Relation_System/Sakura/sakura_gift_menu.rpy:10
translate english sakura_gift_like1_ca3d23e1:

    # sk "Gracias"
    sk "ขอบคุณนะ"

# game/scripts/Systems/Relation_System/Sakura/sakura_gift_menu.rpy:16
translate english sakura_gift_like2_aca0e111:

    # sk "Vaya, ¿Para mí?" with vpunch
    sk "ว้าว ให้ฉันเหรอเนี่ย?" with vpunch

# game/scripts/Systems/Relation_System/Sakura/sakura_gift_menu.rpy:18
translate english sakura_gift_like2_73d58ccc:

    # sk "¡Muchas gracias!"
    sk "ขอบคุณมากๆ เลยนะ!"

# game/scripts/Systems/Relation_System/Sakura/sakura_gift_menu.rpy:20
translate english sakura_gift_like2_bd5dfe0e:

    # sk "La atesoraré mucho"
    sk "ฉันจะเก็บรักษาไว้อย่างดีเลยล่ะ"

# game/scripts/Systems/Relation_System/Sakura/sakura_gift_menu.rpy:26
translate english sakura_gift_nolike_06672513:

    # sk "Mmm, ¿Gracias?"
    sk "อืม... ขอบคุณเหรอ?"

# game/scripts/Systems/Relation_System/Sakura/sakura_gift_menu.rpy:32
translate english sakura_gift_no_friendly_level_f85f7f24:

    # sk "Mmmm, me temo que lo tengo que rechazar" with dissolve1
    sk "อืม... ฉันคงต้องปฏิเสธล่ะนะ" with dissolve1

# game/scripts/Systems/Relation_System/Sakura/sakura_gift_menu.rpy:33
translate english sakura_gift_no_friendly_level_4de4861a:

    # sk "No siento que sea adecuado que me des ese tipo de regalos..."
    sk "ฉันรู้สึกว่ามันไม่ค่อยเหมาะสมเท่าไหร่ที่คุณจะเอาของขวัญแบบนี้มาให้..."

# game/scripts/Systems/Relation_System/Sakura/sakura_gift_menu.rpy:38
translate english sakura_gift_classic_0552a2fd:

    # sk "¡Vaya!" with vpunch
    sk "ว้าว!" with vpunch

# game/scripts/Systems/Relation_System/Sakura/sakura_gift_menu.rpy:40
translate english sakura_gift_classic_00c2184a:

    # sk "¿Para mí? ¡Muchas Gracias!"
    sk "ให้ฉันเหรอ? ขอบคุณมากๆ เลยนะ!"

# game/scripts/Systems/Relation_System/Sakura/sakura_gift_menu.rpy:42
translate english sakura_gift_classic_d9341033:

    # sk "Es idéntica a la ropa que usaba cuando era joven"
    sk "เหมือนกับชุดที่ฉันเคยใส่ตอนเด็กๆ เลยล่ะ"

# game/scripts/Systems/Relation_System/Sakura/sakura_gift_menu.rpy:43
translate english sakura_gift_classic_f0c24833:

    # sk "Te lo agradezco mucho"
    sk "ซาบซึ้งใจจริงๆ เลย"

# game/scripts/Systems/Relation_System/Sakura/sakura_gift_menu.rpy:48
translate english sakura_gift_bikini_67a8d054:

    # sk "Vaya! ¿De verdad es para mí?" with vpunch
    sk "ว้าว! ให้ฉันจริงๆ เหรอเนี่ย?" with vpunch

# game/scripts/Systems/Relation_System/Sakura/sakura_gift_menu.rpy:49
translate english sakura_gift_bikini_e7486db5:

    # sk "Que bonito, justo estaba pensando en comprarme uno"
    sk "น่ารักจัง ฉันเพิ่งจะคิดอยากได้อยู่พอดีเลย"

# game/scripts/Systems/Relation_System/Sakura/sakura_gift_menu.rpy:51
translate english sakura_gift_bikini_094b8f3f:

    # sk "Lo usaré cuando pueda, muchas gracias"
    sk "ไว้มีโอกาสฉันจะใส่มันนะ ขอบคุณมากๆ เลยล่ะ"

