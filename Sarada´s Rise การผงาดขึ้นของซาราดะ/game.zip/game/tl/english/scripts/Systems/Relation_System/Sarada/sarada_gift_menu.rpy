# TODO: Translation updated at 2024-11-29 23:49

# game/scripts/Systems/Relation_System/Sarada/sarada_gift_menu.rpy:8
translate english sarada_gift_like1_4c245cff:

    # sr "¿Un regalo?" with dissolve1
    sr "ของขวัญเหรอ?" with dissolve1

# game/scripts/Systems/Relation_System/Sarada/sarada_gift_menu.rpy:10
translate english sarada_gift_like1_163e0422:

    # sr "Gracias"
    sr "ขอบใจนะ"

# game/scripts/Systems/Relation_System/Sarada/sarada_gift_menu.rpy:16
translate english sarada_gift_like2_854820c3:

    # sr "¿M-Me lo quieres regalar?" with dissolve1
    sr "จ-จะให้ฉันจริงๆ เหรอ?" with dissolve1

# game/scripts/Systems/Relation_System/Sarada/sarada_gift_menu.rpy:18
translate english sarada_gift_like2_a6df2844:

    # sr "Muchas gracias jaja"
    sr "ขอบคุณมากๆ เลยนะ ฮ่าๆ"

# game/scripts/Systems/Relation_System/Sarada/sarada_gift_menu.rpy:20
translate english sarada_gift_like2_0eb78679:

    # sr "Estoy agradecida, me has alegrado el día"
    sr "ฉันซาบซึ้งใจจริงๆ วันนี้ทำให้ฉันมีความสุขขึ้นเยอะเลย"

# game/scripts/Systems/Relation_System/Sarada/sarada_gift_menu.rpy:26
translate english sarada_gift_nolike_c443c12d:

    # sr "Eh, gracias... Supongo..."
    sr "หา ขอบคุณ... มั้งนะ..."

# game/scripts/Systems/Relation_System/Sarada/sarada_gift_menu.rpy:33
translate english sarada_gift_no_friendly_level_05c2f3f8:

    # sr "Eeeh, no lo sé"
    sr "ฮู่... ไม่รู้สิ"

# game/scripts/Systems/Relation_System/Sarada/sarada_gift_menu.rpy:35
translate english sarada_gift_no_friendly_level_548c42b8:

    # sr "No creo que debas darme eso..."
    sr "ฉันว่านายไม่น่าเอาอันนี้มาให้ฉันเลย..."

# game/scripts/Systems/Relation_System/Sarada/sarada_gift_menu.rpy:40
translate english sarada_gift_classic_22ff2568:

    # sr "¿Es lo que creo que es?"
    sr "นี่มัน... เหมือนกับที่ฉันคิดไว้หรือเปล่าเนี่ย?"

# game/scripts/Systems/Relation_System/Sarada/sarada_gift_menu.rpy:43
translate english sarada_gift_classic_2f883755:

    # sr "Es idéntica a la ropa que usaba hace años"
    sr "มันเหมือนกับชุดที่ฉันเคยใส่เมื่อหลายปีก่อนเป๊ะเลย"

# game/scripts/Systems/Relation_System/Sarada/sarada_gift_menu.rpy:45
translate english sarada_gift_classic_dd7e6464:

    # sr "Recuerdo que esa ropa se me dañó en una batalla"
    sr "จำได้ว่าชุดนั้นพังเสียหายตอนสู้น่ะสิ"

# game/scripts/Systems/Relation_System/Sarada/sarada_gift_menu.rpy:47
translate english sarada_gift_classic_cdfd7ab1:

    # sr "Te lo agradezco mucho, la cuidaré muy bien"
    sr "ขอบคุณมากๆ เลยนะ ฉันจะดูแลมันเป็นอย่างดีเลยล่ะ"

# game/scripts/Systems/Relation_System/Sarada/sarada_gift_menu.rpy:53
translate english sarada_gift_time_skip_2fe5f14e:

    # sr "¿Para mí? Gracias"
    sr "ให้ฉันเหรอ? ขอบใจนะ"

# game/scripts/Systems/Relation_System/Sarada/sarada_gift_menu.rpy:55
translate english sarada_gift_time_skip_75540554:

    # sr "Oh, recuerdo esta ropa, la usé por un tiempo cuando la ropa que usaba se dañó en una batalla"
    sr "โอ้ ฉันจำชุดนี้ได้แล้ว ตอนที่ชุดเก่าของฉันพังตอนสู้ ฉันก็ใส่ชุดนี้อยู่พักหนึ่งเลยล่ะ"

# game/scripts/Systems/Relation_System/Sarada/sarada_gift_menu.rpy:57
translate english sarada_gift_time_skip_5216795a:

    # sr "Aunque luego la cambié, no era muy práctica en combate"
    sr "ถึงสุดท้ายฉันจะเปลี่ยนไปใส่ชุดอื่นก็เถอะ เพราะชุดนี้มันไม่ค่อยเหมาะกับการต่อสู้สักเท่าไหร่"

# game/scripts/Systems/Relation_System/Sarada/sarada_gift_menu.rpy:59
translate english sarada_gift_time_skip_fd06f476:

    # sr "Igual muchas gracias, la cuidaré mucho"
    sr "ยังไงก็ขอบคุณมากๆ เลยนะ ฉันจะดูแลมันเป็นอย่างดีเลย"

# game/scripts/Systems/Relation_System/Sarada/sarada_gift_menu.rpy:65
translate english sarada_gift_bikini_0e1ef602:

    # sr "¿Un bikini?"
    sr "บิกินีเหรอเนี่ย?"

# game/scripts/Systems/Relation_System/Sarada/sarada_gift_menu.rpy:67
translate english sarada_gift_bikini_58d786a8:

    # sr "¿Quieres que use esto?"
    sr "อยากให้ฉันใส่ชุดนี้เหรอ?"

# game/scripts/Systems/Relation_System/Sarada/sarada_gift_menu.rpy:69
translate english sarada_gift_bikini_0344e551:

    # sr "¿Te gustaría verme casi sin ropa?"
    sr "ชอบให้ฉันใส่ชุดน้อยชิ้นไรงี้รึไง?"

# game/scripts/Systems/Relation_System/Sarada/sarada_gift_menu.rpy:71
translate english sarada_gift_bikini_9fe2f401:

    # mn "Eeeh, no es eso"
    mn "ฮ่า, ไม่ใช่สักหน่อย"

# game/scripts/Systems/Relation_System/Sarada/sarada_gift_menu.rpy:73
translate english sarada_gift_bikini_eb878459:

    # sr "Estoy bromeando jaja"
    sr "ล้อเล่นน่า ฮ่าๆ"

# game/scripts/Systems/Relation_System/Sarada/sarada_gift_menu.rpy:75
translate english sarada_gift_bikini_ee8e9883:

    # sr "Lo guardaré muy bien"
    sr "ฉันจะเก็บรักษาไว้อย่างดีเลย"

# game/scripts/Systems/Relation_System/Sarada/sarada_gift_menu.rpy:77
translate english sarada_gift_bikini_de8014f0:

    # sr "Gracias por el detalle"
    sr "ขอบคุณสำหรับความใส่ใจนะ"

