# TODO: Translation updated at 2024-11-29 23:49

translate english strings:

    # game/scripts/Systems/Relation_System/stats.rpy:104
    old "El Regalo le gustó"
    new "เธอชอบของขวัญชิ้นนี้นะ"

    # game/scripts/Systems/Relation_System/stats.rpy:106
    old "+20 Amistad"
    new "+20 ความสัมพันธ์"

    # game/scripts/Systems/Relation_System/stats.rpy:122
    old "¡El Regalo le encantó!"
    new "เธอถูกใจของขวัญชิ้นนี้มาก!"

    # game/scripts/Systems/Relation_System/stats.rpy:123
    old "Su humor ha mejorado"
    new "อารมณ์ของเธอดีขึ้นแล้ว"

    # game/scripts/Systems/Relation_System/stats.rpy:126
    old "+35 Amistad"
    new "+35 ความสัมพันธ์"

    # game/scripts/Systems/Relation_System/stats.rpy:160
    old "No parece haberle gustado..."
    new "ดูเหมือนเธอจะไม่ค่อยชอบเท่าไหร่..."

    # game/scripts/Systems/Relation_System/stats.rpy:162
    old "+5 Amistad"
    new "+5 ความสัมพันธ์"

    # game/scripts/Systems/Relation_System/stats.rpy:176
    old "¡El regalo le encantó!"
    new "เธอถูกใจของขวัญชิ้นนี้มาก!"

    # game/scripts/Systems/Relation_System/stats.rpy:212
    old "El regalo le gustó"
    new "เธอชอบของขวัญชิ้นนี้นะ"

    # game/scripts/Systems/Relation_System/stats.rpy:342
    old "Su humor ha empeorado..."
    new "อารมณ์ของเธอแย่ลงกว่าเดิม..."

    # game/scripts/Systems/Relation_System/stats.rpy:372
    old "Nivel de amistad requerido: {b}3{/a}"
    new "ระดับความสัมพันธ์ที่ต้องการ: {b}3{/a}"

    # game/scripts/Systems/Relation_System/stats.rpy:419
    old "Nivel de amistad y amor requerido: {b}3{/a}"
    new "ระดับความสัมพันธ์และความรักที่ต้องการ: {b}3{/a}"

    # game/scripts/Systems/Relation_System/stats.rpy:432
    old "Nivel de Amor requerido: {b}3{/a}"
    new "ระดับความรักที่ต้องการ: {b}3{/a}"

    # game/scripts/Systems/Relation_System/stats.rpy:532
    old "Nivel de amor y amistad requerido: {b}3{/a}"
    new "ระดับความรักและความสัมพันธ์ที่ต้องการ: {b}3{/a}"
