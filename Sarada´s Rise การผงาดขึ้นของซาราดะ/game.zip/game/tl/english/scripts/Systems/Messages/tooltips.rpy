# TODO: Translation updated at 2024-11-29 23:49

translate english strings:

    # game/scripts/Systems/Messages/tooltips.rpy:1
    old "¡Oye! ¿Dónde has estado? Quiero que se reúnan conmigo cuando tengan tiempo"
    new "เฮ้! ไปไหนมาเนี่ย? ฉันอยากให้พวกเธอมาเจอกันหน่อยเวลาว่าง"

    # game/scripts/Systems/Messages/tooltips.rpy:2
    old "Lo haré cuando pueda"
    new "เอาไว้ฉันว่างแล้วจะไปนะ"

    # game/scripts/Systems/Messages/tooltips.rpy:3
    old "¡Muy bien!"
    new "เยี่ยมไปเลย!"

    # game/scripts/Systems/Messages/tooltips.rpy:4
    old "Sensei, ¿Cuándo nos vamos a reunir en el campo?"
    new "ท่านอาจารย์คะ เมื่อไหร่พวกเราจะได้ไปรวมตัวกันที่สนามฝึกซ้อมล่ะคะ?"

    # game/scripts/Systems/Messages/tooltips.rpy:5
    old "¡EL PODER DE LA JUVENTUD!"
    new "พลังแห่งวัยรุ่น!"

    # game/scripts/Systems/Messages/tooltips.rpy:6
    old "Si... Ahí estaré"
    new "ค่ะ... เดี๋ยวฉันไปค่ะ"

    # game/scripts/Systems/Messages/tooltips.rpy:7
    old "Ahí estaré Sensei..."
    new "เดี๋ยวผมไปครับ อาจารย์..."

    # game/scripts/Systems/Messages/tooltips.rpy:8
    old "¿Porqué tiene que ser mañana? Maldición..."
    new "ทำไมต้องเป็นพรุ่งนี้ด้วยเนี่ย? ให้ตายสิ..."

    # game/scripts/Systems/Messages/tooltips.rpy:9
    old "Equipo 11, su Sensei querido ha creado este grupo para que todos estemos mejor comunicados"
    new "ทีม 11 อาจารย์สุดที่รักของพวกเธอสร้างกลุ่มนี้ขึ้นมาเพื่อให้พวกเราติดต่อสื่อสารกันได้ดีขึ้นยังไงล่ะ"

    # game/scripts/Systems/Messages/tooltips.rpy:10
    old "También porque quiero darles un aviso importante"
    new "แล้วก็เพราะอาจารย์มีประกาศสำคัญจะแจ้งให้ทราบด้วย"

    # game/scripts/Systems/Messages/tooltips.rpy:11
    old "Quiero que todos se reúnan el día de mañana a las 6:00 a.m"
    new "ครูอยากให้ทุกคนมาเจอกันพรุ่งนี้ตอน 6 โมงเช้า"

    # game/scripts/Systems/Messages/tooltips.rpy:12
    old "Si pueden llegar antes mejor, ¿Entendido? ¡Quiero que me muestren el poder de la Juventud!"
    new "ถ้ามาเร็วกว่านั้นได้ยิ่งดี เข้าใจไหม? ครูอยากเห็นพลังแห่งวัยรุ่นของพวกเธอ!"

    # game/scripts/Systems/Messages/tooltips.rpy:13
    old "¡ASÍ SE HABLA!"
    new "พูดได้ดี!"

    # game/scripts/Systems/Messages/tooltips.rpy:14
    old "¡CON MÁS EMOCIÓN EQUIPO 11!"
    new "ใส่ความกระตือรือร้นเข้าไปอีกหน่อยสิ ทีม 11!"

    # game/scripts/Systems/Messages/tooltips.rpy:15
    old "..."
    new "..."

    # game/scripts/Systems/Messages/tooltips.rpy:16
    old "Hola Sarada, estuve pensando lo que me dijiste hoy, y creo que te haré caso, voy a entrenar la Invisibilidad"
    new "หวัดดีซาราดะ ฉันลองคิดเรื่องที่เธอพูดวันนี้ดูแล้ว และคิดว่าจะทำตามที่เธอแนะนำนะ ฉันจะไปฝึกคาถาล่องหนแล้ว"

    # game/scripts/Systems/Messages/tooltips.rpy:17
    old "Estupendo!"
    new "ยอดเยี่ยม!"

    # game/scripts/Systems/Messages/tooltips.rpy:18
    old "Quería preguntarte si puedes ayudarme a entrenar..."
    new "ฉันเลยอยากจะมาถามว่าเธอพอจะช่วยฉันฝึกหน่อยได้ไหม..."

    # game/scripts/Systems/Messages/tooltips.rpy:19
    old "Mmm... Déjame pensar..."
    new "อืม... ขอคิดดูก่อนนะ..."

    # game/scripts/Systems/Messages/tooltips.rpy:20
    old "Puedo ayudarte por la noche en mi tiempo libre, ¿Te parece?"
    new "ฉันช่วยเธอตอนกลางคืนในเวลาว่างได้นะ ว่าไงล่ะ?"

    # game/scripts/Systems/Messages/tooltips.rpy:22
    old "Bien, ven a mi casa cuando puedas"
    new "ได้สิ มาที่บ้านฉันตอนที่เธอสะดวกก็แล้วกัน"

    # game/scripts/Systems/Messages/tooltips.rpy:23
    old "Chicos, les traigo noticias"
    new "พวกเรา ฉันมีข่าวจะมาบอก"

    # game/scripts/Systems/Messages/tooltips.rpy:24
    old "La prueba será mañana, así que los espero tempranito en el campo de entrenamiento"
    new "การทดสอบจะมีขึ้นในวันพรุ่งนี้ เพราะงั้นฉันจะรอทุกคนแต่เช้าตรู่ที่สนามฝึกซ้อมนะ"

    # game/scripts/Systems/Messages/tooltips.rpy:25
    old "Ya saben como se pone Yuna cuando no llegan a tiempo..."
    new "ก็รู้กันอยู่นะว่ายูนะจะเป็นยังไงถ้ามาสาย..."

    # game/scripts/Systems/Messages/tooltips.rpy:26
    old "No creo que alguien llegue tarde, ya saben lo que les espera si me hacen esperar"
    new "ฉันไม่คิดว่าจะมีใครมาสายหรอกนะ พวกเธอก็รู้ว่าอะไรจะรออยู่ถ้าทำให้ฉันต้องรอ"

    # game/scripts/Systems/Messages/tooltips.rpy:27
    old "A-Ahí estaré!!"
    new "ด-เดี๋ยวฉันไปค่ะ!!"

    # game/scripts/Systems/Messages/tooltips.rpy:29
    old "Hola! Necesito que vengas a la tienda, tengo algo urgente que hablar contigo"
    new "หวัดดี! ฉันอยากให้เธอมาที่ร้านหน่อย มีเรื่องด่วนต้องคุยด้วย"

    # game/scripts/Systems/Messages/tooltips.rpy:30
    old "No olvides que nos reuniremos el {b}Viernes{/a} en {b}La Puerta de la Hoja{/a}"
    new "อย่าลืมนะว่าเราจะเจอกันใน {b}วันศุกร์{/a} ที่ {b}ประตูโคโนฮะ{/a}"

    # game/scripts/Systems/Messages/tooltips.rpy:31
    old "Si lo haces no te lo perdonaré >:("
    new "ถ้าทำล่ะก็ ฉันไม่ให้อภัยแน่ >:("

    # game/scripts/Systems/Messages/tooltips.rpy:32
    old "Voy en camino, ya estoy saliendo de mi casa, estoy a unos minutos"
    new "กำลังไป กำลังออกจากบ้านแล้ว อีกไม่กี่นาทีถึง"

    # game/scripts/Systems/Messages/tooltips.rpy:33
    old "Espero que hayas llegado bien a casa, yo ya voy a dormir, Buenas noches!"
    new "หวังว่าจะถึงบ้านอย่างปลอดภัยนะ ฉันจะไปนอนแล้ว ฝันดีนะ!"

    # game/scripts/Systems/Messages/tooltips.rpy:34
    old "Gracias por acompañarme al viaje, de verdad te lo agradezco"
    new "ขอบคุณที่ร่วมเดินทางมาด้วยกันนะ ฉันซาบซึ้งใจจริงๆ"

    # game/scripts/Systems/Messages/tooltips.rpy:36
    old "Buenos días Tenten, ya estoy en la puerta de la aldea"
    new "อรุณสวัสดิ์เท็นเท็น ตอนนี้ฉันอยู่ที่ประตูหมู่บ้านแล้วล่ะ"

    # game/scripts/Systems/Messages/tooltips.rpy:37
    old "Bien, entonces aquí te espero"
    new "งั้นฉันรออยู่ตรงนี้นะ"

    # game/scripts/Systems/Messages/tooltips.rpy:39
    old "BUENAS NOTICIAS JOVENES!!"
    new "มีข่าวดีจะบอกเว้ยพวกเรา!!"

    # game/scripts/Systems/Messages/tooltips.rpy:40
    old "YA LOS RECOMENDÉ PARA LOS EXÁMENES CHUNIN!"
    new "ครูเสนอชื่อพวกเธอให้เข้าร่วมการสอบจูนินแล้วนะ!"

    # game/scripts/Systems/Messages/tooltips.rpy:41
    old "Ya era hora"
    new "ก็ควรจะเป็นอย่างนั้นตั้งนานแล้วล่ะนะ"

    # game/scripts/Systems/Messages/tooltips.rpy:42
    old "¡Demos nuestro máximo esfuerzo!"
    new "มาพยายามกันให้เต็มที่เถอะ!"

    # game/scripts/Systems/Messages/tooltips.rpy:43
    old "Yuna, al menos muestra algo más de emoción... No seas tan amargada"
    new "ยูนะ อย่างน้อยก็แสดงท่าทางตื่นเต้นหน่อยสิ... อย่าเพิ่งทำหน้าบูดบึ้งน่า"

    # game/scripts/Systems/Messages/tooltips.rpy:44
    old "Yei... Mira cuanta emoción... Hace mucho tiempo tuvo que habernos recomendado..."
    new "เย่... ดูความตื่นเต้นของฉันสิ... พวกเราควรจะถูกเสนอชื่อตั้งแต่เมื่อนานมาแล้วแท้ๆ..."

    # game/scripts/Systems/Messages/tooltips.rpy:45
    old "Como sea... Los espero en el campo de entrenamiento en unas semanas antes de los exámenes, debo darles toda la información"
    new "ช่างเถอะ... ครูจะรอทุกคนที่สนามฝึกซ้อมสักสองสามสัปดาห์ก่อนการสอบนะ ครูต้องแจ้งรายละเอียดทั้งหมดให้ฟัง"

    # game/scripts/Systems/Messages/tooltips.rpy:46
    old "SIN FALTA!!! {image=gui/emojis/light.png}"
    new "ห้ามพลาดเด็ดขาดเลยนะ!!! {image=gui/emojis/light.png}"

    # game/scripts/Systems/Messages/tooltips.rpy:47
    old "{image=gui/emojis/like.png}"
    new "{image=gui/emojis/like.png}"

    # game/scripts/Systems/Messages/tooltips.rpy:49
    old "Hola cariño, buenas noches"
    new "หวัดดีที่รัก ฝันดีนะ"

    # game/scripts/Systems/Messages/tooltips.rpy:50
    old "¿Cómo estás? Espero que bien, te escribo para avisarte que ya me tengo listo tu nuevo traje"
    new "เป็นยังไงบ้าง? หวังว่าสบายดีนะ ฉันเขียนมาเพื่อบอกว่าชุดใหม่ของเธอเสร็จเรียบร้อยแล้วล่ะ"

    # game/scripts/Systems/Messages/tooltips.rpy:51
    old "Puedes venir a traerlo cuando quieras, y recuerda venir personalmente, quiero verte de nuevo {image=gui/emojis/kiss.png}"
    new "เธอมาเอาเมื่อไหร่ก็ได้นะ แล้วก็อย่าลืมมาด้วยตัวเองล่ะ ฉันอยากเจอเธออีก {image=gui/emojis/kiss.png}"

    # game/scripts/Systems/Messages/tooltips.rpy:52
    old "Si... Ahí estaré... {image=gui/emojis/flushed.png}"
    new "อืม... เดี๋ยวฉันไป... {image=gui/emojis/flushed.png}"

    # game/scripts/Systems/Messages/tooltips.rpy:54
    old "Hola Hanna! ¿Cómo estás, tienes tiempo para salir esta noche?"
    new "หวัดดีฮันนะ! เป็นยังไงบ้าง พอจะมีเวลาออกไปข้างนอกคืนนี้ไหม?"

    # game/scripts/Systems/Messages/tooltips.rpy:55
    old "¡Hola! Por supuesto, solo ven a traerme en la noche"
    new "หวัดดี! ได้เลย แค่แวะมารับฉันตอนกลางคืนก็พอ"

    # game/scripts/Systems/Messages/tooltips.rpy:56
    old "¡Hola! Ya es un poco tarde, ¿Puedes mañana por la noche?"
    new "หวัดดี! ตอนนี้ก็ดึกไปหน่อยแล้ว ไว้เป็นพรุ่งนี้คืนแทนได้ไหม?"

    # game/scripts/Systems/Messages/tooltips.rpy:57
    old "Por supuesto! Ahí estaré"
    new "ได้เลย! เดี๋ยวฉันไป"

    # game/scripts/Systems/Messages/tooltips.rpy:59
    old "Ya he salido de mi turno, ¿Vendrás a recogerme? {image=gui/emojis/pleading.png}"
    new "ฉันเพิ่งเลิกงานเอง เธอจะมารับฉันไหม? {image=gui/emojis/pleading.png}"

    # game/scripts/Systems/Messages/tooltips.rpy:60
    old "Por supuesto! Voy en camino"
    new "ได้เลย! กำลังไปนะ"

    # game/scripts/Systems/Messages/tooltips.rpy:61
    old "Perfecto! te esperaré en el Hospital {image=gui/emojis/kissing.png}"
    new "เยี่ยม! งั้นฉันจะรอเธอที่โรงพยาบาล {image=gui/emojis/kissing.png}"

    # game/scripts/Systems/Messages/tooltips.rpy:63
    old "¡Buenos días! Ya tenemos lista la solución para los efectos secundarios del Jutsu de Invisibilidad{image=gui/emojis/beaming.png}"
    new "อรุณสวัสดิ์! ตอนนี้เราเตรียมวิธีแก้ผลข้างเคียงของคาถาล่องหนเสร็จเรียบร้อยแล้วล่ะ{image=gui/emojis/beaming.png}"

    # game/scripts/Systems/Messages/tooltips.rpy:64
    old "No dudes en venir hoy al Hospital, y recuerda que mi turno comienza al medio día, antes no puedo atenderte"
    new "วันนี้แวะมาที่โรงพยาบาลได้เลยนะ แล้วก็จำไว้ล่ะว่าฉันเข้าเวรตอนเที่ยง ก่อนหน้านั้นฉันยังตรวจให้ไม่ได้นะ"

    # game/scripts/Systems/Messages/tooltips.rpy:66
    old "¡Hola! Necesito que vengas a mi oficina mañana mismo, es importante"
    new "หวัดดี! เธอต้องมาที่ห้องทำงานของฉันพรุ่งนี้ให้ได้เลยนะ เรื่องนี้สำคัญมาก"

    # game/scripts/Systems/Messages/tooltips.rpy:67
    old "¡Por supuesto! Ahí estaré"
    new "ได้เลย! เดี๋ยวฉันไป"

    # game/scripts/Systems/Messages/tooltips.rpy:68
    old "¡Hola! Sé que estarás ocupado entrenando, y no quiero quitarte tiempo, pero necesito que vengas a mi oficina, es un asunto muy importante"
    new "หวัดดี! ฉันรู้ว่าเธอดำลังยุ่งกับการฝึกซ้อมและไม่อยากกวนเวลา แต่อยากให้เธอมาที่ห้องทำงานของฉันหน่อย มีเรื่องสำคัญมากๆ เลย"

    # game/scripts/Systems/Messages/tooltips.rpy:70
    old "Buenas noches! Escribo para recordarte que ya mañana es Domingo! Mi Mamá y yo te estarémos esperando, así que no vayas a faltar!"
    new "ฝันดีนะ! ส่งข้อความมาเตือนว่าพรุ่งนี้วันอาทิตย์แล้วนะ! ฉันกับคุณแม่จะรอนะ ห้ามเบี้ยวเด็ดขาดล่ะ!"

