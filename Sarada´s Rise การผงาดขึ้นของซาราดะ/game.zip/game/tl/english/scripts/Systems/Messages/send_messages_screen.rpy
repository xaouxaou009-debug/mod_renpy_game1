
translate english strings:

    # game/scripts/Systems/Messages/send_messages_screen.rpy:6
    old "¿Qué mensaje enviarás?"
    new "คุณจะส่งข้อความว่าอะไรดีล่ะ?"

    # game/scripts/Systems/Messages/send_messages_screen.rpy:8
    old "¿Cuando nos reunirémos?"
    new "พวกเราจะเจอกันเมื่อไหร่ดี?"

    # game/scripts/Systems/Messages/send_messages_screen.rpy:14
    old "¡El Poder de la Juventud!"
    new "พลังแห่งวัยหนุ่มสาว!"

    # game/scripts/Systems/Messages/send_messages_screen.rpy:16
    old "Si..."
    new "อืม..."

    # game/scripts/Systems/Messages/send_messages_screen.rpy:22
    old "¿Puedes ayudarme?"
    new "เธอช่วยฉันหน่อยได้ไหม?"

    # game/scripts/Systems/Messages/send_messages_screen.rpy:28
    old "Perfecto!"
    new "เยี่ยมไปเลย!"
