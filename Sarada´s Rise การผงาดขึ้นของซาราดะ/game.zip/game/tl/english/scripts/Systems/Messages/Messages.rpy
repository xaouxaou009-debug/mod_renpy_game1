# TODO: Translation updated at 2024-11-29 23:49

translate english strings:

    # game/scripts/Systems/Messages/Messages.rpy:60
    old "¡Has recibido un Mensaje!"
    new "คุณได้รับข้อความใหม่!"

