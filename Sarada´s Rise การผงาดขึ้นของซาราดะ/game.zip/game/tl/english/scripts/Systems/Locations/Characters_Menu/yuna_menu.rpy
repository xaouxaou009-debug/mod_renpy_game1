# TODO: Translation updated at 2024-11-29 23:49

# game/scripts/Systems/Locations/Characters_Menu/yuna_menu.rpy:13
translate english yuna_talk0_7f40c29a:

    # yn "¿Qué haces aquí? Si vas a distraerme, mejor lárgate."
    yn "เธอมาทำอะไรที่นี่เนี่ย? ถ้าจะมาทำให้ฉันเสียสมาธิล่ะก็ ไสหัวไปเลยดีกว่า"

# game/scripts/Systems/Locations/Characters_Menu/yuna_menu.rpy:15
translate english yuna_talk0_1b9dfcc3:

    # yn "¿Qué quieres ahora? Pensé que ya habíamos terminado con eso."
    yn "คราวนี้ต้องการอะไรอีก? ฉันนึกว่าเราคุยกันเรื่องนั้นจบไปแล้วซะอีก"

# game/scripts/Systems/Locations/Characters_Menu/yuna_menu.rpy:21
translate english yuna_talk0_eff973ba:

    # yn "Oh, eres tú... ¿Qué haces aquí? ¿No tienes algo mejor que hacer?"
    yn "อ๋อ เธอเองเหรอ... มาทำอะไรที่นี่เนี่ย? ไม่มีอะไรอย่างอื่นที่ดีกว่าทำแล้วรึไง?"

# game/scripts/Systems/Locations/Characters_Menu/yuna_menu.rpy:28
translate english yuna_talk0_1c9eef3c:

    # yn "Oh, eres tú otra vez. Estoy entrenando, sé breve ¿Quieres?"
    yn "อ๋อ เธออีกแล้วเหรอ ฉันกำลังฝึกอยู่ พูดสั้นๆ หน่อยได้ไหม?"

# game/scripts/Systems/Locations/Characters_Menu/yuna_menu.rpy:34
translate english yuna_talk0_8f1cdfb3:

    # yn "Espero que estés tomando los entrenamientos en serio..."
    yn "ฉันหวังว่าเธอจะตั้งใจฝึกซ้อมอยู่นะ..."

# game/scripts/Systems/Locations/Characters_Menu/yuna_menu.rpy:35
translate english yuna_talk0_43446e82:

    # yn "Yo estoy entrenando duro, espero tú también."
    yn "ฉันตั้งใจฝึกอยู่แล้ว หวังว่าเธอเองก็เหมือนกันนะ"

# game/scripts/Systems/Locations/Characters_Menu/yuna_menu.rpy:45
translate english yuna_talk0_9dbd2f23:

    # yn "¿Qué haces aquí? ¿Acaso no puedes dejarme comer tranquila?"
    yn "เธอมาทำอะไรที่นี่เนี่ย? ปล่อยให้ฉันกินข้าวอย่างสงบสุขไม่ได้รึไง?"

# game/scripts/Systems/Locations/Characters_Menu/yuna_menu.rpy:50
translate english yuna_talk0_434220b2:

    # yn "Estoy aquí para relajarme... Si tienes algo que decir, hazlo rápido."
    yn "ฉันมาพักผ่อน... ถ้ามีอะไรจะพูดก็พูดมาเร็วๆ ล่ะ"

# game/scripts/Systems/Locations/Characters_Menu/yuna_menu.rpy:56
translate english yuna_talk0_c30e7156:

    # yn "¿Me sigues ahora? No es como si necesitara compañía, ¿Sabes?"
    yn "นี่แอบสะกดรอยตามฉันอยู่รึไง? ฉันไม่ได้ต้องการเพื่อนแก้เหงาสักหน่อย รู้ไว้ซะด้วย"

