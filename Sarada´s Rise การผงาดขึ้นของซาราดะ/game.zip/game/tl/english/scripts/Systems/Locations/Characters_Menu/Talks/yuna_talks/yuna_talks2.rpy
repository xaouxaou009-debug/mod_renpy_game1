# TODO: Translation updated at 2024-11-29 23:49

# game/scripts/Systems/Locations/Characters_Menu/Talks/yuna_talks/yuna_talks2.rpy:10
translate english yuna_talk2_4866cdde:

    # yn "Estoy ocupada, así que, ¿Por qué no usas tu tiempo para entrenar?"
    yn "ฉันยุ่งอยู่ ทำไมเธอไม่เอาเวลาไปฝึกซ้อมบ้างล่ะ?"

# game/scripts/Systems/Locations/Characters_Menu/Talks/yuna_talks/yuna_talks2.rpy:13
translate english yuna_talk2_aba91d16:

    # yn "¿Acaso te importa? Mejor déjame tranquila..."
    yn "สนใจฉันด้วยเหรอ? ปล่อยฉันไว้คนเดียวดีกว่า..."

# game/scripts/Systems/Locations/Characters_Menu/Talks/yuna_talks/yuna_talks2.rpy:17
translate english yuna_talk2_0420fcea:

    # yn "Estoy bien, preparándome para los exámenes... Aunque aún hay mucho por hacer"
    yn "ฉันสบายดี กำลังเตรียมตัวสอบอยู่... ถึงจะมีเรื่องให้ทำอีกเยอะก็เถอะ"

# game/scripts/Systems/Locations/Characters_Menu/Talks/yuna_talks/yuna_talks2.rpy:22
translate english yuna_talk2_dfe88d20:

    # yn "¿Cómo estoy? Exhausta, pero al menos estoy haciendo algo útil, a diferencia de algunos"
    yn "ถามว่าฉันเป็นยังไงเหรอ? เหนื่อยจะตาย แต่ก็นะ อย่างน้อยฉันก็ได้ทำประโยชน์อะไรบ้าง ไม่เหมือนบางคนแถวนี้หรอก"

# game/scripts/Systems/Locations/Characters_Menu/Talks/yuna_talks/yuna_talks2.rpy:25
translate english yuna_talk2_83f55502:

    # yn "Cansada, pero satisfecha, entrenar por la noche siempre me ayuda a despejarme"
    yn "เหนื่อยแต่ก็พอใจ การฝึกซ้อมตอนกลางคืนช่วยให้ฉันปลอดโปร่งขึ้นเสมอ"

# game/scripts/Systems/Locations/Characters_Menu/Talks/yuna_talks/yuna_talks2.rpy:29
translate english yuna_talk2_566bc3cc:

    # yn "Estoy bien, al menos mientras no me molestes demasiado. ¿Algo más?"
    yn "ฉันสบายดี ตราบใดที่นายไม่มาวุ่นวายกับฉันมากเกินไป มีอะไรอีกไหม?"

# game/scripts/Systems/Locations/Characters_Menu/Talks/yuna_talks/yuna_talks2.rpy:33
translate english yuna_talk2_72d154f0:

    # yn "Estoy bien, gracias"
    yn "ฉันสบายดี ขอบใจนะ"

# game/scripts/Systems/Locations/Characters_Menu/Talks/yuna_talks/yuna_talks2.rpy:35
translate english yuna_talk2_3e87293a:

    # yn "Ahora si me disculpas, se está enfriando mi Ramen..."
    yn "เอาล่ะ ถ้าไม่ว่าอะไร ราเม็งของฉันจะอืดหมดแล้วนะ..."

