

# game/scripts/Systems/Locations/Characters_Menu/sakura_menu.rpy:17
translate english sakura_talk0_ec2a1dc5:

    # mn "Hola Sakura, buenos días"
    mn "สวัสดีครับซากุระ อรุณสวัสดิ์ครับ"

# game/scripts/Systems/Locations/Characters_Menu/sakura_menu.rpy:19
translate english sakura_talk0_bdf82c97:

    # mn "Hola Sakura, buenas noches"
    mn "สวัสดีครับซากุระ ราตรีสวัสดิ์ครับ"

# game/scripts/Systems/Locations/Characters_Menu/sakura_menu.rpy:22
translate english sakura_talk0_e2e0d501:

    # sk "Hola, que gusto verte"
    sk "หวัดดี ดีใจจังที่ได้เจอคุณนะ"

# game/scripts/Systems/Locations/Characters_Menu/sakura_menu.rpy:24
translate english sakura_talk0_069b3992:

    # sk "¿Qué te trae por aquí?"
    sk "มีธุระอะไรถึงมาที่นี่เหรอ?"

# game/scripts/Systems/Locations/Characters_Menu/sakura_menu.rpy:38
translate english sakura_talk0_ec2a1dc5_1:

    # mn "Hola Sakura, buenos días"
    mn "สวัสดีครับซากุระ อรุณสวัสดิ์ครับ"

# game/scripts/Systems/Locations/Characters_Menu/sakura_menu.rpy:40
translate english sakura_talk0_bdf82c97_1:

    # mn "Hola Sakura, buenas noches"
    mn "สวัสดีครับซากุระ ราตรีสวัสดิ์ครับ"

# game/scripts/Systems/Locations/Characters_Menu/sakura_menu.rpy:43
translate english sakura_talk0_1aa6d266:

    # sk "Hola..."
    sk "หวัดดี..."

translate english strings:

    # game/scripts/Systems/Locations/Characters_Menu/sakura_menu.rpy:48
    old "Charlar"
    new "พูดคุย"

    # game/scripts/Systems/Locations/Characters_Menu/sakura_menu.rpy:48
    old "Dar un Regalo"
    new "มอบของขวัญ"
# TODO: Translation updated at 2024-11-29 23:49

# game/scripts/Systems/Locations/Characters_Menu/sakura_menu.rpy:14
translate english sakura_talk0_8afd8fbf:

    # sk "Hola [MN], que gusto verte"
    sk "สวัสดี [MN] ดีใจจังที่ได้เจอ"

# game/scripts/Systems/Locations/Characters_Menu/sakura_menu.rpy:21
translate english sakura_talk0_8586d99e:

    # sk "Hola [MN]..."
    sk "หวัดดี [MN]..."

# game/scripts/Systems/Locations/Characters_Menu/sakura_menu.rpy:47
translate english sakura_menu1_0cb4fef0:

    # sk "Por supuesto, ¿Qué es?"
    sk "ได้สิ มีอะไรเหรอ?"

# game/scripts/Systems/Locations/Characters_Menu/sakura_menu.rpy:50
translate english sakura_menu1_4c4de45d:

    # sk "Justo ahora no puedo..."
    sk "ตอนนี้ยังไม่สะดวกเลย..."
