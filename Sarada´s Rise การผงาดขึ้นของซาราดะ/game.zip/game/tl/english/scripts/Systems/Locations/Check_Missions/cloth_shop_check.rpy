# TODO: Translation updated at 2024-11-29 23:49

translate english strings:

    # game/scripts/Systems/Locations/Check_Missions/cloth_shop_check.rpy:3
    old "Cerrado los fines de Semana"
    new "ปิดทำการในวันเสาร์-อาทิตย์"

    # game/scripts/Systems/Locations/Check_Missions/cloth_shop_check.rpy:16
    old "Cerrado de Noche"
    new "ปิดทำการตอนกลางคืน"
