# TODO: Translation updated at 2024-12-01 21:25

# game/scripts/Systems/Locations/Characters_Menu/Talks/sarada_talks/sarada_exp_talks.rpy:6
translate english sarada_friendly_talk_f48fed99:

    # n "A ella le pareció una Charla interesante!"
    n "เธอพบว่ามันเป็นบทสนทนาที่น่าสนใจทีเดียว!"

# game/scripts/Systems/Locations/Characters_Menu/Talks/sarada_talks/sarada_exp_talks.rpy:9
translate english sarada_friendly_talk_6f61ab6d:

    # n "Y le pareció una buena charla"
    n "และเธอก็คิดว่ามันเป็นบทสนทนาที่ดี"

# game/scripts/Systems/Locations/Characters_Menu/Talks/sarada_talks/sarada_exp_talks.rpy:12
translate english sarada_friendly_talk_bb3d973b:

    # n "Pero no estaba de humor..."
    n "แต่ดูเหมือนเธอจะไม่ได้อารมณ์นั้น..."

# game/scripts/Systems/Locations/Characters_Menu/Talks/sarada_talks/sarada_exp_talks.rpy:14
translate english sarada_friendly_talk_fb7f0dcb:

    # n "Pero no estaba de buen humor..."
    n "แต่ดูเหมือนเธอจะอารมณ์ไม่ค่อยดีนัก..."

# game/scripts/Systems/Locations/Characters_Menu/Talks/sarada_talks/sarada_exp_talks.rpy:34
translate english sarada_love_talk_3adcae70:

    # n "Parece que le gustó!"
    n "ดูเหมือนว่าเธอจะชอบมันนะ!"

# game/scripts/Systems/Locations/Characters_Menu/Talks/sarada_talks/sarada_exp_talks.rpy:37
translate english sarada_love_talk_6f61ab6d:

    # n "Y le pareció una buena charla"
    n "และเธอก็คิดว่ามันเป็นบทสนทนาที่ดี"

# game/scripts/Systems/Locations/Characters_Menu/Talks/sarada_talks/sarada_exp_talks.rpy:40
translate english sarada_love_talk_bb3d973b:

    # n "Pero no estaba de humor..."
    n "แต่ดูเหมือนเธอจะไม่ได้อารมณ์นั้น..."

# game/scripts/Systems/Locations/Characters_Menu/Talks/sarada_talks/sarada_exp_talks.rpy:42
translate english sarada_love_talk_fb7f0dcb:

    # n "Pero no estaba de buen humor..."
    n "แต่ดูเหมือนเธอจะอารมณ์ไม่ค่อยดีนัก..."

# TODO: Translation updated at 2024-12-20 07:52

# game/scripts/Systems/Locations/Characters_Menu/Talks/sarada_talks/sarada_exp_talks.rpy:3
translate english sarada_friendly_talk_b87afa03:

    # n "[MN] se quedó charlando con Sarada"
    n "[MN] อยู่พูดคุยกับซาราดะต่อ"

# game/scripts/Systems/Locations/Characters_Menu/Talks/sarada_talks/sarada_exp_talks.rpy:31
translate english sarada_love_talk_4e21fb32:

    # n "[MN] intentó tener una charla {b}Coqueta{/a} con Sarada"
    n "[MN] พยายามชวนซาราดะคุยแบบ {b}ยั่วยวน{/a}"
