
translate english strings:

    # game/scripts/Systems/Locations/Check_Missions/sakura_bedroom_ckeck.rpy:5
    old "Aún no puedes entrar"
    new "ยังเข้าไปตอนนี้ไม่ได้"
