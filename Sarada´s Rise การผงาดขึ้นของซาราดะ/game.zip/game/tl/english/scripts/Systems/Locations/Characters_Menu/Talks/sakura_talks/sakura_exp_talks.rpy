# TODO: Translation updated at 2024-12-01 21:25

# game/scripts/Systems/Locations/Characters_Menu/Talks/sakura_talks/sakura_exp_talks.rpy:6
translate english sakura_friendly_talk_f48fed99:

    # n "A ella le pareció una Charla interesante!"
    n "เธอพบว่ามันเป็นบทสนทนาที่น่าสนใจทีเดียว!"

# game/scripts/Systems/Locations/Characters_Menu/Talks/sakura_talks/sakura_exp_talks.rpy:9
translate english sakura_friendly_talk_6f61ab6d:

    # n "Y le pareció una buena charla"
    n "และเธอก็คิดว่ามันเป็นบทสนทนาที่ดี"

# game/scripts/Systems/Locations/Characters_Menu/Talks/sakura_talks/sakura_exp_talks.rpy:12
translate english sakura_friendly_talk_bb3d973b:

    # n "Pero no estaba de humor..."
    n "แต่ดูเหมือนเธอจะไม่ได้อารมณ์นั้น..."

# game/scripts/Systems/Locations/Characters_Menu/Talks/sakura_talks/sakura_exp_talks.rpy:14
translate english sakura_friendly_talk_fb7f0dcb:

    # n "Pero no estaba de buen humor..."
    n "แต่ดูเหมือนเธอจะอารมณ์ไม่ค่อยดีนัก..."

# game/scripts/Systems/Locations/Characters_Menu/Talks/sakura_talks/sakura_exp_talks.rpy:36
translate english sakura_love_talk_3adcae70:

    # n "Parece que le gustó!"
    n "ดูเหมือนว่าเธอจะชอบมันนะ!"

# game/scripts/Systems/Locations/Characters_Menu/Talks/sakura_talks/sakura_exp_talks.rpy:39
translate english sakura_love_talk_6f61ab6d:

    # n "Y le pareció una buena charla"
    n "และเธอก็คิดว่ามันเป็นบทสนทนาที่ดี"

# game/scripts/Systems/Locations/Characters_Menu/Talks/sakura_talks/sakura_exp_talks.rpy:42
translate english sakura_love_talk_bb3d973b:

    # n "Pero no estaba de humor..."
    n "แต่ดูเหมือนเธอจะไม่ได้อารมณ์นั้น..."

# game/scripts/Systems/Locations/Characters_Menu/Talks/sakura_talks/sakura_exp_talks.rpy:44
translate english sakura_love_talk_fb7f0dcb:

    # n "Pero no estaba de buen humor..."
    n "แต่ดูเหมือนเธอจะอารมณ์ไม่ค่อยดีนัก..."

# TODO: Translation updated at 2024-12-20 07:52

# game/scripts/Systems/Locations/Characters_Menu/Talks/sakura_talks/sakura_exp_talks.rpy:3
translate english sakura_friendly_talk_25a55276:

    # n "[MN] se quedó charlando con Sakura"
    n "[MN] อยู่คุยกับซากุระต่อ"

# game/scripts/Systems/Locations/Characters_Menu/Talks/sakura_talks/sakura_exp_talks.rpy:34
translate english sakura_love_talk_cf9cef29:

    # n "[MN] intentó tener una charla {b}Coqueta{/a} con Sakura"
    n "[MN] พยายามชวนซากุระคุยแบบ {b}ยั่วยวน{/a}"
