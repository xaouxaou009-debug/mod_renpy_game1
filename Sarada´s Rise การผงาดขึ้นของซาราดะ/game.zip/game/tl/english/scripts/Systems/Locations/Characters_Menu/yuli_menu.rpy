# TODO: Translation updated at 2024-11-29 23:49

# game/scripts/Systems/Locations/Characters_Menu/yuli_menu.rpy:10
translate english yuli_talk_0_47e0d597:

    # yl "Buen día Cariño, qué agradable sorpresa verte por aquí, ¿Qué necesitas hoy?"
    yl "สวัสดีค่ะที่รัก น่าแปลกใจจังที่ได้เจอคุณที่นี่ วันนี้ต้องการอะไรเหรอคะ?"

# game/scripts/Systems/Locations/Characters_Menu/yuli_menu.rpy:16
translate english yuli_talk_0_62937d74:

    # yl "Buen día [MN], ¿Qué necesitas? Siempre es un placer verte por aquí"
    yl "สวัสดีค่ะ [MN] ต้องการอะไรหรือเปล่าคะ? ดีใจทุกครั้งที่ได้เจอคุณที่นี่เลยค่ะ"

# game/scripts/Systems/Locations/Characters_Menu/yuli_menu.rpy:22
translate english yuli_talk_0_228ad666:

    # yl "Oh, [MN]... Gracias por pasar a verme... ¿Qué necesitas?"
    yl "อ๊ะ [MN]... ขอบคุณที่แวะมาหาฉันนะ... มีอะไรให้ช่วยหรือเปล่า?"

# game/scripts/Systems/Locations/Characters_Menu/yuli_menu.rpy:28
translate english yuli_talk_0_ee16afb4:

    # yl "Buen día... ¿Necesitas algo? Te agradecería que fuera rápido..."
    yl "สวัสดีค่ะ... มีธุระอะไรหรือเปล่า? ช่วยพูดให้กระชับหน่อยจะดีมากเลย..."

# game/scripts/Systems/Locations/Characters_Menu/yuli_menu.rpy:58
translate english yuli_shop_menu_bc01bd4c:

    # yl "Dime, ¿De qué se trata?"
    yl "ว่ามาสิ เกี่ยวกับเรื่องอะไรเหรอ?"

# game/scripts/Systems/Locations/Characters_Menu/yuli_menu.rpy:61
translate english yuli_shop_menu_c7932f7b:

    # yl "Justo ahora no puedo hablar..."
    yl "ตอนนี้ฉันยังไม่สะดวกคุย...ดิจิตอล"

# TODO: Translation updated at 2024-12-20 07:52

translate english strings:

    # game/scripts/Systems/Locations/Characters_Menu/yuli_menu.rpy:51
    old "Le quería preguntar algo..."
    new "ฉันอยากจะถามอะไรหน่อยน่ะ..."
