# TODO: Translation updated at 2024-12-01 23:10

translate english strings:

    # game/scripts/Systems/Locations/Characters_Menu/Talks/sarada_talks/sarada_talks.rpy:2
    old "Atrás"
    new "ย้อนกลับ"

# TODO: Translation updated at 2024-12-20 07:52

translate english strings:

    # game/scripts/Systems/Locations/Characters_Menu/Talks/sarada_talks/sarada_talks.rpy:2
    old "Charla Amistosa"
    new "คุยเล่นทั่วไป"

    # game/scripts/Systems/Locations/Characters_Menu/Talks/sarada_talks/sarada_talks.rpy:2
    old "Charla Coqueta"
    new "คุยหยอดจีบ"
