

translate english strings:

    # game/scripts/Systems/Locations/Map_Locations.rpy:162
    old "Trucos"
    new "โกงเกม"

    # game/scripts/Systems/Locations/Map_Locations.rpy:174
    old "+1 Nivel"
    new "+1 เลเวล"

    # game/scripts/Systems/Locations/Map_Locations.rpy:174
    old "+100 ryo"
    new "+100 เรียว"
