
translate english strings:

    # game/scripts/Systems/Locations/Check_Missions/hospital_check.rpy:3
    old "Aún no tienes la flor"
    new "เธอ/นายยังไม่มีดอกไม้"
# TODO: Translation updated at 2024-11-29 23:49

translate english strings:

    # game/scripts/Systems/Locations/Check_Missions/hospital_check.rpy:3
    old "Ni Sakura ni Hanna están de Servicio hoy"
    new "ทั้งซากุระและฮันนะไม่ได้เข้าเวรในวันนี้"

    # game/scripts/Systems/Locations/Check_Missions/hospital_check.rpy:34
    old "Sakura no ha llegado"
    new "ซากุระยังมาไม่ถึง"
