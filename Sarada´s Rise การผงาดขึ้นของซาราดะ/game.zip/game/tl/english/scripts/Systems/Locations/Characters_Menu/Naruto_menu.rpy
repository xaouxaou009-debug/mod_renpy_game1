

# game/scripts/Systems/Locations/Characters_Menu/Naruto_menu.rpy:11
translate english naruto_talk_0_b1436b1f:

    # mn "Buen día Señor Séptimo"
    mn "อรุณสวัสดิ์ครับท่านโฮคาเงะรุ่นที่ 7"

# game/scripts/Systems/Locations/Characters_Menu/Naruto_menu.rpy:14
translate english naruto_talk_0_e5a4e865:

    # n "[MN], ¿Qué tal?"
    n "[MN] สบายดีไหม?"

# game/scripts/Systems/Locations/Characters_Menu/Naruto_menu.rpy:16
translate english naruto_talk_0_a02e1a2f:

    # n "¿Qué puedo hacer por tí?"
    n "มีอะไรให้ฉันช่วยไหม?"

# game/scripts/Systems/Locations/Characters_Menu/Naruto_menu.rpy:23
translate english naruto_menu_9b37b975:

    # n "Este es un menú de prueba"
    n "นี่คือเมนูทดสอบ"

# game/scripts/Systems/Locations/Characters_Menu/Naruto_menu.rpy:31
translate english naruto_menu_4c6cb48b:

    # n "[MN] se prepara para la lucha"
    n "[MN] เตรียมตัวสำหรับการต่อสู้"

# game/scripts/Systems/Locations/Characters_Menu/Naruto_menu.rpy:42
translate english naruto_menu_4c6cb48b_1:

    # n "[MN] se prepara para la lucha"
    n "[MN] เตรียมตัวสำหรับการต่อสู้"

translate english strings:

    # game/scripts/Systems/Locations/Characters_Menu/Naruto_menu.rpy:21
    old "Quiero hacer una misión"
    new "ฉันอยากไปทำภารกิจ"

    # game/scripts/Systems/Locations/Characters_Menu/Naruto_menu.rpy:21
    old "Solo venía a saludar"
    new "แค่อยาแวะมาทักทายเฉยๆ"

    # game/scripts/Systems/Locations/Characters_Menu/Naruto_menu.rpy:21
    old "Zubon Test"
    new "ทดสอบซูบง"

    # game/scripts/Systems/Locations/Characters_Menu/Naruto_menu.rpy:24
    old "Acaba con el ladrón de bragas"
    new "จัดการโจรขโมยชุดชั้นใน"



# game/scripts/Systems/Locations/Characters_Menu/Naruto_menu.rpy:14
translate english naruto_talk_0_4eeaf65f:

    # nt "[MN], ¿Qué tal?"
    nt "[MN] เป็นยังไงบ้าง?"

# game/scripts/Systems/Locations/Characters_Menu/Naruto_menu.rpy:16
translate english naruto_talk_0_31a964c2:

    # nt "¿Qué puedo hacer por tí?"
    nt "มีอะไรให้ฉันช่วยรึเปล่า?"

# game/scripts/Systems/Locations/Characters_Menu/Naruto_menu.rpy:23
translate english naruto_menu_9a682451:

    # nt "Claro, ¿Qué sucede?"
    nt "ได้สิ มีเรื่องอะไรเหรอ?"

translate english strings:

    # game/scripts/Systems/Locations/Characters_Menu/Naruto_menu.rpy:21
    old "Le puedo hacer una pregunta?"
    new "ผมขอถามอะไรหน่อยได้ไหมครับ?"
