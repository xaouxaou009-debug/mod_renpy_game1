# TODO: Translation updated at 2024-12-20 07:52

# game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_mission_menu.rpy:9
translate english naruto_missions_menu_4c6cb48b:

    # n "[MN] se prepara para la lucha"
    n "[MN] เตรียมตัวสำหรับการต่อสู้"

# game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_mission_menu.rpy:13
translate english naruto_missions_menu_dac41fb3:

    # nt "Ja, que recuerdos..."
    nt "ฮ่า คิดถึงความทรงจำเก่า ๆ จัง..."

# game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_mission_menu.rpy:15
translate english naruto_missions_menu_f38bb6bb:

    # nt "Tu misión es encontrar a un Gato que se perdió en la Aldea, cuando lo encuentres se te dará una recompensa"
    nt "ภารกิจของคุณคือการตามหาแมวที่หายไปในหมู่บ้าน เมื่อคุณพบมันแล้วจะได้รับรางวัล"

# game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_mission_menu.rpy:27
translate english naruto_missions_menu_4c6cb48b_1:

    # n "[MN] se prepara para la lucha"
    n "[MN] เตรียมตัวสำหรับการต่อสู้"

# game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_mission_menu.rpy:35
translate english naruto_missions_menu_4c6cb48b_2:

    # n "[MN] se prepara para la lucha"
    n "[MN] เตรียมตัวสำหรับการต่อสู้"

# game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_mission_menu.rpy:43
translate english naruto_missions_menu_4c6cb48b_3:

    # n "[MN] se prepara para la lucha"
    n "[MN] เตรียมตัวสำหรับการต่อสู้"

translate english strings:

    # game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_mission_menu.rpy:2
    old "Encontrar al Gato Perdido"
    new "ตามหาแมวที่หายไป"

    # game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_mission_menu.rpy:2
    old "Acaba con un Bandido"
    new "จัดการโจรให้สิ้นซาก"
