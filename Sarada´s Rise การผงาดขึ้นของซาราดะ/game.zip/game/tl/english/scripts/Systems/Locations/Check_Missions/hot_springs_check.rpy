# TODO: Translation updated at 2024-12-01 21:25

translate english strings:

    # game/scripts/Systems/Locations/Check_Missions/hot_springs_check.rpy:2
    old "En desarrollo"
    new "กำลังพัฒนา"
