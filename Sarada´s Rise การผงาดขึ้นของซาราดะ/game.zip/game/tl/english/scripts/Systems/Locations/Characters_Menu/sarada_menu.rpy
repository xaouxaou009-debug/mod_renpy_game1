

# game/scripts/Systems/Locations/Characters_Menu/sarada_menu.rpy:17
translate english sarada_talk0_e518127c:

    # mn "Sarada, buenos días"
    mn "อรุณสวัสดิ์ ซาราดะ"

# game/scripts/Systems/Locations/Characters_Menu/sarada_menu.rpy:19
translate english sarada_talk0_c9ad38dc:

    # mn "Hola Sarada, buenas noches"
    mn "หวัดดี ซาราดะ ราตรีสวัสดิ์นะ"

# game/scripts/Systems/Locations/Characters_Menu/sarada_menu.rpy:22
translate english sarada_talk0_9e7840af:

    # sr "[MN], hola"
    sr "หวัดดีจ่ะ [MN]"

# game/scripts/Systems/Locations/Characters_Menu/sarada_menu.rpy:24
translate english sarada_talk0_8f0a2052:

    # sr "¿Qué te trae por aquí hoy?"
    sr "มีธุระอะไรถึงมาที่นี่เหรอวันนี้?"

# game/scripts/Systems/Locations/Characters_Menu/sarada_menu.rpy:38
translate english sarada_talk0_e518127c_1:

    # mn "Sarada, buenos días"
    mn "อรุณสวัสดิ์ ซาราดะ"

# game/scripts/Systems/Locations/Characters_Menu/sarada_menu.rpy:40
translate english sarada_talk0_c9ad38dc_1:

    # mn "Hola Sarada, buenas noches"
    mn "เฮ้ ซาราดะ ราตรีสวัสดิ์นะ"

# game/scripts/Systems/Locations/Characters_Menu/sarada_menu.rpy:43
translate english sarada_talk0_08989730:

    # sr "H-Hola..."
    sr "ก-หวัดดี..."

# game/scripts/Systems/Locations/Characters_Menu/sarada_menu.rpy:45
translate english sarada_talk0_40d3b680:

    # sr "¿Necesitas algo?"
    sr "มีอะไรหรือเปล่า?"

translate english strings:

    # game/scripts/Systems/Locations/Characters_Menu/sarada_menu.rpy:50
    old "{color=#ffb740}Solo venía a entrenar un poco.{/a}"
    new "{color=#ffb740}ฉันแค่แวะมาฝึกซ้อมนิดหน่อยน่ะ{/a}"

    # game/scripts/Systems/Locations/Characters_Menu/sarada_menu.rpy:50
    old "{color=#ffb740}Te estaba buscando.{/a}"
    new "{color=#ffb740}ฉันกำลังตามหาเธออยู่พอดีเลย{/a}"

    # game/scripts/Systems/Locations/Characters_Menu/sarada_menu.rpy:50
    old "{color=#ffb740}¿Me ayudarás a entrenar?{/a}"
    new "{color=#ffb740}เธอจะช่วยฉันฝึกซ้อมหน่อยได้ไหม?{/a}"

    # game/scripts/Systems/Locations/Characters_Menu/sarada_menu.rpy:50
    old "Solo quería saludar"
    new "ฉันแค่อยากมาทักทายเฉยๆ"



# game/scripts/Systems/Locations/Characters_Menu/sarada_menu.rpy:63
translate english sarada_menu1_ef110a73:

    # sr "Claro, ¿De qué se trata?"
    sr "ได้สิ มีเรื่องอะไรเหรอ?"

# game/scripts/Systems/Locations/Characters_Menu/sarada_menu.rpy:66
translate english sarada_menu1_8ebae043:

    # sr "Justo ahora quisiera estar sola..."
    sr "ตอนนี้ฉันอยากอยู่คนเดียวน่ะ..."

# game/scripts/Systems/Locations/Characters_Menu/sarada_menu.rpy:73
translate english sarada_menu1_3dc61bd6:

    # sr "Muy bien, preparate"
    sr "เอาล่ะ เตรียมตัวให้ดีนะคะ"

# game/scripts/Systems/Locations/Characters_Menu/sarada_menu.rpy:81
translate english sarada_menu1_a343716b:

    # sr "No estoy de humor por ahora..."
    sr "ฉันยังไม่ค่อยอารมณ์เท่าไหร่ตอนนี้..."

translate english strings:

    # game/scripts/Systems/Locations/Characters_Menu/sarada_menu.rpy:50
    old "Te quería preguntar algo"
    new "ฉันอยากจะถามอะไรหน่อยน่ะ"

    # game/scripts/Systems/Locations/Characters_Menu/sarada_menu.rpy:50
    old "¿Te apetece un combate?"
    new "สนใจมาลองสู้กันสักตั้งไหม?"
# TODO: Translation updated at 2024-11-29 23:49

# game/scripts/Systems/Locations/Characters_Menu/sarada_menu.rpy:14
translate english sarada_talk0_bfc22aaf:

    # sr "[MN], Hola, ¿Qué te trae por aquí?"
    sr "[MN] สวัสดี มีธุระอะไรถึงมาที่นี่เหรอ?"

# game/scripts/Systems/Locations/Characters_Menu/sarada_menu.rpy:20
translate english sarada_talk0_4a3c6b24:

    # sr "[MN]..."
    sr "[MN]..."

translate english strings:

    # game/scripts/Systems/Locations/Characters_Menu/sarada_menu.rpy:42
    old "{color=#ffd240}Vengo a entrenar un poco.{/a}"
    new "{color=#ffd240}ฉันมาฝึกซ้อมนิดหน่อยน่ะ{/a}"

    # game/scripts/Systems/Locations/Characters_Menu/sarada_menu.rpy:42
    old "{color=#ffd240}Te estaba buscando.{/a}"
    new "{color=#ffd240}ฉันกำลังตามหาเธออยู่พอดีเลย{/a}"

    # game/scripts/Systems/Locations/Characters_Menu/sarada_menu.rpy:42
    old "{color=#ffd240}¿Me ayudarás a entrenar?{/a}"
    new "{color=#ffd240}เธอจะช่วยฉันฝึกซ้อมหน่อยได้ไหม?{/a}"
