# TODO: Translation updated at 2024-12-01 21:25

# game/scripts/Systems/Locations/Characters_Menu/Talks/ino_talks/ino_exp_talks.rpy:3
translate english ino_friendly_talk_01756f46:

    # n "[MN] se quedó charlando con Ino"
    n "[MN] อยู่คุยกับอิโนะต่อ"

# game/scripts/Systems/Locations/Characters_Menu/Talks/ino_talks/ino_exp_talks.rpy:6
translate english ino_friendly_talk_f48fed99:

    # n "A ella le pareció una Charla interesante!"
    n "เธอรู้สึกว่ามันเป็นการพูดคุยที่น่าสนใจมาก!"

# game/scripts/Systems/Locations/Characters_Menu/Talks/ino_talks/ino_exp_talks.rpy:9
translate english ino_friendly_talk_6f61ab6d:

    # n "Y le pareció una buena charla"
    n "และเธอคิดว่ามันเป็นการพูดคุยที่ดีทีเดียว"

# game/scripts/Systems/Locations/Characters_Menu/Talks/ino_talks/ino_exp_talks.rpy:12
translate english ino_friendly_talk_bb3d973b:

    # n "Pero no estaba de humor..."
    n "แต่ดูเหมือนเธอจะไม่ได้อารมณ์นั้น..."

# game/scripts/Systems/Locations/Characters_Menu/Talks/ino_talks/ino_exp_talks.rpy:14
translate english ino_friendly_talk_fb7f0dcb:

    # n "Pero no estaba de buen humor..."
    n "แต่ดูเหมือนเธอจะอารมณ์ไม่ค่อยดีนัก..."

# game/scripts/Systems/Locations/Characters_Menu/Talks/ino_talks/ino_exp_talks.rpy:35
translate english ino_love_talk_20a2b34e:

    # n "[MN] intentó tener una charla {b}Coqueta{/a} con Ino"
    n "[MN] พยายามชวนอิโนะคุยแบบ{b}จีบ{/a}"

# game/scripts/Systems/Locations/Characters_Menu/Talks/ino_talks/ino_exp_talks.rpy:38
translate english ino_love_talk_3adcae70:

    # n "Parece que le gustó!"
    n "ดูเหมือนว่าเธอจะชอบมันนะ!"

# game/scripts/Systems/Locations/Characters_Menu/Talks/ino_talks/ino_exp_talks.rpy:41
translate english ino_love_talk_6f61ab6d:

    # n "Y le pareció una buena charla"
    n "และเธอคิดว่ามันเป็นการพูดคุยที่ดีทีเดียว"

# game/scripts/Systems/Locations/Characters_Menu/Talks/ino_talks/ino_exp_talks.rpy:44
translate english ino_love_talk_bb3d973b:

    # n "Pero no estaba de humor..."
    n "แต่ดูเหมือนเธอจะไม่ได้อารมณ์นั้น..."

# game/scripts/Systems/Locations/Characters_Menu/Talks/ino_talks/ino_exp_talks.rpy:46
translate english ino_love_talk_fb7f0dcb:

    # n "Pero no estaba de buen humor..."
    n "แต่ดูเหมือนเธอจะอารมณ์ไม่ค่อยดีนัก..."

