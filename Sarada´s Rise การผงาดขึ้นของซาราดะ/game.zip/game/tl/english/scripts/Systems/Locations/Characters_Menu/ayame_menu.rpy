# TODO: Translation updated at 2024-11-29 23:49

# game/scripts/Systems/Locations/Characters_Menu/ayame_menu.rpy:11
translate english ayame_talk0_05dd3d06:

    # ay "Bienvenido a Ichiraku Ramen, ¿Qué se te ofrece?"
    ay "ยินดีต้อนรับสู่ราเม็งอิจิราคุค่ะ รับอะไรดีคะ?"

# game/scripts/Systems/Locations/Characters_Menu/ayame_menu.rpy:16
translate english ayame_talk0_2d4094cd:

    # ay "[MN]! Siempre es un gusto verte, ¿Qué te trae hoy? Además de mi ramen, claro"
    ay "[MN]! ดีใจจังที่ได้เจอคุณ มีธุระอะไรถึงมาที่นี่วันนี้ล่ะ? นอกจากเรื่องราเม็งของฉันน่ะนะ"

# game/scripts/Systems/Locations/Characters_Menu/ayame_menu.rpy:19
translate english ayame_talk0_0a549adf:

    # ay "Buen día [MN], ¿Qué necesitas?"
    ay "สวัสดีจ้า [MN] มีอะไรให้ช่วยรึเปล่า?"

# game/scripts/Systems/Locations/Characters_Menu/ayame_menu.rpy:22
translate english ayame_talk0_a8c413b5:

    # ay "Oh, [MN]... Lo siento si hoy no estoy de Humor... ¿Qué necesitas?"
    ay "อ้าว [MN]... ขอโทษนะถ้าวันนี้ฉันดูอารมณ์ไม่ค่อยดี... มีอะไรล่ะ?"

# game/scripts/Systems/Locations/Characters_Menu/ayame_menu.rpy:26
translate english ayame_talk0_bf9dd8f1:

    # ay "[MN]... ¿Qué necesitas? Te agradecería que fueras breve..."
    ay "[MN]... มีอะไรเหรอ? ช่วยพูดให้สั้นกระชับหน่อยจะดีมากเลย..."

# game/scripts/Systems/Locations/Characters_Menu/ayame_menu.rpy:30
translate english ayame_talk0_a12eb012:

    # ay "Vaya, si es mi cliente favorito"
    ay "แหม ๆ... ลูกค้าคนโปรดมาแล้ว"

# game/scripts/Systems/Locations/Characters_Menu/ayame_menu.rpy:31
translate english ayame_talk0_7fa9d456:

    # ay "Dime, vienes por Ramen o... ¿Hay algo más que quieres probar?"
    ay "ว่ามาสิ วันนี้มาทานราเม็งหรือว่า... มีอย่างอื่นที่อยากลองอีกล่ะ?"

# game/scripts/Systems/Locations/Characters_Menu/ayame_menu.rpy:35
translate english ayame_talk0_40ee945b:

    # ay "¡Buen día [MN]!, ¿Listo para el mejor Ramen de la Aldea de la Hoja?"
    ay "สวัสดีจ้า [MN]! พร้อมทานราเม็งที่อร่อยที่สุดในหมู่บ้านโคโนฮะรึยัง?"

# game/scripts/Systems/Locations/Characters_Menu/ayame_menu.rpy:38
translate english ayame_talk0_64e72a03:

    # ay "Que alegría verte [MN], ¿Quieres lo de siempre?"
    ay "ดีใจจังที่ได้เจอคุณนะ [MN] จะรับแบบเดิมรึเปล่า?"

# game/scripts/Systems/Locations/Characters_Menu/ayame_menu.rpy:41
translate english ayame_talk0_9df1239d:

    # ay "[Mn]... Justo ahora estoy algo ocupada, así que si no es por ramen, ¿Podrías volver luego?"
    ay "[MN]... ตอนนี้ฉันยุ่งอยู่นิดหน่อย ถ้าไม่ได้มาทานราเม็ง ช่วยแวะมาใหม่ทีหลังได้ไหม?"

# game/scripts/Systems/Locations/Characters_Menu/ayame_menu.rpy:45
translate english ayame_talk0_164cc270:

    # ay "¿Sabes? Hay días en que los clientes de ponen de mal humor..."
    ay "รู้ไหม? บางวันลูกค้าก็ทำให้ฉันอารมณ์เสียสุด ๆ เลย..."

# game/scripts/Systems/Locations/Characters_Menu/ayame_menu.rpy:46
translate english ayame_talk0_d549827a:

    # ay "Me gustaría probar mis habilidades usando cucharas con ellos..."
    ay "ฉันชักอยากจะลองเอาช้อนมาฟาดหัวพวกเขาสักที..."

# game/scripts/Systems/Locations/Characters_Menu/ayame_menu.rpy:50
translate english ayame_talk0_cae6289a:

    # ay "Siempre es un placer verte por aquí, pero..."
    ay "ดีใจทุกครั้งที่เห็นคุณแวะเวียนมาแถวนี้ แต่ว่านะ..."

# game/scripts/Systems/Locations/Characters_Menu/ayame_menu.rpy:52
translate english ayame_talk0_b14168aa:

    # ay "¿Alguna vez pensaste en quedarte después de cerrar?"
    ay "คุณเคยคิดอยากจะอยู่ต่อหลังจากร้านปิดไหมล่ะ?"

# game/scripts/Systems/Locations/Characters_Menu/ayame_menu.rpy:53
translate english ayame_talk0_a7001a1c:

    # ay "Podríamos encontrar maneras de entretenernos, si ya sabes a lo que me refiero"
    ay "เราอาจจะหาอะไรสนุก ๆ ทําด้วยกันได้นะ ถ้าคุณเข้าใจที่ฉันพูด"

translate english strings:

    # game/scripts/Systems/Locations/Characters_Menu/ayame_menu.rpy:80
    old "Charlar (En desarrollo)"
    new "พูดคุย (กำลังพัฒนา)"

    # game/scripts/Systems/Locations/Characters_Menu/ayame_menu.rpy:80
    old "{color#fc608f}Intimidad{/a} (En desarrollo)"
    new "{color#fc608f}ความสนิทสนม{/a} (กำลังพัฒนา)"

# TODO: Translation updated at 2024-12-20 07:52

translate english strings:

    # game/scripts/Systems/Locations/Characters_Menu/ayame_menu.rpy:80
    old "Comprar"
    new "ซื้อสินค้า"

    # game/scripts/Systems/Locations/Characters_Menu/ayame_menu.rpy:80
    old "{color=#fc608f}Intimidad{/a} (En desarrollo)"
    new "{color=#fc608f}ความสนิทสนม{/a} (กำลังพัฒนา)"
