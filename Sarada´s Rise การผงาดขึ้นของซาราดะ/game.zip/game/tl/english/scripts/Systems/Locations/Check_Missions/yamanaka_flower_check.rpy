
translate english strings:

    # game/scripts/Systems/Locations/Check_Missions/yamanaka_flower_check.rpy:10
    old "Ya tienes la flor, vuelve en otro momento"
    new "คุณได้ดอกไม้มาแล้ว กลับมาใหม่ในภายหลังนะ"
