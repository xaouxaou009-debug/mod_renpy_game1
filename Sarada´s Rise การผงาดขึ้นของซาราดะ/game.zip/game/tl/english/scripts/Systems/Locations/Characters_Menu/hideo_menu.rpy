# TODO: Translation updated at 2024-11-29 23:49

# game/scripts/Systems/Locations/Characters_Menu/hideo_menu.rpy:12
translate english hideo_talk0_94a4c04e:

    # hd "¡[MN]! Me alegra verte..."
    hd "[MN]! ดีใจจังที่ได้เจอ...เจ้า"

# game/scripts/Systems/Locations/Characters_Menu/hideo_menu.rpy:15
translate english hideo_talk0_62ba0d62:

    # hd "Estoy un poco nervioso por la prueba de Zubon-Sensei... ¿Tú no?"
    hd "ฉันแอบกังวลกับการทดสอบของอาจารย์ซูบงนิดหน่อยแฮะ... นายไม่กังวลเหรอ?"

# game/scripts/Systems/Locations/Characters_Menu/hideo_menu.rpy:18
translate english hideo_talk0_71674ce6:

    # hd "¡[MN]! Debémos celebrar ¿No lo crees? Pasámos la prueba de Zubon-Sensei"
    hd "[MN]! เราน่าจะฉลองกันหน่อยนะ ว่าไหม? เราผ่านการทดสอบของอาจารย์ซูบงมาได้แล้วนี่"

# game/scripts/Systems/Locations/Characters_Menu/hideo_menu.rpy:19
translate english hideo_talk0_1b6539b7:

    # hd "Nuestro trabajo en equipo fue perfecto, ¿No lo crees?"
    hd "การทำงานเป็นทีมของเรานี่มันยอดเยี่ยมไปเลย ว่าไหมล่ะ?"

# game/scripts/Systems/Locations/Characters_Menu/hideo_menu.rpy:22
translate english hideo_talk0_d6e58d31:

    # mn "Hideo, ¿Qué haces aquí?"
    mn "ฮิเดโอะ นายมาทำอะไรที่นี่น่ะ?"

# game/scripts/Systems/Locations/Characters_Menu/hideo_menu.rpy:23
translate english hideo_talk0_21926b7b:

    # hd "Oh, solo estoy ayudando a los niños a entender lo básico"
    hd "อ๋อ ฉันแค่มาช่วยเด็กๆ ทำความเข้าใจพื้นฐานน่ะ"

# game/scripts/Systems/Locations/Characters_Menu/hideo_menu.rpy:24
translate english hideo_talk0_3b058886:

    # hd "¿No sabías que soy asistente de Mirai?"
    hd "นายไม่รู้เหรอว่าฉันเป็นผู้ช่วยของมิไรน่ะ?"

# game/scripts/Systems/Locations/Characters_Menu/hideo_menu.rpy:26
translate english hideo_talk0_78b15996:

    # hd "Aunque es extraño, ¿Sabes?... A veces siento que los niños tienen más talento que yo"
    hd "แต่ก็น่าแปลกนะรู้ไหม?... บางทีฉันก็รู้สึกว่าเด็กพวกนี้มีพรสวรรค์มากกว่าฉันซะอีก"

# game/scripts/Systems/Locations/Characters_Menu/hideo_menu.rpy:29
translate english hideo_talk0_77b8e886:

    # hd "Es raro estar en la academia en estos días..."
    hd "ช่วงนี้การได้มาอยู่ที่โรงเรียนนีนี่มันรู้สึกแปลกๆ แฮะ..."

# game/scripts/Systems/Locations/Characters_Menu/hideo_menu.rpy:30
translate english hideo_talk0_589cc66e:

    # hd "Todo se siente diferente... Ahora que nos estamos preparando para misiones reales... "
    hd "ทุกอย่างดูเปลี่ยนไปหมดเลย... ตอนนี้ที่เรากำลังเตรียมตัวสำหรับภารกิจจริงๆ เนี่ย..."

# game/scripts/Systems/Locations/Characters_Menu/hideo_menu.rpy:40
translate english hideo_talk0_ae0aef32:

    # hd "¡[MN]! Tienes que ayudarme, hoy tengo entrenamiento con Zubon-Sensei..."
    hd "[MN]! นายต้องช่วยฉันนะ วันนี้ฉันมีฝึกกับอาจารย์ซูบง..."

# game/scripts/Systems/Locations/Characters_Menu/hideo_menu.rpy:42
translate english hideo_talk0_9f6f2c94:

    # hd "Tengo miedo de que termine siendo el saco de golpes de Yuna otra vez..."
    hd "ฉันกลัวว่าตัวเองจะต้องไปเป็นกระสอบทรายให้ยูนะอีกแน่ๆ..."

# game/scripts/Systems/Locations/Characters_Menu/hideo_menu.rpy:44
translate english hideo_talk0_8695c228:

    # hd "¿Deberíamos hablar con Zubon para que baje un poco la intensidad? Mi cuerpo no aguantará más..."
    hd "เราไปคุยกับซูบงให้ลดความเข้มงวดลงหน่อยดีไหม? ร่างกายฉันจะไม่ไหวอยู่แล้ว..."

# game/scripts/Systems/Locations/Characters_Menu/hideo_menu.rpy:48
translate english hideo_talk0_53b42ddd:

    # hd "[MN]... Ya no puedo... Yuna literalmente me usa como su saco de boxeo para probar sus jutsus..."
    hd "[MN]... ฉันไม่ไหวแล้ว... ยูนะเอาฉันไปเป็นกระสอบทรายไว้ทดสอบวิชานินจาจริงๆ ด้วย..."

# game/scripts/Systems/Locations/Characters_Menu/hideo_menu.rpy:50
translate english hideo_talk0_5919ad93:

    # hd "Esto no es entrenamiento... ¡ES UNA TORTURA!" with vpunch
    hd "นี่มันไม่ใช่การฝึกแล้ว... แต่มันคือการทรมานชัดๆ!" with vpunch

# game/scripts/Systems/Locations/Characters_Menu/hideo_menu.rpy:52
translate english hideo_talk0_db9f8257:

    # hd "No creo llegar vivo a los Exámenes... Debes de salvarme..."
    hd "ฉันไม่คิดว่าตัวเองจะมีชีวิตรอดไปถึงวันสอบหรอ... นายต้องช่วยฉันนะ..."

# game/scripts/Systems/Locations/Characters_Menu/hideo_menu.rpy:55
translate english hideo_talk0_fa92faff:

    # hd "*suspiro* Hoy es un día tranquilo..."
    hd "*ถอนหายใจ* วันนี้เป็นวันที่สงบเงียบดีจัง..."

# game/scripts/Systems/Locations/Characters_Menu/hideo_menu.rpy:58
translate english hideo_talk0_99e5f1c1:

    # hd "Bueno, tan tranquilo como puede ser con Yuna lanzándome Kunais por doquier..."
    hd "เอ่อ เท่าที่จะสงบได้แหละนะ ทั้งที่ยูนะปาคุโนะฮายใส่ฉันไปทั่วเนี่ย..."

# game/scripts/Systems/Locations/Characters_Menu/hideo_menu.rpy:60
translate english hideo_talk0_a923ff83:

    # hd "¿Cómo le hacías para soportarla...?"
    hd "นายนี่ทนมือทนเท้าเธอมาได้ยังไงกัน...?"

# game/scripts/Systems/Locations/Characters_Menu/hideo_menu.rpy:69
translate english hideo_talk0_023d1cc2:

    # hd "¡Ah, [MN]! Te invito un ramen y..."
    hd "อ๊ะ [MN]! เดี๋ยวฉันเลี้ยงราเม็งแล้วก็..."

# game/scripts/Systems/Locations/Characters_Menu/hideo_menu.rpy:71
translate english hideo_talk0_4a918598:

    # hd "Bueno, ¿Mejor me invitas tú?... Jeje"
    hd "งั้น... เปลี่ยนเป็นนายเลี้ยงฉันแทนดีไหมล่ะ? แหะๆ"

# game/scripts/Systems/Locations/Characters_Menu/hideo_menu.rpy:73
translate english hideo_talk0_b358795f:

    # hd "Estoy ahorrando porque Zubon-Sensei dice que tenemos que traer nuestros propios suministros para la Prueba..."
    hd "ช่วงนี้ฉันกำลังเก็บเงินอยู่ เพราะอาจารย์ซูบงบอกว่าเราต้องเตรียมอุปกรณ์ของเราไปเองสำหรับการทดสอบ..."

# game/scripts/Systems/Locations/Characters_Menu/hideo_menu.rpy:77
translate english hideo_talk0_151777e3:

    # hd "Después de un día de entrenamiento con Yuna, necesito este ramen más que nada en el mundo..."
    hd "หลังจากผ่านการฝึกกับยูนะมาทั้งวัน ราเม็งนี่แหละคือสิ่งที่ฉันต้องการมากที่สุดในโลกเลย..."

# game/scripts/Systems/Locations/Characters_Menu/hideo_menu.rpy:78
translate english hideo_talk0_9ce665ab:

    # hd "No sé si lo hago porque me gusta, o porque es lo único que me calma el dolor..."
    hd "ฉันก็ไม่รู้เหมือนกันนะว่ากินเพราะชอบ หรือเพราะมันเป็นสิ่งเดียวที่ช่วยบรรเทาอาการเจ็บปวดได้กันแน่..."

# game/scripts/Systems/Locations/Characters_Menu/hideo_menu.rpy:82
translate english hideo_talk0_1004757c:

    # hd "¿Alguna vez has probado pedirle a Ayame que te haga un plato especial?"
    hd "นายเคยลองขอให้อายาเมะทำเมนูพิเศษให้กินบ้างหรือยังล่ะ?"

# game/scripts/Systems/Locations/Characters_Menu/hideo_menu.rpy:84
translate english hideo_talk0_8e2260ed:

    # hd "Dicen que si le caes bien te lo prepara..."
    hd "เขาว่ากันว่าถ้าเธอชอบใคร เธอจะยอมทำให้เป็นพิเศษเลยนะ..."

# game/scripts/Systems/Locations/Characters_Menu/hideo_menu.rpy:887
translate english hideo_talk0_cf9bc7f5:

    # hd "Aunque, yo nunca he tenido esa suerte..."
    hd "แต่ก็นะ... ฉันไม่เคยมีโชคแบบนั้นเลยสิ"

translate english strings:

    # game/scripts/Systems/Locations/Characters_Menu/hideo_menu.rpy:97
    old "¿Cómo estás?"
    new "สบายดีไหม?"

