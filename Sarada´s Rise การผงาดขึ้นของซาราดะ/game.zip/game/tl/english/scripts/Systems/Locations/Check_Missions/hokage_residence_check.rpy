# TODO: Translation updated at 2024-11-29 23:49

translate english strings:

    # game/scripts/Systems/Locations/Check_Missions/hokage_residence_check.rpy:3
    old "Naruto no trabaja los fines de semana"
    new "นารูโตะไม่ทำงานในช่วงวันหยุดสุดสัปดาห์"
