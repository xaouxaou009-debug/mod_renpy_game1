
translate english strings:

    # game/scripts/Systems/Locations/Check_Missions/uchiha_house_check.rpy:3
    old "No hay nadie"
    new "ไม่มีใครอยู่เลย"

    # game/scripts/Systems/Locations/Check_Missions/uchiha_house_check.rpy:6
    old "Están dormidos"
    new "พวกเขากำลังนอนหลับอยู่"
# TODO: Translation updated at 2024-11-29 23:49

translate english strings:

    # game/scripts/Systems/Locations/Check_Missions/uchiha_house_check.rpy:7
    old "Vuelve al Medio Día"
    new "กลับมาตอนเที่ยง"

    # game/scripts/Systems/Locations/Check_Missions/uchiha_house_check.rpy:22
    old "Están dormidas"
    new "พวกเธอนอนหลับกันอยู่"
