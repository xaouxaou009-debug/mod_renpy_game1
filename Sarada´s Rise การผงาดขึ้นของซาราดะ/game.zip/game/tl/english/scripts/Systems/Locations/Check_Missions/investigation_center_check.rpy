# TODO: Translation updated at 2024-11-29 23:49

translate english strings:

    # game/scripts/Systems/Locations/Check_Missions/investigation_center_check.rpy:7
    old "Está Cerrado"
    new "ปิดทำการ"

# TODO: Translation updated at 2024-12-01 21:25

translate english strings:

    # game/scripts/Systems/Locations/Check_Missions/investigation_center_check.rpy:5
    old "Vuelve en la noche"
    new "กลับมาใหม่ตอนกลางคืน"

    # game/scripts/Systems/Locations/Check_Missions/investigation_center_check.rpy:8
    old "En Desarrollo"
    new "กำลังพัฒนา"
