# TODO: Translation updated at 2024-11-29 23:49

# game/scripts/Systems/Locations/Characters_Menu/zubon_menu.rpy:12
translate english zubon_talk0_017fb00b:

    # zb "¡[MN]! Que buen momento en el que has llegado"
    zb "[MN]! ช่างมาได้จังหวะเวลาพอดีเป๊ะเลยนะเนี่ย"

# game/scripts/Systems/Locations/Characters_Menu/zubon_menu.rpy:13
translate english zubon_talk0_91935094:

    # zb "¿Qué tal si te unes al entrenamiento de hoy? Estos chicos han mejorado mucho"
    zb "มาร่วมการฝึกวันนี้หน่อยเป็นไง? เด็กๆ พวกนี้พัฒนาขึ้นเยอะเลยล่ะ"

# game/scripts/Systems/Locations/Characters_Menu/zubon_menu.rpy:14
translate english zubon_talk0_c5a3e483:

    # zb "Solo mira a Yuna... Ella ha mejorado mucho gracias a mi buen ejemplo"
    zb "ดูยูนะสิ... พัฒนาขึ้นตั้งเยอะก็เพราะตัวอย่างอันดีงามของฉันเองแหละ"

# game/scripts/Systems/Locations/Characters_Menu/zubon_menu.rpy:17
translate english zubon_talk0_6c462cb1:

    # zb "Y Hideo... Bueno, Hideo necesita algo más que solo entrenamiento físico, ¿No?"
    zb "ส่วนฮิเดโอะ... อืม ฮิเดโอะเนี่ยต้องฝึกอะไรมากกว่าแค่ร่างกายสินะ?"

# game/scripts/Systems/Locations/Characters_Menu/zubon_menu.rpy:20
translate english zubon_talk0_219a8fc8:

    # zb "Vamos, únete, ¡Muéstrame el poder de la Juventud!"
    zb "มาเถอะ มาร่วมแจมกัน แสดงพลังแห่งวัยหนุ่มให้ฉันเห็นหน่อยสิ!"

# game/scripts/Systems/Locations/Characters_Menu/zubon_menu.rpy:23
translate english zubon_talk0_38e0771a:

    # zb "Ajá!, uno de mis mejores alumnos, ya veía venir que iban a pasar al prueba esta vez"
    zb "ฮ่าๆ! หนึ่งในลูกศิษย์คนโปรดของฉัน รู้อยู่แล้วเชียวว่าเธอต้องผ่านการทดสอบครั้งนี้ได้"

# game/scripts/Systems/Locations/Characters_Menu/zubon_menu.rpy:25
translate english zubon_talk0_cce56910:

    # zb "Pero no te confíes, la verdadera prueba empieza ahora"
    zb "แต่อย่าเพิ่งตายใจไปล่ะ ของจริงมันเพิ่งจะเริ่มต้นต่างหาก"

# game/scripts/Systems/Locations/Characters_Menu/zubon_menu.rpy:26
translate english zubon_talk0_289489ae:

    # zb "Ya les he dado una buena dosis de entrenamiento, pero ahora necesitamos mejorar en equipo"
    zb "ฉันเคี่ยวกรำพวกเธอมาพอสมควรแล้ว แต่ตอนนี้เราต้องพัฒนาเรื่องการทำงานเป็นทีมด้วย"

# game/scripts/Systems/Locations/Characters_Menu/zubon_menu.rpy:27
translate english zubon_talk0_783d7202:

    # zb "Si no puedes confiar tus amigos, olvídate de ser un ninja"
    zb "ถ้าไม่รู้จักไว้ใจเพื่อนล่ะก็ เลิกคิดจะเป็นนินจาไปได้เลย"

# game/scripts/Systems/Locations/Characters_Menu/zubon_menu.rpy:29
translate english zubon_talk0_d4b01207:

    # zb "Los exámenes Chunin se acercan, ¿verdad?"
    zb "การสอบจูนินใกล้เข้ามาแล้วสินะ?"

# game/scripts/Systems/Locations/Characters_Menu/zubon_menu.rpy:30
translate english zubon_talk0_7eecaf48:

    # zb "Recuerden que, si no pueden trabajar en equipo, no hay forma de ganar"
    zb "จำไว้ว่าถ้าทำงานเป็นทีมไม่ได้ ก็ไม่มีทางชนะหรอกนะ"

# game/scripts/Systems/Locations/Characters_Menu/zubon_menu.rpy:31
translate english zubon_talk0_577734b3:

    # zb "Si pueden controlar sus miedos y dejar de lado sus diferencias, estoy seguro que podrán superarlos"
    zb "ถ้าพวกเธอควบคุมความกลัวและก้าวข้ามความบาดหมางกันไปได้ ฉันมั่นใจว่าต้องผ่านมันไปได้แน่"

# game/scripts/Systems/Locations/Characters_Menu/zubon_menu.rpy:33
translate english zubon_talk0_47d6f1ea:

    # zb "De lo contrario, tendrán que regresar a la academia con el rabo entre las patas"
    zb "ไม่อย่างนั้นพวกเธอได้กลับไปเรียนที่สถาบันนินจาด้วยความอับอายแน่"

