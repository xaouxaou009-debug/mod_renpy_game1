# TODO: Translation updated at 2024-12-20 07:52

# game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_questions.rpy:3
translate english naruto_question_sarada_dialog_25ff9e27:
    # mn "Señor Séptimo..."
    mn "ท่านโฮคาเงะรุ่นที่เจ็ด..."

# game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_questions.rpy:5
translate english naruto_question_sarada_dialog_f392e370:
    # mn "¿Usted se encuentra bien?"
    mn "คุณไหวไหมครับเนี่ย?"

# game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_questions.rpy:8
translate english naruto_question_sarada_dialog_ca47354a:
    # nt "¿Si me encuentro bien?"
    nt "ฉันจะไหวไหมงั้นเหรอ?"

# game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_questions.rpy:10
translate english naruto_question_sarada_dialog_8bb9062f:
    # nt "¿A qué viene la pregunta?"
    nt "ถามทำไมเนี่ย?"

# game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_questions.rpy:14
translate english naruto_question_sarada_dialog_52810f4a:
    # mn "(No creo que deba decirle que sé que está débil...)"
    mn "(ฉันว่าไม่ควรบอกเขาหรอกมั้งว่ารู้เรื่องที่เขากำลังอ่อนแอน่ะ...)"

# game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_questions.rpy:16
translate english naruto_question_sarada_dialog_9441b186:
    # mn "(Mejor no se lo digo por ahora... No quiero delatar a Sarada)"
    mn "(ตอนนี้อย่าเพิ่งบอกเลยดีกว่า... ไม่อยากให้ซาราดะซวยไปด้วย)"

# game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_questions.rpy:19
translate english naruto_question_sarada_dialog_422d0b5f:
    # mn "Oh, no es nada jaja, pregunto porque supongo que este trabajo debe de ser muy duro..."
    mn "อ๋อ ไม่มีอะไรครับ ฮ่าๆ แค่ถามดูเฉยๆ เพราะคิดว่างานนี้น่าจะหนักหนาสาหัสเอาการ..."

# game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_questions.rpy:22
translate english naruto_question_sarada_dialog_b5898710:
    # nt "Aaah, no te preocupes jajaja, deberas"
    nt "อ่า ไม่ต้องห่วงน่า ฮ่าๆ จริงๆ นะ"

# game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_questions.rpy:24
translate english naruto_question_sarada_dialog_527142c0:
    # nt "Soy el Séptimo Hokage, no hay nada que pueda conmigo jejeje"
    nt "ฉันคือโฮคาเงะรุ่นที่เจ็ดเชียวนะ ไม่มีอะไรโค่นฉันได้หรอกน่า ฮìฮìฮì"

# game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_questions.rpy:26
translate english naruto_question_sarada_dialog_bc6ed36f:
    # nt "No te preocupes por mí, pero aún así agradezco la pregunta"
    nt "ไม่ต้องห่วงฉันหรอก แต่ยังไงก็ขอบใจที่เป็นห่วงนะ"

# game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_questions.rpy:33
translate english naruto_question1_82166017:
    # mn "Señor Séptimo, ¿Puedo preguntar sobre Boruto?"
    mn "ท่านโฮคาเงะรุ่นที่เจ็ดครับ ผมขอถามเรื่องของโบรูโตะหน่อยได้ไหมครับ?"

# game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_questions.rpy:36
translate english naruto_question1_b62c52cf:
    # nt "¿Boruto?"
    nt "โบรูโตะงั้นเหรอ?"

# game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_questions.rpy:38
translate english naruto_question1_a5b48174:
    # nt "Pensé que ya sabías que no se encuentra en al aldea"
    nt "ฉันนึกว่าเธอรู้ตั้งนานแล้วซะอีกว่าเขาไม่ได้อยู่ในหมู่บ้าน"

# game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_questions.rpy:40
translate english naruto_question1_ba1cbfee:
    # nt "Se fue hace unos años con Sasuke y Kawaki a entrenar"
    nt "เขาออกไปฝึกวิชากับซาสึเกะและคาวากิเมื่อไม่กี่ปีមុនนี้น่ะ"

# game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_questions.rpy:42
translate english naruto_question1_1ddef3d6:
    # nt "Jeje, seguro que Sasuke lo entrenó bastante bien"
    nt "ฮìฮì ฉันมั่นใจว่าซาสึเกะต้องฝึกสอนเขาอย่างดีเยี่ยมแน่ๆ"

# game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_questions.rpy:44
translate english naruto_question1_8472ddfd:
    # nt "A tal nivel de superarnos jeje"
    nt "ถึงขนาดที่จะเหนือกว่าพวกเราเลยล่ะมั้ง ฮìฮì"

# game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_questions.rpy:47
translate english naruto_question1_a6b71577:
    # mn "¿Eso no le afecta? Que Boruto lo supere"
    mn "ไม่รู้สึกหงุดหงิดใจบ้างเหรอครับ? ที่โบรูโตะอาจจะเก่งเหนือกว่าคุณน่ะ?"

# game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_questions.rpy:50
translate english naruto_question1_e125fc29:
    # nt "¿Molestarme? Para nada jaja"
    nt "หงุดหงิดใจงั้นเหรอ? ไม่มีทางหรอก ฮ่าๆ"

# game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_questions.rpy:52
translate english naruto_question1_598573f2:
    # nt "Me enorgullecería si nos llegase a superar"
    nt "ฉันจะภูมิใจซะด้วยซ้ำถ้าเขาเหนือกว่าพวกเราได้จริงๆ"

# game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_questions.rpy:54
translate english naruto_question1_aad9ec4e:
    # nt "Además, cuando yo ya no esté, tu generación va a ser la que se encargará de la aldea"
    nt "อีกอย่างนะ พูถึงตอนที่ฉันไม่อยู่แล้ว คนรุ่นของพวกเธอต่างหากที่จะต้องเป็นคนดูแลหมู่บ้านต่อไป"

# game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_questions.rpy:56
translate english naruto_question1_a37ebb63:
    # nt "Me sentiría feliz si me voy y la aldea queda en buenas manos"
    nt "ฉันคงจะดีใจมากเลยล่ะถ้าถึงเวลาที่ฉันต้องไป แล้วหมู่บ้านตกอยู่ในมือของคนเก่งๆ ที่น่าไว้วางใจ"

# game/scripts/Systems/Locations/Characters_Menu/Talks/naruto_talks/naruto_questions.rpy:58
translate english naruto_question1_32462c4b:
    # mn "..."
    mn "..."
