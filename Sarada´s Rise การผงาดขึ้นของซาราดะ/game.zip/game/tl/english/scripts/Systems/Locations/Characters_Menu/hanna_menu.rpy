# TODO: Translation updated at 2024-12-01 23:11

# game/scripts/Systems/Locations/Characters_Menu/hanna_menu.rpy:10
translate english hanna_talk_fe6b6f39:

    # hn "Hola, tenga buen día"
    hn "สวัสดี ขอให้เป็นวันที่ดีนะ"

# game/scripts/Systems/Locations/Characters_Menu/hanna_menu.rpy:11
translate english hanna_talk_3d0fa2e6:

    # hn "¿En qué lo puedo ayudar?"
    hn "มีอะไรให้ฉันช่วยไหม"

# game/scripts/Systems/Locations/Characters_Menu/hanna_menu.rpy:25
translate english hanna_talk_b81bbc7f:

    # hn "¡[MN]! Que alegría verte"
    hn "[MN]! ดีใจจังที่ได้เจอคุณ"

# game/scripts/Systems/Locations/Characters_Menu/hanna_menu.rpy:27
translate english hanna_talk_0bf31205:

    # hn "¿Te puedo ayudar en algo?"
    hn "มีอะไรให้ฉันช่วยหน่อยไหม"

# game/scripts/Systems/Locations/Characters_Menu/hanna_menu.rpy:33
translate english hanna_talk_63c34de6:

    # hn "Hola [MN] ¿Cómo va todo?"
    hn "สวัสดี [MN] ทุกอย่างเป็นยังไงบ้าง"

# game/scripts/Systems/Locations/Characters_Menu/hanna_menu.rpy:34
translate english hanna_talk_385361a3:

    # hn "Tengo algo de tiempo si quieres charlar un rato"
    hn "ฉันพอมีเวลาว่างนะ ถ้าคุณอยากคุยกันสักหน่อย"

# game/scripts/Systems/Locations/Characters_Menu/hanna_menu.rpy:40
translate english hanna_talk_77567f20:

    # hn "Oh, hola [MN]"
    hn "อ๋อ สวัสดีจ้ะ [MN]"

# game/scripts/Systems/Locations/Characters_Menu/hanna_menu.rpy:41
translate english hanna_talk_9097d2d8:

    # hn "Hoy no estoy en mi mejor momento, pero me alegra que hayas venido a verme..."
    hn "วันนี้ฉันไม่ค่อยสบายเท่าไหร่ แต่ก็ดีใจที่คุณมาหา..."

# game/scripts/Systems/Locations/Characters_Menu/hanna_menu.rpy:47
translate english hanna_talk_9cca5c8e:

    # hn "Hola [MN]..."
    hn "สวัสดีจ้ะ [MN]..."

# game/scripts/Systems/Locations/Characters_Menu/hanna_menu.rpy:48
translate english hanna_talk_afe22b2d:

    # hn "Para serte sincera, hoy no es un gran día para mí..."
    hn "พูดตามตรง วันนี้ไม่ใช่วันที่ดีของฉันเลย..."

# game/scripts/Systems/Locations/Characters_Menu/hanna_menu.rpy:49
translate english hanna_talk_54e25789:

    # hn "Pero si tienes algo importante que decir, supongo que podría escucharte"
    hn "แต่ถ้าคุณมีเรื่องสำคัญจะพูดล่ะก็ ฉันพอจะฟังอยู่หรอกนะ"

# game/scripts/Systems/Locations/Characters_Menu/hanna_menu.rpy:75
translate english hanna_menu1_b9af84dc:

    # hn "Claro, ¿Qué necesitas?"
    hn "ได้สิ เธอต้องการอะไรล่ะ"

# game/scripts/Systems/Locations/Characters_Menu/hanna_menu.rpy:78
translate english hanna_menu1_6b6925cf:

    # hn "Los siento, justo ahora no puedo..."
    hn "โทษที ตอนนี้ฉันไม่ว่างเลย..."

# game/scripts/Systems/Locations/Characters_Menu/hanna_menu.rpy:82
translate english hanna_menu1_f7fef0ee:

    # hn "Claro, siga adelante"
    hn "ได้สิ เอาเลย"

# game/scripts/Systems/Locations/Characters_Menu/hanna_menu.rpy:85
translate english hanna_menu1_8217ce23:

    # "[MN] trabajó todo el día en el Hospital con Sakura"
    "[MN] ทำงานอยู่ที่โรงพยาบาลกับซากุระมาทั้งวันเลย"

# game/scripts/Systems/Locations/Characters_Menu/hanna_menu.rpy:95
translate english hanna_menu1_45c6d164:

    # hn "Me temo que la señorita Sakura no está"
    hn "เกรงว่าคุณซากุระจะไม่ค่อยอยู่น่ะสิคะ"

# game/scripts/Systems/Locations/Characters_Menu/hanna_menu.rpy:98
translate english hanna_menu1_387c2572:

    # hn "Puede volver al {b}Medio Día{/a} o en la {b}Tarde{/a} que es cuando está de turno"
    hn "คุณกลับมาใหม่ตอน {b}เที่ยง{/a} หรือช่วง {b}บ่าย{/a} ตอนที่เธอเข้าเวรก็ได้นะ"

translate english strings:

    # game/scripts/Systems/Locations/Characters_Menu/hanna_menu.rpy:72
    old "Trabajar con Sakura"
    new "ทำงานร่วมกับซากุระ"

