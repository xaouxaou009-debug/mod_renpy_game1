# TODO: Translation updated at 2024-12-01 23:07

# game/scripts/Systems/Locations/Characters_Menu/tenten_menu.rpy:10
translate english tenten_talk_0_74ff967c:

    # tt "Hola [MN], ¿Qué necesitas?"
    tt "สวัสดี [MN] มีอะไรให้ช่วยหรือเปล่า?"

# game/scripts/Systems/Locations/Characters_Menu/tenten_menu.rpy:16
translate english tenten_talk_0_34e7662a:

    # yl "Hola... ¿Necesitas algo?"
    yl "สวัสดี... มีอะไรต้องการรึเปล่าคะ?"

translate english strings:

    # game/scripts/Systems/Locations/Characters_Menu/tenten_menu.rpy:26
    old "Vender"
    new "ขายของ"
