# TODO: Translation updated at 2024-11-29 23:49

translate english strings:

    # game/scripts/Systems/Locations/Check_Missions/uzumaki_house_check.rpy:6
    old "Vuelve el Domingo por la Mañana"
    new "กลับมาพบกันอีกครั้งในเช้าวันอาทิตย์"
