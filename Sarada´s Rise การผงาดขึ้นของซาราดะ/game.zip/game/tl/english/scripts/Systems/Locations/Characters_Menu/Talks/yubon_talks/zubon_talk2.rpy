# TODO: Translation updated at 2024-11-29 23:49

# game/scripts/Systems/Locations/Characters_Menu/Talks/yubon_talks/zubon_talk2.rpy:8
translate english zubon_talk2_5e7c4661:

    # zb "Yo, ¿Cómo estoy?"
    zb "โย่ ฉันเป็นไงบ้างล่ะ?"

# game/scripts/Systems/Locations/Characters_Menu/Talks/yubon_talks/zubon_talk2.rpy:11
translate english zubon_talk2_2b6be546:

    # zb "¡Estupendamente jajaja!" with vpunch
    zb "ยอดเยี่ยมไปเลย ฮ่าๆๆ!" with vpunch

# game/scripts/Systems/Locations/Characters_Menu/Talks/yubon_talks/zubon_talk2.rpy:14
translate english zubon_talk2_42f5e55f:

    # zb "Ver como progresan los jovenes me apasiona"
    zb "เห็นพวกเด็กๆ พัฒนาขึ้นแล้วมันทำให้ฉันตื่นเต้นจริงๆ"

# game/scripts/Systems/Locations/Characters_Menu/Talks/yubon_talks/zubon_talk2.rpy:17
translate english zubon_talk2_2a5e147b:

    # zb "¡La juventud hoy en día es algo increíble JAJAJA!" with vpunch
    zb "วัยรุ่นสมัยนี้นี่เหลือเชื่อจริงๆ ฮ่าฮ่าฮ่า!" with vpunch

# game/scripts/Systems/Locations/Characters_Menu/Talks/yubon_talks/zubon_talk2.rpy:20
translate english zubon_talk2_9c772fce:

    # zb "Aunque, si te soy sincero, acá entre nos"
    zb "แต่พูดตามตรงนะ เอาไประหว่างเราสองคนเนี่ย"

# game/scripts/Systems/Locations/Characters_Menu/Talks/yubon_talks/zubon_talk2.rpy:22
translate english zubon_talk2_d6425849:

    # zb "Ver a Hideo entrenar... Como que me provoca depresión..."
    zb "พอได้ดูฮิเดโอะฝึกซ้อม... มันก็แอบทำให้ฉันหดหู่เหมือนกันนะ..."

# game/scripts/Systems/Locations/Characters_Menu/Talks/yubon_talks/zubon_talk2.rpy:24
translate english zubon_talk2_b87f9196:

    # zb "¿Cómo crees que estoy?"
    zb "เธอคิดว่าฉันเป็นยังไงบ้างล่ะ?"

# game/scripts/Systems/Locations/Characters_Menu/Talks/yubon_talks/zubon_talk2.rpy:25
translate english zubon_talk2_6a67488b:

    # zb "¡Hoy revoso de alegría!" with vpunch
    zb "วันนี้ฉันรู้สึกเปี่ยมไปด้วยความสุขเลยล่ะ!" with vpunch

# game/scripts/Systems/Locations/Characters_Menu/Talks/yubon_talks/zubon_talk2.rpy:26
translate english zubon_talk2_e51485f5:

    # zb "¡Ay!... Aunque... Si quedé adolorido después de la prueba..."
    zb "อ่า!... แต่ว่านะ... หลังจากการทดสอบ ฉันดันปวดเมื่อยไปหมดเลย..."

# game/scripts/Systems/Locations/Characters_Menu/Talks/yubon_talks/zubon_talk2.rpy:27
translate english zubon_talk2_8713ac5d:

    # zb "Maldición... Ya me siento como todo un viejo..."
    zb "ให้ตายสิ... ฉันเริ่มรู้สึกเหมือนตัวเองเป็นตาแก่เข้าไปทุกทีแล้ว..."

# game/scripts/Systems/Locations/Characters_Menu/Talks/yubon_talks/zubon_talk2.rpy:30
translate english zubon_talk2_4e0dd724:

    # zb "Uff, ahora estoy mejor"
    zb "เฮ้อ ตอนนี้รู้สึกดีขึ้นเยอะเลย"

# game/scripts/Systems/Locations/Characters_Menu/Talks/yubon_talks/zubon_talk2.rpy:33
translate english zubon_talk2_0d2b998f:

    # zb "¡Estoy en perfectas condiciones!" with vpunch
    zb "สภาพร่างกายฟิตเต็มร้อยเลยล่ะ!" with vpunch

# game/scripts/Systems/Locations/Characters_Menu/Talks/yubon_talks/zubon_talk2.rpy:35
translate english zubon_talk2_9d5ca5ad:

    # zb "Me tomé un tiempo para descansar luego de la prueba, y ahora estoy listo para cualquier cosa Jajaja"
    zb "ฉันใช้เวลาพักผ่อนนิดหน่อยหลังการทดสอบ ตอนนี้เลยพร้อมลุยทุกสถานการณ์แล้ว ฮ่าๆๆ"

