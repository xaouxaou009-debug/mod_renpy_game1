# TODO: Translation updated at 2024-11-29 23:49

# game/scripts/Systems/Locations/Characters_Menu/Talks/yuna_talks/yuna_talks1.rpy:10
translate english yuna_talk1_09ff24ae:

    # yn "Si vienes a decir algo inútil, mejor ahórratelo"
    yn "ถ้าเธอมาเพื่อพูดเรื่องไร้สาระล่ะก็ เก็บคำพูดนั้นไว้ซะดีกว่า"

# game/scripts/Systems/Locations/Characters_Menu/Talks/yuna_talks/yuna_talks1.rpy:11
translate english yuna_talk1_d9848f63:

    # yn "No estoy de humor para conversaciones sin sentido"
    yn "ฉันไม่มีอารมณ์มาคุยเรื่องไร้สาระหรอกนะ"

# game/scripts/Systems/Locations/Characters_Menu/Talks/yuna_talks/yuna_talks1.rpy:15
translate english yuna_talk1_89e6f209:

    # yn "Estoy... Bien. Aunque no puedo evitar pensar que podríamos haberlo hecho mejor en la Prueba."
    yn "ฉัน... ก็สบายดี แต่ช่วยไม่ได้ที่จะคิดว่าเราน่าจะทำได้ดีกว่านี้ในการทดสอบ"

# game/scripts/Systems/Locations/Characters_Menu/Talks/yuna_talks/yuna_talks1.rpy:17
translate english yuna_talk1_c3bbd207:

    # yn "Aunque no quiera admitirlo, debémos mejorar nuestro trabajo en equipo"
    yn "ต่อให้ไม่อยากยอมรับก็เถอะ แต่เราต้องปรับปรุงการทำงานเป็นทีมกันหน่อยแล้ว"

# game/scripts/Systems/Locations/Characters_Menu/Talks/yuna_talks/yuna_talks1.rpy:20
translate english yuna_talk1_dfe29311:

    # yn "Justo ahora estoy ocupada, ¿Porqué no buscas a tu amiguita Sarada para hablar con ella?"
    yn "ตอนนี้ฉันยุ่งอยู่ ทำไมเธอไม่ไปคุยกับเพื่อนซี้อย่างซาราดะล่ะ?"

# game/scripts/Systems/Locations/Characters_Menu/Talks/yuna_talks/yuna_talks1.rpy:24
translate english yuna_talk1_49a97378:

    # yn "Si estás aquí para hablar, asegúrate de que sea algo importante"
    yn "ถ้าเธอมาเพื่อคุยล่ะก็ ขอให้มันเป็นเรื่องสำคัญก็แล้วกัน"

# game/scripts/Systems/Locations/Characters_Menu/Talks/yuna_talks/yuna_talks1.rpy:25
translate english yuna_talk1_8f31d4dd:

    # yn "De lo contrario, estás perdiendo tu tiempo y el mío"
    yn "ไม่งั้นเธอจะเสียเวลาเปล่าแถมยังทำให้ฉันเสียเวลาด้วย"

# game/scripts/Systems/Locations/Characters_Menu/Talks/yuna_talks/yuna_talks1.rpy:28
translate english yuna_talk1_879f18e7:

    # yn "Entrenar por la noche tiene su encanto, ¿no crees?"
    yn "การฝึกตอนกลางคืนนี่มีเสน่ห์ในแบบของมันนะ ว่าไหมล่ะ?"

# game/scripts/Systems/Locations/Characters_Menu/Talks/yuna_talks/yuna_talks1.rpy:29
translate english yuna_talk1_eafd4d26:

    # yn "Por eso, si no vienes a entrenar, mejor no me hagas perder mi tiempo"
    yn "งั้นถ้าไม่ได้มาเพื่อฝึกซ้อม ก็อย่ามาเสียเวลาฉันเลย"

# game/scripts/Systems/Locations/Characters_Menu/Talks/yuna_talks/yuna_talks1.rpy:33
translate english yuna_talk1_45023275:

    # yn "Si no tienes algo importante que decir, mejor ahorra tu aliento"
    yn "ถ้าไม่มีเรื่องสำคัญจะพูด เก็บแรงไว้หายใจซะดีกว่า"

# game/scripts/Systems/Locations/Characters_Menu/Talks/yuna_talks/yuna_talks1.rpy:37
translate english yuna_talk1_fdee9ac0:

    # yn "Este un buen lugar para relajarse después de un día largo..."
    yn "ที่นี่เป็นที่ที่ดีสำหรับการผ่อนคลายหลังจากวันที่ยาวนาน..."

# game/scripts/Systems/Locations/Characters_Menu/Talks/yuna_talks/yuna_talks1.rpy:39
translate english yuna_talk1_b33bbebe:

    # yn "Mi entrenamiento ha sido pesado últimamente..."
    yn "ช่วงนี้การฝึกของฉันค่อนข้างหนักเลยล่ะ..."

# game/scripts/Systems/Locations/Characters_Menu/Talks/yuna_talks/yuna_talks1.rpy:41
translate english yuna_talk1_f8a9b3eb:

    # yn "Espero tú también te estés esforzando"
    yn "ฉันหวังว่าเธอเองก็จะพยายามเหมือนกันนะ"

