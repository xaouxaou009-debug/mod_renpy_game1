# TODO: Translation updated at 2024-11-29 23:49

# game/scripts/Systems/Locations/Characters_Menu/ino_menu.rpy:12
translate english ino_talk0_0b4a19de:

    # ino "¡[MN]! Qué bueno verte, hoy me siento muy llena de energía"
    ino "[MN]! ดีใจจังที่ได้เจอ วันนี้ฉันรู้สึกมีพลังเต็มเปี่ยมเลยล่ะ"

# game/scripts/Systems/Locations/Characters_Menu/ino_menu.rpy:14
translate english ino_talk0_04cbc227:

    # ino "¿Te puedo ayudar con algo?"
    ino "มีอะไรให้ฉันช่วยหรือเปล่าจ๊ะ?"

# game/scripts/Systems/Locations/Characters_Menu/ino_menu.rpy:20
translate english ino_talk0_29504ebb:

    # ino "Hola [MN], ¿Qué tal va tu día? ¿Necesitas algo?"
    ino "สวัสดีจ่ะ [MN] วันนี้เป็นยังไงบ้าง? ต้องการอะไรหรือเปล่า?"

# game/scripts/Systems/Locations/Characters_Menu/ino_menu.rpy:26
translate english ino_talk0_62cb39d0:

    # ino "Ah, [MN]... Estoy un poco agotada hoy, ¿Qué puedo hacer por ti?"
    ino "อ๊ะ [MN]... วันนี้ฉันค่อนข้างเหนื่อยเลย มีอะไรให้ฉันช่วยไหมล่ะ?"

# game/scripts/Systems/Locations/Characters_Menu/ino_menu.rpy:32
translate english ino_talk0_b75c1383:

    # ino "Hoy no es un buen día para mí, [MN]... Si puedes ser breve lo agradecería..."
    ino "วันนี้ฉันไม่ค่อยสบอารมณ์เท่าไหร่เลย [MN]... ถ้ามีอะไรก็ช่วยพูดกระชับๆ หน่อยนะ จะขอบคุณมากเลย..."

# game/scripts/Systems/Locations/Characters_Menu/ino_menu.rpy:61
translate english ino_menu1_6e4e7e4c:

    # ino "No estoy de humor..."
    ino "ฉันไม่มีอารมณ์จะคุยด้วยหรอก..."

# game/scripts/Systems/Locations/Characters_Menu/ino_menu.rpy:67
translate english ino_menu1_4503700f:

    # ino "Lo siento... Hoy no estoy de humor..."
    ino "ขอโทษที... วันนี้ฉันไม่มีอารมณ์จริงๆ..."

# game/scripts/Systems/Locations/Characters_Menu/ino_menu.rpy:70
translate english ino_menu1_2417395a:

    # ino "Hoy no quiero hablar... ¿Puedes volver en otro momento?"
    ino "วันนี้ฉันไม่อยากคุยเลย... ไว้ค่อยมาใหม่วันหลังได้ไหม?"

translate english strings:

    # game/scripts/Systems/Locations/Characters_Menu/ino_menu.rpy:55
    old "Te puedo preguntar algo?"
    new "ฉันถามอะไรหน่อยได้ไหม?"

