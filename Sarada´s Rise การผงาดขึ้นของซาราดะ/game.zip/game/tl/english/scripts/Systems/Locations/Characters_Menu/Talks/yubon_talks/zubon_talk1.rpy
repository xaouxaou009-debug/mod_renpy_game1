# TODO: Translation updated at 2024-11-29 23:49

# game/scripts/Systems/Locations/Characters_Menu/Talks/yubon_talks/zubon_talk1.rpy:8
translate english zubon_talk1_9fdd5de8:

    # zb "Entonces no vienes a entrenar, ¿eh?"
    zb "งั้นก็แปลว่าจะไม่ไปฝึกสินะ?"

# game/scripts/Systems/Locations/Characters_Menu/Talks/yubon_talks/zubon_talk1.rpy:10
translate english zubon_talk1_a9eebd50:

    # zb "No te preocupes, te contaré una de mis grandes historias después"
    zb "ไม่ต้องห่วง ไว้เดี๋ยวฉันจะเล่าเรื่องเด็ดๆ ให้ฟังทีหลัง"

# game/scripts/Systems/Locations/Characters_Menu/Talks/yubon_talks/zubon_talk1.rpy:12
translate english zubon_talk1_c7977def:

    # zb "¿O mejor quieres consejos para recuperar el corazón de Yuna?"
    zb "หรือว่านายอยากได้คำแนะนำเรื่องพิชิตใจยูนะมากกว่าล่ะ?"

# game/scripts/Systems/Locations/Characters_Menu/Talks/yubon_talks/zubon_talk1.rpy:14
translate english zubon_talk1_73c424b6:

    # zb "Este es el momento de mostrar de lo que realmente estás hecho"
    zb "นี่แหละคือช่วงเวลาที่จะได้แสดงฝีมือที่แท้จริงออกมา"

# game/scripts/Systems/Locations/Characters_Menu/Talks/yubon_talks/zubon_talk1.rpy:15
translate english zubon_talk1_0399322d:

    # zb "Si no aguantas la presión aquí, no hay forma de que llegues lejos en el futuro"
    zb "ถ้าแค่นี้ยังรับมือกับแรงกดดันไม่ไหว ในอนาคตก็ไปได้ไม่ไกลหรอกนะ"

# game/scripts/Systems/Locations/Characters_Menu/Talks/yubon_talks/zubon_talk1.rpy:18
translate english zubon_talk1_13269d3d:

    # zb "¡Aja! Estos exámenes son solo el comienzo, muchacho"
    zb "ฮ่าๆ! การสอบพวกนี้มันเพิ่งเริ่มต้นเท่านั้นแหละ ไอ้หนู"

# game/scripts/Systems/Locations/Characters_Menu/Talks/yubon_talks/zubon_talk1.rpy:20
translate english zubon_talk1_5be334f1:

    # zb "Cuando terminen, tendrán una visión completamente diferente del mundo ninja"
    zb "พอสอบเสร็จเมื่อไหร่ มุมมองที่นายมีต่อโลกนินจาจะเปลี่ยนไปอย่างสิ้นเชิงเลยล่ะ"

