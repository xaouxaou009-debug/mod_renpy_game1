
translate english strings:

    # game/scripts/Systems/Battle/level_up_screen.rpy:11
    old "¡Has Subido de Nivel!"
    new "เลเวลอัปแล้ว!"

    # game/scripts/Systems/Battle/level_up_screen.rpy:14
    old "Skill Point +1"
    new "แต้มสกิล +1"

    # game/scripts/Systems/Battle/level_up_screen.rpy:15
    old "Max HP +15"
    new "HP สูงสุด +15"

    # game/scripts/Systems/Battle/level_up_screen.rpy:16
    old "Max Chakra +10"
    new "จักระสูงสุด +10"

    # game/scripts/Systems/Battle/level_up_screen.rpy:17
    old "ATTACK +3"
    new "พลังโจมตี +3"

    # game/scripts/Systems/Battle/level_up_screen.rpy:18
    old "Chakra Control +3"
    new "การควบคุมจักระ +3"

    # game/scripts/Systems/Battle/level_up_screen.rpy:19
    old "All Resistences increased"
    new "ความต้านทานทั้งหมดเพิ่มขึ้น"

translate english strings:

    # game/scripts/Systems/Battle/level_up_screen.rpy:4
    old "^^ Subes de Nivel ^^"
    new "^^ เลเวลอัป ^^"
