

translate english strings:

    # game/scripts/Systems/Battle/Jutsu_Screen.rpy:18
    old "[skill.name]"
    new "[skill.eng_name]"

    # game/scripts/Systems/Battle/Jutsu_Screen.rpy:48
    old "Mejorar : [jutsu_menu]"
    new "Upgrade"
