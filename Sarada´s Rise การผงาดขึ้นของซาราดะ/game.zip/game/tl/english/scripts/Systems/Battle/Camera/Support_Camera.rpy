
# game/scripts/Systems/Battle/Camera/Support_Camera.rpy:12
translate english camera_electric_charge1_f1db0024:

    # n "¡Hideo ha empezado a cargar energía eléctrica!"
    n "ฮิเดโอะเริ่มรวบรวมพลังงานไฟฟ้าแล้ว!"
