
# game/scripts/Systems/Battle/Camera/Player_Camera.rpy:94
translate english camera_player_sharingan_c1ac0dc9:

    # n "[MN] ha usado [player.current_attack]"
    n ""

# game/scripts/Systems/Battle/Camera/Player_Camera.rpy:116
translate english camera_player_karugan_attack1_9284f931:

    # n "[MN] desapareció"
    n "[MN] หายตัวไปแล้ว"

# game/scripts/Systems/Battle/Camera/Player_Camera.rpy:148
translate english camera_player_majestic_flame_ae5cbf2f:

    # mn "¡Sharingan!"
    mn "เนตรวงแหวน!"

# game/scripts/Systems/Battle/Camera/Player_Camera.rpy:152
translate english camera_player_majestic_flame_8cf28be7:

    # mn "{b}Estilo de Fuego:{/a}"
    mn "{b}คาถาไฟ:{/a}"

# game/scripts/Systems/Battle/Camera/Player_Camera.rpy:161
translate english camera_player_majestic_flame_9877afa6:

    # mn "{b}¡Majestuosa Llama Destructora!{/a}"
    mn "{b}วิชาเพลิงผลาญสวรรค์{/a}"


# game/scripts/Systems/Battle/Camera/Player_Camera.rpy:94
translate english camera_player_sharingan_19ab1603:

    # n "[MN] ha usado Sharingan"
    n "[MN]ใช้เนตรวงแหวน!"

# game/scripts/Systems/Battle/Camera/Player_Camera.rpy:179
translate english camera_player_sharingan_genjutsu_e3950785:

    # n "[MN] ha usado Sharingan: Genjutsu"
    n "[MN]ใช้เนตรวงแหวน: คาถาภาพลวงตา!"

# game/scripts/Systems/Battle/Camera/Player_Camera.rpy:181
translate english camera_player_sharingan_genjutsu_848996c9:

    # n "Pero no ha funcionado"
    n "แต่ว่ามันไม่ได้ผล"

# game/scripts/Systems/Battle/Camera/Player_Camera.rpy:183
translate english camera_player_sharingan_genjutsu_73825953:

    # n "Pero no funciona en Sarada"
    n "แต่ว่ามันใช้กับซาราดะไม่ได้ผล"

# game/scripts/Systems/Battle/Camera/Player_Camera.rpy:185
translate english camera_player_sharingan_genjutsu_7212be3b:

    # n "Pero no funciona en Naruto"
    n "แต่ว่ามันใช้กับนารูโตะไม่ได้ผล"
