# TODO: Translation updated at 2024-02-17 12:30

# game/scripts/Systems/Battle/Battle.rpy:10
translate english begin_battle_48f58bde:

    # n "Comienza la batalla!"
    n "การต่อสู้เริ่มต้นขึ้น"

# game/scripts/Systems/Battle/Battle.rpy:27
translate english player_attack_cf306b35:

    # n "Atacaste a {b}[enemy.name]{/a} y le quitaste {b}[mn_dmg]{/a} puntos de Salud"
    n ""

# game/scripts/Systems/Battle/Battle.rpy:35
translate english enemy_attack_3deb9aee:

    # n "{b}[enemy.name]{/a} te atacó y te quitó {b}[enemy_dmg]{/a} puntos de Salud"
    n ""

# game/scripts/Systems/Battle/Battle.rpy:43
translate english support_attack_818a8dfc:

    # n "{b}[support.name]{/a} atacó a {b}[enemy.name]{/a} y le quitó {b}[support_dmg]{/a} puntos de Salud"
    n ""

# game/scripts/Systems/Battle/Battle.rpy:50
translate english enemy_loss_turn_1d3dd5fc:

    # n "¡El enemigo está Aturdido!"
    n "ศัตรูติดสถานะมึนงง!"

# game/scripts/Systems/Battle/Battle.rpy:56
translate english enemy_loss_turn_3472ee50:

    # n "¡El enemigo está Paralizado!"
    n "ศัตรูติดสถานะอัมพาต!"

# game/scripts/Systems/Battle/Battle.rpy:64
translate english player_debuff_check_2c44b44b:

    # n "¡[MN] está aturddo!"
    n "[MN] ติดสถานะมึนงง!"

# game/scripts/Systems/Battle/Battle.rpy:70
translate english player_debuff_check_4bc334a2:

    # n "¡[MN] está atrapado!"
    n "[MN] ติดสถานะอัมพาต!"

# game/scripts/Systems/Battle/Battle.rpy:86
translate english yuna_defend_5e70bf10:

    # n "[enemy.name] ataca con [enemy_current_attack]"
    n ""

# game/scripts/Systems/Battle/Battle.rpy:87
translate english yuna_defend_51b940b8:

    # n "Por suerte Yuna defendió a [MN]."
    n "โชคดีที่ยูนะช่วยปกป้อง [MN] เอาไว้ได้"

# game/scripts/Systems/Battle/Battle.rpy:58
translate english enemy_loss_turn_f5dee18e:

    # n "¡El enemigo está en un Genjutsu!"
    n "ศัตรูติดอยู่ในภาพลวงตา!"
