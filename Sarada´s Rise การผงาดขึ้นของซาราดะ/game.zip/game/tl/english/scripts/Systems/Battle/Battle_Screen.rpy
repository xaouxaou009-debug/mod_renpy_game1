

translate english strings:

    # game/scripts/Systems/Battle/Battle_Screen.rpy:137
    old "[skill.description]"
    new "[skill.eng_description]"
# TODO: Translation updated at 2024-12-20 07:52

translate english strings:

    # game/scripts/Systems/Battle/Battle_Screen.rpy:160
    old "Recargando..."
    new "Recharging..."
