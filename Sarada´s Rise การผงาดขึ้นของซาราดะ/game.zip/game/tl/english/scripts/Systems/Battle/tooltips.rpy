

translate english strings:

    # game/scripts/Systems/Battle/tooltips.rpy:1
    old "Sharingan"
    new "เนตรวงแหวน"

    # game/scripts/Systems/Battle/tooltips.rpy:2
    old "Es el Kekkei Genkai del Clan Uchiha. Al usarlo pone al usuario en {b}Modo Sharingan{/a}, donde multiplica {b}x2{/a} el daño de todos los ninjutsus"
    new "มันคือขีดจำกัดสายเลือดของตระกูลอุจิวะ เมื่อใช้งานจะเข้าสู่ {b}โหมดเนตรวงแหวน{/a} ซึ่งจะเพิ่มความเสียหายของนินจุทสูทั้งหมดขึ้น {b}2 เท่า{/a}"

    # game/scripts/Systems/Battle/tooltips.rpy:4
    old "Jutsu Bola de Fuego"
    new "คาถาไฟ ลูกบอลเพลิง"

    # game/scripts/Systems/Battle/tooltips.rpy:5
    old "El Jutsu bola de Fuego hace que el usuario lance una bola de fuego por la boca hacia el objetivo, causando daño de Fuego"
    new "คาถาไฟ ลูกบอลเพลิงทำให้ผู้ใช้พ่นลูกไฟออกจากปากใส่เป้าหมาย สร้างความเสียหายธาตุไฟ"

    # game/scripts/Systems/Battle/tooltips.rpy:7
    old "Jutsu Majestuosa Llama Destructora"
    new "คาถาเพลิงผลาญฟ้า"

    # game/scripts/Systems/Battle/tooltips.rpy:8
    old "Majestuosa Llama Destructora es un poderoso jutsu de Fuego, donde el usuario lanza {b}6{/a} bolas de fuego hacia el objetivo"
    new "คาถาเพลิงผลาญฟ้าคือคาถาไฟอันทรงพลังที่ผู้ใช้จะปล่อยลูกไฟจำนวน {b}6{/a} ลูกใส่เป้าหมาย"

    # game/scripts/Systems/Battle/tooltips.rpy:10
    old "Karugan: Ataque Sorpresa"
    new "คารูกัน: จู่โจมฉับพลัน"

    # game/scripts/Systems/Battle/tooltips.rpy:11
    old "El usuario se vuelva invisible y ataca por la espalda causando {b}Aturdimiento{/a} y {b}Daño Físico{/a}, un ataque fuerte pero también le causa daño a su portador"
    new "ผู้ใช้จะล่องหนและโจมตีจากด้านหลัง สร้างสถานะ {b}มึนงง{/a} และ {b}ความเสียหายทางกายภาพ{/a} เป็นการโจมตีที่รุนแรงแต่ก็สร้างความเสียหายให้แก่ผู้ใช้ด้วยเช่นกัน"

    # game/scripts/Systems/Battle/tooltips.rpy:13
    old "Chidori"
    new "พันปักษา"

    # game/scripts/Systems/Battle/tooltips.rpy:16
    old "Rasengan"
    new "กระสุนวงจักร"

    # game/scripts/Systems/Battle/tooltips.rpy:19
    old "Tajo de Fuego"
    new "คมมีดเพลิง"

    # game/scripts/Systems/Battle/tooltips.rpy:22
    old "Sharingan: Genjutsu"
    new "เนตรวงแหวน: คาถาภาพลวงตา"

    # game/scripts/Systems/Battle/tooltips.rpy:23
    old "El usuario utiliza el {b}Sharingan{/a} para atrapar al oponente en un {b}Genjutsu{/a} para bajar sus defensas, en este estado el enemigo recibe daño {b}Físico X2{/a} durante 2 turnos"
    new "ผู้ใช้ใช้ {b}เนตรวงแหวน{/a} เพื่อขังคู่ต่อสู้ไว้ใน {b}คาถาภาพลวงตา{/a} เพื่อลดพลังป้องกันลง ในสถานะนี้ศัตรูจะได้รับ{b}ความเสียหายทางกายภาพ 2 เท่า{/a} เป็นเวลา 2 เทิร์น"

    # game/scripts/Systems/Battle/tooltips.rpy:28
    old "El usuario concentra su Chakra en el enemigo, cargando una fuerte explosión eléctrica. Requiere {b}{color=#e9a02d}2{/a}{/a} Turnos para cargarse"
    new "ผู้ใช้รวบรวมจักระไปที่ศัตรู เพื่อชาร์จการระเบิดสายไฟฟ้าอันทรงพลัง ต้องใช้เวลา {b}{color=#e9a02d}2{/a}{/a} เทิร์นในการชาร์จ"

    # game/scripts/Systems/Battle/tooltips.rpy:31
    old "El usuario es capaz de convertir sus brazos en duras varas de Hierro, que usa para proteger al Jugador de casi cualquier ataque durante {b}{color=#e9a02d}2{/a}{/a} Turnos"
    new "ผู้ใช้สามารถเปลี่ยนแขนของตนให้กลายเป็นท่อนเหล็กแข็ง ซึ่งใช้ปกป้องผู้เล่นจากการโจมตีเกือบทุกชนิดเป็นเวลา {b}{color=#e9a02d}2{/a}{/a} เทิร์น"
# TODO: Translation updated at 2024-12-20 07:52

translate english strings:

    # game/scripts/Systems/Battle/tooltips.rpy:27
    old "{b}{color=#e9a02d}Estilo de Rayo: Carga Eléctrica{/a}{/a}"
    new "{b}{color=#e9a02d}คาถา สายฟ้า: ประจุไฟฟ้า{/a}{/a}"

    # game/scripts/Systems/Battle/tooltips.rpy:28
    old "Hideo concentra su Chakra en el enemigo, cargando una fuerte explosión eléctrica. Requiere {b}{color=#e9a02d}1{/a}{/a} Turnos para cargarse"
    new "ฮิเดโอะรวบรวมจักระไปที่ศัตรู เพื่อชาร์จการระเบิดสายไฟฟ้าอันทรงพลัง ต้องใช้เวลา {b}{color=#e9a02d}1{/a}{/a} เทิร์นในการชาร์จ"

    # game/scripts/Systems/Battle/tooltips.rpy:30
    old "{b}{color=#cca6d9}Estilo de Acero: Brazos de Acero{/a}{/a}"
    new "{b}{color=#cca6d9}คาถา เหล็ก: แขนเหล็ก{/a}{/a}"

    # game/scripts/Systems/Battle/tooltips.rpy:31
    old "Yuna refuerza sus brazos con Acero para proteger al Jugador de {b}{color=#e9a02d}2{/a}{/a} ataques"
    new "ยูนะเสริมความแข็งแกร่งให้แขนด้วยเหล็กเพื่อปกป้องผู้เล่นจากการโจมตี {b}{color=#e9a02d}2{/a}{/a} ครั้ง"
