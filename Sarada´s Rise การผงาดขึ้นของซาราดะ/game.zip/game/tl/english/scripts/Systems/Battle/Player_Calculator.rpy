# TODO: Translation updated at 2024-12-20 07:52

translate english strings:

    # game/scripts/Systems/Battle/Player_Calculator.rpy:87
    old "Sin Chakra o Carga Shinobi"
    new "ไม่มีจักระหรือพลังชินโนบิ"
