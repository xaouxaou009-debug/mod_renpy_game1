
translate english strings:

    # game/scripts/Systems/Battle/support_class.rpy:30
    old "Ya tienes Protección."
    new "เธอมีคุณสมบัติป้องกันแล้ว"
