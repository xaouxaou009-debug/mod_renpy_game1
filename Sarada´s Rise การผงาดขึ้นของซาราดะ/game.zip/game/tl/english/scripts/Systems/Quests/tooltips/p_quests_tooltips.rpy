# TODO: Translation updated at 2024-11-29 23:49

translate english strings:

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:2
    old "Primeros Pasos"
    new "ก้าวแรก"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:3
    old "Ve al campo de entrenamiento"
    new "ไปที่สนามฝึกซ้อม"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:6
    old "Ve al campo de entrenamiento por la {b}Mañana{/a}"
    new "ไปที่สนามฝึกซ้อมช่วง {b}เช้า{/a}"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:8
    old "Ayuda para Hideo"
    new "ช่วยเหลือฮิเดโอะ"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:9
    old "Ve a la Academia Ninja por la {b}Mañana{/a}"
    new "ไปที่สถาบันนินจาช่วง {b}เช้า{/a}"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:11
    old "La prueba de Kakashi"
    new "บททดสอบของคาคาชิ"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:12
    old "Ve al Río por la {b}Mañana{/a}"
    new "ไปที่แม่น้ำช่วง {b}เช้า{/a}"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:14
    old "El Entrenamiento de Sarada"
    new "การฝึกซ้อมของซาราดะ"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:15
    old "Habla con Sarada por la {b}Mañana{/a}"
    new "คุยกับซาราดะช่วง {b}เช้า{/a}"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:17
    old "Calzoncillos de Corazones?"
    new "กางเกงในลายหัวใจเหรอ?"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:20
    old "Una Tanga Negra!"
    new "จีสตริงสีดำ!"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:23
    old "Volverse Fuerte"
    new "แข็งแกร่งขึ้น"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:24
    old "Alcanza el nivel {b}10{/a}"
    new "บรรลุระดับ {b}10{/a}"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:26
    old "¿Querrá ayudarme?"
    new "เธอจะยอมช่วยฉันไหมนะ?"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:27
    old "Ve a tu {b}Apartamento{/a}"
    new "ไปที่ {b}อพาร์ตเมนต์{/a} ของคุณ"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:29
    old "Entrenando el Karugan"
    new "ฝึกฝนคารูกัน"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:30
    old "Habla con Sarada por la {b}Noche{/a}"
    new "คุยกับซาราดะตอน {b}กลางคืน{/a}"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:32
    old "El Exámen de Zubon"
    new "การสอบของซูบง"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:33
    old "Ve a {b}Dormir{/a}"
    new "ไป {b}นอน{/a}"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:35
    old "Misiones"
    new "ภารกิจ"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:36
    old "Ve a hablar con {b}Naruto{/a}"
    new "ไปคุยกับ {b}นารูโตะ{/a}"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:38
    old "Mi Ex-Suegra"
    new "อดีตแม่ยายของฉัน"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:39
    old "Ve a la {b}Tienda de Ropa{/a} de día"
    new "ไปที่ {b}ร้านขายเสื้อผ้า{/a} ในตอนกลางวัน"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:41
    old "¿Nuevo Equipo?"
    new "ชุดใหม่เหรอ?"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:42
    old "Ve a la {b}Tienda de Tenten{/a}"
    new "ไปที่ {b}ร้านของเท็นเท็น{/a}"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:45
    old "Investigación"
    new "การสืบสวน"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:49
    old "Busca a Sakura en el {b}Hospital{/a}"
    new "ตามหาซากุระที่ {b}โรงพยาบาล{/a}"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:51
    old "Analizando el Karugan"
    new "วิเคราะห์คารูกัน"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:54
    old "Preparaciones para el Examen Chunin"
    new "เตรียมตัวสำหรับการสอบจูนิน"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:55
    old "Avanza en las misiones de {b}Sakura{/a} y {b}Tenten{/a}"
    new "ทำภารกิจของ {b}ซากุระ{/a} และ {b}เท็นเท็น{/a} ให้คืบหน้า"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:58
    old "Ve a tu {b}Apartamento{/a} a la {b}Media Noche{/a}"
    new "ไปที่ {b}อพาร์ตเมนต์{/a} ของคุณตอน {b}เที่ยงคืน{/a}"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:61
    old "Completa la misión {b}El Paquete{/a}"
    new "ทำภารกิจ {b}พัสดุ{/a} ให้เสร็จสิ้น"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:63
    old "Un día con Naruto"
    new "หนึ่งวันกับนารูโตะ"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:67
    old "Ve a la {b}Oficina del Hokage{/a} de día"
    new "ไปที่ {b}สำนักงานโฮคาเงะ{/a} ในตอนกลางวัน"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:69
    old "Últimos Preparativos"
    new "เตรียมตัวขั้นสุดท้าย"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:70
    old "Completa la Misión {b}El Nuevo Traje{/a}"
    new "ทำภารกิจ {b}ชุดใหม่{/a} ให้เสร็จสิ้น"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:73
    old "Avanza en las misiones de {b}Ino{/a}"
    new "ทำภารกิจของ {b}อิโนะ{/a} ให้คืบหน้า"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:75
    old "Perspectiva"
    new "มุมมอง"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:81
    old "Aguas Termales con Madre e Hija"
    new "บ่อน้ำพุร้อนกับแม่ลูก"

    # game/scripts/Systems/Quests/tooltips/p_quests_tooltips.rpy:82
    old "Ve a la {b}Casa Uchiha{/a} el día {b}Viernes{/a} al {b}Medio Día{/a}"
    new "ไปที่ {b}บ้านอุจิฮะ{/a} ในวัน {b}ศุกร์{/a} ตอน {b}เที่ยงวัน{/a}"

