# TODO: Translation updated at 2024-11-29 23:49

translate english strings:

    # game/scripts/Systems/Quests/Quests.rpy:32
    old "Misión Actualizada!"
    new "อัปเดตภารกิจแล้ว!"
