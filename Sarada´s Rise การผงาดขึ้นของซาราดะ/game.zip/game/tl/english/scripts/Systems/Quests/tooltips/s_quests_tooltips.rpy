# TODO: Translation updated at 2024-12-01 23:05

translate english strings:

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:3
    old "La ayuda de Ayame"
    new "ความช่วยเหลือของอายาเมะ"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:4
    old "Ve a {b}Ichiraku Ramen{/a}"
    new "ไปที่ {b}ร้านราเม็งอิจิราคุ{/a}"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:6
    old "Clase de coqueteo"
    new "คลาสเรียนจีบสาว"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:7
    old "Habla con Ayame de {b}Noche{/a}"
    new "คุยกับอายาเมะตอน{b}กลางคืน{/a}"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:9
    old "Colección de Bragas"
    new "คอลเลกชันกางเกงใน"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:13
    old "Ve a la calle principal de {b}Noche{/a}"
    new "ไปที่ถนนสายหลักตอน{b}กลางคืน{/a}"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:15
    old "El golpe de Ayame"
    new "หมัดของอายาเมะ"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:21
    old "La Clase Final"
    new "คลาสเรียนสุดท้าย"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:25
    old "Ve a la Ichiraku Ramen de {b}Noche{/a}"
    new "ไปที่ร้านราเม็งอิจิราคุตอน{b}กลางคืน{/a}"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:28
    old "Una visita a Sakura"
    new "ไปเยี่ยมซากุระ"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:29
    old "Ve a la {b}Casa del Clan Uchiha{/a} por la tarde"
    new "ไปที่{b}บ้านตระกูลอุจิวะ{/a}ในช่วงบ่าย"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:31
    old "Una Flor Extraña"
    new "ดอกไม้ประหลาด"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:32
    old "Ve al {b}Hospital{/a} de día"
    new "ไปที่{b}โรงพยาบาล{/a}ในช่วงกลางวัน"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:35
    old "Ve a la {b}Florería Yamanaka{/a} de día"
    new "ไปที่{b}ร้านดอกไม้ยามานากะ{/a}ในช่วงกลางวัน"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:38
    old "Vuelve al {b}Hospital{/a} de día"
    new "กลับไปที่{b}โรงพยาบาล{/a}ในช่วงกลางวัน"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:42
    old "Vamos a Beber?"
    new "ไปดื่มกันหน่อยไหม?"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:43
    old "Ve a la {b}Tienda de Flores Yamanaka{/a}"
    new "ไปที่{b}ร้านดอกไม้ยามานากะ{/a}"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:48
    old "Ve al {b}Hospital{/a} al Medio día o por la Tarde"
    new "ไปที่{b}โรงพยาบาล{/a}ตอนเที่ยงหรือช่วงบ่าย"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:50
    old "Resultados"
    new "ผลลัพธ์"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:56
    old "Gotas"
    new "หยดน้ำ"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:57
    old "Ve al {b}Hospital{/a} al medio día"
    new "ไปที่ {b}โรงพยาบาล{/a}ตอนเที่ยง"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:59
    old "Lagrimas y Pasión"
    new "น้ำตากับความหลงใหล"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:60
    old "Ve al {b}Hospital{/a} por la noche"
    new "ไปที่ {b}โรงพยาบาล{/a}ตอนกลางคืน"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:63
    old "La Propuesta"
    new "การขอแต่งงาน"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:64
    old "Ve a la {b}Tienda de Tenten{/a} de día"
    new "ไปที่ {b}ร้านของเท็นเท็น{/a}ในช่วงกลางวัน"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:67
    old "Habla con {b}Sarada{/a} en el {b}Campo de Entrenamiento{/a}"
    new "คุยกับ {b}ซาราดะ{/a} ที่ {b}สนามฝึกซ้อม{/a}"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:70
    old "Vuelve a hablar con {b}Tenten{/a}"
    new "คุยกับ {b}เท็นเท็น{/a} อีกครั้ง"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:72
    old "El Descubrimiento"
    new "การค้นพบ"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:73
    old "Reúnete con Tenten en la {b}Puerta de la Hoja{/a} el {b}Viernes{/a} por la {b}Mañana{/a}"
    new "พบกับเท็นเท็นที่ {b}ประตูโคโนฮะ{/a} ใน{b}วันศุกร์{/a} ช่วง{b}เช้า{/a}"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:75
    old "La Espada Kasairyu"
    new "ดาบคะไซริว"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:79
    old "Completa la misión {b}Medidas Íntimas{/a}"
    new "ทำภารกิจ {b}วัดขนาดตัวสุดสยิว{/a} ให้สำเร็จ"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:82
    old "Medidas Íntimas"
    new "วัดขนาดตัวสุดสยิว"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:85
    old "El Nuevo Traje"
    new "ชุดใหม่"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:86
    old "Ve a tu {b}Apartamento{/a} a la Media Noche"
    new "ไปที่{b}อพาร์ตเมนต์{/a}ของคุณตอนเที่ยงคืน"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:92
    old "Un Encuentro Inesperado"
    new "การพบกันโดยไม่คาดคิด"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:93
    old "Envíale un mensaje a Hanna con el {b}Teléfono{/a}"
    new "ส่งข้อความหาฮันนะด้วย{b}โทรศัพท์{/a}"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:99
    old "Espera que sea de {b}Noche{/a}"
    new "รอจนกว่าจะถึงเวลา{b}กลางคืน{/a}"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:102
    old "Ve al Hospital por la {b}Noche{/a}"
    new "ไปที่โรงพยาบาลตอน{b}กลางคืน{/a}"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:105
    old "Llamado del Hokage"
    new "เสียงเรียกจากโฮคาเงะ"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:106
    old "Ve a tu {b}Apartamento{/a} de noche"
    new "ไปที่{b}อพาร์ตเมนต์{/a}ของคุณตอนกลางคืน"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:111
    old "Vigía Nocturna"
    new "ยามวิกาล"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:112
    old "Ve al {b}Centro de Investigación{/a} por la Noche"
    new "ไปที่ {b}ศูนย์วิจัย{/a} ตอนกลางคืน"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:114
    old "Informe al Hokage"
    new "รายงานท่านโฮคาเงะ"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:117
    old "Gato Perdido"
    new "แมวหาย"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:118
    old "Encuentra al {b}Gato Perdido{/a}"
    new "ตามหา {b}แมวที่หายไป{/a}"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:120
    old "Familia Uzumaki"
    new "ครอบครัวอุซึมากิ"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:121
    old "Ve al {b}Río{/a} al {b}Medio Día{/a}"
    new "ไปที่ {b}แม่น้ำ{/a} ตอน {b}เที่ยงวัน{/a}"

    # game/scripts/Systems/Quests/tooltips/s_quests_tooltips.rpy:124
    old "Ve a la {b}Residencia Uzumaki{/a} el {b}Domingo{/a} por la {b}Mañana{/a}"
    new "ไปที่ {b}บ้านพักอุซึมากิ{/a} ใน{b}วันอาทิตย์{/a} ช่วง{b}เช้า{/a}"

