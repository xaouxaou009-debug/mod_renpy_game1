

translate english strings:

    # game/scripts/Systems/Customization/Customization.rpy:7
    old "Personalización de Personajes"
    new "ปรับแต่งตัวละคร"
