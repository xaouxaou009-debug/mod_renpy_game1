
translate english strings:

    # game/scripts/Systems/Gallery/Gallery.rpy:32
    old "[MN] Gallery"
    new "[MN] แกลเลอรี"
