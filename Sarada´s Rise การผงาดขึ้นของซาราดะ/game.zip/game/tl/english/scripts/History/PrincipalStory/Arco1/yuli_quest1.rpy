

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:9
translate english yuli_quest1_c94f5ab4:

    # mn "¿Una tienda de ropa?"
    mn "ร้านขายเสื้อผ้าเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:11
translate english yuli_quest1_34daa762:

    # mn "Esto no estaba aquí antes"
    mn "แต่ก่อนตรงนี้ไม่เห็นมีนี่นา"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:13
translate english yuli_quest1_356dc691:

    # mn "Hmm, supongo que puedo entrar a echar un vistazo"
    mn "อืม... ลองแวะเข้าไปดูหน่อยดีกว่า"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:15
translate english yuli_quest1_2779abb9:

    # mn "No estaría mal un cambio de look"
    mn "เปลี่ยนลุคส้าวนิดหน่อยก็ไม่เลวเหมือนกันนะ"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:17
translate english yuli_quest1_24058f13:

    # n "[MN] entra a la nueva tienda de la Hoja"
    n "[MN] เดินเข้าไปในร้านใหม่ของโคโนฮะ"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:24
translate english yuli_quest1_84e1ab83:

    # mn "Bueno... Parece que venden mayormente ropa para mujer"
    mn "เอ่อ... ดูเหมือนว่าส่วนใหญ่จะขายเสื้อผ้าผู้หญิงสินะเนี่ย"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:26
translate english yuli_quest1_860d8526:

    # mn "¿Quién será el dueño de esta tienda? Parece muy lujosa..."
    mn "ใครเป็นเจ้าของร้านกันนะ? ดูหรูหรามากเลย..."

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:31
translate english yuli_quest1_302d3ffe:

    # d "Hola sea bienve..."
    d "สวัสดีค่ะ ยินดีต้อนรับ..."

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:34
translate english yuli_quest1_d7531408:

    # mn "¿S-Señorita Yuli?"
    mn "ะ-คุณยูริ?"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:37
translate english yuli_quest1_be4e40dc:

    # yl "Ooh, [MN]..."
    yl "อ๊ะ [MN]..."

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:39
translate english yuli_quest1_c31f5835:

    # yl "Cuanto tiempo sin verte"
    yl "ไม่ได้เจอกันนานเลยนะ"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:42
translate english yuli_quest1_7799062a:

    # mn "Sí jaja, cuanto tiempo..."
    mn "นั่นสินะครับ ฮ่าๆ นานเลย..."

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:45
translate english yuli_quest1_f06a4acc:

    # yl "¿Cómo estás?, ¿Sigues saliendo con Yuna?"
    yl "เป็นยังไงบ้างล่ะเนี่ย? ยังคบอยู่กับยูนะอยู่หรือเปล่า?"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:48
translate english yuli_quest1_6d48f212:

    # mn "No... Su hija y yo terminamos hace un tiempo..."
    mn "เปล่าครับ... ผมกับลูกสาวของคุณเลิกกันไปสักพักแล้วล่ะครับ..."

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:51
translate english yuli_quest1_b994f355:

    # yl "Oh..."
    yl "เอ๊ะ..."

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:53
translate english yuli_quest1_735a114f:

    # yl "¿De verdad?"
    yl "จริงเหรอเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:56
translate english yuli_quest1_3c83442c:

    # mn "Sí... Tuvimos nuestras diferencias y tuve que romper con ella..."
    mn "ครับ... เรามีเรื่องที่ไม่เข้าใจกันหลายอย่าง ผมเลยต้องเป็นฝ่ายบอกเลิกเธอ..."

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:59
translate english yuli_quest1_c154ab8a:

    # yl "No puedo creerlo... Hacían una bonita pareja..."
    yl "ไม่อยากจะเชื่อเลย... ทั้งที่เป็นคู่ที่ดูเหมาะสมกันแท้ๆ..."

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:61
translate english yuli_quest1_94f179bb:

    # yl "Esa chica no tiene remedio, ¿Cómo pudo dejarte ir?"
    yl "ยายเด็กคนนี้นี่ใช้ไม่ได้เลยจริงๆ ปล่อยผู้ชายแบบเธอหลุดมือไปได้ยังไงกัน?"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:63
translate english yuli_quest1_9c761e0f:

    # yl "Es decir, mírate..."
    yl "หมายถึง ดูเธอตอนนี้สิ..."

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:65
translate english yuli_quest1_9affa963:

    # yl "Eres muy guapo y estás en muy buena forma"
    yl "ทั้งหล่อแถมหุ่นยังฟิตปั๋งอีกต่างหาก"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:68
translate english yuli_quest1_556b986e:

    # mn "Jeje... Muchas gracias..."
    mn "แหะๆ... ขอบคุณมากครับ..."

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:72
translate english yuli_quest1_ee8c6d2c:

    # yl "¿Hmm?"
    yl "หืม?"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:75
translate english yuli_quest1_3f5194b2:

    # yl "¿Eso es un ojo de contacto?"
    yl "นั่นใส่คอนแทคเลนส์อยู่เหรอ?"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:77
translate english yuli_quest1_69d700df:

    # yl "¿Alguna nueva moda?"
    yl "แฟชั่นใหม่ไรงี้เหรอ?"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:80
translate english yuli_quest1_c0831b72:

    # mn "Es una larga historia..."
    mn "เรื่องมันยาวน่ะครับ..."

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:82
translate english yuli_quest1_17e92d4e:

    # mn "Pero para resumirlo un poco, es un nuevo jutsu que adquirí"
    mn "แต่ถ้าให้สรุปสั้นๆ ก็คือมันเป็นวิชานินจาใหม่ที่ผมได้มาน่ะครับ"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:86
translate english yuli_quest1_795ad106:

    # yl "Vaya... Eso me trae recuerdos de cuando era una kunoichi..."
    yl "โห... ชวนให้นึกถึงตอนที่ฉันยังเป็นนินจาหญิงเลยแหะ..."

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:89
translate english yuli_quest1_523b5663:

    # mn "¿Usted era una ninja?"
    mn "คุณเคยเป็นนินจาด้วยเหรอครับเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:92
translate english yuli_quest1_2e9f23f2:

    # yl "Sí, pero tuve que retirarme cuando quedé embarazada de Yuna"
    yl "ใช่จ่ะ แต่ฉันต้องลาออกตอนที่ท้องยูนะน่ะ"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:94
translate english yuli_quest1_f64d37f8:

    # yl "Pensé en volver a serlo luego del nacimiento de Yuna, pero no podía"
    yl "เคยคิดจะกลับไปเป็นอีกรอบหลังจากคลอดและเลี้ยงยูนะน่ะนะ แต่ก็ทำไม่ได้หรอก"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:96
translate english yuli_quest1_3e077813:

    # yl "Nadie podía cuidarla así que me hice cargo de ella"
    yl "ไม่มีใครช่วยดูแลแก ฉันเลยต้องเป็นคนดูแลเอง"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:98
translate english yuli_quest1_c93de10c:

    # yl "Tuve realmente muchos trabajos para que las dos saliéramos adelante, nuestra vida no fué tan fácil"
    yl "ตอนนั้นฉันรับจ๊อบเยอะมากเพื่อให้เราสองคนอยู่รอด ชีวิตมันไม่ได้ง่ายเลยล่ะนะ"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:100
translate english yuli_quest1_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:103
translate english yuli_quest1_e51cc914:

    # yl "Pero ahora en la actualidad, soy dueña de una tienda de moda femenina, ¿Quién lo diría no?"
    yl "แต่ตอนนี้ฉันมีร้านเสื้อผ้าผู้หญิงเป็นของตัวเองแล้ว ใครจะไปคิดล่ะเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:105
translate english yuli_quest1_9841a3b9:

    # yl "Trabajé muy duro para poder abrirla, son los ahorros de mi vida"
    yl "ฉันตั้งหน้าตั้งตาทำงานหนักเพื่อเปิดร้านนี้เลยนะ นี่คือเงินเก็บทั้งชีวิตของฉันเลยล่ะ"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:108
translate english yuli_quest1_671dcd9b:

    # mn "Vaya, muchas felicidades, no pensé que usted abriría una tienda"
    mn "โอ้โห ยินดีด้วยนะครับ ผมไม่เคยคิดเลยว่าคุณจะมาเปิดร้านเองเนี่ย"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:111
translate english yuli_quest1_809364b5:

    # yl "Gracias jaja"
    yl "ขอบคุณนะจ๊ะ ฮ่าๆ"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:113
translate english yuli_quest1_e214b2b8:

    # yl "Por cierto, aprovechando que estás aquí"
    yl "ว่าแต่... ในเมื่อเธอมาอยู่ที่นี่พอดีแล้วล่ะก็"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:115
translate english yuli_quest1_8174e0b5:

    # yl "¿Puedo pedirte una pequeña ayudita?"
    yl "ช่วยฉันสักเรื่องหน่อยได้ไหมจ๊ะ?"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:118
translate english yuli_quest1_aca340f8:

    # mn "Claro, ¿Qué necesita?"
    mn "ได้สครับ ให้ช่วยอะไรเหรอครับ?"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:122
translate english yuli_quest1_55ba4f2c:

    # yl "Sígueme al almacén"
    yl "ตามฉันมาที่โกดังหน่อยสจ๊ะ"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:124
translate english yuli_quest1_4b89b551:

    # n "[MN] sigue a la madre de Yuna al almacén de la tienda"
    n "[MN] เดินตามแม่ของยูนะไปที่โกดังหลังร้าน"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:135
translate english yuli_quest1_32a6c41c:

    # yl "Justo aquí"
    yl "ตรงนี้แหละจ่ะ"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:138
translate english yuli_quest1_d48521c0:

    # mn "Vaya, son muchas cajas"
    mn "โห กล่องเยอะชะมัดเลยนะครับเนี่ย"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:141
translate english yuli_quest1_5e89c4bc:

    # yl "Si, demaciadas realmente"
    yl "นั่นสินะ เอาจริงๆ ก็คือเยอะเกินไปด้วยซ้ำ"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:144
translate english yuli_quest1_873fc611:

    # mn "Así que, ¿Qué necesita?"
    mn "แล้วสรุปว่าให้ผมช่วยอะไรเหรอครับ?"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:147
translate english yuli_quest1_16772fed:

    # yl "Necesito que me ayudes a descargar un par de cajas, es solo eso"
    yl "ฉันอยากให้เธอช่วยยกกล่องพวกนี้หน่อยน่ะ คือว่านะ"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:149
translate english yuli_quest1_79668076:

    # yl "Solo... Deja que busque entre las cajas"
    yl "คือว่า... ขอฉันเช็คของในกล่องพวกนี้แป๊บเดียวนะ"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:151
translate english yuli_quest1_e2ba0dcf:

    # yl "De tantas que hay, no sé donde vienen las cosas jaja"
    yl "มันเยอะมากจนฉันจำไม่ได้แล้วเนี่ยว่าอะไรอยู่ไหน ฮ่าๆ"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:154
translate english yuli_quest1_4d908784:

    # mn "Claro, yo le ayudaré"
    mn "ได้เลยครับ เดี๋ยวผมช่วยเอง"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:157
translate english yuli_quest1_141d4906:

    # yl "Aah, eres mi salvación Cariño"
    yl "อ่า เธอนี่คือผู้ช่วยชีวิตของฉันเลยนะที่รัก"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:159
translate english yuli_quest1_68ff9821:

    # yl "Dame un momento, buscaré las cajas"
    yl "รอแป๊บนึงนะ เดี๋ยวฉันหากล่องพวกนั้นก่อน"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:161
translate english yuli_quest1_47ee39ff:

    # n "La madre de Yuna empieza a buscar entre las cajas"
    n "แม่ของยูนะเริ่มคุ้ยหาของในกล่อง"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:165
translate english yuli_quest1_d27635bb:

    # yl "Creo que... Son estas de aquí"
    yl "ฉันว่า... น่าจะเป็นพวกกล่องตรงนี้นี่แหละ"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:167
translate english yuli_quest1_f7c21b3e:

    # mn "(Santa... La señorita Yuli tiene un culazo...)"
    mn "(ให้ตายสิ... คุณยูรินี่หุ่นเซ็กซี่เป็นบ้าเลย...)"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:169
translate english yuli_quest1_030a290c:

    # yl "..."
    yl "..."

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:170
translate english yuli_quest1_5a8a0992:

    # yl "¿Ves algo que te guste...? Jeje"
    yl "เห็นอะไรถูกใจเข้าเหรอ...? ฮี่ๆ"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:171
translate english yuli_quest1_189ad487:

    # mn "Oh, y-yo... lo lamento mucho..."
    mn "อ๊ะ ผม... ผมขอโทษครับ..."

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:172
translate english yuli_quest1_05813fa3:

    # yl "Está bien, no te preocupes..."
    yl "ไม่เป็นไรจ่ะ ไม่ต้องห่วงนะ..."

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:173
translate english yuli_quest1_1f2f4d65:

    # yl "No me molesta en lo absoluto..."
    yl "ฉันไม่ได้ถือสาอะไรเลยสักนิด..."

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:174
translate english yuli_quest1_cccb9b91:

    # mn "Y-ya veo..."
    mn "ง...งั้นเหรอครับ..."

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:175
translate english yuli_quest1_a92b446f:

    # yl "¿No te gustaría tocarlo...?"
    yl "ไม่อยากลองสัมผัสดูหน่อยเหรอ...?"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:176
translate english yuli_quest1_9f462200:

    # mn "Preferiría no hacerlo... Es la madre de mi ex-novia..."
    mn "อย่าเลยดีกว่าครับ... คุณเป็นแม่ของแฟนเก่าผมนะ..."

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:178
translate english yuli_quest1_940aee37:

    # mn "(Voy a odiarme un mes por decir eso, pero el simple hecho de pensar que es la madre de Yuna me pone mal...)"
    mn "(ฉันคงจะเกลียดตัวเองไปเป็นเดือนที่พูดแบบนั้นออกไป แต่แค่คิดว่าเธอเป็นแม่ของยูนะก็รู้สึกแปลกๆ แล้ว...)"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:180
translate english yuli_quest1_d3236e8d:

    # yl "Oh, bueno... que lástima que así sea..."
    yl "งั้นเหรอ... น่าเสียดายจังเลยนะ..."

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:181
translate english yuli_quest1_ca203fed:

    # yl "Bueno, ayúdame con esto y te lo compensaré luego"
    yl "งั้นช่วยฉันจัดการตรงนี้ให้เสร็จ แล้วเดี๋ยวฉันจะมีรางวัลตอบแทนให้ทีหลังนะจ๊ะ"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:182
translate english yuli_quest1_50bb5215:

    # mn "Claro, yo me encargo"
    mn "ได้เลยครับ เดี๋ยวผมจัดการให้เอง"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:185
translate english yuli_quest1_207d471a:

    # n "[MN] pasó un tiempo ayudando a Yuli"
    n "[MN] ใช้เวลาอยู่พักหนึ่งเพื่อช่วยเหลืองานของยูริ"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:193
translate english yuli_quest1_03eabf28:

    # mn "Y eso sería todo... En verdad tiene ropa muy bonita aquí..."
    mn "เรียบร้อยแล้วล่ะครับ... ที่จริงที่นี่มีเสื้อผ้าสวยๆ เยอะเหมือนกันนะเนี่ย"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:196
translate english yuli_quest1_a746b786:

    # yl "Gracias, me alegra que te guste"
    yl "ขอบคุณนะจ๊ะ ดีใจที่เธอชอบ"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:198
translate english yuli_quest1_67e94f2d:

    # yl "Y toma, aquí tienes un bono por ayudarme"
    yl "แล้วก็นี่จ๊ะ ค่าตอบแทนพิเศษสำหรับคนที่มาช่วยฉัน"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:203
translate english yuli_quest1_97ede885:

    # mn "Oh, muchas gracias señorita Yuli"
    mn "โอ้ ขอบคุณมากครับคุณยูริ"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:206
translate english yuli_quest1_45a08cf5:

    # yl "Gracias a ti, guapo"
    yl "ขอบใจเธอเหมือนกันนะพ่อหนุ่มรูปหล่อ"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:208
translate english yuli_quest1_fe4d0430:

    # yl "Recuerda pasar de vez en cuando por aquí para hacerme compañía"
    yl "แวะมาหาฉันบ้างเป็นครั้งคราวเพื่อมาอยู่เป็นเพื่อนกันนะ"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:212
translate english yuli_quest1_9ecff0e2:

    # mn "Claro, hasta luego"
    mn "ได้เลยครับ ไว้เจอกันใหม่"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:217
translate english yuli_quest1_509b7800:

    # yl "Hasta luego Cariño..."
    yl "แล้วเจอกันนะที่รัก..."

translate english strings:

    # game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:199
    old "+50 ryo"
    new "+50 เรียว"
# TODO: Translation updated at 2024-03-28 15:40

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:98
translate english yuli_quest1_77e88163:

    # yl "Tuve realmente muchos trabajos para que las dos saliéramos adelante, nuestra vida no fue tan fácil"
    yl "ฉันมีงานตั้งหลายอย่างเพื่อให้เราสองคนก้าวหน้า ชีวิตพวกเรามันไม่ได้ง่ายเลยนะ"

# game/scripts/History/PrincipalStory/Arco1/yuli_quest1.rpy:141
translate english yuli_quest1_bc76b9cf:

    # yl "Si, demasiadas realmente"
    yl "ใช่ เยอะจนเกินไปด้วยซ้ำถ้าพูดตามตรง"
