# TODO: Translation updated at 2024-12-01 21:25

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:6
translate english arc2_main_quest5_2_a1e4fc94:

    # n "Al día siguiente"
    n "วันต่อมา"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:10
translate english arc2_main_quest5_2_984e9669:

    # n "Era una mañana serena en la Aldea de la Hoja" with fade
    n "เป็นยามเช้าอันสงบสุขในหมู่บ้านโคโนฮะ" with fade

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:11
translate english arc2_main_quest5_2_cc13e8bc:

    # n "El viento fresco acariciaba suavemente el entorno, trayendo consigo el eco lejano de la naturaleza despertando"
    n "สายลมบริสุทธิ์พัดโชยสัมผัสรอบกายอย่างอ่อนโยน พร้อมกับเสียงแว่วของธรรมชาติที่กำลังตื่นตัวจากระยะไกล"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:12
translate english arc2_main_quest5_2_984e3ffc:

    # n "El rocío aún cubría la hierba y las hojas de los árboles"
    n "หยาดน้ำค้างยังคงเกาะพราวอยู่บนผืนหญ้าและใบไม้"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:13
translate english arc2_main_quest5_2_0dcf00e1:

    # n "Brillando bajo los primeros rayos del sol que apenas comenzaban a filtrarse entre las copas de los altos árboles"
    n "ส่องประกายระยิบระยับใต้แสงแรกของดวงอาทิตย์ที่เพิ่งเริ่มสาดส่องลอดผ่านยอดไม้สูง"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:14
translate english arc2_main_quest5_2_4ad82c89:

    # n "El día nacía con tranquilo..."
    n "วันใหม่เริ่มต้นขึ้นอย่างเงียบงัน..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:17
translate english arc2_main_quest5_2_2ffb30a8:

    # n "Pero en el campo de entrenamiento, la atmósfera no era la misma..."
    n "แต่ทว่าที่สนามฝึกซ้อม บรรยากาศกลับไม่เป็นเช่นนั้น..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:24
translate english arc2_main_quest5_2_dfd695e0:

    # n "El viento, aunque suave, parecía traer consigo una tensión sutil que se aferraba al aire"
    n "สายลมแม้จะแผ่วเบา แต่กลับแฝงไปด้วยความตึงเครียดบางเบาที่อบอวลอยู่ในอากาศ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:35
translate english arc2_main_quest5_2_7f2b3512:

    # n "Frente a frente, Sarada y [MN] se encontraban en silencio, observándose mutuamente"
    n "ซาราดะและ [MN] ยืนประจันหน้ากันอย่างเงียบเชียบ ต่างฝ่ายต่างจ้องมองกันและกัน"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:36
translate english arc2_main_quest5_2_3925cac7:

    # n "El entrenamiento intensivo de [MN] estaba a punto de comenzar"
    n "การฝึกฝนอย่างเข้มข้นของ [MN] กำลังจะเริ่มต้นขึ้นแล้ว"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:37
translate english arc2_main_quest5_2_7ec9230f:

    # n "Y mientras el viento continuaba soplando entre ellos, Sarada firme y con la mirada fija en [MN], rompió finalmente el silencio"
    n "และในขณะที่สายลมยังคงพัดผ่านระหว่างทั้งสองคน ซาราดะผู้เด็ดเดี่ยวและจ้องมองตรงมาที่ [MN] ก็เป็นฝ่ายทำลายความเงียบขึ้นในที่สุด"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:39
translate english arc2_main_quest5_2_86efc3a6:

    # sr "El Séptimo Hokage y yo creémos en tu potencial"
    sr "ท่านโฮคาเงะรุ่นที่เจ็ดและฉันเชื่อในศักยภาพของเธอนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:40
translate english arc2_main_quest5_2_57b7e39b:

    # sr "Pero antes de comenzar con el entrenamiento intensivo, necesito saber exactamente de qué eres capaz actualmente"
    sr "แต่ก่อนจะเริ่มการฝึกฝนอย่างเข้มข้น ฉันจำเป็นต้องรู้ให้แน่ชัดเสียก่อนว่าตอนนี้เธอมีความสามารถถึงระดับไหนแล้ว"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:41
translate english arc2_main_quest5_2_a3141078:

    # sr "Ha pasado un tiempo desde que entrenamos por última vez, pero quiero ver como te desenvuelves en un {b}Combate Real{/a}"
    sr "ก็ไม่ได้ฝึกด้วยกันมาสักพักแล้วล่ะนะ แต่ฉันอยากเห็นว่าเธอจะรับมือได้ดีแค่ไหนในการ {b}ต่อสู้จริง{/a}"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:43
translate english arc2_main_quest5_2_ef27874c:

    # sr "Así que hoy quiero que luches contra mí con todo lo que tienes"
    sr "เพราะงั้นวันนี้ฉันอยากให้เธอสู้กับฉันด้วยทุกสิ่งที่มี"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:44
translate english arc2_main_quest5_2_e82dcd96:

    # sr "No voy a contenerme como las otras veces, así que espero que tú tampoco lo hagas"
    sr "ฉันจะไม่ยั้งมือเหมือนครั้งก่อนๆ หวังว่าเธอเองก็จะไม่ยั้งมือเหมือนกันนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:45
translate english arc2_main_quest5_2_4ef39c87:

    # sr "¿Entendido?"
    sr "เข้าใจไหม?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:46
translate english arc2_main_quest5_2_d129f12a:

    # mn "Entendido"
    mn "เข้าใจแล้ว"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:48
translate english arc2_main_quest5_2_9ecf9126:

    # mn "Si eso es lo que quieres..."
    mn "ถ้าต้องการแบบนั้นล่ะก็..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:49
translate english arc2_main_quest5_2_122be843:

    # mn "¡Me emplearé a fondo!" with vpunch
    mn "ฉันจะลุยให้เต็มที่เลย!" with vpunch

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:50
translate english arc2_main_quest5_2_9143d206:

    # sr "Muy bien, entonces..."
    sr "งั้นก็..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:53
translate english arc2_main_quest5_before_sarada_battle_94a03aac:

    # sr "¡A LUCHAR!" with vpunch
    sr "ลุยกันเลย!" with vpunch

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:64
translate english arc2_quest5_after_sarada_battle_abfafaaa:

    # n "Luego de una batalla intensa entre [MN] y Sarada..."
    n "หลังจากการต่อสู้อันดุเดือดระหว่าง [MN] และซาราดะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:65
translate english arc2_quest5_after_sarada_battle_b9017ec1:

    # n "Ella ya ha comprobado las capacidades de [MN], y está lista para dar un análisis"
    n "เธอได้ทดสอบความสามารถของ [MN] เรียบร้อยแล้ว และพร้อมที่จะวิเคราะห์ผลลัพธ์"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:78
translate english arc2_quest5_after_sarada_battle_221966dd:

    # n "[MN] luego de la lucha respiraba con dificultad y estaba empapado en sudor, mientras Sarada permanecía de pie frente a él"
    n "[MN] หอบหายใจหนักหน่วงและชุ่มไปด้วยเหงื่อหลังจากการต่อสู้ ขณะที่ซาราดะยืนอยู่ตรงหน้าเขา"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:79
translate english arc2_quest5_after_sarada_battle_41ee3d67:

    # sr "Muy bien, ya es suficiente"
    sr "เอาล่ะ พอแค่นี้แหละ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:80
translate english arc2_quest5_after_sarada_battle_2da90a49:

    # mn "*jadeo* S-Si..."
    mn "*หอบ* ค-ครับ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:83
translate english arc2_quest5_after_sarada_battle_37e3f231:

    # mnn "(Maldición... Lo dí todo en esa batalla...)"
    mnn "(เวรเอ๊ย... ฉันใส่สุดแรงเกิดไปกับการต่อสู้เมื่อกี้เลยนะ...)"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:84
translate english arc2_quest5_after_sarada_battle_1b03ca22:

    # mnn "(Peleé contra ella dando mi máximo, y ella no usó ni su Sharingan...)"
    mnn "(ฉันสู้กับเธอด้วยทุกสิ่งที่มี แต่เธอสู้โดยที่ยังไม่ได้ใช้เนตรวงแหวนด้วยซ้ำ...)"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:85
translate english arc2_quest5_after_sarada_battle_f5384382:

    # mnn "(Y ni siquiera parece estar cansada, en cambio yo...)"
    mnn "(แถมเธอยังดูไม่เหนื่อยเลยสักนิด ในขณะที่ฉัน...)"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:86
translate english arc2_quest5_after_sarada_battle_9cd1544f:

    # mnn "(Estoy cansado... Usé tanto el {b}Sharingan{/a} como el {b}Karugan{/a} y no creo hacerle mucho daño...)"
    mnn "(ฉันหมดแรงแล้วแฮะ... ใช้ทั้ง {b}เนตรวงแหวน{/a} และ {b}คารูกัน{/a} ไปด้วย แต่ดูเหมือนจะสร้างความเสียหายให้เธอได้ไม่เท่าไหร่เลย...)"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:87
translate english arc2_quest5_after_sarada_battle_177e8203:

    # mnn "(Así que así son los {b}Jonin{/a}...)"
    mnn "(นี่น่ะเหรอพลังของระดับ {b}โจนิน{/a}...)"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:90
translate english arc2_quest5_after_sarada_battle_04e26f2b:

    # sr "Hmmm..."
    sr "อืม..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:93
translate english arc2_quest5_after_sarada_battle_3f9c9d29:

    # sr "Muy bien, te diré todo esto sin tapujos..."
    sr "เอาล่ะ ฉันจะพูดตรงๆ ไม่อ้อมค้อมก็แล้วกันนะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:94
translate english arc2_quest5_after_sarada_battle_f4bebda1:

    # sr "Es evidente que tienes un gran talento para esto..."
    sr "เห็นได้ชัดเลยว่าเธอมีพรสวรรค์ด้านนี้สูงมาก..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:96
translate english arc2_quest5_after_sarada_battle_321d76bf:

    # sr "Pero eso no es suficiente"
    sr "แต่แค่นั้นมันยังไม่พอหรอก"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:97
translate english arc2_quest5_after_sarada_battle_5502cecb:

    # mnn "..."
    mnn "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:98
translate english arc2_quest5_after_sarada_battle_d6ef6a9c:

    # sr "Vas a necesitar mucho más que talento para ser más fuerte..."
    sr "เธอจำเป็นต้องมีอะไรมากกว่าแค่พรสวรรค์ ถ้าอยากจะเก่งขึ้นกว่านี้..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:100
translate english arc2_quest5_after_sarada_battle_ae97f60e:

    # sr "Gastas demasiada energía en movimientos innecesarios, te tensas demasiado cuando luchas y tu respiración está completamente descontrolada"
    sr "เธอใช้พลังงานเปล่าประโยชน์ไปกับการเคลื่อนไหวที่ไม่จำเป็นมากเกินไป เกร็งตัวเกินไปเวลาต่อสู้ และแถมการหายใจก็ยังผิดจังหวะสุดๆ อีกด้วย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:101
translate english arc2_quest5_after_sarada_battle_cf24d0db:

    # sr "Todo eso hace que tus movimientos sean limitados, rígidos y fáciles de predecir"
    sr "ทั้งหมดนั่นทำให้การเคลื่อนไหวของเธอถูกจำกัด แข็งทื่อ และเดาทางง่าย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:103
translate english arc2_quest5_after_sarada_battle_d7a500f7:

    # n "[MN] aún jadeante, escuchaba con atención cada crítica de Sarada"
    n "[MN] ที่ยังคงหอบหายใจ ตั้งใจฟังคำวิจารณ์ทุกคำของซาราดะอย่างเงียบๆ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:104
translate english arc2_quest5_after_sarada_battle_86752b6c:

    # n "Cada una golpeaba con la misma fuerza que los ataques de Sarada..."
    n "ทุกคำพูดนั้นหนักหน่วงและทรงพลังไม่ต่างจากการโจมตีของซาราดะเลย..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:105
translate english arc2_quest5_after_sarada_battle_d82dfe2a:

    # n "Pero justo ahora no había lugar para la complacencia..."
    n "แต่ตอนนี้ไม่ใช่เวลาที่จะมาตายใจ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:106
translate english arc2_quest5_after_sarada_battle_310738fc:

    # sr "Para alguien de tu nivel, cada error en combate te puede costar la vida"
    sr "สำหรับคนในระดับเธอ ความผิดพลาดเพียงครั้งเดียวในการต่อสู้หมายถึงชีวิตเลยนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:107
translate english arc2_quest5_after_sarada_battle_121b9374:

    # sr "Y no solo tu vida, también la vida de tus compañeros, Yuna, Hideo, incluso la de Zubon"
    sr "และไม่ใช่แค่ชีวิตของเธอคนเดียว แต่รวมถึงชีวิตของเพื่อนร่วมทีมอย่างยูนะ ฮิเดโอะ หรือแม้กระทั่งซูบงด้วย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:108
translate english arc2_quest5_after_sarada_battle_2d40b97b:

    # sr "Un solo error puede ser la perdición de uno de ustedes"
    sr "ความผิดพลาดแค่ครั้งเดียวอาจนำพาหายนะมาสู่พวกเธอสักคนได้เลย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:109
translate english arc2_quest5_after_sarada_battle_5502cecb_1:

    # mnn "..."
    mnn "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:110
translate english arc2_quest5_after_sarada_battle_729bb529:

    # sr "Y no es solo cuestión aprender un jutsu o una técnica"
    sr "และมันไม่ใช่แค่เรื่องของการเรียนรู้วิชานินจาหรือกระบวนท่าหรอกนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:111
translate english arc2_quest5_after_sarada_battle_1dbfb904:

    # sr "Por lo que ví en nuestro combate, tienes que mejorar todo, desde lo más básico: postura, movimientos, respiración... Todo"
    sr "จากที่ฉันเห็นในการต่อสู้ของเรา เธอจำเป็นต้องปรับปรุงทุกอย่าง เริ่มตั้งแต่พื้นฐานเลย: ท่าทาง การเคลื่อนไหว การหายใจ... ทุกอย่างนั่นแหละ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:112
translate english arc2_quest5_after_sarada_battle_769ab629:

    # sr "También trabajarémos en tu resistencia, te cansas demasiado rápido, y cansado tu cuerpo no responderá bien y te convertirás en un obstáculo para tu equipo"
    sr "เราจะฝึกความอึดของเธอด้วย เธอน่ะหมดแรงเร็วเกินไป และพอเหนื่อย ร่างกายก็จะไม่ค่อยตอบสนองแถมจะกลายเป็นตัวถ่วงของทีมซะเปล่าๆ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:114
translate english arc2_quest5_after_sarada_battle_4b0e0d13:

    # sr "Eventualmente te entrenaré para que domines mejor la {b}Manipulación de Chakra{/a} como te prometí"
    sr "ไว้ถึงเวลาค่อยฝึกให้เธอควบคุม {b}การควบคุมจักระ{/a} ได้ดีขึ้นอย่างที่ฉันสัญญาไว้"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:115
translate english arc2_quest5_after_sarada_battle_8d10ccd9:

    # sr "Pero eso será secundario por ahora"
    sr "แต่ตอนนี้ให้เรื่องนั้นเป็นรองไปก่อน"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:116
translate english arc2_quest5_after_sarada_battle_da6598b7:

    # sr "No podrás controlarlo adecuadamente hasta que aprendas a controlar perfectamente tu propio cuerpo y mantener un buen ritmo"
    sr "เธอจะควบคุมมันได้ไม่ดีหรอก จนกว่าเธอจะเรียนรู้ที่จะควบคุมร่างกายของตัวเองให้สมบูรณ์แบบและรักษาจังหวะให้คงที่เสียก่อน"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:117
translate english arc2_quest5_after_sarada_battle_5502cecb_2:

    # mnn "..."
    mnn "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:119
translate english arc2_quest5_after_sarada_battle_b38c80fc:

    # sr "Este entrenamiento no será fácil, ya te lo había dicho"
    sr "การฝึกนี้ไม่ง่ายหรอกนะ ฉันบอกเธอไปแล้วล่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:120
translate english arc2_quest5_after_sarada_battle_2a1a63cf:

    # sr "Entrenarémos cada mañana desde que el sol nazca y no terminaremos hasta muy tarde en la noche"
    sr "เราจะฝึกกันทุกเช้าตั้งแต่พระอาทิตย์ขึ้น และไม่เลิกจนกว่าจะดึกดื่น"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:121
translate english arc2_quest5_after_sarada_battle_6f3043f1:

    # sr "Todos los días, durante semanas... Hasta que comiencen los Exámenes Chunin"
    sr "ทุกๆ วัน เป็นเวลาหลายสัปดาห์... จนกว่าการสอบจูนินจะเริ่มขึ้น"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:122
translate english arc2_quest5_after_sarada_battle_4783207b:

    # sr "Voy a presionarte al máximo... Si sobrevives a esto, serás más fuerte, más rápido y más resistente en combate"
    sr "ฉันจะรีดเค้นขีดจำกัดของเธอให้ถึงที่สุด... ถ้าเธอรอดจากการฝึกนี้ไปได้ เธอก็จะแข็งแกร่งขึ้น เร็วขึ้น และอึดขึ้นในการต่อสู้"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:124
translate english arc2_quest5_after_sarada_battle_bc2442d1:

    # sr "Dicho esto..."
    sr "เอาล่ะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:128
translate english arc2_quest5_after_sarada_battle_b8b107bc:

    # sr "¿Listo para empezar?"
    sr "พร้อมจะเริ่มหรือยัง?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:129
translate english arc2_quest5_after_sarada_battle_ebcafb37:

    # n "[MN] sabía que este entrenamiento sería el más difícil que había enfrentado hasta ahora"
    n "[MN] รู้ดีว่าการฝึกนี้จะเป็นบททดสอบที่ยากที่สุดเท่าที่เขาเคยเจอมา"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:131
translate english arc2_quest5_after_sarada_battle_ff11793f:

    # n "Pero también sabía que era el único camino para mejorar como {b}Ninja{/a}"
    n "แต่เขาก็รู้ดีว่านี่คือหนทางเดียวที่จะพัฒนาในฐานะ {b}นินจา{/a}"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:132
translate english arc2_quest5_after_sarada_battle_c8ff407d:

    # n "No podía dar marcha atrás en este punto"
    n "เขาหันหลังกลับตอนนี้ไม่ได้อีกแล้ว"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:133
translate english arc2_quest5_after_sarada_battle_a6394315:

    # mn "¡Estoy listo!" with vpunch
    mn "ผมพร้อมแล้ว!" with vpunch

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:136
translate english arc2_quest5_after_sarada_battle_593d0a08:

    # n "Y así, [MN] comenzó un duro entrenamiento con Sarada"
    n "แล้ว [MN] ก็ได้เริ่มต้นการฝึกฝนอย่างหนักหน่วงกับซาราดะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:137
translate english arc2_quest5_after_sarada_battle_d0f469bd:

    # n "Las semanas pasaron rápidamente, y mientras [MN] entrenaba exhaustivamente bajo la enseñanza de Sarada"
    n "เวลาผ่านไปอย่างรวดเร็ว ในขณะที่ [MN] ฝึกซ้อมอย่างเหน็ดเหนื่อยภายใต้คำสั่งสอนของซาราดะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:139
translate english arc2_quest5_after_sarada_battle_178d1268:

    # n "La Aldea de la Hoja se llenaba de muchos visitantes" with fade
    n "หมู่บ้านโคโนะฮะก็เริ่มเนืองแน่นไปด้วยผู้คนมากมาย" with fade

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:140
translate english arc2_quest5_after_sarada_battle_ef4e382c:

    # n "Los exámenes Chunin se aproximaban, y ninjas de todas las aldeas comenzaban a llegar"
    n "การสอบจูนินกำลังจะมาถึง และเหล่านินจาจากแคว้นต่างๆ ก็เริ่มทยอยเดินทางมาถึงแล้ว"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:141
translate english arc2_quest5_after_sarada_battle_b72cf04a:

    # n "Ninjas de la Arena, del Rayo, de la Tierra, etc."
    n "ทั้งนินจาจากแคว้นสึนะ แคว้นคุโมะ แคว้นอิวะ และอื่นๆ อีกมากมาย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:143
translate english arc2_quest5_after_sarada_battle_146dce74:

    # n "Sin emmbargo..."
    n "อย่างไรก็ตาม..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:145
translate english arc2_quest5_after_sarada_battle_d2d85470:

    # n "En la puerta de la Hoja..." with fade
    n "ที่ประตูทางเข้าหมู่บ้านโคโนะฮะ..." with fade

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:146
translate english arc2_quest5_after_sarada_battle_87937cdb:

    # n "Tres figuras caminan hacia la aldea de la hoja"
    n "เงาร่างสามคนกำลังเดินมุ่งหน้าเข้ามายังหมู่บ้านโคโนะฮะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:147
translate english arc2_quest5_after_sarada_battle_1d7e4afa:

    # n "Parecían ser..."
    n "ดูเหมือนว่าพวกเขาจะเป็น..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:148
translate english arc2_quest5_after_sarada_battle_909e3dd3:

    # n "Ninjas de la Aldea escondida entre la Niebla"
    n "เหล่านินจาจากหมู่บ้านคิรากะคุเระ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:163
translate english arc2_quest5_after_sarada_battle_99f30fe2:

    # d1 "Aquí estamos... La aldea de la Hoja"
    d1 "ถึงสักทีสินะ... หมู่บ้านโคโนฮะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:165
translate english arc2_quest5_after_sarada_battle_597d9bdd:

    # d1 "Me la imaginaba diferente..."
    d1 "ฉันจินตนาการไว้ต่างจากนี้นิดหน่อยแฮะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:166
translate english arc2_quest5_after_sarada_battle_96df50f8:

    # d1 "Es decepcionante..."
    d1 "น่าผิดหวังชะมัด..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:167
translate english arc2_quest5_after_sarada_battle_91dcd1c4:

    # d2 "¿Qué te esperabas, armas en los muros?"
    d2 "นายคาดหวังอะไรไว้ล่ะ ติดอาวุธไว้ตามกำแพงงั้นเหรอ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:168
translate english arc2_quest5_after_sarada_battle_ada487ef:

    # d2 "Desde que terminó la Cuarta Gran Guerra Ninja las aldeas han estado en paz, es de esperar"
    d2 "สงครามโลกนินจาครั้งที่สี่จบลงไปแล้ว พวกหมู่บ้านต่างๆ ก็อยู่กันอย่างสงบสุข ก็เป็นธรรมดาแหละนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:169
translate english arc2_quest5_after_sarada_battle_2813d1dd:

    # d1 "Lo sé, pero para ser la aldea con mayor poder militar, se puede esperar algo más, ¿No?"
    d1 "ฉันรู้หน่า แต่สำหรับหมู่บ้านที่มีกำลังทหารมากที่สุดทั้งที ก็น่าจะคาดหวังอะไรที่มันดูยิ่งใหญ่กว่านี้หน่อยสิ จริงไหม?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:170
translate english arc2_quest5_after_sarada_battle_795610c4:

    # d1 "Ya sabes, equipos de Ninjas en los muros vigilando que no hayan intrusos"
    d1 "แบบว่า มีทีมนินจาคอยยืนลาดตระเวนเฝ้าระวังผู้บุกรุกอยู่ตามกำแพง"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:172
translate english arc2_quest5_after_sarada_battle_31894d8d:

    # d1 "Listos para batirse en una lucha épica contra cualquiera que quiera perturbar su amada Paz"
    d1 "พร้อมเปิดฉากต่อสู้ครั้งใหญ่กับใครก็ตามที่บังอาจมาทำลายสันติภาพอันเป็นที่รักของพวกมัน"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:173
translate english arc2_quest5_after_sarada_battle_c1b39d33:

    # d2 "*suspiro*"
    d2 "*ถอนหายใจ*"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:175
translate english arc2_quest5_after_sarada_battle_b10eea9b:

    # d1 "Nunca está de más soñar... ¿Cierto?"
    d1 "การมีความฝันเนี่ย มันไม่เสียหายหรอก... ว่าไหมล่ะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:178
translate english arc2_quest5_after_sarada_battle_a51b5a52:

    # d3 "Dejen la plática para después" with dissolve1
    d3 "เก็บเรื่องคุยเล่นไว้ทีหลังเถอะน่า" with dissolve1

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:179
translate english arc2_quest5_after_sarada_battle_799ff34d:

    # d3 "Estamos aquí para cumplir una misión..."
    d3 "พวกเรามาที่นี่เพื่อทำภารกิจ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:180
translate english arc2_quest5_after_sarada_battle_9a185c0d:

    # d3 "No estamos de turismo, ¿Entendido?"
    d3 "ไม่ได้มาเดินเที่ยวเล่นกัน เข้าใจไหม?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:182
translate english arc2_quest5_after_sarada_battle_1f68d228:

    # d1 "S-Si... Lo siento"
    d1 "อ-เข้าใจแล้ว... ขอโทษที"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:186
translate english arc2_quest5_after_sarada_battle_daf877a8:

    # d3 "Prepárense, que no sospechen de ustedes o están acabados" with dissolve1
    d3 "เตรียมตัวให้ดี อย่าให้พวกมันสงสัยเด็ดขาด ไม่งั้นพวกนายไม่รอดแน่" with dissolve1

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:187
translate english arc2_quest5_after_sarada_battle_4698295b:

    # d3 "Actúen lo más natural posible"
    d3 "ทำตัวให้เป็นธรรมชาติเข้าไว้"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:190
translate english arc2_quest5_after_sarada_battle_151a36b1:

    # n "Los tres ninjas siguen su rumbo y pasan por la puerta de la hoja"
    n "นินจาทั้งสามคนเดินหน้าต่อไปและผ่านประตูทางเข้าหมู่บ้านโคโนฮะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:205
translate english arc2_quest5_after_sarada_battle_38285c8c:

    # n "Los tres ninjas de la niebla se dirigen a la puerta de la hoja y son recibidos por {b}Mirai Sarutobi{/a}"
    n "นินจาจากหมู่บ้านคิริคาคุเระทั้งสามคนมุ่งหน้าไปยังประตูโคโนะฮะและได้รับการต้อนรับจาก {b}ซารุโทบิ มิไร{/a}"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:206
translate english arc2_quest5_after_sarada_battle_b8c1d5d1:

    # mr "Hola, bienvenidos a la Aldea de la Hoja"
    mr "สวัสดีค่ะ ยินดีต้อนรับสู่หมู่บ้านโคโนฮะนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:207
translate english arc2_quest5_after_sarada_battle_997b5a8f:

    # mr "Oh, ¿Ustedes son Ninjas, vienen también para participar en los Exámenes Chunin?"
    mr "อ๋อ เป็นเหล่านินจาที่มาเข้าร่วมการสอบจูนินเหมือนกันสินะคะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:208
translate english arc2_quest5_after_sarada_battle_2e2988b5:

    # d2 "Así es, ¿Podémos pasar?"
    d2 "ถูกต้องครับ พวกเราเข้าไปได้หรือยัง?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:209
translate english arc2_quest5_after_sarada_battle_eca62518:

    # mr "Claro, solo, déjenme ver sus documentos primero"
    mr "ได้ค่ะ ขอฉันตรวจสอบเอกสารของพวกคุณก่อนนะคะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:210
translate english arc2_quest5_after_sarada_battle_5f23d455:

    # d3 "..."
    d3 "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:213
translate english arc2_quest5_after_sarada_battle_7f6a3451:

    # n "Tras un breve intercambio de palabras"
    n "หลังจากพูดคุยกันครู่หนึ่ง"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:214
translate english arc2_quest5_after_sarada_battle_e08d6fcb:

    # n "Mirai revisa los Documentos de los 3 ninjas de la Niebla..."
    n "มิไรตรวจสอบเอกสารของนินจาจากคิริงาคุเระทั้งสามคน..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:215
translate english arc2_quest5_after_sarada_battle_0c784097:

    # mr "Veamos... Voy a necesitar que se quiten las máscaras para comprobar bien sus documentos"
    mr "งั้นมาดูกัน... รบกวนช่วยถอดหน้ากากออกหน่อยนะคะ จะได้ตรวจเอกสารให้เรียบร้อย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:216
translate english arc2_quest5_after_sarada_battle_bb76bc14:

    # mr "Empecémos contigo, Tu nombre es..."
    mr "งั้นเริ่มจากคุณก่อนเลยนะคะ ชื่อของคุณคือ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:222
translate english arc2_quest5_after_sarada_battle_af88c835:

    # ka "Me llamo {b}Katsuro Kurogane{/a}" with dissolve1
    ka "ฉันชื่อ {b}คุโรกาเนะ คัตสึโระ{/a} ครับ" with dissolve1

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:223
translate english arc2_quest5_after_sarada_battle_021326c5:

    # ka "Tengo 22 años"
    ka "อายุ 22 ปีครับ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:225
translate english arc2_quest5_after_sarada_battle_c4b9d6b5:

    # ka "Y vengo a participar en los Exámenes Chunin para probar mis habilidades contra ninjas poderosos"
    ka "แล้วก็มาเพื่อเข้าร่วมการสอบจูนิน เพื่อทดสอบฝีมือของตัวเองกับเหล่านินจาเก่งๆ ครับ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:226
translate english arc2_quest5_after_sarada_battle_eeda0152:

    # mr "Ooh, muy bien, gusto en conocerte Katsuro, puedes pasar"
    mr "อ๋อ เรียบร้อยดีค่ะ ยินดีที่ได้รู้จักนะคัตสึโระ เชิญผ่านได้เลยค่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:228
translate english arc2_quest5_after_sarada_battle_1e20c575:

    # mr "Te deseo mucha suerte!"
    mr "ขอให้โชคดีนะคะ!"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:230
translate english arc2_quest5_after_sarada_battle_0535b2b2:

    # ka "Gracias!"
    ka "ขอบคุณครับ!"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:232
translate english arc2_quest5_after_sarada_battle_e4144484:

    # mr "Ahora la siguiente, tu nombre es..." with dissolve1
    mr "เอาล่ะ คนต่อไป ชื่อของคุณคือ..." with dissolve1

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:236
translate english arc2_quest5_after_sarada_battle_3669a39c:

    # mi "Soy {b}Mizuki Mikage{/a}, un placer" with dissolve1
    mi "ฉันชื่อ {b}มิคาเงะ มิซึกิ{/a} ค่ะ ยินดีที่ได้รู้จัก" with dissolve1

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:237
translate english arc2_quest5_after_sarada_battle_eef4d11e:

    # mi "Vengo a participar en los Exámenes Chunin por..."
    mi "ฉันมาเข้าร่วมการสอบจูนินเพื่อ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:239
translate english arc2_quest5_after_sarada_battle_49dfc645:

    # mi "Bueno, digamos que por placer..."
    mi "อืม เอาเป็นว่ามาหาความสนุกใส่ตัวก็แล้วกัน..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:240
translate english arc2_quest5_after_sarada_battle_5d313048:

    # mr "El placer es mío Mizuki, puedes pasar, todo está en regla"
    mr "ทางนี้ก็ยินดีที่ได้รู้จักเช่นกันค่ะมิซึกิ เชิญผ่านได้เลย ทุกอย่างเรียบร้อยดีค่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:242
translate english arc2_quest5_after_sarada_battle_1fbebd1b:

    # mr "Ahora, la última y no menos importante"
    mr "ทีนี้ คนสุดท้ายแต่ไม่ท้ายสุด"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:243
translate english arc2_quest5_after_sarada_battle_93ff8cbf:

    # mr "Tu nombre es..."
    mr "ชื่อของคุณคือ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:247
translate english arc2_quest5_after_sarada_battle_f3b12b95:

    # oy "Oyuki..." with dissolve1
    oy "โอยูกิค่ะ..." with dissolve1

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:248
translate english arc2_quest5_after_sarada_battle_6faa04b6:

    # mr "Eh, un placer Oyuki..."
    mr "เอ๊ะ ยินดีที่ได้รู้จักนะโอยูกิ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:249
translate english arc2_quest5_after_sarada_battle_a908690b:

    # mr "Oyuki... ¿De qué clan vienes?"
    mr "โอยูกิ... มาจากตระกูลไหนเหรอคะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:252
translate english arc2_quest5_after_sarada_battle_2c155f65:

    # oy "..."
    oy "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:255
translate english arc2_quest5_after_sarada_battle_6683e91d:

    # oy "¿Es relevante?"
    oy "จำเป็นด้วยเหรอ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:256
translate english arc2_quest5_after_sarada_battle_3bf558d4:

    # mr "Eh, si, es para verificar los datos de los Documentos que me proporcionas"
    mr "เอ่อ ค่ะ ก็เพื่อตรวจสอบความถูกต้องของข้อมูลในเอกสารที่คุณยื่นมาน่ะค่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:257
translate english arc2_quest5_after_sarada_battle_c78f3314:

    # oy "Ya veo..."
    oy "งั้นเหรอ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:258
translate english arc2_quest5_after_sarada_battle_d5e03a76:

    # oy "Soy del Clan {b}Yukimura{/a}..."
    oy "ฉันมาจากตระกูล {b}ยูคิมูระ{/a} ค่ะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:259
translate english arc2_quest5_after_sarada_battle_1e2cbf74:

    # mr "Mmm..."
    mr "อืม..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:260
translate english arc2_quest5_after_sarada_battle_332a8653:

    # mr "Si, parece ser que todo está en regla... Puedes pasar"
    mr "ค่ะ ดูเหมือนว่าทุกอย่างจะเรียบร้อยดีนะ... เชิญผ่านได้เลยค่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:262
translate english arc2_quest5_after_sarada_battle_da407766:

    # oy "Gracias..."
    oy "ขอบคุณค่ะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:264
translate english arc2_quest5_after_sarada_battle_6c9b83e8:

    # mr "..."
    mr "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:265
translate english arc2_quest5_after_sarada_battle_89e08e40:

    # mr "Que gente tan extraña..."
    mr "ช่างเป็นคนแปลกๆ จริง..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:266
translate english arc2_quest5_after_sarada_battle_dc3743af:

    # mr "Solo espero que no vayan a provocar problemas... Es lo menos que deseamos..."
    mr "ฉันแค่หวังว่าพวกเขาจะไม่ก่อเรื่องนะ... นั่นคือสิ่งที่เราไม่อยากให้เกิดขึ้นที่สุดเลย..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:269
translate english arc2_quest5_after_sarada_battle_f5e63503:

    # n "Luego que de comprobaran que sus documentos estuvieran en regla, los 3 ninjas entran a la Aldea de la Hoja..."
    n "หลังจากตรวจสอบความถูกต้องของเอกสารเรียบร้อยแล้ว นินจาทั้ง 3 คนก็เข้ามาในหมู่บ้านโคโนฮะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:283
translate english arc2_quest5_after_sarada_battle_c98d9f27:

    # mi "Eso fue fácil... Más de lo que pensé..."
    mi "ง่ายกว่าที่คิดแฮะ... ง่ายกว่าที่คิดไว้ซะอีก..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:285
translate english arc2_quest5_after_sarada_battle_ffc22353:

    # ka "Si, todo está saliendo según lo previsto"
    ka "ใช่ ทุกอย่างเป็นไปตามแผนเลย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:286
translate english arc2_quest5_after_sarada_battle_5d306817:

    # ka "Todo gracias a que el señor {b}Mizukage{/a} nos-"
    ka "ต้องขอบคุณท่าน {b}มิซึคาเงะ{/a} ที่-"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:291
translate english arc2_quest5_after_sarada_battle_0c6a3051:

    # mi "¡Shh! Cállate idiota, recuerda que estamos en territorio enemigo" with vpunch
    mi "ชู่ว! หุบปากน่า เจ้าบ้า จำไว้สิว่าเราอยู่ในดินแดนของศัตรูนะ" with vpunch

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:292
translate english arc2_quest5_after_sarada_battle_23d839e8:

    # mi "No puedes decir cualquier cosa en medio de la calle"
    mi "จะมาพูดจาอะไรกลางถนนแบบนี้ไม่ได้หรอก"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:294
translate english arc2_quest5_after_sarada_battle_2b64bca7:

    # ka "Aah... Lo siento jeje, esta es mi primera misión de este tipo..."
    ka "อ่า... โทษทีๆ นี่เป็นภารกิจแนวนี้ครั้งแรกของฉันน่ะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:301
translate english arc2_quest5_after_sarada_battle_33836193:

    # oy "Síganme..."
    oy "ตามฉันมา..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:305
translate english arc2_quest5_after_sarada_battle_cd1dc7e5:

    # n "Los tres ninjas de la Niebla suben a los tejados de la aldea..."
    n "นินจาหมอกทั้งสามคนกระโดดขึ้นไปบนหลังคาบ้านเรือนในหมู่บ้าน..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:320
translate english arc2_quest5_after_sarada_battle_1e2672a7:

    # oy "Muy bien, escuchen..." with dissolve1
    oy "เอาล่ะ ฟังให้ดี..." with dissolve1

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:322
translate english arc2_quest5_after_sarada_battle_194ff899:

    # oy "Hoy nos dividirémos. Cada uno buscará información sobre los que participarán en los Exámenes Chunin"
    oy "วันนี้เราจะแยกย้ายกันปฏิบัติภารกิจ แต่ละคนจะต้องไปรวบรวมข้อมูลเกี่ยวกับผู้ที่จะเข้าร่วมการสอบจูนิน"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:323
translate english arc2_quest5_after_sarada_battle_b4e3b868:

    # oy "Deben ser precavidos, aunque estén en tiempos de paz, la seguridad de la Hoja es impresionante"
    oy "พวกเธอต้องระมัดระวังตัวให้ดี ถึงแม้จะเป็นช่วงเวลาแห่งความสงบสุข แต่ระบบรักษาความปลอดภัยของโคโนฮะก็ยังน่าประทับใจไม่เปลี่ยน"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:324
translate english arc2_quest5_after_sarada_battle_5eb8b703:

    # oy "Mizuki, creo que ya te diste cuenta del domo, ¿Cierto?"
    oy "มิซึกิ ฉันว่าเธอคงสังเกตเห็นโดมพลังงานนั่นแล้วใช่ไหม?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:325
translate english arc2_quest5_after_sarada_battle_fb94e523:

    # mi "Si, un domo sensorial que cubre toda la aldea de la hoja"
    mi "ใช่ค่ะ โดมตรวจจับที่ครอบคลุมทั่วทั้งหมู่บ้านโคโนฮะเลยสินะคะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:328
translate english arc2_quest5_after_sarada_battle_d228e88b:

    # ka "¿Eh, de qué están hablando?"
    ka "เอ๊ะ อะไรเหรอ กำลังพูดถึงอะไรกันน่ะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:329
translate english arc2_quest5_after_sarada_battle_5ffcf51b:

    # oy "Con un perímetro sensorial así, debemos actuar con precaución, usen el {b}Dispositivo{/a} si es necesario"
    oy "ด้วยเขตตรวจจับพลังสัมผัสแบบนั้น พวกเราต้องระมัดระวังให้มาก ใช้ {b}อุปกรณ์{/a} ซะถ้าจำเป็น"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:330
translate english arc2_quest5_after_sarada_battle_b7b475b8:

    # oy "Katsuro, también debes contactar con nuestro {b}Enlace{/a}. Infórmale de las nuevas órdenes de {b}El Patrón{/a}"
    oy "คัตสึโระ นายต้องติดต่อไปหา {b}ผู้ประสานงาน{/a} ของเราด้วย แจ้งคำสั่งใหม่จาก {b}เดอะ บอส{/a} ให้เขารู้"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:332
translate english arc2_quest5_after_sarada_battle_d998e89c:

    # ka "Así se hará Oyuki-Sama"
    ka "รับทราบครับ ท่านโอยูกิ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:337
translate english arc2_quest5_after_sarada_battle_bb2cf764:

    # n "..."
    n "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:339
translate english arc2_quest5_after_sarada_battle_a31df04e:

    # n "Durante semanas, los tres ninjas de la Niebla se dispersaron de forma estratégica en la Aldea de la Hoja"
    n "เป็นเวลาหลายสัปดาห์แล้วที่นินจาหมอกทั้งสามแยกย้ายกันไปแทรกซึมตามจุดต่างๆ ในหมู่บ้านโคโนฮะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:340
translate english arc2_quest5_after_sarada_battle_f489de06:

    # n "Su misión era recolectar información sobre los participantes de los Exámenes Chunin"
    n "ภารกิจของพวกเขาคือการรวบรวมข้อมูลเกี่ยวกับผู้เข้าร่วมการสอบจูนิน"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:342
translate english arc2_quest5_after_sarada_battle_a5398287:

    # n "Miyuki se movió como una sombra por las calles y los tejados..." with fade
    n "มิซึกิเคลื่อนไหวราวกับเงาดำไปตามท้องถนนและหลังคาบ้าน..." with fade

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:343
translate english arc2_quest5_after_sarada_battle_d5d52788:

    # n "Pasó gran parte de sus días observando discretamente el equipo de la Aldea de la Roca, haciendo especial hincapié en su líder..."
    n "เธอใช้เวลาส่วนใหญ่ไปกับการแอบสังเกตการณ์ทีมจากหมู่บ้านอิวะอย่างเงียบเชียบ โดยเพ่งเล็งไปที่หัวหน้าทีมเป็นพิเศษ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:344
translate english arc2_quest5_after_sarada_battle_784f390b:

    # n "Una ninja con un gran dominio sobre el Doton y una actitud competitiva que la convertía en una gran rival"
    n "นินจาผู้มีความเชี่ยวชาญขั้นสูงในคาถาธาตุดินและมีจิตวิญญาณแห่งการแข่งขันสูง ซึ่งทำให้เธอเป็นคู่แข่งที่น่ากลัว"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:345
translate english arc2_quest5_after_sarada_battle_dacbc717:

    # n "En sus informes, Miyuki mencionó la ventaja de neutralizar primero a este líder"
    n "ในรายงานของเธอ มิซึกิได้ระบุถึงข้อได้เปรียบในการกำจัดหัวหน้าทีมคนนี้เป็นอันดับแรก"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:346
translate english arc2_quest5_after_sarada_battle_562c0492:

    # n "Ya que su velocidad y capacidad ofensiva podrían complicar cualquier enfrentamiento futuro"
    n "เนื่องจากความเร็วและพลังโจมตีของเธออาจสร้างความยุ่งยากให้กับการปะทะกันในอนาคตได้"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:348
translate english arc2_quest5_after_sarada_battle_bc7a2b20:

    # n "Luego, Katsuro, cuyo instinto se inclinaba hacia el combate directo"
    n "ในขณะเดียวกัน คัตสึโระ ผู้มีสัญชาตญาณโน้มเอียงไปทางด้านการต่อสู้ระยะประชิด"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:349
translate english arc2_quest5_after_sarada_battle_97b1c0b2:

    # n "Aprovechó los campos de entrenamiento para observar de cerca a los equipos que practicaban"
    n "ได้ใช้ประโยชน์จากสนามฝึกซ้อมเพื่อแอบดูการฝึกฝนของทีมต่างๆ อย่างใกล้ชิด"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:352
translate english arc2_quest5_after_sarada_battle_06890ec2:

    # n "Sus ojos se fijaron en un grupo de la Aldea de la Hoja, donde una ninja destacaba notablemente" with fade
    n "สายตาของเขาจับจ้องไปที่กลุ่มนินจาจากหมู่บ้านโคโนฮะ ซึ่งมีนินจาคนหนึ่งโดดเด่นสะดุดตาเป็นอย่างมาก" with fade

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:353
translate english arc2_quest5_after_sarada_battle_05087ecc:

    # n "No solo por su imponente presencia, sino por la precisión de cada uno de sus movimientos"
    n "ไม่ใช่แค่เพราะรัศมีอันน่าเกรงขามของเธอ แต่เป็นเพราะความแม่นยำในทุกๆ การเคลื่อนไหวต่างหาก"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:354
translate english arc2_quest5_after_sarada_battle_3a7e108c:

    # n "La ninja tenía una técnica particular... Su cuerpo parecía recubrirse en un metal oscuro"
    n "นินจาคนนั้นมีเทคนิคเฉพาะตัว... ร่างกายของเธอดูเหมือนจะถูกปกคลุมไปด้วยโลหะสีเข้ม"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:355
translate english arc2_quest5_after_sarada_battle_0c7e6793:

    # n "El {b}Estilo de Acero{/a}, que aumentaba su defensa y hacía que sus ataques fueran devastadores"
    n "{b}คาถาเหล็ก{/a} ซึ่งช่วยเพิ่มพลังป้องกันและทำให้การโจมตีของเธอรุนแรงถึงตาย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:356
translate english arc2_quest5_after_sarada_battle_e3c5a53b:

    # n "Katsuro quedó intrigado al instante, pues este Kekkei Genkai, aparte de ser sumamente extraño"
    n "คัตสึโระรู้สึกสนใจในทันที เพราะขีดจำกัดสายเลือดนี้ นอกจากจะหาได้ยากยิ่งแล้ว"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:357
translate english arc2_quest5_after_sarada_battle_387fb11c:

    # n "Requería una maestría en el uso del chakra que pocos alcanzaban"
    n "ยังต้องอาศัยการควบคุมจักระในระดับที่น้อยคนนักจะทำได้"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:358
translate english arc2_quest5_after_sarada_battle_e3ee546c:

    # n "La ninja, a pesar de su destreza y poder, mostraba un leve desfase en su postura cada vez que activaba su técnica"
    n "แต่นินจาคนนั้น แม้จะมีฝีมือและพลังอันแข็งแกร่ง แต่ก็ยังแสดงความผิดพลาดเล็กน้อยในท่าทางทุกครั้งที่เธอใช้เทคนิค"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:359
translate english arc2_quest5_after_sarada_battle_4027d221:

    # n "Lo que abría algunos puntos ciegos en su defensa"
    n "ซึ่งเปิดช่องว่างและจุดบอดบางอย่างในแนวป้องกันของเธอ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:360
translate english arc2_quest5_after_sarada_battle_e6bc2f11:

    # n "Katsuro anotó en su mente estos detalles si llegaba a enfrentarse con ella, esa rigidez sería la clave para superarla"
    n "คัตสึโระบันทึกรายละเอียดเหล่านี้ไว้ในใจ หากเขาต้องเผชิญหน้ากับเธอ ความแข็งกระด้างนั้นจะเป็นกุญแจสำคัญในการเอาชนะเธอ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:362
translate english arc2_quest5_after_sarada_battle_3d4ea228:

    # n "Finalmente, Oyuki mantuvo una vigilancia más amplia"
    n "ในที่สุด โอยูกิก็ยังคงคอยเฝ้าระวังในขอบเขตที่กว้างขึ้น"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:363
translate english arc2_quest5_after_sarada_battle_1942a180:

    # n "Recorriendo puntos estratégicos desde donde pudiera monitorear tanto la actividad de la aldea como la ubicación de los participantes."
    n "โดยคอยดูแลจุดยุทธศาสตร์ที่เธอสามารถจับตาดูทั้งความเคลื่อนไหวของหมู่บ้านและตำแหน่งของผู้เข้าแข่งขันได้พร้อมๆ กัน"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:364
translate english arc2_quest5_after_sarada_battle_fc75aebb:

    # n "No había dejado a ningún equipo sin observar, y cada uno de sus movimientos era calculado para pasar desapercibida"
    n "เธอไม่ได้ปล่อยให้ทีมไหนรอดพ้นจากการสังเกตการณ์ไปได้เลย และทุกๆ การเคลื่อนไหวของเธอก็ถูกคำนวณมาเป็นอย่างดีเพื่อให้ไม่มีใครจับสังเกตได้"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:367
translate english arc2_quest5_after_sarada_battle_f00882e9:

    # n "Y ahora, sus ojos se posaban en una kunoichi de renombre, Sarada Uchiha, quien entrenaba a [MN]" with fade
    n "และตอนนี้ สายตาของเธอก็ทอดมองไปยังคุโนอิจิชื่อดังอย่าง อุจิวะ ซาราดะ ผู้ซึ่งกำลังฝึกฝนให้กับ [MN]" with fade

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:368
translate english arc2_quest5_after_sarada_battle_2b547275:

    # oy "Sarada Uchiha... portadora del Sharingan..."
    oy "อุจิวะ ซาราดะ... ผู้ครอบครองเนตรวงแหวน..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:369
translate english arc2_quest5_after_sarada_battle_a2e05862:

    # n "Oyuki la observaba con aparente interés, aunque Sarada mantenía una postura firme y precisa"
    n "โอยูกิจ้องมองเธอด้วยความสนใจอย่างเห็นได้ชัด แม้ว่าซาราดะจะรักษาท่าทางที่มั่นคงและแม่นยำเอาไว้ก็ตาม"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:370
translate english arc2_quest5_after_sarada_battle_97a4648c:

    # n "Sus movimientos y reflejos distaban de la destreza que Oyuki esperaría de un verdadero prodigio Uchiha"
    n "การเคลื่อนไหวและปฏิกิริยาตอบสนองของเธอยังห่างไกลจากฝีมือที่โอยูกิคาดหวังจากอัจฉริยะแห่งตระกูลอุจิวะของจริง"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:371
translate english arc2_quest5_after_sarada_battle_203adeac:

    # oy "Sí, hay potencial... Aunque aún le falta mucho... Tal vez, con el tiempo, perfeccione ese Sharingan que apenas domina..."
    oy "ใช่ มีศักยภาพอยู่... แม้ว่าเธอยังต้องไปอีกไกลก็ตาม... บางที เมื่อเวลาผ่านไป เธอก่อร่างสร้างเนตรวงแหวนที่แทบจะควบคุมไม่ได้นั่นให้สมบูรณ์แบบได้นะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:372
translate english arc2_quest5_after_sarada_battle_606c4407:

    # n "Sus ojos apenas se desviaron hacia el compañero de Sarada"
    n "สายตาของเธอเหลือบมองไปยังเพื่อนร่วมทางของซาราดะเพียงเล็กน้อย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:373
translate english arc2_quest5_after_sarada_battle_d063865e:

    # n "Un joven que, aunque poseía un Sharingan, parecía tener un dominio casi nulo sobre él"
    n "ชายหนุ่มผู้ซึ่งถึงแม้จะมีเนตรวงแหวน แต่กลับดูเหมือนแทบจะควบคุมมันไม่ได้เลย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:374
translate english arc2_quest5_after_sarada_battle_3e8001bd:

    # oy "¿Y ese tipo...? Otro portador del Sharingan, pero sin nada destacable... Movimientos decentes, pero nada más"
    oy "ส่วนไอ้หมอนั่น...? ผู้ถือครองเนตรวงแหวนอีกคน แต่ก็ไม่มีอะไรน่าประทับใจ... การเคลื่อนไหวใช้ได้ แต่ก็แค่นั้นแหละ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:375
translate english arc2_quest5_after_sarada_battle_7c6e05ce:

    # oy "Debe ser [MN]... Participante de los Exámenes Chunin y miembro del Equipo 11"
    oy "คงจะเป็น [MN]... ผู้เข้าสอบจูนินและสมาชิกทีม 11 สินะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:376
translate english arc2_quest5_after_sarada_battle_b89af8e4:

    # oy "No tiene tanto potencial como la chica de cabello morado... {b}Yuna{/b}, creo que se llamaba"
    oy "เขามีศักยภาพไม่เท่าเด็กผู้หญิงผมสีม่วงคนนั้น... ถ้าจำไม่ผิด น่าจะชื่อ {b}ยูนะ{/b} สินะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:377
translate english arc2_quest5_after_sarada_battle_c7114d74:

    # oy "Aunque, al menos, no es un inútil completo... a diferencia de su otro compañero de Amarillo"
    oy "อย่างน้อย ๆ เขาก็ไม่ใช่พวกไร้ประโยชน์ไปซะทีเดียว... ไม่เหมือนเพื่อนร่วมทีมหัวเหลืองอีกคนของเขา"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:378
translate english arc2_quest5_after_sarada_battle_6e44d9a2:

    # n "De pronto, Oyuki notó un cambio sutil en el flujo de chakra [MN], que captó su atención"
    n "ทันใดนั้น โอยูกิก็สังเกตเห็นความเปลี่ยนแปลงเล็กน้อยในกระแสจักระของ [MN] ซึ่งดึงดูดความสนใจของเธอเข้าพอดี"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:379
translate english arc2_quest5_after_sarada_battle_c2eb0972:

    # n "El chico, que hasta ese momento parecía apenas un espectador en su propio entrenamiento"
    n "เด็กหนุ่มผู้ซึ่งจนถึงวินาทีนั้นแทบจะดูเหมือนเป็นแค่คนดูการฝึกของตัวเองเท่านั้น"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:380
translate english arc2_quest5_after_sarada_battle_e4f1aa38:

    # n "Comenzó a emitir un chakra inusualmente... Familiar"
    n "กลับเริ่มแผ่จักระที่ผิดปกติ... และคุ้นเคยออกมา"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:381
translate english arc2_quest5_after_sarada_battle_1793d94b:

    # oy "Oyuki observó con interés el cambio en el flujo de chakra, hasta que pudo reconocerlo..."
    oy "โอยูกิจ้องมองการเปลี่ยนแปลงของกระแสจักระด้วยความสนใจ จนกระทั่งเธอจำมันได้..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:387
translate english arc2_quest5_after_sarada_battle_cdd76d96:

    # mn "¡Muy bien, ahora vamos con todo!" with vpunch
    mn "เอาล่ะ คราวนี้เอา100%เต็มเลยนะ!" with vpunch

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:389
translate english arc2_quest5_after_sarada_battle_9de1c8d9:

    # n "Aquel brillo inconfundible, un chakra imposible de pasar por alto..." with dissolve1
    n "แสงเรืองรองที่คุ้นเคยนั้น จักระที่ไม่อาจมองข้ามได้..." with dissolve1

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:390
translate english arc2_quest5_after_sarada_battle_a6a92f90:

    # n "El ojo derecho de [MN] se transformó en algo que Oyuki reconoció de inmediato"
    n "ดวงตาข้างขวาของ [MN] แปรเปลี่ยนเป็นบางสิ่งที่โอยูกิจำได้ในทันที"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:393
translate english arc2_quest5_after_sarada_battle_f02f3841:

    # n "¡El {b}Karugan{/b}!" with vpunch
    n "{b}คารูกัน{/b}!" with vpunch

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:394
translate english arc2_quest5_after_sarada_battle_dfa51233:

    # oy "No... No puede ser... ¿El Karugan...?"
    oy "ไม่... เป็นไปไม่ได้... คารูกันงั้นเหรอ...?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:395
translate english arc2_quest5_after_sarada_battle_595ad526:

    # oy "Pero eso solo significa una cosa..."
    oy "แต่นั่นหมายความว่า... มีแค่เรื่องเดียวเท่านั้น..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:396
translate english arc2_quest5_after_sarada_battle_2c155f65_1:

    # oy "..."
    oy "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:397
translate english arc2_quest5_after_sarada_battle_4287c25e:

    # oy "Después de tanto tiempo, después de todo lo que ha pasado... y aquí está..."
    oy "หลังจากเวลาผ่านไปนานขนาดนี้ หลังจากเรื่องทั้งหมดที่เกิดขึ้น... และตอนนี้มันก็มาปรากฏอยู่ตรงนี้..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:398
translate english arc2_quest5_after_sarada_battle_f63c5273:

    # oy "Esto lo cambia todo... {b}Él{/b} ya había perdido las esperanzas... Pero aquí está"
    oy "นี่มันพลิกสถานการณ์ทุกอย่างเลย... {b}เขา{/b}หมดหวังไปแล้วแท้ ๆ... แต่ตอนนี้มันกลับอยู่ที่นี่"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:399
translate english arc2_quest5_after_sarada_battle_5b3ae464:

    # oy "Esto le encantará... Debo informar de inmediato al {b}Patrón{/a}"
    oy "เขาต้องชอบเรื่องนี้แน่ๆ... ฉันต้องรายงาน {b}บอส{/a} เดี๋ยวนี้เลย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:403
translate english arc2_quest5_after_sarada_battle_36749c0d:

    # n "Oyuki siguió observando como [MN] y Sarada seguían entrenando" with vpunch
    n "โอยูกิยังคงเฝ้ามอง [MN] และซาราดะฝึกซ้อมกันต่อไป" with vpunch

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:404
translate english arc2_quest5_after_sarada_battle_a3b01a55:

    # n "[MN] se esforzó todo lo que pudo, ha pasado semanas entrenando con Sarada para los exámenes Chunin"
    n "[MN] พยายามอย่างเต็มที่ เขาใช้เวลาหลายสัปดาห์ในการฝึกซ้อมกับซาราดะเพื่อเตรียมตัวสอบจูนิน"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:405
translate english arc2_quest5_after_sarada_battle_837ec0d0:

    # n "Y sin duda ha mejorado mucho"
    n "และฝีมือของเขาก็พัฒนาขึ้นมากอย่างไม่ต้องสงสัย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:408
translate english arc2_quest5_after_sarada_battle_f405678a:

    # n "Y luego del entrenamiento"
    n "และหลังจากฝึกซ้อมเสร็จ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:409
translate english arc2_quest5_after_sarada_battle_a325cb0d:

    # n "[MN] detuvo sus movimientos y fijó su mirada en la dirección desde donde Oyuki lo observaba"
    n "[MN] ก็หยุดการเคลื่อนไหวและมองไปยังทิศทางที่โอยูกิกำลังแอบมองเขาอยู่"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:410
translate english arc2_quest5_after_sarada_battle_8d7270b5:

    # n "Como si de alguna manera hubiera sentido su fría presencia"
    n "ราวกับว่าบางทีเขาอาจจะสัมผัสถึงไอเย็นยะเยือกของเธอได้"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:411
translate english arc2_quest5_after_sarada_battle_a173fbac:

    # n "Sin embargo, ya no había nada... El aire estaba tranquilo, como si nadie hubiera estado ahí..."
    n "ทว่ากลับไม่มีอะไรเลย... สายลมสงบนิ่ง ราวกับว่าไม่มีใครเคยอยู่ที่นั่น..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:424
translate english arc2_quest5_after_sarada_battle_ea69c15e:

    # mn "¿Qué fue eso?, Sentí como si alguien nos estuviera observando..."
    mn "เมื่อกี้อะไรน่ะ? เหมือนฉันรู้สึกว่ามีใครกำลังมองพวกเราอยู่เลย..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:425
translate english arc2_quest5_after_sarada_battle_c76c4718:

    # mn "¿Habrá sido solo mi imaginación?"
    mn "คิดไปเองเหรอเนี่ย?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:426
translate english arc2_quest5_after_sarada_battle_66e295bf:

    # sr "¿Todo bien, [MN]?"
    sr "มีอะไรเหรอ [MN]?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:428
translate english arc2_quest5_after_sarada_battle_60f16440:

    # mn "¿Mmm? Oh, sí..."
    mn "หืม? อ๋อ เปล่า..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:439
translate english arc2_quest5_after_sarada_battle_60209b7e:

    # mn "Nada de qué preocuparse"
    mn "ไม่มีอะไรต้องห่วงหรอก"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:440
translate english arc2_quest5_after_sarada_battle_a34e002f:

    # sr "Bien, entonces ya hemos acabado por hoy"
    sr "งั้นวันนี้ก็พอแค่นี้แหละ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:443
translate english arc2_quest5_after_sarada_battle_f724a0ad:

    # sr "O mejor dicho, ya has acabado tu entrenamiento conmigo"
    sr "หรือจะพูดให้ถูกคือ นายฝึกกับฉันเสร็จพอดีต่างหาก"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:445
translate english arc2_quest5_after_sarada_battle_90fff9ed:

    # sr "Has mejorado muchísimo en estas semanas, [MN], incluso más de lo que imaginé"
    sr "ช่วงหลายสัปดาห์นี้นายพัฒนาขึ้นเยอะเลยนะ [MN] เกินกว่าที่ฉันคิดไว้ซะอีก"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:446
translate english arc2_quest5_after_sarada_battle_1c076e09:

    # sr "Tienes un talento innato, solamente necesitabas pulir más tus habilidades"
    sr "นายมีพรสวรรค์ติดตัวอยู่แล้ว แค่ต้องขัดเกลาฝีมือเพิ่มอีกหน่อยเท่านั้นเอง"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:447
translate english arc2_quest5_after_sarada_battle_3f08945f:

    # mn "Gracias jaja, aunque, sinceramente aún no puedo confiarme... Tengo mucho que mejorar todavía"
    mn "ขอบคุณนะ ฮ่าๆ แต่เอาจริงๆ ฉันก็ยังประมาทไม่ได้หรอก... ฉันยังต้องพัฒนาอีกเยอะเลย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:448
translate english arc2_quest5_after_sarada_battle_ddb1a7f5:

    # mn "Ahí afuera deben de haber Shinobis mucho más fuertes que yo"
    mn "ข้างนอกนั้นต้องมีนินจาที่เก่งกว่าฉันอีกมากแน่ๆ เลย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:450
translate english arc2_quest5_after_sarada_battle_16278896:

    # sr "..."
    sr "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:452
translate english arc2_quest5_after_sarada_battle_c17c6841:

    # sr "¿Sabes? Ese es un rasgo que me encanta de tí"
    sr "รู้ไหม? นั่นคือจุดเด่นในตัวนายที่ฉันชอบเลยล่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:454
translate english arc2_quest5_after_sarada_battle_dba56bbb:

    # mn "¿E-Eh, q-qué dices?"
    mn "ฮ-หะ, พ-พูดอะไรของเธอน่ะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:456
translate english arc2_quest5_after_sarada_battle_44a988d9:

    # sr "Esa humildad que posees, no solo tienes habilidad, sino que sabes reconocer en qué debes trabajar y seguir mejorando"
    sr "ความอ่อนน้อมถ่อมตนที่นายมีเนี่ย นอกจากจะมีฝีมือแล้ว นายยังรู้ด้วยว่าตัวเองต้องปรับปรุงตรงไหนและพัฒนาตัวเองต่อไปเรื่อยๆ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:458
translate english arc2_quest5_after_sarada_battle_a8004a27:

    # sr "Nunca dejes que tu ego te domine, ¿Entendido?"
    sr "อย่าปล่อยให้อีโก้ครอบงำเด็ดขาด เข้าใจไหม?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:459
translate english arc2_quest5_after_sarada_battle_c10e377f:

    # sr "Muchos ninjas se dejan llevar por su Ego y se creen más fuertes de lo que son"
    sr "นินจาหลายคนมักจะหลงระเริงไปกับอีโก้ของตัวเองและคิดว่าตัวเองเก่งกว่าที่เป็นอยู่"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:460
translate english arc2_quest5_after_sarada_battle_dd181c9f:

    # sr "Pero cuando se encuetran con un enemigo más fuerte hasta ahí es que ven la realidad"
    sr "แต่พอต้องมาเจอกับศัตรูที่เก่งกว่า นั่นแหละคือตอนที่พวกเขาจะได้ตาสว่างเห็นความจริง"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:462
translate english arc2_quest5_after_sarada_battle_6397708e:

    # sr "Por eso no tienes que creerte más de lo que eres, pero tampoco creerte tan poco"
    sr "นั่นแหละคือเหตุผลที่นายไม่ควรคิดว่าตัวเองเหนือกว่าความเป็นจริง แต่ก็ต้องไม่ดูถูกตัวเองจนเกินไปด้วย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:463
translate english arc2_quest5_after_sarada_battle_8a591148:

    # sr "Tiene que haber un balance, ¿Entendiste?"
    sr "ต้องรักษาสมดุลให้อยู่ตรงกลาง เข้าใจไหม?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:465
translate english arc2_quest5_after_sarada_battle_3aba1ea4:

    # mn "Mmmm si... Creo que lo entendí..."
    mn "อื้ม เข้าใจแล้วล่ะ... คิดว่านะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:466
translate english arc2_quest5_after_sarada_battle_362fcbfd:

    # sr "Bien, con esa actitud vas a llegar lejos [MN], estoy segura de eso"
    sr "ดีแล้ว ด้วยทัศนคตินี้นายไปได้ไกลแน่ [MN] ฉันมั่นใจเลย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:467
translate english arc2_quest5_after_sarada_battle_a2261686:

    # sr "Ahora dejando eso de lado..."
    sr "เอาล่ะ นอกเหนือจากเรื่องนั้น..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:468
translate english arc2_quest5_after_sarada_battle_5b6d0284:

    # sr "Ya que hemos terminado con tu entrenamiento, ¿Qué te parece si para celebrar vienes a cenar a mi casa?"
    sr "ไหนๆ ก็ฝึกเสร็จกันแล้ว ไปฉลองด้วยการกินมื้อเย็นที่บ้านฉันดีไหมล่ะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:470
translate english arc2_quest5_after_sarada_battle_ecad6e00:

    # mn "Oh, ¡Me encantaría!" with vpunch
    mn "โอ้ เอาสิ อยากไปอยู่พอดีเลย!" with vpunch

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:471
translate english arc2_quest5_after_sarada_battle_ea87fac6:

    # sr "!Perfecto! ¿Vamos entonces?"
    sr "เยี่ยม งั้นเราไปกันเลยไหม?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:474
translate english arc2_quest5_after_sarada_battle_8583b4d7:

    # n "Luego de que [MN] pasara semanas entrenando con Sarada, su entrenamiento al fin ha terminado"
    n "หลังจากที่ [MN] ใช้เวลาฝึกซ้อมร่วมกับซาราดะมาหลายสัปดาห์ ในที่สุดการฝึกของเขาก็สิ้นสุดลง"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:475
translate english arc2_quest5_after_sarada_battle_95d28612:

    # n "Y como celebración Sarada ha invitado a [MN] a ir a cenar a su casa"
    n "และเพื่อเป็นการฉลอง ซาราดะจึงชวน [MN] มาทานมื้อเย็นที่บ้านของเธอ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:476
translate english arc2_quest5_after_sarada_battle_8389981a:

    # n "-{b}Momentos Después{/a}-"
    n "-{b}เวลาต่อมา{/a}-"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:484
translate english arc2_quest5_after_sarada_battle_52360427:

    # sr "Hola Mamá, ya llegué, y traje una sorpresa"
    sr "หนูมาแล้วค่ะคุณแม่ แล้วก็พาเซอร์ไพรส์มาด้วยคนนึงค่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:486
translate english arc2_quest5_after_sarada_battle_564942b8:

    # mn "¿Ella no sabía que yo iba a venir?"
    mn "เธอไม่ได้บอกแม่เหรอว่าฉันจะมา?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:487
translate english arc2_quest5_after_sarada_battle_404fc145:

    # sr "No, también preparé esto porque hace mucho no venías a cenar"
    sr "เปล่าจ้ะ ฉันตั้งใจเซอร์ไพรส์เองแหละ เพราะนายไม่ได้มาทานมื้อเย็นด้วยกันนานแล้ว"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:488
translate english arc2_quest5_after_sarada_battle_861f9c39:

    # sr "Así que me pareció que le iba a encantar"
    sr "ฉันก็เลยคิดว่าแม่น่าจะชอบนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:489
translate english arc2_quest5_after_sarada_battle_5502cecb_3:

    # mnn "..."
    mnn "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:491
translate english arc2_quest5_after_sarada_battle_bbf29b75:

    # mnn "(Después de lo que pasó la última vez... No sé si le alegre verme...)"
    mnn "(หลังจากเรื่องที่เกิดขึ้นครั้งก่อน... ฉันไม่รู้เลยว่าเธอจะดีใจที่ได้เจอฉันไหม...)"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:494
translate english arc2_quest5_after_sarada_battle_275ef255:

    # n "Momentos después, Sakura hace presencia"
    n "ไม่นานนัก ซากุระก็ปรากฏตัวขึ้น"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:504
translate english arc2_quest5_after_sarada_battle_3e4f79f5:

    # sk "Buenas noches Sa..."
    sk "สวัสดีจ้า ซา..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:509
translate english arc2_quest5_after_sarada_battle_dd9e91fd:

    # sk "Oh, ¡[MN]!" with vpunch
    sk "อ้าว, [MN]!" with vpunch

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:510
translate english arc2_quest5_after_sarada_battle_9cee1161:

    # mn "H-Hola Sakura... Buenas noches..."
    mn "ส-สวัสดีครับ ซากุระ... สวัสดีตอนเย็นครับ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:512
translate english arc2_quest5_after_sarada_battle_a8c221cb:

    # sr "¿A que es una gran sorpresa?"
    sr "เซอร์ไพรส์ดีใช่ไหมล่ะคะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:515
translate english arc2_quest5_after_sarada_battle_71d22000:

    # sr "Hace mucho que [MN] no venía a cenar, así que pensé que sería una gran idea traerlo para celebrar"
    sr "[MN] ไม่ได้มาทานมื้อเย็นด้วยกันนานแล้วค่ะ หนูเลยคิดว่าพามาร่วมฉลองด้วยน่าจะเป็นความคิดที่ดี"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:518
translate english arc2_quest5_after_sarada_battle_ef85dbbd:

    # sk "¿Celebrar?"
    sk "ฉลองงั้นเหรอ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:519
translate english arc2_quest5_after_sarada_battle_54cb9729:

    # sr "Bueno, tenía en mente hacer una cena como celebración, [MN] ha mejorado muchísimo gracias a mi entrenamiento"
    sr "ก็คือหนูตั้งใจจะจัดมื้อเย็นฉลองน่ะค่ะ [MN] เก่งขึ้นตั้งเยอะด้วยการฝึกของหนูเอง"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:521
translate english arc2_quest5_after_sarada_battle_e32aac6b:

    # sk "Oh, ¡¿De verdad?! Si es así entonces..."
    sk "อ๋อ จริงเหรอเนี่ย! ถ้าอย่างนั้นล่ะก็..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:523
translate english arc2_quest5_after_sarada_battle_3282cb18:

    # sk "¡A celebrar!" with hpunch
    sk "ฉลองกันเถอะ!" with hpunch

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:526
translate english arc2_quest5_after_sarada_battle_eb59c816:

    # sr "¡A celebrar!" with vpunch
    sr "ฉลองกันเถอะค่ะ!" with vpunch

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:528
translate english arc2_quest5_after_sarada_battle_6e9085ca:

    # sk "*ejem* Pero sin Alcohol..."
    sk "*แฮ่ม* แต่ห้ามมีแอลกอฮอล์นะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:530
translate english arc2_quest5_after_sarada_battle_b974bdc1:

    # mn "Si, claro jaja..."
    mn "ครับ แน่นอนอยู่แล้ว ฮ่าๆ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:533
translate english arc2_quest5_after_sarada_battle_29fb4c3d:

    # n "Después de que Sarada le mencionara la situación a Sakura"
    n "หลังจากที่ซาราดะเล่าสถานการณ์ให้ซากุระฟัง"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:534
translate english arc2_quest5_after_sarada_battle_6e9182ed:

    # n "Los tres se dirigieron hacia la conina para celebrar la cena para [MN]"
    n "ทั้งสามคนก็พากันไปที่ห้องครัวเพื่อเริ่มมื้อเย็นฉลองให้กับ [MN]"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:535
translate english arc2_quest5_after_sarada_battle_8abd793c:

    # n "Luego de unas cuantas horas platicando durante la cena, esta ha acabado, y [MN] está listo para irse"
    n "หลังจากนั่งคุยกันเพลินๆ ระหว่างทานมื้อเย็นอยู่หลายชั่วโมง งานเลี้ยงก็จบลง และ [MN] ก็พร้อมที่จะกลับแล้ว"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:545
translate english arc2_quest5_after_sarada_battle_aa8f7698:

    # mn "Aaah, esa fue una gran celebración"
    mn "อ่าห์ เป็นการฉลองที่ยอดเยี่ยมจริงๆ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:546
translate english arc2_quest5_after_sarada_battle_426284a4:

    # mn "Muchas gracias por invitarme Sarada, también gracias a tí por la comida Sakura"
    mn "ขอบคุณมากนะซาราดะที่ชวนมา แล้วก็ขอบคุณสำหรับอาหารด้วยนะครับซากุระ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:547
translate english arc2_quest5_after_sarada_battle_9e0080f9:

    # sk "Sin problema, sabes que {b}pase lo que pase{/a}, puedes contar conmigo"
    sk "ไม่เป็นไรหรอก ลูกก็รู้ว่า{b}ไม่ว่าจะเกิดอะไรขึ้น{/a} ก็พึ่งพาแม่ได้เสมอนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:548
translate english arc2_quest5_after_sarada_battle_ec349135:

    # sr "Igual conmigo, siempre estaré para tí [MN]"
    sr "ฉันก็เหมือนกัน ฉันจะคอยอยู่เคียงข้างเธอเสมอนะ [MN]"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:549
translate english arc2_quest5_after_sarada_battle_bd19c9a3:

    # mn "Muchas gracias... De verdad no sé lo que haría si no fuera por ustedes..."
    mn "ขอบคุณมากๆ นะ... ฉันไม่รู้จริงๆ ว่าจะทำยังไงถ้าไม่มีพวกเธอ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:551
translate english arc2_quest5_after_sarada_battle_6f78da45:

    # sr "Puedes agradecernoslo convirtiéndote en Chunin durante los próximos Exámenes"
    sr "งั้นก็ตอบแทนพวกเราด้วยการสอบให้ผ่านเป็นจูนินในการสอบที่กำลังจะถึงนี้สิคะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:554
translate english arc2_quest5_after_sarada_battle_277708c9:

    # mn "Jajaja, entonces así será"
    mn "ฮ่าๆๆ ถ้าอย่างนั้นก็เอาตามนี้เลย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:556
translate english arc2_quest5_after_sarada_battle_55adb1d4:

    # mn "Luego de todo el entrenamiento, estoy seguro que los pasaré"
    mn "หลังจากการฝึกทั้งหมดที่ผ่านมา ฉันมั่นใจว่าต้องผ่านแน่ๆ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:558
translate english arc2_quest5_after_sarada_battle_e9ba6d71:

    # mn "Pero, quería preguntarte algo"
    mn "แต่ว่า... ฉันมีเรื่องอยากจะถามหน่อยน่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:559
translate english arc2_quest5_after_sarada_battle_00aa1a00:

    # mn "Aún faltan unos días para los Exámenes, ¿Qué hago durante esos días?"
    mn "การสอบก็ยังเหลือเวลาอีกไม่กี่วัน ฉันควรทำอะไรดีล่ะในช่วงนั้น?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:562
translate english arc2_quest5_after_sarada_battle_1402140b:

    # sr "¿Qué más puede ser? {b}Descansar{/a}"
    sr "จะเป็นอะไรไปได้ล่ะคะ? {b}พักผ่อน{/a}ไงคะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:564
translate english arc2_quest5_after_sarada_battle_80b28595:

    # sr "El descanso y la relajación son cosas sumamente importantes también"
    sr "การพักผ่อนหย่อนใจก็เป็นเรื่องที่สำคัญมากๆ เหมือนกันนะคะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:567
translate english arc2_quest5_after_sarada_battle_e93627d6:

    # sr "Yo también me relajaré hasta entonces, entrenarte no fue una tarea fácil, estos últimos días fueron duros"
    sr "หนูก็จะพักผ่อนจนกว่าจะถึงตอนนั้นเหมือนกัน การฝึกให้เธอนี่ไม่ใช่เรื่องง่ายเลยนะ ช่วงนี้หนักหนาเอาการเลยล่ะค่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:569
translate english arc2_quest5_after_sarada_battle_cce8edf6:

    # mn "Lo siento jaja..."
    mn "ขอโทษทีนะ ฮ่าๆ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:573
translate english arc2_quest5_after_sarada_battle_0863d355:

    # sr "De hecho..."
    sr "อันที่จริงแล้ว..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:575
translate english arc2_quest5_after_sarada_battle_fdedd5c6:

    # sr "Se me ocurrió algo..."
    sr "หนูคิดอะไรดีๆ ออกล่ะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:576
translate english arc2_quest5_after_sarada_battle_2cc71f42:

    # sk "¿Qué cosa?"
    sk "อะไรเหรอจ๊ะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:579
translate english arc2_quest5_after_sarada_battle_26a0a2a3:

    # sr "Mamá, ¿Cuándo tienes tu día libre?" with dissolve1
    sr "แม่คะ วันหยุดของแม่คือวันไหนเหรอคะ?" with dissolve1

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:581
translate english arc2_quest5_after_sarada_battle_75ba1704:

    # sk "¿Mi día libre? El {b}Viernes{/a}, ¿Porqué preguntas?"
    sk "วันหยุดของฉันเหรอ? {b}วันศุกร์{/a}จ่ะ ถามทำไมเหรอ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:584
translate english arc2_quest5_after_sarada_battle_961d9c28:

    # sr "Entonces, si es así" with dissolve1
    sr "งั้นถ้าเป็นแบบนั้นล่ะก็" with dissolve1

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:586
translate english arc2_quest5_after_sarada_battle_150b108a:

    # sr "El Viernes podríamos ir a las {b}Aguas Termales{/a} para relajarnos un poco"
    sr "วันศุกร์นี้พวกเราไป {b}บ่อน้ำร้อน{/a} เพื่อผ่อนคลายกันหน่อยดีกว่า"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:588
translate english arc2_quest5_after_sarada_battle_a27eba40:

    # sr "Sería una buena forma de despejarnos después de tanto trabajo y preparar la mente antes de los Exámenes"
    sr "น่าจะเป็นวิธีที่ดีในการเคลียร์สมองหลังจากทำงานหนักมาตลอด และเป็นการเตรียมความพร้อมทางจิตใจก่อนสอบด้วยนะคะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:589
translate english arc2_quest5_after_sarada_battle_99d90c62:

    # mn "¿Las Aguas Termales? Suena... Interesante"
    mn "บ่อน้ำร้อนงั้นเหรอ? ฟังดู... น่าสนใจแฮะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:590
translate english arc2_quest5_after_sarada_battle_b0af553f:

    # sk "Mmm si, sería una buena forma de relajarse, y después de todo tu esfuerzo, definitivamente te lo mereces [MN]"
    sk "อืม ใช่แล้วล่ะจ่ะ น่าจะเป็นวิธีผ่อนคลายที่ดีนะ แล้วหลังจากความพยายามทั้งหมดที่ผ่านมา เธอก็สมควรได้รับมันแล้วล่ะจ่ะ [MN]"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:591
translate english arc2_quest5_after_sarada_battle_0fa59ea7:

    # mn "Entonces, ¡Está decidido! Iré con ustedes"
    mn "ถ้าอย่างนั้นก็ตกลงตามนี้! ผมจะไปด้วยครับ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:593
translate english arc2_quest5_after_sarada_battle_4de4e824:

    # sr "Así se habla!" with vpunch
    sr "เยี่ยมมาก แบบนั้นสิคะ!" with vpunch

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:595
translate english arc2_quest5_after_sarada_battle_8def00b3:

    # sr "Entonces ya está, te espero el Viernes aquí al {b}Media día{/a}, ¿Listo?"
    sr "งั้นก็ตามนี้นะ ฉันจะรอเธอตรงนี้วันศุกร์ตอน {b}เที่ยงวัน{/a} ตกลงไหม?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:602
translate english arc2_quest5_after_sarada_battle_9b2c6409:

    # n "Luego de planear el día en el que irán a las {b}Aguas Termales{/a}, [MN] se despide de Sakura y Sarada"
    n "หลังจากวางแผนวันที่จะไป {b}บ่อน้ำร้อน{/a} กันเรียบร้อย [MN] ก็กล่าวลาซากุระและซาราดะ"

# TODO: Translation updated at 2024-12-20 07:52

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:460
translate english arc2_quest5_after_sarada_battle_98ac9232:

    # sr "Pero cuando se encuentran con un enemigo más fuerte hasta ahí es que ven la realidad"
    sr "แต่พอต้องเผชิญหน้ากับศัตรูที่แข็งแกร่งกว่า นั่นแหละค่ะถึงจะได้เห็นความเป็นจริง"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest5_2.rpy:534
translate english arc2_quest5_after_sarada_battle_ff9c7e53:

    # n "Los tres se dirigieron hacia la cocina para celebrar la cena para [MN]"
    n "ทั้งสามคนมุ่งหน้าไปยังห้องครัวเพื่อร่วมฉลองมื้อค่ำให้แก่ [MN]"
