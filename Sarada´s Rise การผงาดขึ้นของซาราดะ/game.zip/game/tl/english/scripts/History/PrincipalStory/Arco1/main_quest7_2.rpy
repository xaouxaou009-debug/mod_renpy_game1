# TODO: Translation updated at 2024-03-04 17:48

# game/scripts/History/PrincipalStory/Arco1/main_quest7_2.rpy:5
translate english main_quest7_2_8bb1d30e:

    # n "[MN] vuelve a su Apatamento"
    n "[MN] กลับมาที่ห้องพักของเขา"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_2.rpy:11
translate english main_quest7_2_3f0be5d3:

    # mn "Aah, que satisfacción"
    mn "อ่า ช่างน่าพอใจจริงๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_2.rpy:13
translate english main_quest7_2_0c7349b6:

    # mn "Ya domino mejor el {b}Karugan{/a}"
    mn "ฉันควบคุม {b}คารูกัน{/a} ได้คล่องขึ้นแล้วล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_2.rpy:15
translate english main_quest7_2_ed3c41be:

    # mn "Aunque Sarada me dijo que entrenara... Y aún no lo uso en combate"
    mn "ถึงซาราดะจะบอกให้ฉันฝึก... แต่ฉันก็ยังไม่ได้เอาไปใช้ในการต่อสู้จริงอยู่ดี"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_2.rpy:18
translate english main_quest7_2_ba342187:

    # mn "Quizás ella pueda ayudarme, le preguntaré si puede ayudarme"
    mn "บางทีเธออาจจะช่วยฉันได้ ลองไปถามเธอหน่อยดีกว่า"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_2.rpy:39
translate english meditation_quest_3_d85199ec:

    # mn "Bien, aceptó a ayudarme"
    mn "เอาล่ะ เธอยอมช่วยฉันแล้ว"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_2.rpy:41
translate english meditation_quest_3_6af0a3d4:

    # mn "Ahora solo tengo que ir a buscarla por la noche"
    mn "ทีนี้ก็แค่ต้องไปหาเธอตอนกลางคืน"

