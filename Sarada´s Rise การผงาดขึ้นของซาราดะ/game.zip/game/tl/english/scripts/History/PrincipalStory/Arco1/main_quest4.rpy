# TODO: Translation updated at 2024-03-04 17:48

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:11
translate english main_quest4_f51f412f:

    # mn "Hideo, llegaste temprano"
    mn "ฮิเดโอะ นายมาเร็วจังนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:15
translate english main_quest4_78d3dd5c:

    # hd "¡[MN], Buenos días!"
    hd "[MN] อรุณสวัสดิ์!"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:18
translate english main_quest4_3ad2a4c0:

    # hd "¿Estás listo para la prueba de hoy?"
    hd "พร้อมสำหรับการทดสอบวันนี้รึยัง?"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:21
translate english main_quest4_f1301200:

    # mn "Si, aunque tengo algo de hambre"
    mn "อื้ม ถึงจะหิวอยู่นิดหน่อยก็เถอะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:24
translate english main_quest4_52f8af1f:

    # hd "Si, por eso traje un poco de comida para cuando terminemos la prueba"
    hd "นั่นสินะ งั้นฉันเลยเตรียมของกินไว้ให้ตอนที่เราสอบเสร็จยังไงล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:27
translate english main_quest4_600f565c:

    # mn "¿En serio?"
    mn "จริงเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:30
translate english main_quest4_cb1254e6:

    # hd "Sí, la preparó mi abuela, luce delicioso"
    hd "อื้ม คุณย่าเป็นคนทำเองเลยนะ ดูน่าอร่อยมากเลยล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:33
translate english main_quest4_ef34c737:

    # mn "Espero que Kakashi llegue pronto para poder comer lo antes posible"
    mn "หวังว่าคาคาชิจะมาถึงเร็ว ๆนี้นะ ฉันจะได้กินเร็ว ๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:36
translate english main_quest4_206c0ff8:

    # hd "Yo igual"
    hd "ฉันก็เหมือนกัน"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:39
translate english main_quest4_7703dc2e:

    # n "Un par de horas más tarde..."
    n "ผ่านไปสองสามชั่วโมงต่อมา..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:44
translate english main_quest4_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:45
translate english main_quest4_5dbc7d5a:

    # hd "..."
    hd "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:50
translate english main_quest4_ac87a660:

    # mn "¡Ahhhh!"
    mn "อ๊ากกกก!"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:52
translate english main_quest4_b04fe435:

    # mn "¡Ya no aguanto más!"
    mn "ฉันจะไม่ทนแล้วนะ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:57
translate english main_quest4_401632d6:

    # hd "¿Crees que se le habrá olvidado?"
    hd "นายว่าเขาจะลืมไปแล้วรึเปล่า?"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:61
translate english main_quest4_e98c1b31:

    # mn "¡¿Cómo pudo olvidar algo así? Nos dijo que viniéramos sin comer!"
    mn "จะลืมเรื่องแบบนั้นได้ยังไงกันเล่า! ก็เขาเป็นคนบอกให้เรามาแบบไม่ต้องกินอะไรมาไม่ใช่เหรอ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:64
translate english main_quest4_43595a7f:

    # hd "Yo también tengo hambre..."
    hd "ฉันก็หิวเหมือนกันนะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:66
translate english main_quest4_5dbc7d5a_1:

    # hd "..."
    hd "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:68
translate english main_quest4_80938a54:

    # hd "Tal vez... Podamos comer un poco"
    hd "งั้น... เรามากินอะไรกันสักหน่อยดีไหม"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:71
translate english main_quest4_89039fae:

    # hd "Para calmar levemente el hambre"
    hd "จะได้แก้หิวไปพลาง ๆ ก่อน"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:74
translate english main_quest4_6fe0cffc:

    # mn "¿Esa es la comida que te preparó tu abuela?"
    mn "นั่นอาหารที่ย่านายทำให้อย่างนั้นเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:77
translate english main_quest4_103455d3:

    # hd "Si, la comida de mi abuela es la mejor"
    hd "ใช้วิธีฝีมือย่าฉันเนี่ยอร่อยที่สุดแล้วล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:80
translate english main_quest4_6e5b2c4c:

    # mn "Bien, no perdamos el tiempo y empecemos a comer"
    mn "งั้นก็อย่าเสียเวลาเลย มากินกันเถอะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:83
translate english main_quest4_ed548e68:

    # hd "Sí, solo déjame sacar los..."
    hd "อื้ม เดี๋ยวขอหยิบ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:91
translate english main_quest4_420600cd:

    # hd "¿Palillos...?"
    hd "ตะเกียบ...?"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:93
translate english main_quest4_75e00ec4:

    # mn "¡AHHHHHHHHHH!"
    mn "อ๊ากกกกกกกก!"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:94
translate english main_quest4_2accdcf0:

    # kk "Vaya, parece que no siguieron mis instrucciones, les dije que sin desayunar"
    kk "โฮหก ดูเหมือนพวกเธอจะไม่ได้ทำตามคำสั่งสินะ ฉันบอกแล้วไงว่าห้ามกินมื้อเช้า"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:96
translate english main_quest4_09e41aeb:

    # hd "¿Q-Qué?"
    hd "อะ-อะไรนะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:104
translate english main_quest4_eab4dd60:

    # hd "¡[MN]!"
    hd "[MN]!"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:105
translate english main_quest4_fedd28f9:

    # kk "Querías que te entrenara, ¿no? Pues aquí va la primera lección"
    kk "อยากให้ฉันฝึกให้ไม่ใช่เหรอ? งั้นนี่คือบทเรียนแรก"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:106
translate english main_quest4_22589e8b:

    # kk "En el mundo de los ninjas, aquellos que rompen las reglas son escoria"
    kk "ในโลกนินจาน่ะ พวกที่แหกกฎมันก็แค่เศษสวะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:108
translate english main_quest4_334e51b6:

    # mn "(Fue tan rápido que ni siquiera logré alcanzar a verlo...)"
    mn "(เร็วจนมองตามไม่ทันเลยแฮะ...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:109
translate english main_quest4_dce69c11:

    # mn "(Así que este es el poder del sexto Hokage...)"
    mn "(นี่น่ะเหรอพลังของโฮคาเงะรุ่นที่หก...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:113
translate english main_quest4_becc4497:

    # mn "¡No es justo, pasamos toda la mañana esperándolo!"
    mn "มันไม่ยุติธรรมเลยนะ พวกเรานั่งรอนายมาทั้งเช้าเลยเนี่ย!"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:115
translate english main_quest4_f6e7cb13:

    # mn "¡¿Era necesario hacernos pasar hambre?!"
    mn "จำเป็นต้องให้พวกเราอดข้าวขนาดนี้เลยเหรอ?!"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:116
translate english main_quest4_92a31941:

    # kk "Estos jovenes de ahora..."
    kk "เฮ้อ วัยรุ่นสมัยนี้นี่นะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:117
translate english main_quest4_afedd2c6:

    # kk "Bien, será mejor que te tape la boca"
    kk "เอาเถอะ ฉันปิดปากเธอไว้ดีกว่า"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:119
translate english main_quest4_8d747278:

    # n "Kakashi le pone una cinta en la boca a [MN]"
    n "คาคาชิแปะเทปกาวที่ปากของ [MN]"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:122
translate english main_quest4_7afb71a2:

    # kk "No pensé que serías tan gritón"
    kk "ไม่คิดเลยว่าเธอจะเสียงดังขนาดนี้"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:123
translate english main_quest4_7ea0a054:

    # kk "Parecías ser como Sasuke, un engreído que no habla y se cree mejor que los demás..."
    kk "ฉันนึกว่าเธอจะเป็นแบบซาสึเกะ พวกหยิ่งยโสที่ไม่ค่อยพูดและคิดว่าตัวเองเก่งกว่าคนอื่นซะอีก..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:124
translate english main_quest4_4615d8c1:

    # kk "Pero te pareces más a Naruto, un idiota que no hace más que gritar"
    kk "แต่เธอดันเหมือนนารูโตะ พวกงี่เง่าที่เอาแต่โวยวายซะมากกว่า"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:125
translate english main_quest4_4e03a5a0:

    # kk "Si quieres comer, tendrás que esperar a que tu amigo te rescate"
    kk "ถ้าอยากกินข้าวล่ะก็ เธอต้องรอให้เพื่อนมาช่วยซะก่อนนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:126
translate english main_quest4_0dee026b:

    # kk "Oye, ¿Hideo te llamabas cierto?"
    kk "นี่ ฮิเดโอะ ชื่อนี้นี่ใช่ไหม?"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:127
translate english main_quest4_03531b8d:

    # kk "Tu prueba, será rescatar a [MN] antes del anochecer"
    kk "บททดสอบของเธอคือการช่วย [MN] ให้ได้ก่อนค่ำ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:129
translate english main_quest4_ab0b5075:

    # hd "¡¿Qué?!"
    hd "หาพ-!?"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:131
translate english main_quest4_1b103e70:

    # mn "(¡¿Qué?!)"
    mn "(บ้าน่า-!?)"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:133
translate english main_quest4_d36af545:

    # mn "(Maldita sea, me voy a morir de hambre...)"
    mn "(เวรเอ๊ย ฉันได้อดตายจริง ๆ แน่...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:135
translate english main_quest4_ed5066e1:

    # kk "Tendrás que hacerlo solo, por tu cuenta, sin ayuda de nadie"
    kk "เธอจะต้องทำมันคนเดียว ด้วยกำลังของตัวเอง โดยไม่ให้ใครช่วย"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:141
translate english main_quest4_c9b681e5:

    # hd "¿Por mí cuenta?"
    hd "คนเดียวเหรอครับ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:143
translate english main_quest4_36ad2235:

    # kk "¿Estás sordo? No creo que haga falta repetirlo..."
    kk "หูหนวกหรือไง? คิดว่าคงไม่ต้องให้พูดซ้ำหรอกนะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:144
translate english main_quest4_2d505aaf:

    # kk "Sí no puedes hacer eso, rindete ahora y lo soltaré en este instante"
    kk "ถ้าทำไม่ได้ก็ยอมแพ้ซะตั้งแต่ตอนนี้ แล้วฉันจะปล่อยเธอไปเดี๋ยวนี้แหละ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:146
translate english main_quest4_3f948393:

    # mn "(¡No lo hagas, Hideo!)"
    mn "(อย่าไปยอมนะ ฮิเดโอะ!)"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:147
translate english main_quest4_49810617:

    # mn "(¡Si lo haces no te entrenará, sé que puedes hacerlo!)"
    mn "(ถ้าทำแบบนั้นเขาจะไม่ยอมฝึกให้นะ ฉันรู้ว่านายทำได้อยู่แล้ว!)"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:149
translate english main_quest4_1fba1318:

    # hd "[MN]..."
    hd "[MN]..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:150
translate english main_quest4_70075202:

    # kk "¿Y bien?"
    kk "ว่าไงล่ะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:151
translate english main_quest4_a08cf881:

    # kk "¿Que harás?"
    kk "นายจะเอายังไงล่ะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:152
translate english main_quest4_5dbc7d5a_2:

    # hd "..."
    hd "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:154
translate english main_quest4_34e959e3:

    # hd "¡Maldición!"
    hd "โธ่เว้ย!"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:171
translate english main_quest4_60807203:

    # kk "¿Una Bomba de humo?"
    kk "ระเบิดควันงั้นเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:173
translate english main_quest4_329b3be2:

    # kk "No se lanzó directo al combate, es bueno saber que tiene algo de cerebro"
    kk "ไม่พุ่งเข้ามาสู้ตรง ๆ สินะ อย่างน้อยก็รู้ว่ารู้จักใช้สมองอยู่บ้าง"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:175
translate english main_quest4_625782a5:

    # kk "Ven, veamos qué hace tu amigo"
    kk "มาเถอะ ไปดูกันดีกว่าว่าเพื่อนของเธอทำอะไรอยู่"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:194
translate english main_quest4_86d8296c:

    # hd "(Logré esconderme con la ayuda del humo)"
    hd "(ฉันหนีซ่อนตัวได้ทันด้วยควันพรางตา)"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:196
translate english main_quest4_951f46d6:

    # hd "(Maldita sea, ¿Cómo se supone que voy a rescatar a [MN] del Sexto Hokage?)"
    hd "(เวรเอ๊ย ฉันจะไปช่วย [MN] จากท่านโฮคาเงะรุ่นที่หกได้ยังไงเนี่ย?)"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:198
translate english main_quest4_2108e093:

    # hd "(Es absurdo, hay una gran diferencia entre nosotros)"
    hd "(มันไร้สาระสิ้นดี พลังของเรามันต่างกันฟ้ากับเหวเลยนะ)"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:200
translate english main_quest4_bd7a0ce4:

    # hd "(Aaah...)"
    hd "(โธ่เว้ย...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:202
translate english main_quest4_3e23e0cd:

    # hd "(Maldita sea, cálmate Hideo... Concentrate en la prueba)"
    hd "(ตั้งสติไว้สิ ฮิเดโอะ...กู้อารมณ์แล้วโฟกัสกับการทดสอบนี่ซะ)"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:203
translate english main_quest4_e12ce767:

    # hd "(Primero... Necesito encontrarlo y planear mi siguiente ataque)"
    hd "(อย่างแรก... ฉันต้องหาตัวเขาก่อนแล้วค่อยวางแผนโจมตีในขั้นตอนต่อไป)"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:204
translate english main_quest4_49beb28e:

    # hd "(No tengo que derrotarlo, solo tengo que rescatar a [MN]...)"
    hd "(ฉันไม่ได้ต้องเอาชนะเขา แค่ต้องช่วย [MN] ออกมาให้ได้...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:206
translate english main_quest4_986af292:

    # hd "(Del sexto Hokage...)"
    hd "(จากท่านโฮคาเงะรุ่นที่หกเนี่ยนะ...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:208
translate english main_quest4_5dbc7d5a_3:

    # hd "..."
    hd "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:210
translate english main_quest4_c6ca2143:

    # hd "Aaah, esto será difícil..."
    hd "โธ่เว้ย งานนี้ไม่ง่ายเลย..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:212
translate english main_quest4_5afb76e9:

    # n "Al anochecer..."
    n "ยามพลบค่ำ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:222
translate english main_quest4_d1336a02:

    # kk "Ya se está haciendo de noche..."
    kk "เริ่มจะมืดแล้วนะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:224
translate english main_quest4_d6456588:

    # kk "¿Se habrá dado por vencido?"
    kk "ยอมแพ้ไปแล้วรึเปล่าเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:226
translate english main_quest4_d97b39b8:

    # kk "¿O aún no nos ha encontrado?"
    kk "หรือว่ายังหาพวกเราไม่เจอซะที?"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:228
translate english main_quest4_e3e5cd2a:

    # kk "De ser eso, sus habilidades rastreando son muy malas..."
    kk "ถ้าเป็นแบบนั้นจริง ทักษะการสะกดรอยตามของหมอนี่คงแย่สุด ๆ เลยสินะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:230
translate english main_quest4_32462c4b_1:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:232
translate english main_quest4_ff07a8f6:

    # mn "(No aguanto el hambre...)"
    mn "(ฉันจะทนความหิวไม่ไหวอยู่แล้ว...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:233
translate english main_quest4_3429ba79:

    # mn "(Apresúrate Hideo... Me muero de hambre...)"
    mn "(รีบหน่อยสิฮิเดโอะ... ฉันจะหิวตายอยู่แล้วนะ...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:236
translate english main_quest4_32edcc21:

    # kk "¿Qué tal tú? Seguro tienes muchas cosas que decir"
    kk "แล้วเธอล่ะ? คงจะมีเรื่องอยากพูดตั้งเยอะแยะเลยสินะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:237
translate english main_quest4_dd35c3e3:

    # kk "Lamento haberte metido en este lío, pero esto es una lección para ambos"
    kk "ฉันต้องขอโทษด้วยที่ลากเธอเข้ามาพัวพันกับเรื่องยุ่ง ๆ นี้ แต่ถือซะว่านี่คือบทเรียนสำหรับพวกเราทั้งคู่ก็แล้วกัน"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:239
translate english main_quest4_32462c4b_2:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:241
translate english main_quest4_a7aef972:

    # kk "No me mires así... Te quitaría eso de la boca, pero gritas mucho..."
    kk "อย่ามามองฉันด้วยสายตาแบบนั้นเลย... จริง ๆ ฉันอยากจะแกะไอ้นี่ออกจากปากเธออยู่หรอกนะ แต่เธอชอบโวยวายเสียงดังซะเหลือเกิน..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:245
translate english main_quest4_88e0fcdc:

    # mn "(Genial, ahora tengo fama de gritón...)"
    mn "(เยี่ยม ตอนนี้ฉันกลายเป็นคนชอบโวยวายไปซะแล้วสิ...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:247
translate english main_quest4_3cb08d19:

    # mn "(Vamos Hideo, ¿Dónde estás...?)"
    mn "(เร็วเข้าสิฮิเดโอะ นายอยู่ที่ไหนเนี่ย...?)"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:249
translate english main_quest4_a717e4b1:

    # kk "¿Hmm?"
    kk "หืม?"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:250
translate english main_quest4_b058753e:

    # kk "Vaya, parece que por fin logró encontrarnos"
    kk "โอ้ ดูเหมือนว่าในที่สุดเขาจะหาพวกเราเจอแล้วแฮะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:257
translate english main_quest4_2fcb3ef9:

    # hd "¡[MN]! ¡Te encontré!"
    hd "[MN]! ฉันเจอตัวเธอแล้ว!"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:259
translate english main_quest4_3b1c111a:

    # kk "Genial, avísale al enemigo dónde estás"
    kk "เยี่ยมไปเลย ประกาศให้ศัตรูรู้พิกัดของตัวเองซะงั้น"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:260
translate english main_quest4_1e221e9e:

    # kk "No eres muy listo, ¿Cierto?"
    kk "ดูท่าทางนายจะไม่ค่อยฉลาดเท่าไหร่เลยสินะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:262
translate english main_quest4_aee89219:

    # hd "Tch..."
    hd "ชิ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:264
translate english main_quest4_e991f3d1:

    # hd "No me caracterizo por saber una gran variedad de jutsus"
    hd "ฉันไม่ใช่พวกที่มีคาถาหลากหลายอะไรนักหรอก"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:266
translate english main_quest4_65b22417:

    # hd "Pero..."
    hd "แต่ว่า..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:268
translate english main_quest4_b212794a:

    # hd "Me alegra dominar este"
    hd "โชคดีจริงๆ ที่ฉันฝึกคาถานี้จนเชี่ยวชาญ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:285
translate english main_quest4_bbef39a3:

    # hd "¡Jutsu clones de sombra!"
    hd "คาถาแยกเงาร่าง!"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:288
translate english main_quest4_0fd65ed8:

    # kk "Vaya, esto me trae recuerdos..."
    kk "โอ้โห ชวนให้คิดถึงความหลังจริงๆ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:289
translate english main_quest4_79748f2b:

    # kk "Jutsu clones de sombra"
    kk "คาถาแยกเงาร่างสินะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:291
translate english main_quest4_5e9c7368:

    # hd1 "Disculpa la tardanza, [MN]"
    hd1 "ขอโทษที่มาช้านะ [MN]"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:294
translate english main_quest4_bc009e1b:

    # hd2 "La verdad soy un asco rastreando..."
    hd2 "เอาเข้าจริงแล้ว... ฉันเนี่ยสะกดรอยตามห่วยแตกสุดๆ เลยล่ะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:296
translate english main_quest4_e432b086:

    # kk "Ya lo veo..."
    kk "งั้นเหรอ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:298
translate english main_quest4_51e6e554:

    # hd "Tch"
    hd "ชิ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:302
translate english main_quest4_2a673411:

    # hd "¡Tome esto!"
    hd "รับนี่ไปซะ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:313
translate english main_quest4_6141228a:

    # kk "..."
    kk "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:316
translate english main_quest4_11a6600f:

    # kk "Aaah... ¿Qué hice para merecerme esto?"
    kk "อ๊า... ฉันไปทำอะไรให้ถึงต้องมาเจอเรื่องแบบนี้เนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:318
translate english main_quest4_8afa9288:

    # hd "¡Maldición, fallé!"
    hd "เวรเอ๊ย พลาดซะได้!"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:320
translate english main_quest4_986a50f9:

    # mn "(Tengo hambre...)"
    mn "(หิวจังเลย...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:323
translate english main_quest4_5e0aa74f:

    # kk "Parece que rastrear no es lo único que se te da mal..."
    kk "ดูท่าการสะกดรอยจะไม่ใช่สิ่งเดียวที่นายทำได้แย่สินะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:324
translate english main_quest4_f63552d8:

    # kk "Un ataque a distancia es lo más logico cuando tu enemigo está a una gran distancia... Pero..."
    kk "การโจมตีระยะไกลเป็นสิ่งที่สมเหตุสมผลที่สุดเวลาที่ศัตรูอยู่ห่างออกไปมาก... แต่ว่านะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:325
translate english main_quest4_64c0e38e:

    # kk "Lamento decirte que si no puedes atinar un Kunai, de ninguna forma eso funcionará"
    kk "ต้องขอโทษด้วยนะที่ต้องบอกว่า แค่ขว้างคุนะจายให้โดนยังทำไม่ได้ วิธีนั้นไม่มีทางได้ผลหรอก"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:327
translate english main_quest4_f530ac6f:

    # kk "Veamos como luchas cuerpo a cuerpo"
    kk "งั้นมาดูกันหน่อยซิว่าเวลาสู้มือเปล่านายน่ะฝีมือแคไหน"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:343
translate english main_quest4_5dbc7d5a_4:

    # hd "..."
    hd "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:344
translate english main_quest4_033bc974:

    # kk "Tuviste todo el día para planear algo..."
    kk "นายน่ะมีเวลาทั้งวันในการวางแผนแท้ๆ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:345
translate english main_quest4_3879a9ca:

    # kk "Sí esto es lo mejor que puedes hacer, no vale la pena que te entrene"
    kk "ถ้าฝีมือทำได้แค่นี้ ก็ไม่เห็นคุ้มค่าที่จะเสียเวลาฝึกให้เลยนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:347
translate english main_quest4_0557006e:

    # hd1 "Yo no estaría tan seguro"
    hd1 "อย่าเพิ่งด่วนสรุปแบบนั้นสิครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:363
translate english main_quest4_3f7be878:

    # kk "¿Q-Qué?"
    kk "อ-อะไรกัน?"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:364
translate english main_quest4_ce739e49:

    # kk "¿Los tres eran clones?"
    kk "นี่พวกมันเป็นร่างโคลนกันหมดเลยงั้นเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:366
translate english main_quest4_a443c90e:

    # kk "¿Y el original dónde...?"
    kk "แล้วตัวจริงมันไปอยู่ไหนกัน...?"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:367
translate english main_quest4_42662d00:

    # hd "Kakashi-Sensei..."
    hd "คุณครูคาคาชิ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:377
translate english main_quest4_d87b9c61:

    # hd "Sí... No se equivocó al decir que tuve todo el día para planear algo"
    hd "ใช่แล้วล่ะครับ... ที่คุณบอกว่าผมมีเวลาทั้งวันในการวางแผนน่ะ ไม่ผิดเลยสักนิด"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:379
translate english main_quest4_b376c475:

    # hd "Si planeé una estrategia"
    hd "ใช่แล้ว ผมวางแผนกลยุทธ์เอาไว้ต่างหากล่ะครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:381
translate english main_quest4_6cface1a:

    # kk "En ese momento..."
    kk "งั้นก็หมายความว่าตอนนั้น..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:382
translate english main_quest4_1a1c1501:

    # kk "El Kunai que fallaste... Eras tú"
    kk "คุนายที่คุณปาพลาดไปเมื่อกี้... จริงๆ แล้วคือนายเองสินะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:393
translate english main_quest4_6e5aa121:

    # hd "Si, tenía que esperar el momento perfecto para deshacer la transformación"
    hd "ใช่ครับ ผมต้องรอจังหวะที่เหมาะสมที่สุดเพื่อคลายคาถาร่างแปลงออกน่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:395
translate english main_quest4_81295307:

    # hd "Cuando bajó del árbol fue el momento perfecto"
    hd "เพราะงั้น ตอนที่คุณกระโดดลงมาจากต้นไม้ เลยเป็นจังหวะที่เหมาะที่สุดสินะครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:399
translate english main_quest4_d38d68eb:

    # mn "Eso fue increíble Fideo..."
    mn "สุดยอดไปเลย 'ฟิเดโอ'..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:401
translate english main_quest4_77b06075:

    # mn "Ahora vamos a comer Ramen..."
    mn "งั้นตอนนี้ไปกินราเม็งกันเถอะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:405
translate english main_quest4_ebeb100a:

    # hd "¿Fideo?"
    hd "ฟิเดโอ? เหมือนเส้นบะหมี่เนี่ยนะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:407
translate english main_quest4_e3eea583:

    # kk "(Lo hizo igual que lo hizo él...)"
    kk "(เจ้าเด็กนี่... ทำแบบเดียวกับหมอนั่นเปี๊ยบเลย...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:409
translate english main_quest4_be2cf419:

    # kk "(Aah, ¿Cómo pude caer con ese movimiento?)"
    kk "(ให้ตายสิ ฉันพลาดท่าให้กับลูกเล่นแบบนั้นได้ยังไงกัน?)"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:413
translate english main_quest4_e45cbb3a:

    # kk "Muy bien, parece ser que superaste mi prueba"
    kk "ทำได้ดีมาก ดูเหมือนว่าพวกเธอจะผ่านบททดสอบของฉันแล้วล่ะนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:414
translate english main_quest4_031dd8fd:

    # kk "En el mundo ninja, aquellos que rompen las reglas son escoria"
    kk "ในโลกนินจาน่ะ คนที่ไม่ยอมทำตามกฎระเบียบคือพวกสวะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:415
translate english main_quest4_67100751:

    # kk "Pero aquellos que abandonan a un amigo, son peor que escoria"
    kk "แต่ว่าคน 3 คนที่ทิ้งเพื่อนร่วมทีม ยิ่งกว่าพวกสวะซะอีก"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:416
translate english main_quest4_951a88f2:

    # kk "Bien hecho chicos"
    kk "ทำได้ดีมากพวกนาย"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:418
translate english main_quest4_634b3a7c:

    # hd "Muchas gracias"
    hd "ขอบคุณมากครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:422
translate english main_quest4_bf152bdd:

    # mn "Oigan... ¿Ya podemos ir a comer?"
    mn "นี่... พวกเราไปหาอะไรกินกันได้รึยัง?"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:424
translate english main_quest4_fc53f65e:

    # mn "Me muero de hambre..."
    mn "ฉันหิวจนไส้จะขาดอยู่แล้วเนี่ย..."

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:427
translate english main_quest4_aa609ee7:

    # kk "Claro, se lo ganaron"
    kk "ได้สิ พวกเธอสมควรได้รับมันแล้วล่ะนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:428
translate english main_quest4_b64bae5e:

    # kk "Vamos a comer a Ichiraku"
    kk "ไปกินราเม็งอิจิราคุร้านโปรดกันเถอะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:433
translate english main_quest4_97b30126:

    # mn "Justo ahora me comería todo lo que haya en la tienda"
    mn "ตอนนี้ฉันกินได้หมดร้านเลยล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:437
translate english main_quest4_8fccad84:

    # n "Luego de la prueba, [MN], Kakashi y Hideo van a comer a Ichiraku Ramen"
    n "หลังจากการทดสอบสิ้นสุดลง [MN], คาคาชิ และฮิเดโอะ ก็พากันไปกินราเม็งอิจิราคุ"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:438
translate english main_quest4_9d6156f1:

    # n "Pero justo antes de terminar de comer, Kakashi se va desapercibido, y le tocó pagar a Hideo toda la comida"
    n "แต่ทว่าก่อนที่เราจะกินเสร็จกันไม่นาน คาคาชิก็แอบปลีกตัวออกไปโดยไม่มีใครทันสังเกต และสุดท้ายก็ตกเป็นภาระของฮิเดโอะที่ต้องเป็นคนจ่ายค่าอาหารทั้งหมด"

# game/scripts/History/PrincipalStory/Arco1/main_quest4.rpy:439
translate english main_quest4_c02b6d07:

    # kk "Yo no dije que pagaría la cuenta"
    kk "ผมไม่ได้บอกสักหน่อยว่าจะเลี้ยงมื้อนี้น่ะ"
