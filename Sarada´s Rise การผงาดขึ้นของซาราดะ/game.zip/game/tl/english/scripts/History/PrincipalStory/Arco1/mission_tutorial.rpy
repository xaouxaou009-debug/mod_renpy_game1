

# game/scripts/History/PrincipalStory/Arco1/mission_tutorial.rpy:12
translate english arc1_mission_tutorial_8cf5d484:

    # mn "Buen día señor séptimo"
    mn "อรุณสวัสดิ์ครับท่านโฮคาเงะรุ่นที่ 7"

# game/scripts/History/PrincipalStory/Arco1/mission_tutorial.rpy:15
translate english arc1_mission_tutorial_eb8eacee:

    # nt "[MN], buen día"
    nt "[MN] อรุณสวัสดิ์"

# game/scripts/History/PrincipalStory/Arco1/mission_tutorial.rpy:17
translate english arc1_mission_tutorial_1213aa3e:

    # nt "Recibí el informe de Sarada, Es impactante darte cuenta de tanta información de golpe"
    nt "ฉันได้รับรายงานของซาราดะแล้วล่ะ พอรู้ข้อมูลอะไรเยอะแยะพร้อมกันทีเดียวแบบนี้ก็น่าตกใจอยู่เหมือนกันนะ"

# game/scripts/History/PrincipalStory/Arco1/mission_tutorial.rpy:19
translate english arc1_mission_tutorial_2790bcb0:

    # nt "¿Te sientes bien?"
    nt "ไหวไหมเนี่ยเธอ?"

# game/scripts/History/PrincipalStory/Arco1/mission_tutorial.rpy:22
translate english arc1_mission_tutorial_65a71e78:

    # mn "Oh, sí, ya no se preocupe por eso, ya lo estoy llevando de mejor manera"
    mn "อ๋อ ครับ ไม่ต้องเป็นห่วงหรอกครับ ตอนนี้ผมจัดการความรู้สึกได้ดีขึ้นแล้วล่ะ"

# game/scripts/History/PrincipalStory/Arco1/mission_tutorial.rpy:25
translate english arc1_mission_tutorial_924f1783:

    # nt "Me alegra oír eso, ¿Y a qué debo la visita de hoy?"
    nt "ได้ยินอย่างนั้นก็โล่งใจ แล้ววันนี้มีธุระอะไรถึงมาหาฉันล่ะเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/mission_tutorial.rpy:27
translate english arc1_mission_tutorial_e5d29e96:

    # nt "¿Te sientes preparado a tomar misiones de mayor rango?"
    nt "รู้สึกว่าพร้อมจะรับภารกิจระดับที่สูงขึ้นแล้วหรือยัง?"

# game/scripts/History/PrincipalStory/Arco1/mission_tutorial.rpy:30
translate english arc1_mission_tutorial_f392770d:

    # mn "Jaja, realmente no lo creo señor séptimo"
    mn "ฮ่าๆ ผมยังไม่ค่อยมั่นใจเลยครับท่านโฮคาเงะรุ่นที่ 7"

# game/scripts/History/PrincipalStory/Arco1/mission_tutorial.rpy:32
translate english arc1_mission_tutorial_67ea68b0:

    # mn "Quiero ir despacio, quiero dominar mejor este nuevo Dojutsu"
    mn "ผมอยากค่อยเป็นค่อยไปมากกว่า อยากฝึกเนตรวิญญาณอันใหม่นี่ให้คล่องกว่านี้ก่อนครับ"

# game/scripts/History/PrincipalStory/Arco1/mission_tutorial.rpy:35
translate english arc1_mission_tutorial_90e4ae9f:

    # nt "Entiendo..."
    nt "งั้นเหรอ..."

# game/scripts/History/PrincipalStory/Arco1/mission_tutorial.rpy:37
translate english arc1_mission_tutorial_28a2a421:

    # nt "Bueno, tómate tu tiempo, no hay prisa de cualquier manera"
    nt "งั้นก็ค่อยเป็นค่อยไปเถอะ ไม่รีบหรอกน่า"

# game/scripts/History/PrincipalStory/Arco1/mission_tutorial.rpy:40
translate english arc1_mission_tutorial_dedf4f11:

    # nt "Ya sabes qué tienes que hacer si quieres tomar una misión"
    nt "เธอรู้อยู่แล้วนี่นะว่าต้องทำยังไงถ้าอยากจะรับภารกิจ"
