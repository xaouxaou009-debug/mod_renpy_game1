# TODO: Translation updated at 2024-03-04 17:48

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:5
translate english main_quest7_e9f34fac:

    # mn "Buenos días, Sa..."
    mn "อรุณสวัสดิ์ ซา..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:9
translate english main_quest7_24b0962b:

    # mn "¡¿S-Sarada?!"
    mn "ซ-ซาราดะงั้นเหรอ?!"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:10
translate english main_quest7_a828305d:

    # sr "Oh, [MN], me alegra verte hoy"
    sr "อ้าว [MN] ดีจังเลยนะที่ได้เจอคุณวันนี้"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:11
translate english main_quest7_8a12ff89:

    # mn "¿Q-Qué haces?"
    mn "ท-ทำอะไรอยู่เหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:12
translate english main_quest7_5f80d738:

    # sr "Solo me estoy estirando un poco"
    sr "ฉันแค่วอร์มร่างกายอยู่นิดหน่อยน่ะค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:13
translate english main_quest7_ae24f568:

    # sr "Ya acabé mi entrenamiento, acostumbro a hacer estiramientos luego del entrenamento"
    sr "ฉันฝึกเสร็จเรียบร้อยแล้ว ปกติหลังฝึกเสร็จฉันก็มักจะยืดเส้นยืดสายนี่แหละค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:14
translate english main_quest7_e657c59e:

    # sr "Deberías hacerlo de vez en cuando"
    sr "คุณเองก็น่าจะลองทำดูบ้างนะคะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:15
translate english main_quest7_5077c859:

    # mn "S-Si... Intentaré hacerlo..."
    mn "ค-ครับ... เดี๋ยวจะลองทำดูนะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:16
translate english main_quest7_c70b9d37:

    # mn "(Atesoraré esta imagen mental toda mi vida...)"
    mn "(ฉันจะจดจำภาพนี้ไว้ในความทรงจำไปตลอดชีวิตเลย...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:17
translate english main_quest7_7c4c5f4f:

    # sr "Oye..."
    sr "นี่..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:18
translate english main_quest7_a22f8646:

    # sr "¿Me podrías, ayudar a levantarme...?"
    sr "ช่วยพยุงฉันลุกขึ้นหน่อยได้ไหมคะ...?"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:19
translate english main_quest7_114dd07c:

    # mn "Oh, si claro"
    mn "อ๋อ ได้สิ แน่นอนอยู่แล้ว"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:21
translate english main_quest7_714ba873:

    # n "[MN] ayuda a Sarada a levantarse"
    n "[MN] ช่วยพยุงซาราดะลุกขึ้น"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:29
translate english main_quest7_0eb21eb5:

    # sr "Hoy llegaste justo a tiempo, te estaba esperando"
    sr "วันนี้คุณมาตรงเวลาพอดีเลย ฉันกำลังรออยู่เลยค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:31
translate english main_quest7_b0c74d4a:

    # sr "Hoy vamos a investigar tu {b}Karugan{/a}"
    sr "วันนี้เราจะไปตรวจสอบ {b}คารูกัน{/a} ของคุณกันค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:33
translate english main_quest7_5220124d:

    # sr "Primero explícame más o menos como lo has activado"
    sr "ก่อนอื่นช่วยอธิบายคร่าวๆ ให้ฉันฟังหน่อยได้ไหมคะว่าคุณเปิดใช้งานมันยังไง"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:36
translate english main_quest7_6a140397:

    # mn "La primera vez que lo hice fue de manera inconsciente"
    mn "ครั้งแรกที่ผมทำมันโดยไม่รู้ตัวน่ะครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:39
translate english main_quest7_32e6f068:

    # mn "La segunda vez fue en un entrenamiento que organizó Zubon-Sensei"
    mn "ส่วนครั้งที่สองเกิดขึ้นระหว่างการฝึกที่ซูบงเซนเซย์จัดขึ้นครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:41
translate english main_quest7_cc1c2004:

    # mn "Simplemente pasa por así decirlo..."
    mn "พูดง่ายๆ คือมันเกิดขึ้นเองน่ะครับ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:43
translate english main_quest7_4433661e:

    # mn "Hace no mucho intenté activarlo, y pude hacerlo pero me costó mucho"
    mn "เมื่อไม่นานมานี้ผมลองพยายามเปิดใช้งานมันดู แล้วก็ทำได้นะ แต่ว่ามันยากมากๆ เลยล่ะครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:45
translate english main_quest7_e5904be0:

    # mn "Además de que fue por un muy breve período de tiempo"
    mn "แถมมันยังอยู่ได้แค่แป๊บเดียวเองด้วยครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:48
translate english main_quest7_71507e0b:

    # sr "Hmm, no sé si ayude de mucho saber esto, pero como ambos son Dojutsus tal vez la forma de activarlo sea similar"
    sr "อืม ฉันก็ไม่รู้หรอกนะว่าการรู้นี้จะช่วยได้มากแค่ไหน แต่เนื่องจากพวกมันเป็นเนตรวิชาเหมือนกัน บางทีวิธีเปิดใช้อาจจะคล้ายกันก็ได้ค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:51
translate english main_quest7_7f8b9229:

    # mn "¿A qué te refieres?"
    mn "หมายความว่ายังไงเหรอครับ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:54
translate english main_quest7_68a7f428:

    # sr "El Sharingan está fuertemente relacionado con las emociones del usuario"
    sr "เนตรวงแหวนมีความเกี่ยวข้องอย่างมากกับอารมณ์ของผู้ใช้ค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:56
translate english main_quest7_9393a86e:

    # sr "En este caso para activar el Sharingan no basta simplemente con desearlo"
    sr "ในกรณีนี้ การจะเบิกเนตรวงแหวนได้ แค่เพียงนึกอยากจะใช้มันเฉยๆ น่ะไม่พอหรอค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:58
translate english main_quest7_8cc4e5c2:

    # sr "Tienes que sentirlo..."
    sr "คุณต้องรู้สึกถึงมัน..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:61
translate english main_quest7_f8ea57f8:

    # mn "¿Sentirlo?"
    mn "รู้สึกถึงมันเหรอครับ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:64
translate english main_quest7_6df3e614:

    # sr "¿Recuerdas lo que sentías cuando activaste el karugan?"
    sr "คุณจำได้ไหมคะว่าตอนที่เปิดใช้งานคารูกัน คุณรู้สึกยังไงบ้าง?"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:66
translate english main_quest7_6a7b1dfa:

    # mn "Mmm..."
    mn "อืม..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:68
translate english main_quest7_b506ea8d:

    # mn "Sí, de hecho..."
    mn "ถ้าจะให้พูดล่ะก็..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:70
translate english main_quest7_b0a65455:

    # mn "Recuerdo que en ambas ocasiones sentía... ¿Ansiedad?"
    mn "จำได้ว่าทั้งสองครั้งที่ใช้ ผมรู้สึก... เหมือนมีความวิตกกังวลล่ะมั้งครับ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:72
translate english main_quest7_96cab9f3:

    # mn "Como unas ganas muy fuerdes de desaparecer, de ocultarme"
    mn "เหมือนมีความรู้สึกอยากจะหายตัวไป อยากจะซ่อนตัวอยู่ข้างในลึกๆ น่ะครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:75
translate english main_quest7_fc646f69:

    # sr "¿De ocultarte?"
    sr "อยากจะซ่อนตัวงั้นเหรอคะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:77
translate english main_quest7_f1b6492b:

    # sr "Me dijiste que la primera vez que lo activaste fue al despertar"
    sr "คุณเคยบอกฉันนี่คะว่าครั้งแรกที่คุณเปิดใช้งานมันคือตอนที่คุณตื่นนอนขึ้นมา"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:79
translate english main_quest7_d0b28c44:

    # mn "Ah... Sobre eso..."
    mn "อ่า... เรื่องนั้น..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:81
translate english main_quest7_9dd607f6:

    # mn "Mentí... jeje"
    mn "ผมโกหกน่ะครับ... แหะๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:84
translate english main_quest7_b25e980c:

    # sr "¿Qué, por qué?"
    sr "อะไรนะ ทำไมล่ะคะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:88
translate english main_quest7_4cf408ad:

    # mn "(Mierda, yo y mi bocota)"
    mn "(ซวยแล้ว ปากพาซวยแท้ๆ เลยเรา)"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:89
translate english main_quest7_7fa9b651:

    # mn "(Tendré que improvisar algo, no puedo decirle que pasó cuando Sakura estaba borracha y semi-desnuda)"
    mn "(คงต้องหาเรื่องแก้ตัวไปน้ำขุ่นๆ แล้วล่ะ จะบอกความจริงเรื่องที่ซากุระซังเมาแล้วเกือบเปลือยไม่ได้เด็ดขาด)"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:92
translate english main_quest7_cbbc039c:

    # mn "Verás..."
    mn "คืออย่างนี้นะครับ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:94
translate english main_quest7_66e5bb71:

    # mn "Al despertar salí al balcón"
    mn "พอตื่นนอนปุ๊บ ผมก็เดินออกไปที่ระเบียงปั๊บเลยล่ะครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:96
translate english main_quest7_87c74e5e:

    # mn "Y no recordaba que estaba desnudo..."
    mn "แล้วก็ดันลืมไปซะสนิทเลยว่าตัวเองไม่ได้ใส่อะไรอยู่..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:99
translate english main_quest7_91ba4314:

    # sr "¿Qué? Jajajajaja"
    sr "หา? ฮ่าๆๆๆๆๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:101
translate english main_quest7_ab0a9df1:

    # sr "Con razón no quisiste decirme la verdad jaja"
    sr "มิน่าล่ะ คุณถึงไม่ยอมบอกความจริง ฮ่าๆๆๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:104
translate english main_quest7_91798be7:

    # mn "Oye, es vergonzoso"
    mn "โธ่ มันน่าอายออกจะตายไปนะคร้าบ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:107
translate english main_quest7_ef46dd38:

    # sr "Jajaja de solo imaginarme tu cara hace que me duela el estomago"
    sr "ฮ่าๆๆๆ แค่นึกภาพหน้าของคุณ ฉันก็ปวดท้องไปหมดแล้วเนี่ย"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:110
translate english main_quest7_d665182e:

    # mn "(De hecho... Sería algo que podría pasarme perfectamente)"
    mn "(เอาเข้าจริง... เรื่องแบบนี้มันก็อาจจะเกิดขึ้นกับฉันได้เหมือนกันแฮะ)"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:114
translate english main_quest7_3914233f:

    # sr "Bueno, prueba con eso"
    sr "งั้นก็ลองวิธีนั้นดูสคะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:116
translate english main_quest7_da0f5061:

    # sr "Por ahora intenta recordar esa situación"
    sr "ตอนนี้ลองพยายามนึกถึงสถานการณ์ตอนนั้นดูนะคะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:118
translate english main_quest7_3094d404:

    # sr "De esa forma podrás acostumbrar a tu cuerpo a esa sensación"
    sr "ด้วยวิธีนี้ จะได้ช่วยให้ร่างกายของคุณคุ้นเคยกับความรู้สึกนั้นยังไงล่ะคะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:120
translate english main_quest7_5f21e177:

    # sr "En teoría mientras más lo hagas, más fácil se te hará hacerlo a voluntad"
    sr "ในทางทฤษฎีแล้ว ยิ่งคุณทำบ่อยเท่าไหร่ คุณก็จะยิ่งเรียกใช้มันได้ตามใจชอบง่ายขึ้นเท่านั้นค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:123
translate english main_quest7_a11c65db:

    # mn "Bien..."
    mn "โอเคครับ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:125
translate english main_quest7_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:132
translate english main_quest7_32462c4b_1:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:137
translate english main_quest7_423f0b1f:

    # mn "(Recuerdo ambas situaciones...)"
    mn "(นึกถึงทั้งสองสถานการณ์นั้นออกแล้ว...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:138
translate english main_quest7_1e0689b3:

    # mn "(Recuerdo esa sensación...)"
    mn "(จำความรู้สึกนั้นได้แล้ว...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:140
translate english main_quest7_ef98ff12:

    # mn "(Tan estresante... La sensaciión de estar en un lugar donde no debería)"
    mn "(เครียดชะมัด... ความรู้สึกเหมือนอยู่ในที่ที่เราไม่ควรอยู่)"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:141
translate english main_quest7_c07bbc45:

    # mn "(Esa ansiedad... De pensar qué diría de mí...)"
    mn "(ความวิตกกังวลนั้น... ที่เอาแต่คิดว่าเขาจะพูดถึงเราว่ายังไง...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:144
translate english main_quest7_ec196833:

    # mn "(Si eso hubiera pasado...)"
    mn "(ถ้าตอนนั้นเกิดเรื่องแบบนั้นขึ้นมาล่ะก็...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:155
translate english main_quest7_5c381ae4:

    # mn "¡Karugan!"
    mn "คารูกัน!"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:160
translate english main_quest7_0df99665:

    # sr "Vaya, realmente lo hiciste"
    sr "ว้าว ทำได้จริงๆ ด้วยแฮะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:162
translate english main_quest7_c3a3550c:

    # sr "No puedo verte en lo absoluto"
    sr "ฉันมองไม่เห็นคุณเลยสักนิดเดียว"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:165
translate english main_quest7_66e5ce24:

    # mn "¡Si, lo logré!"
    mn "เยส ผมทำได้แล้ว!"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:167
translate english main_quest7_75c14626:

    # mn "Vaya, esto es increíble"
    mn "โว้ สุดยอดไปเลยแฮะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:170
translate english main_quest7_e0eb1227:

    # mn "(Un momento... Se me acaba de ocurrir algo)"
    mn "(เดี๋ยวก่อนนะ... นึกอะไรดีๆ ออกแล้วล่ะ)"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:172
translate english main_quest7_a5d0fc18:

    # mn "(En el entrenamiento anterior, me bajó el pantalón cuando estuve en su Genjutsu...)"
    mn "(ตอนฝึกครั้งก่อน ตอนที่ฉันโดนคาถาภาพลวงตาเล่นงาน เขาเป็นคนดึงกางเกงฉันลงสินะ...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:174
translate english main_quest7_eb1741c7:

    # mn "(Jeje, bien, esta será mi venganza...)"
    mn "(หึหึ งั้นนี่ก็ถือเป็นการเอาคืนก็แล้วกัน...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:179
translate english main_quest7_b9847c7e:

    # sr "Oye, ¿Sigues ahí?"
    sr "นี่ ยังอยู่หรือเปล่าคะเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:181
translate english main_quest7_9843951a:

    # sr "Ahora intenta volver a..."
    sr "งั้นลองใหม่อีกรอบนะคะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:189
translate english main_quest7_94253c85:

    # sr "¡Aaaah!"
    sr "กรี๊ด!"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:191
translate english main_quest7_3bfb449d:

    # mn "(Oh Dios mío!)"
    mn "(ให้ตายสิ!)"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:192
translate english main_quest7_fb2eb3a4:

    # mn "(¿U-Usa Tanga?)"
    mn "(ม-ใส่กางเกงในจีสตริงด้วยเหรอเนี่ย?)"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:194
translate english main_quest7_eed7a001:

    # sr "¡¿Q-Qué se supone que haces?!"
    sr "ท-ทำบ้าอะไรของคุณเนี่ยยย?!"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:195
translate english main_quest7_0ede7d36:

    # mn "Esta es mi venganza jajaja"
    mn "นี่เป็นการเอาคืนของฉันเอง ฮ่าๆๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:196
translate english main_quest7_ef0e35a9:

    # sr "¿V-Venganza?"
    sr "ก-การเอาคืนเหรอคะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:198
translate english main_quest7_b473f5e5:

    # sr "¿P-Por el Genjutsu? ¡L-Lo siento, ahora déjame!"
    sr "ร-เรื่องคาถาภาพลวงตานั่นเหรอคะ? ฉ-ฉันขอโทษ ปล่อยฉันนะ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:201
translate english main_quest7_1a380ed0:

    # mn "Si, ya jaja"
    mn "ใช่แล้วล่ะ ฮ่าๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:210
translate english main_quest7_25d395e6:

    # mn "No hay nadie cerca, no te preocupes..."
    mn "แถวนี้ไม่มีใครอยู่ห่างน่า ไม่ต้องห่วงหรอก..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:214
translate english main_quest7_8cfc6c42:

    # mn "(Oooh, que hermosa tanga negras)"
    mn "(โอ้โห กางเกงในจีสตริงสีดำนี่สวยชะมัด)"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:215
translate english main_quest7_797751e9:

    # mn "(Atesoraré esta imagen mental)"
    mn "(ฉันจะเก็บบันทึกภาพนี้ไว้ในความทรงจำเลย)"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:220
translate english main_quest7_36e99f67:

    # sr "¡Aún así, no puedes bajarle los pantalones a una chica!"
    sr "ถึงอย่างนั้นก็มาดึงกางเกงผู้หญิงแบบนี้ไม่ได้นะคะ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:224
translate english main_quest7_1310d795:

    # mn "¡Ah!"
    mn "อ๊ะ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:227
translate english main_quest7_e277b0a1:

    # mn "Maldita sea..."
    mn "เวรเอ๊ย..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:230
translate english main_quest7_b82763ab:

    # sr "O-Oye, ¿Estás bien?"
    sr "ฮ-เฮ้ เป็นอะไรหรือเปล่าคะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:232
translate english main_quest7_fcf58a0f:

    # sr "¿Qué ocurre?"
    sr "เกิดอะไรขึ้นเหรอคะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:235
translate english main_quest7_a0878b56:

    # mn "Mi ojo me arde mucho, incluso veo borroso un poco borroso"
    mn "ตาฉันแสบมากเลย แถมยังมองเห็นไม่ค่อยชัดด้วย"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:237
translate english main_quest7_b9d0d93c:

    # mn "Supongo que es un efecto secundario"
    mn "สงสัยจะเป็นผลข้างเคียงแหละมั้ง"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:240
translate english main_quest7_e22a30f5:

    # sr "Ardor en el ojo... Pérdida breve de la vista..."
    sr "แสบตา... แถมมองไม่เห็นชั่วขณะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:243
translate english main_quest7_13afb10e:

    # sr "Se parecen bastante a los efectos secundarios del {b}Mangekyo Sharingan{/a}"
    sr "อาการพวกนี้ดูคล้ายกับผลข้างเคียงของ {b}เนตรวงแหวนกระจุกเงาโลหิต{/a} เลยนะคะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:246
translate english main_quest7_bdb3aad9:

    # sr "Puede llegar a ser peligroso"
    sr "มันอาจจะอันตรายได้เลยนะเนี่ย"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:249
translate english main_quest7_3307b8dd:

    # mn "Bueno, por lo menos ya sé como hacerlo a voluntad, aunque debo seguir practicando"
    mn "ก็ เอาเป็นว่าตอนนี้ฉันรู้วิธีใช้มันตามใจชอบแล้วล่ะ แม้ว่าจะยังต้องฝึกฝนต่ออีกหน่อยก็เถอะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:252
translate english main_quest7_566c92ac:

    # sr "Si... Se podría decir que sí..."
    sr "ค่ะ... จะว่างั้นก็ได้นะคะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:254
translate english main_quest7_c135deee:

    # sr "Aún así ten cuidado"
    sr "ยังไงก็ระวังตัวด้วยนะคะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:257
translate english main_quest7_ce6c5bd7:

    # mn "Lo tendré"
    mn "ฉันจะระวังไว้"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:259
translate english main_quest7_4c2c8ece:

    # mn "Bueno, de verdad agradezco que me hayas ayudado Sarada"
    mn "เอาล่ะ ขอบคุณเธอจริงๆ นะซาราดะที่ช่วยฉันเนี่ย"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:261
translate english main_quest7_f632b726:

    # mn "Fuiste la única que intentó ayudarme con esto"
    mn "เธอเป็นคนเดียวเลยนะที่พยายามช่วยฉันเรื่องนี้"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:263
translate english main_quest7_b2ef3536:

    # mn "Lo aprecio mucho"
    mn "ฉันซาบซึ้งใจจริงๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:266
translate english main_quest7_cba5d0da:

    # sr "N-no... Fue nada..."
    sr "ม-ไม่หรอกค่ะ... เรื่องแค่นี้เอง..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:269
translate english main_quest7_32462c4b_2:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:271
translate english main_quest7_7c4c5f4f_1:

    # sr "Oye..."
    sr "นี่..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:274
translate english main_quest7_cc9bdd32:

    # mn "¿Sí?"
    mn "หืม?"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:277
translate english main_quest7_51ddb164:

    # sr "No vuelvas hacer algo así nuevamente, ¿Entendiste?"
    sr "อย่าทำเรื่องแบบนั้นอีกเด็ดขาดเลยนะคะ เข้าใจไหมคะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:280
translate english main_quest7_e948446b:

    # mn "Oh, si jeje, lo lamento"
    mn "อ่า ได้เลย แหะๆ ขอโทษทีนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:283
translate english main_quest7_81af4e84:

    # sr "Nunca pensé que le bajarías los Shorts a una chica..."
    sr "ไม่คิดเลยนะคะว่าคุณจะกล้าดึงกางเกงขาสั้นของเด็กผู้หญิง...น่ะค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:286
translate english main_quest7_d7564cbd:

    # mn "Nunca pensé que se los bajarías los pantalones a un chico"
    mn "ฉันก็ไม่คิดเหมือนกันล่ะนะว่าเธอจะกล้าดึงกางเกงผู้ชายเหมือนกันนั่นแหละ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:288
translate english main_quest7_16278896:

    # sr "..."
    sr "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:290
translate english main_quest7_f16e66dc:

    # sr "Jajaja, tampoco creí que usaras Bóxers de corazones jaja"
    sr "ฮ่าๆๆ แล้วก็ไม่คิดเหมือนกันนะคะว่าคุณจะใส่กางเกงบ็อกเซอร์ลายหัวใจด้วย ฮ่าๆๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:293
translate english main_quest7_bbfd2dca:

    # mn "¡!"
    mn "!"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:295
translate english main_quest7_c5179749:

    # mn "Jeh, tampoco creí que te gustara usar tangas"
    mn "หึ ฉันก็ไม่คิดเหมือนกันว่าเธอจะชอบใส่กางเกงในจีสตริงเหมือนกันนี่"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:298
translate english main_quest7_664c9313:

    # sr "O-Oye..."
    sr "ด-เดี๋ยวสิคะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:300
translate english main_quest7_dbb5035f:

    # sr "Las uso por comodidad... Muchos ninjas hombres las usan por eso mismo también"
    sr "ฉันใส่เพื่อความสบายต่างหากล่ะคะ... นินจาผู้ชายหลายคนเขาก็ใส่เพราะเหตุผลนั้นกันทั้งนั้นแหละค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:303
translate english main_quest7_330df7e2:

    # mn "Si claro jaja"
    mn "อ่า แน่นอนอยู่แล้ว ฮ่าๆๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:306
translate english main_quest7_21cb7c9e:

    # sr "Bueno... Entonces estamos a mano..."
    sr "งั้น... เราก็หายกันแล้วสินะคะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:309
translate english main_quest7_548dfa49:

    # mn "Si, estamos a mano"
    mn "อื้ม เราหายกันแล้วล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:311
translate english main_quest7_8469e990:

    # mn "Bien, entonces iré a escribirles a mis compañeros que ya estoy listo"
    mn "งั้นเดี๋ยวฉันขอไปส่งข้อความบอกเพื่อนร่วมทีมก่อนนะว่าฉันพร้อมแล้ว"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:314
translate english main_quest7_a6bff849:

    # sr "Mmm, te recomiendo que primero entrenes un poco más"
    sr "อืม ฉันแนะนำให้คุณฝึกฝนเพิ่มอีกหน่อยก่อนดีกว่าค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:316
translate english main_quest7_3db46659:

    # sr "Ya sabes como hacerlo a voluntad, pero intenta dominarlo mejor"
    sr "ถึงคุณจะรู้วิธีใช้ตามใจชอบแล้ว แต่ก็พยายามฝึกให้มันคล่องกว่านี้อีกนิดเถอะค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:318
translate english main_quest7_6edfc1ab:

    # sr "Cuando ya te sientas más listo, entonces haz la prueba"
    sr "ไว้รู้สึกว่ามั่นใจและพร้อมกว่านี้ค่อยไปทดสอบก็ยังไม่สายค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:321
translate english main_quest7_c846840c:

    # mn "Entiendo... Entonces les avisaré luego"
    mn "เข้าใจแล้วล่ะ... งั้นเดี๋ยวไว้ฉันค่อยบอกเธออีกทีนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:324
translate english main_quest7_a8d46c79:

    # sr "Bien, entonces te deseo mucha suerte"
    sr "ค่ะ งั้นก็ขอให้โชคดีนะคะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:327
translate english main_quest7_bd40e2fd:

    # mn "Gracias, nos vemos luego Sarada"
    mn "ขอบใจนะ แล้วเจอกันใหม่ซาราดะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:331
translate english main_quest7_5070ae29:

    # sr "Nos vemos..."
    sr "ไว้เจอกันค่ะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:333
translate english main_quest7_16278896_1:

    # sr "..."
    sr "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7.rpy:336
translate english main_quest7_05fca92d:

    # sr "Ay, nunca creí que me vería así"
    sr "โอ๊ะ ไม่คิดเลยนะคะว่าตัวเองจะมีสภาพแบบนี้เนี่ย"
