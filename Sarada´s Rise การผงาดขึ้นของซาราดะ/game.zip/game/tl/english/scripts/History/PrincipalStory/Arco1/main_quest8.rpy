

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:5
translate english main_quest8_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:7
translate english main_quest8_929bc2a3:

    # "(sonido de celular vibrando)"
    "(เสียงโทรศัพท์มือถือสั่น)"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:8
translate english main_quest8_21be8491:

    # mn "Aaaagh..."
    mn "อ๊ากกก..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:9
translate english main_quest8_37529391:

    # mn "¿Q-Qué?"
    mn "อ-อะไรเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:11
translate english main_quest8_929bc2a3_1:

    # "(sonido de celular vibrando)"
    "(เสียงโทรศัพท์มือถือสั่น)"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:20
translate english main_quest8_66f5111e:

    # mn "¿Acaso ya nadie puede dormir tranquilamente luego de haber entrenado toda la noche?"
    mn "นี่จะไม่มีใครปล่อยให้คนอื่นได้นอนหลับอย่างสงบสุขหลังจากฝึกซ้อมมาทั้งคืนเลยรึไง?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:24
translate english main_quest8_a20a86bd:

    # mn "¿Quién puede estar llamando tan temprano?"
    mn "ใครโทรมาแต่เช้าเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:26
translate english main_quest8_32462c4b_1:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:32
translate english main_quest8_2a60dcd3:

    # mn "¡¿QUÉ?!"
    mn "อะไรนะ?!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:33
translate english main_quest8_4cd7ee18:

    # mn "¿Y-Yuna?"
    mn "ยู-ยูนะงั้นเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:34
translate english main_quest8_85dff56d:

    # mn "¡¿Yuna me está llamando... A mí?!"
    mn "ยูนะโทรหา... ฉันเนี่ยนะ?!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:36
translate english main_quest8_3521a11f:

    # mn "*Ejem* Vamos, no te exaltes..."
    mn "*แฮ่ม* เอา⁠น่า อย่าเพิ่งตื่นตระหนกสิ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:38
translate english main_quest8_cd054dc0:

    # mn "Demonios... ¿Qué querrá?"
    mn "ให้ตายสิ... ยัยนี่ต้องการอะไรเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:39
translate english main_quest8_32462c4b_2:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:40
translate english main_quest8_9f897235:

    # mn "Bueno, sea lo que sea, debo contestar"
    mn "ช่างเถอะ ยังไงก็ต้องรับสายสินะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:44
translate english main_quest8_aecb256b:

    # n "[MN] contesta el teléfono"
    n "[MN] รับโทรศัพท์"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:46
translate english main_quest8_0d4661c0:

    # mn "¿Hola?"
    mn "ฮัลโหล?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:51
translate english main_quest8_087beeaa:

    # yn "¡POR FIN CONTESTAS MALDITO IDIOTA!"
    yn "ในที่สุดก็ยอมรับสายสักทีนะไอ้โง่เอ้ย!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:55
translate english main_quest8_29c425a4:

    # yn "¡TE HEMOS ESTADO ESPERANDO HACE 20 MINUTOS, ¿ACASO CREES QUE TENEMOS TODO TU TIEMPO?!"
    yn "พวกเรายืนรอแกมา 20 นาทีแล้วนะ แกคิดว่าพวกฉันมีเวลาว่างเหลือเฟือหรือไงห๊ะ?!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:60
translate english main_quest8_16af36c3:

    # yn "¡SI NO ESTÁS AQUÍ EN 5 MINUTOS TE IRÉ A TRAER A PATADAS IMBÉCIL!"
    yn "ถ้าภายใน 5 นาทีนี้แกยังไม่มาถึงนะ ฉันจะไปอัดแกคว่ำแน่ไอ้เวรเอ้ย!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:62
translate english main_quest8_991dedde:

    # "(acaba la llamada)"
    "(สายตัดไปแล้ว)"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:63
translate english main_quest8_32462c4b_3:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:65
translate english main_quest8_d6701bec:

    # mn "Si..."
    mn "ดะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:67
translate english main_quest8_a5094350:

    # mn "Un momento"
    mn "เดี๋ยวก่อนสิ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:69
translate english main_quest8_ee6c7392:

    # mn "¿Esperándome?"
    mn "รอฉันงั้นเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:72
translate english main_quest8_89e1ccc0:

    # mn "¡Ah!, ¡Maldita sea!"
    mn "อ๊ะ! ให้ตายสิ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:74
translate english main_quest8_439eac63:

    # mn "¡La prueba de Zubon-Sensei!"
    mn "บททดสอบของอาจารย์ซูบงนี่!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:77
translate english main_quest8_367fb83c:

    # mn "Maldición, tengo que darme prisa"
    mn "เวรแล้ว ฉันต้องรีบแล้วสิเนี่ย"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:85
translate english main_quest8_a0c39140:

    # n "[MN] se cambia y sale de su casa lo más pronto posible"
    n "[MN] เปลี่ยนเสื้อผ้าและรีบออกจากบ้านโดยเร็วที่สุด"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:90
translate english main_quest8_8d14ea49:

    # mn "(Me sorprendió que Yuna fue quien me llamó)"
    mn "(แปลกใจแฮะที่ยูนะเป็นคนโทรมาหาฉัน)"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:91
translate english main_quest8_a75e4674:

    # mn "(¿Por qué Zubon-Sensei o Hideo no lo hicieron?)"
    mn "(ทำไมอาจารย์ซูบงหรือฮิเดโอะถึงไม่โทรมาล่ะ?)"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:92
translate english main_quest8_cb0210f3:

    # mn "(Hubiera preferido que uno de ellos me llamara)"
    mn "(ฉันยอมให้สองคนนั้นโทรมาปลุกยังดีซะกว่า)"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:93
translate english main_quest8_3690aada:

    # mn "(Yuna da miedo cuando se enoja)"
    mn "(เวลายูนะโกรธนี่น่ากลัวชะมัด)"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:99
translate english main_quest8_f33d7b7d:

    # d "¡Ah!"
    d "โอ๊ย!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:100
translate english main_quest8_201762cf:

    # mn "(Maldita sea... ¿Choqué con alguien?)"
    mn "(เวรเอ้ย... เดินชนใครเข้าเนี่ย?)"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:101
translate english main_quest8_e43b72a8:

    # mn "(Me distraje con mis pensamientos, tengo que ayudarla cuanto...)"
    mn "(มัวแต่คิดอะไรเพลิน... ต้องรีบช่วยเธอเก็บของก่อน...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:106
translate english main_quest8_5fb79ab7:

    # mn "Antes..."
    mn "ก่อนจะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:108
translate english main_quest8_7bc909ad:

    # mn "(¡Maldición!)"
    mn "(ให้ตายสิ!)"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:109
translate english main_quest8_c3eddd25:

    # mn "(¡Es la esposa del 7mo Hokage, ¿Cómo pude chocar con ella?)"
    mn "(เธอก็คือภรรยาของท่านโฮคาเงะรุ่นที่ 7 แท้ๆ ฉันไปเดินชนเธอได้ยังไงเนี่ย?)"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:112
translate english main_quest8_e79ab690:

    # hi "L-Lo siento..."
    hi "ฉ-ฉันขอโทษนะคะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:113
translate english main_quest8_3f2aa8ba:

    # hi "No ví que venías y..."
    hi "ฉันไม่ทันได้มองว่าคุณเดินมา แล้วก็..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:114
translate english main_quest8_565e0e95:

    # mn "N-No... L-La culpa es mía por correr sin cuidado"
    mn "ม-ไม่เป็นไรครับ... ค-ความผิดผมเองที่วิ่งไม่ดูตาม้าตาเรือ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:115
translate english main_quest8_d4650534:

    # mn "Permítame ayudarla, enserio no fue mi intención..."
    mn "ให้ผมช่วยนะครับ ผมไม่ได้ตั้งใจจริงๆ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:117
translate english main_quest8_af6260a4:

    # n "[MN] ayuda a Hinata"
    n "[MN] ช่วยเหลือฮินาตะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:130
translate english main_quest8_d0ca43d7:

    # mn "Nuevamente, lo siento por chocar con usted, señorita Hinata..."
    mn "ต้องขอโทษด้วยจริงๆ นะครับที่เดินชนคุณฮินาตะ...เอ๊ย คุณฮินาตะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:133
translate english main_quest8_06bf1e64:

    # hi "N-No te preocupes, no fue nada..."
    hi "ม-ไม่ต้องคิดมากหรอกค่ะ มันไม่มีอะไร... สักหน่อย..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:134
translate english main_quest8_32462c4b_4:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:137
translate english main_quest8_25ea9533:

    # hi "Un momento... ¿Tú no eres [MN]?"
    hi "เดี๋ยวก่อนนะ... เธอคือ [MN] ใช่ไหมคะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:139
translate english main_quest8_304af32b:

    # mn "Ah, s-si... Cuanto tiempo sin verla"
    mn "อ่า ค-ครับ... ไม่ได้เจอกันนานเลยนะครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:142
translate english main_quest8_2edd6a7a:

    # hi "Si, hace mucho, has crecido bastante"
    hi "นั่นสิคะ ไม่ได้เจอกันนานเลย เธอโตขึ้นเยอะเลยนะเนี่ย"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:144
translate english main_quest8_1153dd5c:

    # hi "Hace mucho que no vas a visitarnos"
    hi "เธอไม่ได้มาเยี่ยมพวกเราซะนานเลยนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:146
translate english main_quest8_8c4a990d:

    # hi "Supongo que es porque Boruto y Himawari ya no pasan mucho tiempo en casa"
    hi "สงสัยเป็นเพราะช่วงนี้โบรูโตะกับฮิมาวาริไม่ค่อยได้อยู่บ้านกันด้วยล่ะมั้งคะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:149
translate english main_quest8_7690c67b:

    # mn "Jaja, no es eso, últimamente no he tenido mucho tiempo libre"
    mn "ฮ่าๆ ไม่ใช่หรอกครับ ช่วงนี้ผมไม่ค่อยมีเวลาว่างต่างหากล่ะครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:152
translate english main_quest8_5e181dc1:

    # hi "..."
    hi "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:154
translate english main_quest8_a5ac1594:

    # mn "Eh... Señorita... Me pone nervioso si me ve tan fijamente..."
    mn "เอ่อ... คุณฮินาตะ... จ้องผมแบบนั้นผมก็เขินแย่สิครับ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:156
translate english main_quest8_e447093b:

    # hi "Hmm, ¿Siempre tuviste el ojo de ese color?"
    hi "อืม ดวงตาข้างนั้นของเธอ... มีสีแบบนั้นมาตั้งแต่แรกแล้วเหรอคะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:159
translate english main_quest8_0db961fc:

    # mn "Oh, eso... Han pasado muchas cosas estos días..."
    mn "อ๋อ เรื่องนั้น... ช่วงนี้มีเรื่องเกิดขึ้นตั้งหลายอย่างน่ะครับ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:162
translate english main_quest8_7540a9cd:

    # hn "Entiendo..."
    hn "เข้าใจแล้ว..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:165
translate english main_quest8_1f3e182a:

    # mn "(Me gustaría quedarme a hablar con ella, pero realmente llevo prisa)"
    mn "(ฉันก็อยากจะยืนคุยกับเธอต่อนะ แต่ว่ากำลังรีบจริงๆ)"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:168
translate english main_quest8_069f516e:

    # mn "Eh, lo siento, justo ahora llevo algo de prisa... ¿Pero qué le prece si la visito y le cuento toda la historia?"
    mn "เอ่อ ผมต้องขอตัวก่อน พอดีตอนนี้รีบนิดหน่อยน่ะครับ... งั้นเอาไว้ผมแวะไปหาที่บ้านแล้วเล่าเรื่องทั้งหมดให้ฟังดีไหมครับ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:171
translate english main_quest8_51a4b009:

    # mn "Así nos ponemos al corriente de lo que ha pasado"
    mn "ถือโอกาสอัปเดตเรื่องราวต่างๆ ที่เกิดขึ้นไปด้วยเลย"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:174
translate english main_quest8_cdb2ad85:

    # hi "Oh, me parece una gran idea"
    hi "แหม ฟังดูเข้าท่านะคะเนี่ย"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:176
translate english main_quest8_3725d296:

    # hi "Seguro eso le gustará a Himawari, y a Naruto también"
    hi "ฮิมาวาริคงดีใจแน่ๆ รวมถึงนารูโตะด้วยค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:179
translate english main_quest8_6a4be8f7:

    # hi "Aunque... Es una pena que Boruto no esté... Le hubiera gustado volver a encontrarse contigo"
    hi "แต่... น่าเสียดายจังที่โบรูโตะไม่อยู่ด้วย ไม่งั้นเขาคงดีใจนะที่ได้เจอเธออีกครั้ง"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:181
translate english main_quest8_32462c4b_5:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:183
translate english main_quest8_eeec8879:

    # mn "(Se ve... Que le duele que Boruto no esté...)"
    mn "(ดูเหมือนว่า... การที่โบรูโตะไม่อยู่จะทำให้เธอเจ็บปวดสินะ...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:185
translate english main_quest8_110f3acb:

    # mn "(Boruto se fue con Sasuke y Kawaki hace unos años, después del incidente con Ishiki, según iban a entrenar... Pero yo sé que hay otro motivo)"
    mn "(โบรูโตะออกเดินทางไปกับซาสึเกะและคาวากิเมื่อหลายปีก่อน หลังเกิดเหตุการณ์เรื่องอิชิกิ เพื่อไปฝึกฝน... แต่ฉันรู้ว่ามันมีเหตุผลอื่นด้วย)"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:187
translate english main_quest8_f9fea41b:

    # mn "(Pero supongo que es un motivo que no pueden contar)"
    mn "(แต่คิดว่าคงเป็นเหตุผลที่พวกเขาพูดออกมาไม่ได้สินะ)"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:188
translate english main_quest8_80d4ab9e:

    # mn "(Sea como sea, Hinata no ha visto a Boruto desde que se fué, eso hace 7 años... Y Himawari ahora es una ninja)"
    mn "(ยังไงก็ตาม ฮินาตะก็ไม่ได้เจอโบรูโตะเลยตั้งแต่เขาจากไปเมื่อ 7 ปีមុន... แถมตอนนี้ฮิมาวาริก็กลายเป็นนินจาไปแล้วด้วย)"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:192
translate english main_quest8_c9c08f2a:

    # mn "Seguro Boruto está bien"
    mn "ผมมั่นใจว่าโบรูโตะต้องไม่เป็นไรแน่นอนครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:195
translate english main_quest8_264750d4:

    # mn "Conociéndolo, seguro ahora es un ninja increíble, puede que ya sea mucho mejor que el mismo Sasuke"
    mn "นิสัยอย่างเขา ป่านนี้คงเติบโตเป็นนินจาที่เก่งกาจสุดๆ ไปแล้วล่ะครับ บางทีอาจจะเก่งกว่าคุณซาสึเกะไปแล้วด้วยซ้ำ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:198
translate english main_quest8_e8ed61f3:

    # hi "Jaja, seguro que sí... Boruto ya debe de ser todo un hombre..."
    hi "ฮ่าๆ นั่นสินะคะ... ป่านนี้โบรูโตะคงโตเป็นผู้ชายเต็มตัวแล้ว..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:201
translate english main_quest8_1a4833ad:

    # mn "Si, no tiene que preocuparse"
    mn "ครับ ไม่ต้องเป็นห่วงหรอกครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:204
translate english main_quest8_93818de7:

    # hi "Si..."
    hi "นั่นสินะคะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:206
translate english main_quest8_a7b2814f:

    # hi "Gracias por las palabras, ya no te quito tiempo, no olvides mandarme un mensaje avisando tu visita, para contarle a Himawari"
    hi "ขอบคุณสำหรับคำพูดดีๆ นะคะ งั้นฉันไม่รบกวนเวลาเธอแล้วล่ะ อย่าลืมส่งข้อความบอกล่วงหน้าตอนที่จะมาด้วยนะ จะได้บอกให้ฮิมาวาริรู้"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:209
translate english main_quest8_b2fceb75:

    # mn "Oh, pero no tengo su número"
    mn "อ๊ะ แต่ผมไม่มีเบอร์ติดต่อคุณฮินาตะนี่ครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:212
translate english main_quest8_64d4b9c9:

    # hi "No te preocupes, luego te lo mandaré, creo recordar que Naruto lo tiene"
    hi "ไม่ต้องห่วงค่ะ เดี๋ยวฉันส่งให้ทีหลัง ดูเหมือนนารูโตะจะมีเบอร์ของเธออยู่นะคะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:215
translate english main_quest8_8c5ae824:

    # mn "Oh, entonces no hay problema"
    mn "อ่า งั้นก็ไม่มีปัญหาครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:217
translate english main_quest8_afe72ad3:

    # mn "Nos vemos entonces, señorita Hinata"
    mn "ไว้เจอกันใหม่นะครับ คุณฮินาตะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:222
translate english main_quest8_ba6b034a:

    # hi "Nos vemos..."
    hi "ไว้เจอกันค่ะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:224
translate english main_quest8_a58e9e4e:

    # hi "*suspiro*... Boruto debe de estar tan grande como él..."
    hi "*ถอนหายใจ*... ป่านนี้โบรูโตะคงโตเท่าเขาแล้วสินะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:228
translate english main_quest8_9c0fa1c7:

    # n "[MN] vuelve a correr nuevamente hacia el campo de entrenamiento..."
    n "[MN] วิ่งมุ่งหน้าไปยังสนามฝึกซ้อมอีกครั้ง..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:233
translate english main_quest8_85b77973:

    # mn "(...)"
    mn "(...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:234
translate english main_quest8_a6ef0b2c:

    # mn "(Hace mucho tiempo no voy a casa del 7mo, para ser más preciso, desde que Boruto se fue con Sasuke y Kawaki)"
    mn "(ไม่ได้ไปบ้านท่านรุ่น 7 นานมากแล้ว พูดให้ถูกก็คือตั้งแต่ที่โบรูโตะออกเดินทางไปกับซาสึเกะและคาวากิสินะ)"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:235
translate english main_quest8_55c3f856:

    # mn "(A Boruto no lo conozco mucho, pero me caía bien, pero Kawaki...)"
    mn "(ฉันไม่ได้สนิทกับโบรูโตะมากนัก แต่ก็ชอบเขานะ ส่วนคาวากิ...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:236
translate english main_quest8_52818e7f:

    # mn "(Quisiera decir lo mismo... Pero realmente no es así)"
    mn "(ก็อยากจะพูดแบบนั้นเหมือนกัน... แต่มันไม่ใช่แบบนั้นจริงๆ)"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:237
translate english main_quest8_41f04f1d:

    # mn "(Aunque no creo que sea mala persona, sé que quiere mucho al 7mo Hokage, y por eso se fue con Sasuke luego del incidente de Ishiki)"
    mn "(ถึงฉันจะไม่คิดว่าเขาเป็นคนไม่ดีก็เถอะ รู้ว่าเขารักท่านโฮคาเงะรุ่นที่ 7 มาก นั่นแหละคือเหตุผลที่เขาไปกับซาสึเกะหลังเหตุการณ์ของอิชิกิ)"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:238
translate english main_quest8_cacb1c0d:

    # mn "(Pero desde entonces no he sabido nada de él)"
    mn "(แต่หลังจากนั้นก็ไม่ได้ข่าวคราวจากเขาอีกเลย)"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:239
translate english main_quest8_85b77973_1:

    # mn "(...)"
    mn "(...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:240
translate english main_quest8_36284e85:

    # mn "(Hinata desde entonces ha estado decaída supongo, porque desde que pasó eso ha pasado más tiempo sola...)"
    mn "(ฉันเดาว่าหลังจากนั้นเป็นต้นมาฮินาตะก็คงซึมเศร้าไปเลย เพราะตั้งแต่เกิดเรื่องนั้นขึ้นเธอก็ใช้เวลาอยู่คนเดียวมากขึ้น...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:241
translate english main_quest8_a6342a2e:

    # mn "(Tendré que pasar a saludarla como se debe)"
    mn "(ไว้ฉันต้องแวะมาทักทายให้เป็นเรื่องเป็นราวหน่อยแล้ว)"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:242
translate english main_quest8_d396fb46:

    # mn "(Pero justo ahora debo concentrarme en la prueba, ya casi llego)"
    mn "(แต่ตอนนี้ฉันต้องมีสมาธิกับการทดสอบก่อน ใกล้จะถึงแล้ว)"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:245
translate english main_quest8_8e9ee9fd:

    # n "[MN] llega al campo de entrenamiento..."
    n "[MN] มาถึงสนามฝึกซ้อมแล้ว..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:250
translate english main_quest8_4dbef414:

    # yn "¡TÚ IDIOTA!"
    yn "ไอ้งี่เง่าเอ้ย!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:253
translate english main_quest8_0ae9bcd0:

    # ""
    ""

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:254
translate english main_quest8_24a6706d:

    # zb "Aaah, sabía que esto pasaría..."
    zb "อ่าห์ รู้รู้อยู่แล้วเชียวว่าเรื่องมันต้องเป็นแบบนี้..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:255
translate english main_quest8_c7791637:

    # hd "Y si lo sabía, ¿Porqué no impidió que pasara?"
    hd "ในเมื่อนายรู้ แล้วทำไมไม่ห้ามไม่ให้มันเกิดขึ้นล่ะวะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:256
translate english main_quest8_8b624e56:

    # zb "¿Yo meterme en la relación de esos dos? Ni de broma"
    zb "ให้ฉันไปยุ่งเรื่องความสัมพันธ์ของสองคนนั้นเนี่ยนะ? ไม่มีทางซะหรอก"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:257
translate english main_quest8_3b11d566:

    # zb "Esa relación es más tóxica que el veneno mismo"
    zb "ความสัมพันธ์นั่นน่ะยิ่งกว่าพิษร้ายซะอีก"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:258
translate english main_quest8_03688ec5:

    # yn "¿Qué fue lo que dijo?"
    yn "แกพูดว่าอะไรนะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:259
translate english main_quest8_ce9f27fa:

    # zb "nada..."
    zb "เปล่า... ไม่มีอะไร..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:260
translate english main_quest8_54a76382:

    # yn "Hijo de puta..."
    yn "ไอ้เวรเอ้ย..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:261
translate english main_quest8_69dd0f0a:

    # zb "Más respeto a tu Sensei por favor..."
    zb "ช่วยให้ความเคารพเซนเซหน่อยเถอะน่า..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:262
translate english main_quest8_6a7b1dfa:

    # mn "Mmm..."
    mn "อืม..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:263
translate english main_quest8_73384367:

    # hd "Miren, parece que está despertando"
    hd "ดูนั่นสิ เหมือนเขาจะตื่นแล้วนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:276
translate english main_quest8_f3c1a509:

    # mn "Aaah... ¿Qué?"
    mn "อ่าาห์... อะไรเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:278
translate english main_quest8_44897805:

    # mn "¿Qué pasó?"
    mn "เกิดอะไรขึ้นเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:279
translate english main_quest8_73ff6995:

    # yn "..."
    yn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:281
translate english main_quest8_74055c3e:

    # yn "Hum, idiota..."
    yn "เอ่อ เจ้าทึบเอ้ย..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:285
translate english main_quest8_ea66f16f:

    # zb "Es culpa tuya galán, sabes que a Yuna no le gusta esperar"
    zb "ก็นายผิดเองนี่หว่า ยูกิก็รู้ว่ายูน่าเขาไม่ชอบรอนาน"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:287
translate english main_quest8_5dbc7d5a:

    # hd "..."
    hd "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:289
translate english main_quest8_0f3d45e7:

    # mn "¿Volvió a golpearme?"
    mn "เธอซัดฉันอีกแล้วเหรอเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:292
translate english main_quest8_3c785065:

    # hd "Oye, ¿Estás bien?"
    hd "เฮ้ นายไหวไหมเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:294
translate english main_quest8_cae80692:

    # hd "Con tantos golpes que has recibido de Yuna, me sorprende que no hayas perdido la memoria otra vez"
    hd "โดนยูน่าอัดไปซะขนาดนั้น ฉันแปลกใจจริง ๆ ที่นายยังความจำไม่เสื่อมรอบสองนะเนี่ย"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:297
translate english main_quest8_c6549634:

    # mn "¿Volvió a golpearme así?"
    mn "เธอซัดฉันขนาดนั้นเลยเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:300
translate english main_quest8_dc34e84a:

    # hd "Si... ¿Acaso te dormiste tarde ayer?"
    hd "ใช่... เมื่อวานนี้นายอนดึกเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:302
translate english main_quest8_23883c55:

    # hd "Te esperamos mucho tiempo"
    hd "พวกเรายืนรอนายตั้งนานสองนานแล้วนะเนี่ย"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:305
translate english main_quest8_32462c4b_6:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:307
translate english main_quest8_aacfc553:

    # mn "Si... Estuve con Sarada... Y creo que nos pasamos un poco..."
    mn "อืม... ฉันอยู่กับซาราดะน่ะ... แล้วก็เลยเถิดกันไปหน่อย...กันไปหน่อย..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:311
translate english main_quest8_deb0a69f:

    # zb "¡Ese es mi estudiante, todo un Galán!"
    zb "สมเป็นลูกศิษย์ฉันจริงๆ เจ๋งเป้งไปเลยนี่หว่า!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:313
translate english main_quest8_f1f00da0:

    # zb "JAJAJAJA"
    zb "ฮ่าๆๆๆๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:316
translate english main_quest8_f2b520bb:

    # mn "Eh, no en ese sentido"
    mn "หา ไม่ใช่ในความหมายนั้นสักหน่อย"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:318
translate english main_quest8_4f80c87d:

    # mn "Sarada y yo solo somos amigos"
    mn "ฉันกับซาราดะเป็นแค่เพื่อนกันเฉยๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:321
translate english main_quest8_186f1a7c:

    # yn "*murmurando* Si claro..."
    yn "*พึมพำ* จ้า เชื่อตายเลย..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:325
translate english main_quest8_4bcd8d5b:

    # mn "*suspiro*, Bueno... Supongo que igual les debo una disculpa por haberme demorado"
    mn "*ถอนหายใจ* เอาล่ะ... งั้นฉันคงต้องขอโทษด้วยสินะที่มาสาย"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:327
translate english main_quest8_e70ab0a6:

    # mn "A tí también Yuna... Sé que no te gusta esperar"
    mn "เธอด้วยนะยูน่า... รู้หรอกน่าว่าไม่ชอบรอใคร"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:331
translate english main_quest8_73ff6995_1:

    # yn "..."
    yn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:334
translate english main_quest8_32462c4b_7:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:337
translate english main_quest8_14289d54:

    # "*suspiro*"
    "*ถอนหายใจ*"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:340
translate english main_quest8_d4af9450:

    # zb "Bueno, ahora que ya estamos todos bien"
    zb "เอาล่ะ ในเมื่อพวกเธอไม่มีปัญหาอะไรกันแล้วนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:342
translate english main_quest8_af0f1e87:

    # zb "¿Están listos? La prueba no será nada fácil, tendrán que luchar todos juntos contra mí"
    zb "พร้อมกันรึยังล่ะ? การทดสอบนี้ไม่ง่ายหรอกนะ พวกเธอจะต้องร่วมมือกันสู้กับฉัน"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:346
translate english main_quest8_f1cde4fe:

    # zb "Así que espero que todos hayan avanzado con su entrenamiento"
    zb "เพราะงั้นก็หวังว่าทุกคนจะพัฒนาฝีมือจากการฝึกมาบ้างนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:350
translate english main_quest8_cac78578:

    # hd "¡Ey! ¿Porqué me queda viendo a mí?"
    hd "เฮ้! มองหน้าฉันทำไมเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:352
translate english main_quest8_4e411a80:

    # hd "He estado entrenando muy duro, así que esta vez no seré un problema para ninguno"
    hd "ฉันฝึกมาอย่างหนักเลยนะ เพราะงั้นครั้งนี้ฉันจะไม่เป็นตัวถ่วงของใครแน่"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:356
translate english main_quest8_a1617d7d:

    # zb "¡ESO ES CHICO! Veo determinación en tu mirada"
    zb "งั้นสิลูกผู้ชาย! ฉันเห็นความมุ่งมั่นอยู่ในแววตาของแกเลยนะเนี่ย"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:358
translate english main_quest8_9106f435:

    # zb "Ahora, Yuna, ¿Cómo va el control de tu Kekkei Genkai?"
    zb "แล้วเธอล่ะ ยูน่า การควบคุมขีดจำกัดสายเลือดไปถึงไหนแล้วล่ะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:361
translate english main_quest8_8ce19fbe:

    # yn "Estoy lista para romperte la cara"
    yn "ฉันพร้อมจะซัดหน้าแกให้คว่ำแล้วล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:363
translate english main_quest8_afd60d97:

    # zb "Ush... Que agresiva"
    zb "อู้ว... ดุเดือดซะจริง"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:366
translate english main_quest8_e81ebb7c:

    # zb "¡PERO ASÍ ME GUSTAN!"
    zb "แต่ฉันชอบเว้ย!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:368
translate english main_quest8_73ff6995_2:

    # yn "..."
    yn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:371
translate english main_quest8_fccabac6:

    # zb "Tú galán, ¿Algún progreso con tu ojito brillante?"
    zb "ส่วนเธอ พ่อหนุ่มรูปหล่อ เนตรสวรรค์นั่นมีความคืบหน้าไปถึงไหนแล้วล่ะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:374
translate english main_quest8_49a6cce6:

    # mn "He estado entrenandolo, y ahora tengo un mejor manejo sobre él"
    mn "ฉันฝึกฝนมาตลอด และตอนนี้ก็ควบคุมพลังได้ดีขึ้นเยอะแล้วครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:378
translate english main_quest8_d572cbc1:

    # zb "¡ASÍ ME GUSTA!"
    zb "แบบนี้สิที่ฉันชอบ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:380
translate english main_quest8_7923aff0:

    # zb "Esta es la juventud que quería ver"
    zb "นี่แหละคือความเร่าร้อนของวัยรุ่นที่ฉันอยากเห็น"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:382
translate english main_quest8_8477945d:

    # zb "Ahora créanme cuando les digo que pienso darlo todo así que espero que ustedes hagan lo mismo"
    zb "งั้นก็เชื่อฉันเถอะว่ารอบนี้ฉันเอาจริงแน่ เพราะงั้นก็หวังว่าพวกเธอจะทุ่มสุดตัวเหมือนกันนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:385
translate english main_quest8_fa9e2360:

    # yn "Dile adiós a tu maldito rostro..."
    yn "เตรียมตัวบอกลาหน้าตาโสโครกของแกได้เลย..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:388
translate english main_quest8_48579bd8:

    # hd "No debieron de hacer enojar a Yuna por el bien del Sensei..."
    hd "นายน่าจะระวังเรื่องทำให้ยูน่ายโมโหไว้หน่อยนะเพื่อประโยชน์ของเซนเซย์..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:391
translate english main_quest8_f82041ac:

    # zb "Mucho bla, bla, bla..."
    zb "พูดมากน่ารำคาญจริง... บลาๆๆๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:393
translate english main_quest8_50a95d84:

    # zb "Se olvidan que jamás han peleado conmigo en serio"
    zb "พวกเธอคงลืมไปสินะว่าไม่เคยสู้กับฉันแบบเอาจริงมาก่อนเลย"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:396
translate english main_quest8_09657669:

    # mn "No se nos da muy bien, pero si queremos pasar la prueba vamos a tener que trabajar en equipo"
    mn "พวกเราไม่ค่อยถนัดเรื่องแบบนี้เท่าไหร่หรอก แต่ถ้าอยากจะผ่านการทดสอบล่ะก็ เราต้องร่วมมือกันเป็นทีมแล้วล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:399
translate english main_quest8_b020437e:

    # yn "Supongo que no hay de otra..."
    yn "คงไม่มีทางอื่นแล้วสินะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:402
translate english main_quest8_841a7f29:

    # hd "Estoy con ustedes chicos"
    hd "ฉันเอาด้วยคน"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:408
translate english main_quest8_51c6f600:

    # mn "Es hora de demostrar de lo que somos capaz"
    mn "ได้เวลาแสดงให้เห็นแล้วว่าพวกเราทำอะไรได้บ้าง"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:411
translate english main_quest8_0e26a35b:

    # yn "¡ESO ES, MUÉSTRENME EL PODER DE LA JUVENTUD!"
    yn "เยี่ยมมาก แสดงพลังของวัยรุ่นออกมาให้ฉันดูซิ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:433
translate english before_zubon_battle_4c6cb48b:

    # n "[MN] se prepara para la lucha"
    n "[MN] เตรียมพร้อมสำหรับการต่อสู้"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:442
translate english main_quest8_after_battle_ee4403c4:

    # zb "¡Ya tuve suficiente!"
    zb "ฉันพอแค่นี้แหละ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:445
translate english main_quest8_after_battle_4f872739:

    # zb "¡Terminemos con esto!"
    zb "รีบๆ เคลียร์ให้มันจบๆ กันเถอะ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:450
translate english main_quest8_after_battle_38e27590:

    # hd "¡!"
    hd "!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:451
translate english main_quest8_after_battle_46ec2f32:

    # yn "¡Hideo!"
    yn "ฮิเดโอะ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:452
translate english main_quest8_after_battle_2680f222:

    # hd "Jeh."
    hd "หึ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:457
translate english main_quest8_after_battle_d778cdd1:

    # zb "¡Aaahhh!"
    zb "อ๊ากกก!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:458
translate english main_quest8_after_battle_c7c0be52:

    # yn "¿Q-Qué?"
    yn "อ-อะไรเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:459
translate english main_quest8_after_battle_5b114b6e:

    # mn "¡Ahora es mi Oportunidad!"
    mn "ได้จังหวะแล้ว!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:463
translate english main_quest8_after_battle_5c381ae4:

    # mn "¡Karugan!"
    mn "คารูกัน!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:470
translate english main_quest8_after_battle_4b1006af:

    # zb "Tu..."
    zb "แก..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:472
translate english main_quest8_after_battle_661d45e6:

    # zb "Después de todo aprendiste algo"
    zb "อย่างน้อยพวกแกก็ได้เรียนรู้อะไรมาบ้างสินะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:474
translate english main_quest8_after_battle_a07e78b5:

    # zb "Pero eso no será suficiente"
    zb "แต่แค่นั้นมันยังไม่พอหรอก"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:480
translate english main_quest8_after_battle_572ff21f:

    # zb "¿¡!?"
    zb "!?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:481
translate english main_quest8_after_battle_27294056:

    # zb "¡¿Qué mier...?!"
    zb "อะไรวะเนี่ย...?!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:482
translate english main_quest8_after_battle_b810bdf2:

    # zb "(Siento que alguien me está sujetando por detrás, pero no se ve nadie)"
    zb "(รู้สึกเหมือนมีคนจับฉันไว้จากข้างหลัง แต่กลับมองไม่เห็นใครเลย)"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:483
translate english main_quest8_after_battle_a5691d68:

    # zb "Jaja, no mentiste cuando dijiste que dominaste el {b}Jutsu de Invisibilidad{/a}, [MN]"
    zb "ฮ่าๆ แกไม่ได้โกหกจริงๆ สินะที่บอกว่าฝึก {b}คาถาล่องหน{/a} สำเร็จแล้ว [MN]"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:484
translate english main_quest8_after_battle_cc2407b9:

    # mn "¡Lo tengo, hazlo Yuna!"
    mn "ฉันล็อกตัวไว้แล้ว ลงมือเลยยูนะ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:485
translate english main_quest8_after_battle_ca4f0629:

    # mn "Golpealo..."
    mn "อัดมันเลย..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:487
translate english main_quest8_after_battle_1be3a5e7:

    # mn "¡AHORA!"
    mn "ตอนนี้แหละ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:490
translate english main_quest8_after_battle_915ae8fe:

    # yn "Muy bien..."
    yn "โอเค..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:493
translate english main_quest8_after_battle_19d11190:

    # yn "¡NO SABES CUANTO ESPERÉ ESTO!"
    yn "แกไม่รู้หรอกว่าฉันรอเวลานี้มานานแค่ไหนแล้ว!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:497
translate english main_quest8_after_battle_1620689d:

    # yn "¡TOMA ESTO!"
    yn "รับไปซะ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:498
translate english main_quest8_after_battle_3de395c5:

    # zb "Esto va a doler..."
    zb "งานนี้มีเจ็บตัวแน่..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:509
translate english main_quest8_after_battle_a20cefa7:

    # "..."
    "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:520
translate english main_quest8_after_battle_a830e9e8:

    # hd "¡LO LOGRAMMOS!"
    hd "พวกเราทำได้แล้ว!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:523
translate english main_quest8_after_battle_f15dbe9b:

    # hd "¡Eso fue increíble!"
    hd "สุดยอดไปเลย!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:525
translate english main_quest8_after_battle_0cf37130:

    # hd "El trabajo en equipo fue un éxito"
    hd "การทำงานเป็นทีมของเราประสบความสำเร็จแล้วสินะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:528
translate english main_quest8_after_battle_ea3baf16:

    # mn "Tú también estuviste increíble Hideo, ¿Esas son las técnicas que te enseñó el Sexto Hokage?"
    mn "นายเองก็สุดยอดเหมือนกันนะฮิเดโอะ นั่นคือวิชาที่ท่านโฮคาเงะรุ่นที่ 6 สอนนายมาเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:531
translate english main_quest8_after_battle_7bfef685:

    # yn "¿El Sexto Hokage te entrenó?"
    yn "ท่านโฮคาเงะรุ่นที่ 6 เป็นคนฝึกวิชาให้เธอเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:534
translate english main_quest8_after_battle_a023ad82:

    # hd "Jeje, sí, aceptó a entrenarme hace un tiempo"
    hd "เฮะๆ ใช่แล้วล่ะ เขาเพิ่งยอมรับฝึกวิชาให้ฉันเมื่อไม่นานมานี้เอง"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:537
translate english main_quest8_after_battle_5532787a:

    # hd "Ustedes tampoco lo hicieron nada mal"
    hd "พวกเธอเองก็ทำได้ไม่เลวเลยนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:540
translate english main_quest8_after_battle_2ea5297a:

    # hd "Ese golpe de Yuna fue increíble"
    hd "การโจมตีเมื่อกี้ของยูนะสุดยอดมากเลย"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:543
translate english main_quest8_after_battle_23239242:

    # yn "G-Gracias, fue así porque [MN] me lo dejó fácil..."
    yn "ข-ขอบคุณนะ ก็เพราะ [MN] เปิดช่องทางให้ฉันต่างหาก..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:546
translate english main_quest8_after_battle_9120c74f:

    # mn "Si, pero quien se lleva la gloria eres tú, tú le diste el golpe de gracia"
    mn "ใช่ แต่คนที่รับเครดิตไปเต็มๆ ก็คือเธอ เธอนี่แหละที่เป็นคนเผด็จศึก"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:548
translate english main_quest8_after_battle_242e136a:

    # mn "Dudo que un golpe mío logre noquear a Zubon-Sensei"
    mn "ฉันไม่คิดหรอกว่าการโจมตีแค่นั้นของฉันจะทำให้ครูซูบงสลบไปได้จริงๆ หรอกนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:551
translate english main_quest8_after_battle_67d61ca6:

    # hd "Realmente lo hicimos, trabajando en equipo logramos pasar la prueba"
    hd "พวกเราทำได้จริงๆ ด้วย พอร่วมมือกันเป็นทีมแล้วก็เลยผ่านการทดสอบมาได้"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:555
translate english main_quest8_after_battle_04d58324:

    # mn "Si seguimos así, los exámenes serán pan comido"
    mn "ถ้าพวกเรายังพัฒนาไปแบบนี้เรื่อยๆ การสอบจริงๆ ก็คงหมูๆ เลยล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:559
translate english main_quest8_after_battle_ccef9c74:

    # yn "No lo sé, recuerda que no debemos confiarnos"
    yn "ไม่รู้สิ อย่าลืมสิว่าพวกเราจะชะล่าใจไม่ได้เด็ดขาด"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:561
translate english main_quest8_after_battle_e601f4b9:

    # yn "Si hemos mejorado mucho, pero no sabemos con certeza quienes participarán"
    yn "ใช่ ถึงพวกเราจะเก่งขึ้นมากแล้ว แต่ก็ยังไม่รู้แน่ชัดเลยนี่ว่าใครจะได้เข้าร่วมบ้าง"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:564
translate english main_quest8_after_battle_35a82d9a:

    # mn "Hmm, ese es un muy buen punto"
    mn "อืม นั่นสินะ เป็นประเด็นที่ดีมากๆ เลย"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:567
translate english main_quest8_after_battle_5dbc7d5a:

    # hd "..."
    hd "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:569
translate english main_quest8_after_battle_50ebc6ab:

    # hd "Me alegra volver a verlos juntos"
    hd "ฉันดีใจจังที่ได้เห็นพวกเธอสองคนกลับมาคบกันอีกครั้ง"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:574
translate english main_quest8_after_battle_92f877c5:

    # yn "¡¿J-Juntos?! ¿De qué hablas?"
    yn "ค-คบกันงั้นเหรอ?! นายพูดบ้าอะไรเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:577
translate english main_quest8_after_battle_a82bd585:

    # yn "N-No estamos juntos en lo absoluto"
    yn "พ-พวกเราไม่ได้คบอะไรกันสักหน่อย"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:581
translate english main_quest8_after_battle_a4ea73e6:

    # mn "Sí, nada que ver..."
    mn "นั่นสิ ไม่มีอะไรแบบนั้นสักหน่อย..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:583
translate english main_quest8_after_battle_0a2e9c5f:

    # mn "No sé de qué hablas"
    mn "ฉันไม่รู้หรอกนะว่านายพูดเรื่องอะไรอยู่"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:586
translate english main_quest8_after_battle_2fa5f628:

    # hd "Ah... No me refería a eso..."
    hd "อ่า... ฉันไม่ได้หมายความว่าแบบนั้น..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:590
translate english main_quest8_after_battle_c950c45d:

    # yn "¿Con este tipo? Ni loca"
    yn "กับหมอนี่เนี่ยนะ? ไม่มีทางซะหรอก"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:592
translate english main_quest8_after_battle_7d0f6e56:

    # yn "Ni aunque me pagaran"
    yn "ต่อให้เอาเงินมาจ้างก็ไม่เอาด้วยหรอก"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:595
translate english main_quest8_after_battle_71203ae8:

    # mn "¿Acaso crees que yo quiero estar contigo?"
    mn "คิดว่าฉันอยากจะคู่กับเธอหรือไง?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:598
translate english main_quest8_after_battle_a4a2c466:

    # hd "*suspiro*... Yo y mi bocota..."
    hd "*ถอนหายใจ*... ปากเสียจริง ๆ เลยนะเรา..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:600
translate english main_quest8_after_battle_bc6a05f0:

    # zb "Jejeje..."
    zb "หึ ๆ ๆ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:601
translate english main_quest8_after_battle_98889ad5:

    # zb "Ese es el poder... De la juventud..."
    zb "นี่แหละคือพลัง... แห่งวัยหนุ่ม..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:604
translate english main_quest8_after_battle_c4c52961:

    # n "Luego de un tiempo, Zubon se recupera"
    n "ผ่านไปครู่หนึ่ง ซูบงก็ฟื้นตัวขึ้นมา"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:617
translate english main_quest8_after_battle_32263297:

    # zb "¡ESA FUE UNA GRAN PELEA!"
    zb "เป็น ศึก ที่ ยอด เยี่ยม มาก!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:619
translate english main_quest8_after_battle_cc42c079:

    # zb "¡ESTOY ORGULLO DE TODOS USTEDES!"
    zb "ครู ภูมิ ใจ ใน ตัว พว ก เธอ ทุก คน มาก!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:621
translate english main_quest8_after_battle_5f2a7766:

    # zb "Con esto, todos cumplieron mis espectativas"
    zb "เท่านี้ ทุกคนก็ทำได้ตามความคาดหวังของครูแล้วล่ะนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:623
translate english main_quest8_after_battle_2b43d6e0:

    # zb "Hideo por fin sirve de algo..."
    zb "ฮิเดโอะเองก็มีประโยชน์ขึ้นมาบ้างแล้วสินะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:626
translate english main_quest8_after_battle_abca371c:

    # hd "Hey..."
    hd "นี่..."

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:629
translate english main_quest8_after_battle_e17eedae:

    # zb "Yuna, sigue siendo la misma bestia imparable con sed de sangre, pero con mejor control en sus habilidades"
    zb "ส่วนยูนะ ก็ยังคงเป็นสัตว์ป่ากระหายเลือดที่หยุดไม่อยู่เหมือนเดิม เพิ่มเติมคือควบคุมพลังของตัวเองได้ดีขึ้น"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:632
translate english main_quest8_after_battle_126f0c0f:

    # yn "¿Quieres otra paliza?"
    yn "อยากโดนอัดให้อีกรอบหรือไงคะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:635
translate english main_quest8_after_battle_881dd983:

    # zb "Y [MN] ya dominó su ojito brillante"
    zb "และ [MN] ก็ควบคุมดวงตาสุกใสวิ้งวับนั่นได้คล่องแล้วด้วย"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:638
translate english main_quest8_after_battle_01cf838c:

    # mn "¿Puede dejar de llamarlo así?"
    mn "เลิกเรียกแบบนั้นสักทีได้ไหมครับเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:642
translate english main_quest8_after_battle_1d55448e:

    # zb "¡JAJAJA!"
    zb "ฮ่า ๆ ๆ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:644
translate english main_quest8_after_battle_7c0a732d:

    # zb "Muy bien, lo prometido es deuda"
    zb "เอาล่ะ ในเมื่อรับปากไว้แล้วก็ต้องทำตามสัญญา"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:649
translate english main_quest8_after_battle_cb07068b:

    # zb "Los inscribiré a los exámenes Chunnin, pero no se confíen"
    zb "ครูจะส่งชื่อพวกเธอเข้าสอบจูรินเอง แต่ก็อย่าเพิ่งตายใจไปล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:654
translate english main_quest8_after_battle_192b5d84:

    # zb "Como dijo Yuna, no saben con qué tipo de habilidades cuentan"
    zb "อย่างที่ยูนะบอก พวกมันไม่รู้หรอกว่าคู่ต่อสู้จะมีพลังแบบไหนซ่อนอยู่บ้าง"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:656
translate english main_quest8_after_battle_ffb5cb2b:

    # zb "Así que cuidado"
    zb "เพราะงั้นก็ระวังตัวด้วยล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:658
translate english main_quest8_after_battle_32e50ced:

    # zb "Y sin más que decir, ya pueden irse jóvenes"
    zb "เอาล่ะ ไม่พูดพร่ำทำเพลงแล้ว พวกเธอแยกย้ายกันกลับได้"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:660
translate english main_quest8_after_battle_6b81011b:

    # zb "Yo les mandaré un mensaje cuando sea necesario"
    zb "เดี๋ยวครูจะส่งข้อความไปหาเองถ้ามีเรื่องจำเป็น"

# game/scripts/History/PrincipalStory/Arco1/main_quest8.rpy:665
translate english main_quest8_after_battle_22e5cb82:

    # n "Todos se van del campo de entrenamiento"
    n "ทุกคนทยอยกันเดินออกจากสนามฝึก"
