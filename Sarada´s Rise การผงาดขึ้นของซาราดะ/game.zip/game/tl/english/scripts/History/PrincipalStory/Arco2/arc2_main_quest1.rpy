# TODO: Translation updated at 2024-12-01 21:25

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:13
translate english arc2_main_quest1_7ccc1122:

    # "-{b}Días después de hacer la prueba de Zubon{/a}-"
    "-{b}หลายวันหลังจากผ่านการทดสอบของซูบง{/a}-"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:14
translate english arc2_main_quest1_a20cefa7:

    # "..."
    "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:22
translate english arc2_main_quest1_621da7bc:

    # mn "¡Maldición!" with vpunch
    mn "โธ่เว้ย!" with vpunch

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:23
translate english arc2_main_quest1_60824f8a:

    # mn "Desde que hice la prueba de Zubon-Sensei no para de arderme el ojo"
    mn "ตั้งแต่ที่ฉันไปสอบของอาจารย์ซูบง ตาฉันก็แสบไม่หยุดเลย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:24
translate english arc2_main_quest1_5b86f15e:

    # mn "He intentado soportar el dolor, pero ya estoy harto..."
    mn "พยายามอดทนกับความเจ็บมาตลอดนะ แต่ตอนนี้ไม่ไหวแล้ว..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:25
translate english arc2_main_quest1_4d6c613a:

    # mn "Ya era suficiente con el Sharingan, pero ahora tengo que lidiar con esto también..."
    mn "แค่เนตรวงแหวนก็ภาระพอแรงแล้ว นี่ต้องมาเจออะไรแบบนี้อีกเหรอ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:26
translate english arc2_main_quest1_e12a7dac:

    # mn "Mierda..."
    mn "เว้ย..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:27
translate english arc2_main_quest1_d468932b:

    # mn "Debería hablar con un médico, no quiero quedarme ciego o algo peor"
    mn "ฉันควรไปหาหมอแฮะ ไม่อยากตาบอดหรือเจออะไรที่แย่กว่านั้นหรอกนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:29
translate english arc2_main_quest1_e53fe192:

    # mn "Tal vez es momento de hacerle otra visita a Sakura"
    mn "สงสัยถึงเวลาต้องไปแวะหาซากุระอีกรอบแล้วล่ะมั้ง"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:48
translate english arc2_main_quest1_2_3bfa2e26:

    # mn "Mmm, ¿No está Hanna por aquí?"
    mn "อืม ฮันนะไม่ได้อยู่แถวนี้เหรอเนี่ย?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:49
translate english arc2_main_quest1_2_c9df52db:

    # mn "Tenía ilusión de verla hoy... Es bastante boni..."
    mn "อุตส่าห์ตั้งตารอเจอเธอวันนี้แท้ๆ... น่าร้า..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:53
translate english arc2_main_quest1_2_9573ca50:

    # mn "¡Agh!"
    mn "อ๊าก!"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:54
translate english arc2_main_quest1_2_a6eade2a:

    # d "¡Aaagh, L-Lo siento!"
    d "อ๊ากก ขอโทษด้วยค่ะ!"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:61
translate english arc2_main_quest1_2_f7ccf285:

    # hn "D-De verdad lo siento, ¿Estás bien?"
    hn "ข-ขอโทษจริงๆ นะคะ เป็นอะไรหรือเปล่า?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:62
translate english arc2_main_quest1_2_49b90a79:

    # mn "Aagh... Si... Ahora lo estoy"
    mn "อ๊าก... ไม่เป็นไร... ตอนนี้ไม่เป็นแล้วล่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:64
translate english arc2_main_quest1_2_fdc7343b:

    # mn "(Estas vistas valen el golpe...)"
    mn "(วิวแบบนี้ เจ็บตัวหน่อยก็คุ้มแหะ...)"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:69
translate english arc2_main_quest1_2_df4bca5c:

    # n "Hanna ayuda a [MN] a levantarse"
    n "ฮันนะช่วยพยุง [MN] ให้ลุกขึ้น"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:78
translate english arc2_main_quest1_2_549309c4:

    # hn "De verdad lo siento... Salí corriendo para entregar unos documentos y no me fijé que estabas aquí"
    hn "ฉันขอโทษจริงๆ นะคะ พอดีรีบวิ่งเอาเอกสารไปส่ง เลยไม่ทันได้สังเกตว่าคุณอยู่ตรงนี้"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:81
translate english arc2_main_quest1_2_11a523ab:

    # mn "No te preocupes, de veras"
    mn "ไม่ต้องห่วงเลย จริงๆ นะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:83
translate english arc2_main_quest1_2_6178d1aa:

    # mn "No es nada que no pueda soportar"
    mn "เรื่องแค่นี้ฉันสบายมาก"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:84
translate english arc2_main_quest1_2_cb617b52:

    # hn "Aún así lo siento mucho"
    hn "ถึงอย่างนั้นก็เถอะ ฉันรู้สึกผิดจริงๆ นี่คะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:85
translate english arc2_main_quest1_2_dd48351f:

    # hn "Si necesitas algo en lo que pueda ayudarte, solo dímelo"
    hn "ถ้ามีอะไรให้ฉันช่วย บอกได้เลยนะคะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:86
translate english arc2_main_quest1_2_3f4f1b6a:

    # mn "No es nada..."
    mn "ไม่มีอะไรหรอก..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:89
translate english arc2_main_quest1_2_8d81a3d3:

    # mn "(Mmm... Podría aprovechar esta oportunidad para acercarme un poco más a ella...)"
    mn "(อืม... ถือโอกาสนี้ตีสนิทกับเธอหน่อยดีกว่า...)"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:90
translate english arc2_main_quest1_2_7d0e4408:

    # mn "(Es muy linda...)"
    mn "(น่ารักจริงๆ เลยนะเนี่ย...)"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:93
translate english arc2_main_quest1_2_8207ad47:

    # mn "De hecho..."
    mn "อันที่จริงแล้ว..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:94
translate english arc2_main_quest1_2_b9de4a75:

    # mn "Realmente si podrías hacer algo"
    mn "เธอช่วยฉันได้เรื่องหนึ่งนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:95
translate english arc2_main_quest1_2_a70aad21:

    # mn "¿Qué tal si salimos a comer?"
    mn "ไปหาอะไรกินกันหน่อยไหมล่ะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:97
translate english arc2_main_quest1_2_1d33875b:

    # hn "¡¿S-Salir a comer?!"
    hn "ป-ไปหาอะไรกินด้วยกันเหรอคะ?!"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:101
translate english arc2_main_quest1_2_62f73e73:

    # mn "Oh, pero si no quieres no hay problema"
    mn "อ้อ แต่ถ้าเธอไม่สะดวกก็ไม่เป็นไรนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:102
translate english arc2_main_quest1_2_05864253:

    # hn "N-No, para nada"
    hn "ม-ไม่ค่ะ ไม่ใช่แบบนั้นเลย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:105
translate english arc2_main_quest1_2_3c1404b7:

    # hn "M-Me encantaría"
    hn "ฉ-ฉันยินดีค่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:110
translate english arc2_main_quest1_2_d8039010:

    # mn "¡Muy bien!"
    mn "เยี่ยม!"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:113
translate english arc2_main_quest1_2_bbcfca09:

    # mn "¿Me regalas tu número para quedar un día?"
    mn "ขอเบอร์เธอหน่อยได้ไหม จะได้นัดวันกัน"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:114
translate english arc2_main_quest1_2_d1376775:

    # hn "Claro"
    hn "ได้ค่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:116
translate english arc2_main_quest1_2_b103fbee:

    # "Hanna y [MN] intercambian sus números"
    "ฮันนะและ [MN] แลกเบอร์โทรศัพท์กัน"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:118
translate english arc2_main_quest1_2_16b27efe:

    # mn "Muy bien, ¿Cuándo tienes tiempo?"
    mn "งั้นเธอว่างวันไหนบ้างล่ะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:119
translate english arc2_main_quest1_2_4cdd91f5:

    # hn "Por lo regular trabajo todo el día, así que podemos salir cuando acabe mi turno en la {b}Noche{/a}"
    hn "ปกติฉันทำงานทั้งวันเลยค่ะ ไว้ไปกันตอนกะของฉันเลิกช่วง{b}กลางคืน{/a}แล้วกันนะคะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:120
translate english arc2_main_quest1_2_bd9ba62a:

    # hn "Solo envíame un mensaje y me prepararé"
    hn "ส่งข้อความมาหาฉันได้เลย เดี๋ยวฉันเตรียมตัวรอค่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:121
translate english arc2_main_quest1_2_02a176bb:

    # mn "Bien, entonces yo te escribo"
    mn "โอเค งั้นเดี๋ยวฉันทักไปนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:122
translate english arc2_main_quest1_2_7e057261:

    # hn "Y bien, ¿A qué se debe tu visita al Hospital?"
    hn "ว่าแต่... มีธุระอะไรที่โรงพยาบาลเหรอคะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:123
translate english arc2_main_quest1_2_489ac8c9:

    # mn "Oh, cierto, ¿Está Sakura disponible?"
    mn "อ้อ จริงสิ ซากุระว่างอยู่หรือเปล่า?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:124
translate english arc2_main_quest1_2_90347254:

    # hn "Si, ella acaba de llegar, puedes pasar sin problema"
    hn "ค่ะ เพิ่งมาถึงเลย คุณเข้าไปได้เลยไม่มีปัญหาค่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:125
translate english arc2_main_quest1_2_299ee9da:

    # mn "Bien, entonces pasaré"
    mn "งั้นฉันเข้าไปล่ะนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:126
translate english arc2_main_quest1_2_6a2651f9:

    # hn "Adelante"
    hn "เชิญเลยค่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:129
translate english arc2_main_quest1_2_7bc2dd39:

    # n "[MN] usa el ascensor y llega a la habitación donde está Sakura"
    n "[MN] ใช้ลิฟต์ขึ้นมาจนถึงหน้าห้องของซากุระ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:130
translate english arc2_main_quest1_2_5e982103:

    # n "Pero antes de entrar..."
    n "แต่ก่อนที่จะเข้าไป..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:132
translate english arc2_main_quest1_2_a1bfe7b5:

    # n "Escucha unos gemidos..."
    n "เขากลับได้ยินเสียงครางดังแว่วมา..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:133
translate english arc2_main_quest1_2_959406c8:

    # mn "¿Estos son... Gemidos?"
    mn "เสียงนี่มัน... เสียงครางงั้นเหรอ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:134
translate english arc2_main_quest1_2_a46bc0e6:

    # d "*jadeo* Sasuke..."
    d "*อึก* ซาสึเกะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:135
translate english arc2_main_quest1_2_356bbdd7:

    # mn "(Seguramente sea Sakura... ¿Está haciendo eso aquí en el Hospital?)"
    mn "(ต้องเป็นซากุระแน่ๆ... เธอทำเรื่องแบบนั้นในโรงพยาบาลเนี่ยนะ?)"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:136
translate english arc2_main_quest1_2_31d2fbd8:

    # mn "(¡Y dejó la puerta abierta!)"
    mn "(แถมเธอยยังเปิดประตูทิ้งไว้อีก!)"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:137
translate english arc2_main_quest1_2_f7016258:

    # mn "(Esto es peligroso... Si alguien la ve haciendo eso...)"
    mn "(นี่มันอันตรายชะมัด... ถ้ามีใครมาเห็นเข้าตอนทำแบบนั้น...)"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:138
translate english arc2_main_quest1_2_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:147
translate english arc2_main_quest1_2_espiarla_35ebcf24:

    # mn "Supongo que... Ver un poco no estaría de más..."
    mn "งั้นขอ... แอบดูสักนิดคงไม่เป็นไรมั้ง..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:149
translate english arc2_main_quest1_2_espiarla_67432abc:

    # mn "Veamos..."
    mn "ดูซิ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:162
translate english arc2_main_quest1_2_espiarla_6c3dedd0:

    # sk "¡Aaah!"
    sk "อ๊าห์!"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:163
translate english arc2_main_quest1_2_espiarla_83f5bea1:

    # sk "S-Sasuke... Si..."
    sk "ซ-ซาสึเกะ... แบบนั้นแหละ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:164
translate english arc2_main_quest1_2_espiarla_db0498c8:

    # mn "(Ver a Sakura así...)"
    mn "(เห็นซากุระในสภาพนี้...)"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:165
translate english arc2_main_quest1_2_espiarla_c7c36cd5:

    # mn "(Está pensando en Sasuke...)"
    mn "(เธอกำลังคิดถึงซาสึเกะสินะ...)"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:166
translate english arc2_main_quest1_2_espiarla_57d38f17:

    # mn "(Aún en esta situación...)"
    mn "(ขนาดในสถานการณ์แบบนี้...)"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:167
translate english arc2_main_quest1_2_espiarla_5fd87f7d:

    # sk "*jadeo* Si... Así..."
    sk "*อ่าห์* ใช่... แบบนั้นแหละ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:168
translate english arc2_main_quest1_2_espiarla_0ae9bcd0:

    # ""
    ""

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:169
translate english arc2_main_quest1_2_espiarla_88efadd5:

    # sk "¡Ah!"
    sk "อ๊า!"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:170
translate english arc2_main_quest1_2_espiarla_25883fe7:

    # sk "Si... Así... Sasuke..."
    sk "ใช่... แบบนั้นแหละ... ซาสึเกะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:171
translate english arc2_main_quest1_2_espiarla_85b77973:

    # mn "(...)"
    mn "(...)"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:172
translate english arc2_main_quest1_2_espiarla_c40b3a2f:

    # mn "(Creo que ya es suficiente...)"
    mn "(ฉันว่าแค่นี้ก็พอแล้วมั้ง...)"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:189
translate english arc2_main_quest1_2_esperar_e1a7f3b8:

    # n "[MN] espera a Sakura"
    n "[MN] รอจนซากุระเสร็จธุระ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:191
translate english arc2_main_quest1_2_esperar_fe58a3be:

    # n "Y luego toca la puerta"
    n "แล้วเขาก็เคาะประตู"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:192
translate english arc2_main_quest1_2_esperar_26ab2ed8:

    # sk "¡A-Ah!, U-Un momento..."
    sk "อ-อ๊า! ร-สบกวนรอสักครู่นะคะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:193
translate english arc2_main_quest1_2_esperar_c702986f:

    # mn "(Parece que se está vistiendo...)"
    mn "(ดูเหมือนเธอจะกำลังรีบใส่เสื้อผ้าอยู่นะ...)"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:203
translate english arc2_main_quest1_2_esperar_c7c10d04:

    # mn "H-Hola... Sakura"
    mn "ส-สวัสดีครับ ซากุระ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:204
translate english arc2_main_quest1_2_esperar_61008ce6:

    # sk "[MN], ¿Qué tal estás?"
    sk "[MN] เป็นยังไงบ้างจ๊ะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:205
translate english arc2_main_quest1_2_esperar_9cd53b3e:

    # sk "¿Hoy vienes a trabajar?"
    sk "วันนี้มาทำงานเหรอ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:206
translate english arc2_main_quest1_2_esperar_2d8eb5bb:

    # mn "No, de hecho necesito hablar contigo"
    mn "เปล่าครับ พอดีผมมีเรื่องอยากจะคุยกับคุณหน่อยน่ะครับ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:208
translate english arc2_main_quest1_2_esperar_b902dfb8:

    # sk "¿Hablar? ¿Sobre qué?"
    sk "คุยเหรอ? เรื่องอะไรเหรอจ๊ะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:209
translate english arc2_main_quest1_2_esperar_d6bb0d86:

    # mn "¿Recuerdas lo que te conté sobre mi nuevo {b}Dojutsu{/a}?"
    mn "จำเรื่องที่ผมเคยบอกเกี่ยวกับ {b}เนตรวิถี{/a} ใหม่ของผมได้ไหมครับ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:210
translate english arc2_main_quest1_2_esperar_4601d8eb:

    # sk "Sí claro, ¿Pasó algo con él?"
    sk "จำได้สจ๊ะ มีอะไรเกิดขึ้นกับมันอย่างงั้นเหรอ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:211
translate english arc2_main_quest1_2_esperar_209eafb1:

    # mn "Pues, ya lo estoy dominando, puedo activarlo y desactivarlo cuando quiera..."
    mn "ก็... ตอนนี้ผมเริ่มควบคุมมันได้คล่องขึ้นแล้ว เปิดปิดได้ตามใจชอบเลย..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:212
translate english arc2_main_quest1_2_esperar_569cecb4:

    # mn "Pero algo me preocupa, ¿sabes?"
    mn "แต่ว่ามันมีเรื่องนึงที่ทำให้ผมกังวลน่ะสิครับ รู้ไหม?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:213
translate english arc2_main_quest1_2_esperar_74e6d465:

    # mn "Cuando uso la habilidad, el ojo me arde demasiado, al principio se iba al rato, pero esta última vez el dolor estuvo presente durante toda la noche, casi no pude dormir"
    mn "เวลาที่ผมใช้พลังนั้น ตาของผมมันแสบมากเลย ตอนแรกๆ อาการมันก็จะหายไปเองสักพัก แต่ล่าสุดเนี่ยอาการปวดมันเล่นงานอยู่ทั้งคืนเลย จนแทบไม่ได้นอนเลยครับ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:214
translate english arc2_main_quest1_2_esperar_d9c53881:

    # sk "Ardor al activarlo... ¿Has visto borroso luego de usarlo?"
    sk "แสบตอนที่ใช้งานอย่างงั้นเหรอ... แล้วหลังจากใช้เนี่ย มีอาการตาพร่ามัวบ้างไหม?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:215
translate english arc2_main_quest1_2_esperar_ecc3b85f:

    # mn "Si, pero esa pérdida de vista no permanece mucho"
    mn "มีครับ แต่การมองเห็นที่ลดลงไปมันก็อยู่ไม่นานหรอก"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:216
translate english arc2_main_quest1_2_esperar_e5938516:

    # sk "Entiendo..."
    sk "อย่างนี้นี่เอง..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:217
translate english arc2_main_quest1_2_esperar_c3c41d76:

    # sk "Se parecen bastante a los efectos secundarios por el uso excesivo del {b}Mangekyo Sharingan{/a}..."
    sk "อาการพวกนั้นค่อนข้างคล้ายกับผลข้างเคียงจากการใช้ {b}เนตรวงแหวนกระจกเงาหมื่นบุปผา{/a} มากเลยนะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:218
translate english arc2_main_quest1_2_esperar_c36733b4:

    # mn "Eso dijo Sarada también... ¿Hay algo que pueda hacer?"
    mn "ซาราดะก็พูดแบบนั้นเหมือนกัน... มีอะไรที่ผมพอจะทำได้บ้างไหมครับ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:220
translate english arc2_main_quest1_2_esperar_6ffe8506:

    # sk "Mmmm, primero quiero revisar algo"
    sk "อืม ก่อนอื่นฉันอยากจะตรวจอะไรบางอย่างก่อนน่ะนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:221
translate english arc2_main_quest1_2_esperar_325276c0:

    # sk "Recuéstate en la cama, quiero analizar tu ojo"
    sk "ไปนอนลงบนเตียงซะ เดี๋ยวฉันจะตรวจตาของเธอให้"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:222
translate english arc2_main_quest1_2_esperar_687cdfd5:

    # mn "E-Está bien"
    mn "ค-ครับ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:224
translate english arc2_main_quest1_2_esperar_ec0d9def:

    # n "Sakura le hizo a [MN] todo tipo de análisis al {b}Karugan{/a} de [MN]"
    n "Sakura performed all kinds of tests on [MN]'s {b}Karugan{/a}"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:225
translate english arc2_main_quest1_2_esperar_84796c6a:

    # n "Desde revisar la pupila, hasta pedirle que se vuelva invisible un par de veces"
    n "ตั้งแต่ตรวจเช็กม่านตาไปจนถึงขอให้เขาใช้คาถาล่องหนอยู่หลายครั้ง"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:226
translate english arc2_main_quest1_2_esperar_f216f860:

    # n "Y luego de estudiarlo casi todo el día, Sakura quedó impresionada por los resultados"
    n "และหลังจากศึกษาดูอยู่เกือบทั้งวัน ซากุระก็ต้องทึ่งกับผลลัพธ์ที่ได้"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:233
translate english arc2_main_quest1_2_esperar_5c6fb507:

    # sk "¡Increíble!" with vpunch
    sk "เหลือเชื่อจริงๆ!" with vpunch

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:236
translate english arc2_main_quest1_2_esperar_75014dc1:

    # mn "¡N-No grites tan de la nada!"
    mn "จ-จู่ๆ ก็อย่าเพิ่งตะโกนสิครับ!"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:237
translate english arc2_main_quest1_2_esperar_6a47b3c3:

    # sk "Ah, lo siento jajaja"
    sk "อ่า ขอโทษทีจ่ะ ฮ่าๆๆ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:238
translate english arc2_main_quest1_2_esperar_b4b127ca:

    # sk "Pero esto es increíble, no creí que existiera un jutsu capaz de algo así"
    sk "แต่ว่านี่มันเหลือเชื่อจริงๆ ฉันไม่เคยคิดเลยว่าจะมีวิชาแบบนี้อยู่บนโลกด้วย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:239
translate english arc2_main_quest1_2_esperar_214bb951:

    # mn "¿Descubriste algo importante?"
    mn "พบอะไรสำคัญเหรอครับ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:240
translate english arc2_main_quest1_2_esperar_627a1e03:

    # sk "¿Importante? Esa palabra se queda corta, esto es algo increíble"
    sk "สำคัญเหรอ? ใช้คำว่าสำคัญคงยังน้อยไป อันนี้มันเรื่องใหญ่ระดับเหลือเชื่อเลยต่างหาก"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:241
translate english arc2_main_quest1_2_esperar_69c45ddd:

    # sk "Mira..."
    sk "ดูนี่นะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:242
translate english arc2_main_quest1_2_esperar_3d0b46fa:

    # sk "Tu ojo utiliza tu chakra para absorber la luz que irradia tu cuerpo"
    sk "ตาของเธอใช้จักระในการดูดซับแสงที่ร่างกายปล่อยออกมา"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:243
translate english arc2_main_quest1_2_esperar_908aa65d:

    # mn "¿Absorbe la luz de mi cuerpo con Chakra?"
    mn "ดูดซับแสงจากร่างกายด้วยจักระเหรอครับ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:244
translate english arc2_main_quest1_2_esperar_e940895c:

    # sk "Verás, la luz es el agente físico que hace visible cualquier objeto que existe en este mundo"
    sk "คืออย่างนี้นะ แสงเนี่ยคือตัวการทางกายภาพที่ทำให้สิ่งของทุกอย่างบนโลกนี้มองเห็นได้"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:245
translate english arc2_main_quest1_2_esperar_aa9dd5dc:

    # sk "Los humanos somos visibles gracias a que emitimos una poca cantidad de luz, y bastaría que un humano deje de emitir luz para que se vuelva invisible"
    sk "มนุษย์เรามองเห็นได้ก็เพราะเราปล่อยแสงปริมาณเล็กน้อยออกมา และแค่มนุษย์หยุดปล่อยแสง แค่นั้นก็หายตัวได้แล้วล่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:246
translate english arc2_main_quest1_2_esperar_a7749610:

    # sk "Y tu {b}Karugan{/a} la absorve, de ahí que te puedas hacer invisible"
    sk "และ {b}คารูกัน{/a} ของเธอก็ดูดซับมันเข้าไป นั่นจึงเป็นเหตุผลที่ทำให้เธอล่องหนได้ยังไงล่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:247
translate english arc2_main_quest1_2_esperar_ae671993:

    # sk "Pero cuando te vuelves invisible pareciese que tu ojo no es capaz de soportan el jutsu, y creo que por eso tu esclerótica se vuelve de color negro"
    sk "แต่พอเธอใช้คาถาล่องหน ตาของเธอดูกจะรับวิชานี้ไม่ค่อยไหว และฉันคิดว่านั่นแหละคือสาเหตุที่ทำให้ตาขาวของเธอเปลี่ยนเป็นสีดำ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:248
translate english arc2_main_quest1_2_esperar_e98c0180:

    # sk "Aunque... No sé si debería ser normal, eso es lo que te causa molestias"
    sk "ถึงแม้ว่า... ฉันจะไม่แน่ใจว่ามันควรจะเป็นเรื่องปกติไหม แต่นั่นแหละคือสิ่งที่ทำให้เธอรู้สึกไม่สบายตาอยู่ตอนนี้"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:249
translate english arc2_main_quest1_2_esperar_4a4eb5f8:

    # sk "Me gustaría seguir haciéndote exámenes, para que comprendamos mejor las habilidades que tiene el {b}Karugan{/a} y podamos contrarestar los efectos secundarios"
    sk "ฉันอยากจะทำการทดสอบกับเธอต่ออีกหน่อย เพื่อที่เราจะได้เข้าใจความสามารถของ {b}คารูกัน{/a} ให้ดียิ่งขึ้น รวมถึงหาทางรับมือกับผลข้างเคียงด้วย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:250
translate english arc2_main_quest1_2_esperar_6d76b33d:

    # sk "¿Puedes venir otro día para seguir haciendo pruebas? Quizás descubramos cosas que nos puedan ser de utilidad"
    sk "วันหลังแวะมาทำการทดสอบต่ออีกหน่อยได้ไหม? เผื่อเราจะค้นพบอะไรที่เป็นประโยชน์ขึ้นมาอีก"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:251
translate english arc2_main_quest1_2_esperar_b21d8542:

    # mn "Si, entre más cosas sepa mejor"
    mn "ได้ครับ ยิ่งผมรู้มากเท่าไหร่ก็ยิ่งดีครับ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:252
translate english arc2_main_quest1_2_esperar_5cd2fea1:

    # sk "Bien, ya terminamos por hoy entonces"
    sk "โอเค วันนี้พอแค่นี้ก่อนแล้วกันนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:253
translate english arc2_main_quest1_2_esperar_f2e9371f:

    # sk "Por cierto, me gustaría que usaras el {b}Karugan{/a} lo menos posible, para evitar daños severos o incluso permanentes"
    sk "ยังไงก็เถอะ ฉันอยากให้เธอพยายามใช้ {b}คารูกัน{/a} ให้น้อยที่สุดเท่าที่จะทำได้ เพื่อหลีกเลี่ยงความเสียหายที่รุนแรงหรืออาจถึงขั้นถาวรนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:254
translate english arc2_main_quest1_2_esperar_88c5a813:

    # mn "¿Qué? Pero tenía usarlo en los Exámenes Chunin"
    mn "หา? แต่ผมจำเป็นต้องใช้มันในการสอบจูนินนี่ครับ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:255
translate english arc2_main_quest1_2_esperar_1291c0d8:

    # sk "Calma, con estos datos creo que puedo hacer algo para que el Karugan no te dañe tanto la vista"
    sk "ใจเย็นน่า ด้วยข้อมูลพวกนี้ ฉันคิดว่าน่าจะพอทำอะไรสักอย่างเพื่อไม่ให้คารูกันสร้างความเสียหายแก่การมองเห็นของเธอได้มากนักหรอก"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:256
translate english arc2_main_quest1_2_esperar_0356bde5:

    # sk "Así que puedes estar tranquilo, solo vuelve para seguir haciendo exámenes"
    sk "เพราะงั้นสบายใจได้ แค่แวะกลับมาทดสอบต่อก็พอ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:258
translate english arc2_main_quest1_2_esperar_b0abe312:

    # mn "Está bien, entonces voy a volver otro día"
    mn "เข้าใจแล้วครับ งั้นเดี๋ยววันหลังผมจะมาใหม่นะครัช"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:259
translate english arc2_main_quest1_2_esperar_92038672:

    # sk "Bien, recuerda que mi turno comienza al medio día"
    sk "จ้า อย่าลืมล่ะว่าฉันเข้าเวรตอนเที่ยงนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:261
translate english arc2_main_quest1_2_esperar_52c497c6:

    # mn "Si, nos vemos Sakura"
    mn "ครับ ไว้เจอกันครับซากุระ"

translate english strings:

    # game/scripts/History/PrincipalStory/Arco2/arc2_main_quest1.rpy:139
    old "Esperar a que termine"
    new "รอจนกว่าจะเสร็จสิ้น"

