

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:9
translate english arc1_main_quest3_0b551fee:

    # mn "(Hideo suele estar por aquí en la mañana)"
    mn "(ปกติเวลานี้ฮิเดโอะน่าจะอยู่ที่นี่นะ)"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:11
translate english arc1_main_quest3_d0f3c07e:

    # mn "(Me gustaría saber como va con su entrenamiento)"
    mn "(ฉันอยากรู้จังว่าช่วงนี้เขาฝึกซ้อมไปถึงไหนแล้ว)"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:13
translate english arc1_main_quest3_82182376:

    # mn "(O si al menos está entrenando...)"
    mn "(หรืออย่างน้อยก็อยากรู้ว่าเขาได้ฝึกซ้อมอยู่บ้างหรือเปล่า...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:17
translate english arc1_main_quest3_7ae9f727:

    # hd "¡Debo de hacerme más fuerte!"
    hd "ฉันต้องแข็งแกร่งขึ้นให้ได้!"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:18
translate english arc1_main_quest3_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:20
translate english arc1_main_quest3_2b0baee2:

    # mn "Esa definitivamente es la voz de Hideo"
    mn "นั่นเสียงของฮิเดโอะนี่นา"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:22
translate english arc1_main_quest3_d814339f:

    # n "[MN] entra al salón de clases"
    n "[MN] เดินเข้าไปในห้องเรียน"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:30
translate english arc1_main_quest3_0392cef3:

    # mn "(Parece que está hablando con la señorita Mirai)"
    mn "(ดูเหมือนว่าเขากำลังคุยอยู่กับมิไรเซนเซย์นะ)"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:33
translate english arc1_main_quest3_f357d417:

    # hd "Mis compañeros no paran de volverse más fuertes, ambos consiguieron habilidades increíbles"
    hd "พวกเพื่อนๆ ของผมเก่งขึ้นเรื่อยๆ เลย ทั้งสองคนมีฝีมือที่น่าทึ่งมากๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:35
translate english arc1_main_quest3_5ec98272:

    # hd "Es por eso que tengo que hacer algo para hacerme más fuerte"
    hd "นั่นแหละคือเหตุผลที่ผมต้องทำอะไรสักอย่างเพื่อให้ตัวเองแข็งแกร่งขึ้นบ้าง"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:38
translate english arc1_main_quest3_ad570cb7:

    # mr "Entiendo que te quieras volver más fuerte y que tengas ese entusiasmo"
    mr "ฉันเข้าใจนะว่าเธออยากจะเก่งขึ้นและมีความกระตือรือร้นขนาดไหน"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:40
translate english arc1_main_quest3_30727f68:

    # mr "Pero de nada servirá que estudies si no te pones a entrenar"
    mr "แต่ถ้าเธอไม่เริ่มลงมือฝึกซ้อม ตั้งใจเรียนไปก็เท่านั้นแหละนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:43
translate english arc1_main_quest3_0aaef1b0:

    # hd "Lo sé, lo sé"
    hd "ผมรู้แล้วครับ ผมรู้..."

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:46
translate english arc1_main_quest3_25971371:

    # hd "Es por eso que vine aquí, quería saber si podrías ayudarme a entrenar"
    hd "นั่นแหละครับผมถึงมาที่นี่ อยากจะรู้ว่าครูพอจะช่วยฝึกซ้อมให้ผมหน่อยได้ไหมครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:49
translate english arc1_main_quest3_5a667e0a:

    # mr "Quisiera ayudarte, pero de verdad que no puedo, tengo asignada una misión muy importante"
    mr "ครูก็อยากจะช่วยอยู่นะ แต่ช่วยไม่ได้จริงๆ ช่วงนี้ครูได้รับมอบหมายภารกิจสำคัญมากๆ เลยล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:52
translate english arc1_main_quest3_6ba76946:

    # hd "¿E-En serio...?"
    hd "จ-จริงเหรอครับ...?"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:55
translate english arc1_main_quest3_7f531e85:

    # mr "No te desanimes, sé que puedes encontrar a alguien más"
    mr "อย่าเพิ่งท้อไปเลยน่า ครูเชื่อว่าเธอหาคนอื่นช่วยได้แน่"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:57
translate english arc1_main_quest3_bebd60a7:

    # mr "Siempre hay ninjas fuertes que están dispuestos a echarte una mano"
    mr "มีนินจาเก่งๆ ตั้งหลายคนที่พร้อมจะยื่นมือช่วยเหลือเธออยู่นะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:60
translate english arc1_main_quest3_f7845d55:

    # mn "Como yo, por ejemplo"
    mn "อย่างเช่นผมเป็นต้นไงครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:67
translate english arc1_main_quest3_1fba1318:

    # hd "[MN]..."
    hd "[MN]..."

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:71
translate english arc1_main_quest3_45d4c4d3:

    # mn "Estaba pasando por aquí y escuché un poco su conversación"
    mn "พอดีผมเดินผ่านมาแล้วได้ยินที่พวกคุยกันอยู่นิดหน่อยน่ะครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:73
translate english arc1_main_quest3_efd8e971:

    # mn "Yo podría ayudarte con tu entrenamiento"
    mn "ผมช่วยเธอฝึกซ้อมเองก็ได้นะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:76
translate english arc1_main_quest3_9ae7bb46:

    # mr "¿Ves?, ¿Quién mejor que tu compañero de equipo para ayudarte?"
    mr "เห็นไหมล่ะ ไม่มีใครเหมาะจะช่วยเธอไปมากกว่าเพื่อนร่วมทีมอีกแล้วไม่ใช่เหรอ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:79
translate english arc1_main_quest3_a07d27ef:

    # mn "Hideo, sabes que puedes contar conmigo para entrenar"
    mn "ฮิเดโอะ เธอรู้ใช่ไหมล่ะว่าพึ่งพาฉันในการฝึกซ้อมได้เสมอน่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:82
translate english arc1_main_quest3_ce7b6068:

    # mn "Después de todo, somos compañeros"
    mn "ยังไงซะพวกเราก็เป็นเพื่อนร่วมทีมกันนี่นะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:84
translate english arc1_main_quest3_5dbc7d5a:

    # hd "..."
    hd "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:87
translate english arc1_main_quest3_284cfcde:

    # mr "¿Qué pasa? Ahora estás más desanimado"
    mr "เป็นอะไรไป ทำไมทำหน้าหงอยกว่าเดิมล่ะนั่น"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:90
translate english arc1_main_quest3_0cc7b198:

    # hd "No soy tan fuerte como tú [MN]..."
    hd "ฉันไม่ได้เก่งกาจเท่า [MN] สักหน่อยนี่...อุตส่าห์..."

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:92
translate english arc1_main_quest3_9fa9fe93:

    # hd "Ambos consiguieron nuevas habilidades que tienen que mejorar"
    hd "ทั้งสองคนนั้นต่างก็ได้วิชาใหม่มาและต้องฝึกฝนให้เก่งขึ้นไปอีก"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:94
translate english arc1_main_quest3_8021698f:

    # hd "No tienen que preocuparse por mi entrenamiento, no los quiero atrasar..."
    hd "เธอไม่ต้องมาเป็นห่วงเรื่องการฝึกของฉันหรอืก ไม่อยากถ่วงแข้งถ่วงขาเธอหรอกนะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:96
translate english arc1_main_quest3_32462c4b_1:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:98
translate english arc1_main_quest3_0ca41336:

    # mr "Estás exagerando, no eres tan malo"
    mr "เธอคิดมากไปแล้ว ฝีมือไม่ได้แย่ขนาดนั้นสักหน่อย"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:102
translate english arc1_main_quest3_e4701986:

    # mr "Tienes un excelente control de tu chakra y dominas las habilidades básicas a la perfección"
    mr "เธอควบคุมจักระได้ดีเยี่ยมแถมยังเชี่ยวชาญทักษะพื้นฐานได้อย่างสมบูรณ์แบบเลยด้วยซ้ำ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:106
translate english arc1_main_quest3_6fabde6d:

    # mr "Sólo te hace falta un pequeño empujón aprendiendo algún jutsu fuerte"
    mr "เธอแค่ขาดแรงผลักดันอีกนิดหน่อยด้วยการเรียนรู้วิชานินจาที่ทรงพลังก็เท่านั้นเอง"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:109
translate english arc1_main_quest3_77a7b59d:

    # mr "!!"
    mr "!"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:112
translate english arc1_main_quest3_06ae03fc:

    # mr "¿Cuál me dijiste que era tu naturaleza de chakra?"
    mr "ธาตุจักระของเธอคือธาตุอะไรนะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:114
translate english arc1_main_quest3_00b33a1c:

    # hd "Eh, Rayo"
    hd "เอ่อ... สายฟ้าครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:117
translate english arc1_main_quest3_8e5dbb78:

    # mr "Mmm, jeje..."
    mr "อืม หึๆ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:119
translate english arc1_main_quest3_0562b4b9:

    # mn "¿Qué pasa?"
    mn "เป็นอะไรไปเหรอครับ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:121
translate english arc1_main_quest3_df42e0b2:

    # mr "Creo que sé quién puede ayudar a Hideo"
    mr "ฉันว่าฉันรู้แล้วล่ะว่าใครจะช่วยฝึกให้ฮิเดโอะได้"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:123
translate english arc1_main_quest3_9a72673f:

    # mr "Últimamente he escuchado rumores sobre que se le ha visto en el río de las afueras de la aldea"
    mr "ช่วงนี้ได้ยินข่าวลือมาว่ามีคนเห็นเขาอยู่แถวแม่น้ำนอกหมู่บ้านน่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:125
translate english arc1_main_quest3_6336948b:

    # mr "Sí logran convencerlo, no me cabe dudas de que Hideo se convertirá en un ninja poderoso"
    mr "ถ้าพวกเธอเกลี้ยกล่อมเขาสำเร็จล่ะก็ ฉันมั่นใจเลยว่าฮิเดโอะจะต้องกลายเป็นนินจาที่เก่งกาจขึ้นแน่ๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:128
translate english arc1_main_quest3_a267eb70:

    # hd "¿Pero de quién se trata?"
    hd "แต่ว่าใครกันล่ะครับ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:131
translate english arc1_main_quest3_18b95456:

    # mr "Ni más ni menos que..."
    mr "ก็ไม่ใช่ใครที่ไหน... นอกจาก..."

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:134
translate english arc1_main_quest3_f7db7391:

    # mr "Kakashi Hatake, el sexto Hokage"
    mr "ฮาตาเกะ คาคาชิ โฮคาเงะรุ่นที่หกยังไงล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:138
translate english arc1_main_quest3_20572e6e:

    # "!!"
    "!"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:141
translate english arc1_main_quest3_6bc882e8:

    # hd "P-Pero... ¿Cómo podríamos convencer a alguien como él?"
    hd "ต-แต่ว่า... เราจะไปเกลี้ยกล่อมคนระดับนั้นได้ยังไงล่ะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:145
translate english arc1_main_quest3_5d5bc780:

    # mr "Bueno, eso es algo que deberás de descubrir por tu cuenta"
    mr "เรื่องนั้นพวกเธอต้องไปหาวิธีเอาเองนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:150
translate english arc1_main_quest3_ef2cc75a:

    # mn "Hay que intentarlo Hideo"
    mn "เธอน่าจะลองดูนะ ฮิเดโอะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:153
translate english arc1_main_quest3_1975712c:

    # hd "P-pero..."
    hd "ต-แต่ว่า..."

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:156
translate english arc1_main_quest3_8f266560:

    # mn "No te preocupes, te ayudaré a convencerlo"
    mn "ไม่ต้องห่วง เดี๋ยวฉันช่วยเกลี้ยกล่อมเขาให้อีกแรงเอง"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:158
translate english arc1_main_quest3_8de9e30e:

    # mn "¡Solo piensa en lo fuerte que te convertirás si lo logramos convencer!"
    mn "ลองคิดดูสิว่าเธอจะเก่งขึ้นขนาดไหนถ้าพวกเรากล่อมเขาสำเร็จน่ะ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:161
translate english arc1_main_quest3_e3728c16:

    # hd "S-Supongo que no perdemos nada intentándolo..."
    hd "ฉ-ฉันว่าลองดูก็คงไม่เสียหายอะไรสินะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:164
translate english arc1_main_quest3_b182ef18:

    # mr "Esa es la actitud"
    mr "งั้นสิ ถึงจะถูก"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:169
translate english arc1_main_quest3_38217ffe:

    # mr "Cabe aclarar, que no sé los horarios en los que supuestamente suele estar en el río"
    mr "ต้องบอกไว้ก่อนนะว่าฉันไม่รู้หรอกว่าปกติเขาจะไปที่แม่นั่นตอนกี่โมง"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:171
translate english arc1_main_quest3_e23145b6:

    # mr "Así que si fuera ustedes, no perdería el tiempo e iría a ver si está allí ahora"
    mr "เพราะงั้นถ้าเป็นฉันล่ะก็ คงไม่ปล่อยเวลาให้เสียเปล่าแล้วรีบไปดูซะตั้งแต่ตอนนี้เลยล่ะนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:173
translate english arc1_main_quest3_7bff4b46:

    # mn "Ella tiene razón"
    mn "นั่นสินะครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:175
translate english arc1_main_quest3_ac7648e1:

    # mn "Debemos irnos"
    mn "พวกเราไปกันเถอะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:178
translate english arc1_main_quest3_5cfe7f92:

    # hd "Está bien, entonces nos vemos cuando esté más desocupada"
    hd "งั้นผมขอตัวก่อนนะครับ ไว้คุณมิไรว่างเมื่อไหร่ค่อยมาพบใหม่ครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:181
translate english arc1_main_quest3_0705b8f0:

    # mr "Claro, les deseo mucha suerte"
    mr "จ้า ขอให้โชคดีนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:183
translate english arc1_main_quest3_4c0b346d:

    # n "Luego de despedirse de Mirai, [MN] y Hideo ponen rumbo al río de las afueras de la aldea"
    n "หลังจากบอกลาคุณมิไรแล้ว [MN] และฮิเดโอะก็มุ่งหน้าไปยังแม่น้ำบริเวณนอกหมู่บ้าน"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:191
translate english arc1_main_quest3_fab7098b:

    # mn "Tal vez sea porqué solo tengo un ojo medio bueno, pero aquí no veo a nadie"
    mn "หรือเป็นเพราะฉันตาดีไม่ค่อยดีอยู่ข้างเดียวก็ไม่รู้ แต่ไม่เห็นมีใครอยู่แถวนี้เลยแฮะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:194
translate english arc1_main_quest3_4ff9ab73:

    # hd "Mirai nos dijo que no sabía el horario exacto y que solo eran rumores"
    hd "คุณมิไรบอกแล้วนี่ว่าเธอไม่รู้เวลาที่แน่นอนแถมมันก็เป็นแค่ข่าวลือด้วย"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:196
translate english arc1_main_quest3_3b8a9095:

    # hd "Por lo que cabe la posibilidad de que todo sea falso..."
    hd "งั้นก็มีความเป็นไปได้สูงเลยนะว่าเรื่องทั้งหมดนี้จะไม่จริง..."

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:198
translate english arc1_main_quest3_32462c4b_2:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:200
translate english arc1_main_quest3_d2f939db:

    # mn "Oye, ¿Qué te pasa?"
    mn "เฮ้ เป็นอะไรไปเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:204
translate english arc1_main_quest3_ce64c0c2:

    # hd "¿Eh, a qué te refieres?"
    hd "เอ๊ะ หมายความว่ายังไงเหรอครับ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:207
translate english arc1_main_quest3_94943a6a:

    # mn "Tú no sueles ser tan negativo"
    mn "ปกติแกไม่ใช่คนคิดลบแบบนี้นี่นา"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:209
translate english arc1_main_quest3_b4bbc709:

    # mn "Siempre te has caracterizado por ser optimista y entusiasta"
    mn "นายมักจะเป็นคนมองโลกในแง่ดีและกระตือรือร้นอยู่เสมอไม่ใช่เหรอ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:212
translate english arc1_main_quest3_5dbc7d5a_1:

    # hd "..."
    hd "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:214
translate english arc1_main_quest3_ecadc670:

    # hd "Lamento actuar como un idiota"
    hd "ขอโทษทีนะที่ทำตัวงี่เง่าแบบนี้"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:216
translate english arc1_main_quest3_fbdbf584:

    # hd "Es sólo qué..."
    hd "ก็แค่..."

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:218
translate english arc1_main_quest3_7eec42eb:

    # hd "Me aterra la idea de que no podamos pasar la prueba del sensei por mi culpa"
    hd "ฉันกลัวเหลือเกินว่าพวกเราจะสอบไม่ผ่านบททดสอบของอาจารย์ก็เพราะฉัน"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:220
translate english arc1_main_quest3_19e6be19:

    # hd "Después de tanto tiempo, por fin tenemos una oportunidad de ser {b}Chunin{/a}"
    hd "หลังจากรอมานาน ในที่สุดพวกเราก็มีโอกาสจะได้เป็น {b}จูนิน{/a} สักที"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:222
translate english arc1_main_quest3_8c10c458:

    # hd "Y no quiero arruinarla siendo un estorbo..."
    hd "แล้วฉันก็ไม่อยากทำให้มันพังเพราะความไร้น้ำยาของตัวเอง..."

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:225
translate english arc1_main_quest3_63fab55a:

    # mn "Entonces usa ese miedo para motivarte a mejorar"
    mn "งั้นก็ใช้ความกลัวนั้นมาเป็นแรงผลักดันให้ตัวเองพัฒนาขึ้นสิ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:227
translate english arc1_main_quest3_ec0a3861:

    # mn "Toma ese sentimiento de no querer ser un estorbo y úsalo para entrenar y volverte más fuerte"
    mn "เอาความรู้สึกที่ไม่อยากเป็นตัวถ่วงนั้นมาใช้ฝึกฝนแล้วทำให้ตัวเองเก่งขึ้นซะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:230
translate english arc1_main_quest3_5dbc7d5a_2:

    # hd "..."
    hd "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:232
translate english arc1_main_quest3_64f10056:

    # hd "Tienes razón"
    hd "นั่นสินะครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:235
translate english arc1_main_quest3_22c0f53c:

    # hd "Ya debo dejar de lloriquear y hacer algo al respecto"
    hd "ฉันควรเลิกทำตัวงอแงแล้วทำอะไรสักอย่างเพื่อแก้ไขมันดีกว่า"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:238
translate english arc1_main_quest3_1ef09c31:

    # mn "Sí..."
    mn "นั่นสิ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:241
translate english arc1_main_quest3_22d48e83:

    # mn "Aunque por ahora, creo que deberíamos regresar a la aldea y volver aquí luego"
    mn "แต่ว่าตอนนี้ ฉันว่าพวกเรากลับเข้าหมู่บ้านกันก่อนแล้วค่อยมาที่นี่ใหม่ทีหลังเถอะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:243
translate english arc1_main_quest3_00499723:

    # mn "No veo rastro alguno de..."
    mn "ฉันไม่เห็นร่องรอยของ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:246
translate english arc1_main_quest3_3759bb19:

    # d "¿Ninjas en las afueras de la aldea?"
    d "นินจาแถวชานหมู่บ้านงั้นเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:251
translate english arc1_main_quest3_20572e6e_1:

    # "!!"
    "!"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:257
translate english arc1_main_quest3_4e4e0cc1:

    # kk "No es muy común ver ninjas por aquí"
    kk "ไม่ค่อยได้เห็นนินจามาป้วนเปี้ยนแถวนี้เท่าไหร่เลยนะเนี่ย"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:259
translate english arc1_main_quest3_a83c2bb2:

    # hd "¿U-Usted es...?"
    hd "พ-หรือว่าคุณคือ...?"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:261
translate english arc1_main_quest3_53be9022:

    # kk "Ah, no se preocupen por mí"
    kk "อ่า ไม่ต้องสนใจฉันหรอ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:262
translate english arc1_main_quest3_0a53b1a9:

    # kk "Sólo vengo aquí a pasar el rato y leer un poco"
    kk "ฉันแค่มาเดินเล่นพักผ่อนแล้วก็อ่านหนังสือนิดหน่อยน่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:263
translate english arc1_main_quest3_d7a746f7:

    # kk "Sin embargo, no esperaba ver a nadie por aquí el día de hoy"
    kk "แต่ก็ไม่คิดเลยนะเนี่ยว่าจะเจอใครที่นี่วันนี้"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:266
translate english arc1_main_quest3_a046a112:

    # mn "(¡Es igual a como se ve en la roca Hokage...!)"
    mn "(ดูคล้ายกับผาโฮคาเกะเลยแฮะ...!)"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:270
translate english arc1_main_quest3_9106eb47:

    # kk "¿Están en una misión o algo?"
    kk "พวกเธอมาทำภารกิจอะไรทำทำนองนั้นเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:272
translate english arc1_main_quest3_3537154a:

    # mn "No... De hecho, estamos aquí por usted"
    mn "เปล่าครับ... จริงๆ แล้วพวกเรามาหาคุณต่างหาก"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:275
translate english arc1_main_quest3_bc462510:

    # kk "¿Por mí...?"
    kk "หาฉันเหรอ...?"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:278
translate english arc1_main_quest3_d7690278:

    # kk "Ya veo, entonces se terminó corriendo la voz de que suelo estar por aquí"
    kk "งั้นเหรอ แสดงว่าข่าวลือเรื่องที่ฉันมักจะมาอยู่แถวนี้คงแพร่สะพัดไปสินะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:279
translate english arc1_main_quest3_339e4387:

    # kk "Eso es un poco molesto, ahora tendré que buscar otro sitio para leer"
    kk "น่ารำคาญชะมัด แบบนี้ฉันคงต้องหาที่อ่านหนังสือที่อื่นซะแล้วสิ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:281
translate english arc1_main_quest3_503debaf:

    # hd "Oh, n-no tiene que hacer eso, la verdad solo vinimos para hacerle una pregunta"
    hd "อ๋อ ม-ไม่ต้องทำถึงขนาดนั้นก็ได้ครับ ความจริงคือพวกเราแค่อยากจะมาถามอะไรหน่อยน่ะครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:283
translate english arc1_main_quest3_573174fb:

    # kk "¿Una pregunta?"
    kk "ถามเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:285
translate english arc1_main_quest3_5dbc7d5a_3:

    # hd "..."
    hd "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:287
translate english arc1_main_quest3_2456fe2b:

    # mn "Vamos Hideo, solo dilo"
    mn "เอ้า ฮิเดโอะ พูดออกไปสิ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:290
translate english arc1_main_quest3_e754cb9f:

    # hd "N-necesito ayuda para volverme más fuerte para los exámenes {b}Chunin{/a}"
    hd "ผ-ผมต้องการความช่วยเหลือเพื่อให้เก่งขึ้นสำหรับการสอบ {b}จูนิน{/a} ครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:292
translate english arc1_main_quest3_3175e2ac:

    # hd "Y..."
    hd "แล้วก็..."

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:294
translate english arc1_main_quest3_b1a93f54:

    # kk "¿Y?"
    kk "แล้วก็?"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:298
translate english arc1_main_quest3_1b106bf3:

    # hd "¡Y quería saber si usted podría entrenarme!"
    hd "แล้วก็ผมอยากรู้ว่าคุณจะช่วยฝึกฝนให้ผมได้ไหมครับ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:301
translate english arc1_main_quest3_bedee59c:

    # kk "¿Eso es todo?"
    kk "แค่นั้นเองเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:304
translate english arc1_main_quest3_0d9eee51:

    # hd "S-Sí, señor"
    hd "ค-ครับผม"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:305
translate english arc1_main_quest3_370941e5:

    # kk "Entonces me niego"
    kk "งั้นฉันปฏิเสธ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:309
translate english arc1_main_quest3_25083a39:

    # "¡¿EEh?!"
    "หาบ้าอะไรเนี่ย?!"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:312
translate english arc1_main_quest3_0ded5673:

    # kk "No me juzguen muchachos, es solo que ya estoy retirado"
    kk "อย่าเพิ่งมองฉันแบบนั้นสิพวกนาย คือฉันเกษียณตัวเองไปแล้วน่ะนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:313
translate english arc1_main_quest3_6f0c2204:

    # kk "Seguramente algún Jonin estaría interesado en hacerlo, si lo desean puedo darles alguna recomendación"
    kk "พวกโจนินคนอื่นน่าจะสนใจรับงานนี้นะ ถ้าพวกเธอต้องการ เดี๋ยวฉันแนะนำให้ก็ได้"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:314
translate english arc1_main_quest3_5dbc7d5a_4:

    # hd "..."
    hd "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:316
translate english arc1_main_quest3_bf8f27bb:

    # mn "Bueno, sabíamos no sería fácil convencerlo"
    mn "ก็นะ... พวกเราก็รู้แหละว่าการจะเกลี้ยกล่อมเขามันไม่ง่ายเลย"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:318
translate english arc1_main_quest3_692dd794:

    # mn "Sin embargo, nosotros no aceptaremos un no como respuesta"
    mn "แต่พวกเราไม่ยอมแพ้ง่ายๆ หรอกครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:320
translate english arc1_main_quest3_e4d8fee8:

    # kk "Mmm..."
    kk "อืม..."

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:321
translate english arc1_main_quest3_185c5387:

    # kk "Yo solía usar la banda ninja igual que tú"
    kk "ฉันก็เคยสวมที่คาดหน้าผากนินจาเหมือนกับพวกเธอนี่แหละ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:322
translate english arc1_main_quest3_fc77a188:

    # kk "¿Eres un admirador mío?"
    kk "เป็นแฟนคลับของฉันหรือไง?"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:324
translate english arc1_main_quest3_d31f12f8:

    # mn "De hecho la uso por la misma razón que usted"
    mn "ความจริงแล้วผมสวมมันด้วยเหตุผลเดียวกับคุณเลยครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:326
translate english arc1_main_quest3_8f2f5dea:

    # kk "Entonces tú..."
    kk "งั้นก็..."

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:328
translate english arc1_main_quest3_26e866df:

    # mn "Si... Uno de mis ojos porta el Sharingan señor"
    mn "ใช่ครับ... ดวงตาข้างหนึ่งของผมมีเนตรวงแหวนอยู่ครับท่าน"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:330
translate english arc1_main_quest3_b8405db9:

    # kk "Ya veo..."
    kk "อย่างนี้นี่เอง..."

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:333
translate english arc1_main_quest3_cbf5ade4:

    # kk "Bien, lograste llamar mi atención, así que les daré una oportunidad"
    kk "งั้นก็ถือว่าพวกเธอสามารถดึงความสนใจจากฉันได้แล้ว ฉันจะให้โอกาสก็แล้วกัน"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:335
translate english arc1_main_quest3_2f20b4ba:

    # hd "¡¿En serio?!"
    hd "จริงเหรอครับ?!"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:337
translate english arc1_main_quest3_dd7a312f:

    # kk "Pero, sólo si logran pasar una prueba"
    kk "แต่ว่า... ต้องผ่านบททดสอบของฉันให้ได้ซะก่อนนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:338
translate english arc1_main_quest3_9f7e7b45:

    # kk "Y se los advierto, de perderla más les vale no volver a insistir, porque no pienso hacerla de nuevo"
    kk "แล้วก็ขอเตือนไว้ก่อนเลยนะ ถ้าพวกเธอสอบตก ห้ามมาเซ้าซี้ขอร้องใหม่อีกเด็ดขาด เพราะฉันไม่คิดจะจัดให้อีกรอบแน่"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:339
translate english arc1_main_quest3_c37059ef:

    # kk "Vengan mañana por la mañana a este mismo sitio, y les aconsejo que vengan sin desayunar"
    kk "พรุ่งนี้เช้ามาเจอกันที่เดิมนี่แหละ แล้วก็แนะนำว่าไม่ต้องกินมื้อเช้ามาด้วยล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:341
translate english arc1_main_quest3_4842a8f6:

    # mn "¿Por qué sin desayunar?"
    mn "ทำไมถึงห้ามกินมื้อเช้าล่ะครับ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:343
translate english arc1_main_quest3_d0b17dea:

    # kk "No querrán saber eso"
    kk "รู้ไปตอนนี้ก็ไม่สนุกหรอก"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:345
translate english arc1_main_quest3_e7e11ecf:

    # hd "Bien, no importa"
    hd "ช่างเถอะ ยังไงก็ไม่เป็นไรอยู่แล้ว"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:347
translate english arc1_main_quest3_2a80e97b:

    # hd "¡Acepto el reto!"
    hd "ผมขอรับคำท้านั้นครับ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:350
translate english arc1_main_quest3_3912ff3c:

    # mn "Vaya, el señor entusiasmo volvió"
    mn "โอ้โห พ่อหนุ่มนักสู้กลับมาแล้วแฮะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:353
translate english arc1_main_quest3_46bb8daa:

    # hd "Le agradezco que nos haya dado una oportunidad, señor sexto"
    hd "ขอบคุณที่ให้โอกาสพวกเรานะครับ ท่านรุ่นที่หก"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:355
translate english arc1_main_quest3_5994756a:

    # hd "Mañana vendremos sin falta"
    hd "พรุ่งนี้พวกเราจะมาให้ตรงเวลาแน่นอนครับ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:357
translate english arc1_main_quest3_c79f74e8:

    # kk "Claro, nos vemos entonces"
    kk "อืม ไว้เจอกัน"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:362
translate english arc1_main_quest3_61e0b69f:

    # mn "Hasta pronto, sexto"
    mn "แล้วพบกันใหม่ครับ ท่านรุ่นที่หก"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:371
translate english arc1_main_quest3_6141228a:

    # kk "..."
    kk "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:372
translate english arc1_main_quest3_e3be8e85:

    # kk "Aah, estos jóvenes de ahora..."
    kk "เฮ้อ เด็กสมัยนี้นี่นะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:373
translate english arc1_main_quest3_4007b3f0:

    # kk "Por un momento pensé que ya no podría venir aquí a relajarme"
    kk "มีแวบหนึ่งฉันนึกว่าจะมาพักผ่อนที่นี่สงบๆ ไม่ได้ซะแล้วสิ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:375
translate english arc1_main_quest3_cc8cf668:

    # kk "Bueno, por fin puedo seguir con {b}Haciéndolo en el Paraíso{/a}"
    kk "เอาล่ะ ในที่สุดฉันก็จะได้อ่าน {b}ดูอิง อิท อิน แพราไดซ์{/a} ต่อสักที"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:376
translate english arc1_main_quest3_4699c026:

    # kk "Veamos... ¿Por dónde iba?"
    kk "ไหนดูซิ... อ่านค้างไว้ถึงไหนแล้วนะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:379
translate english arc1_main_quest3_65c4b159:

    # n "[MN] y Hideo vuelven a la aldea"
    n "[MN] และฮิเดโอะเดินทางกลับหมู่บ้าน"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:387
translate english arc1_main_quest3_7fdf4b31:

    # hd "Bien, supongo que aquí nos dividimos hasta mañana"
    hd "งั้นฉันว่าเราแยกกันตรงนี้ก่อน จนกว่าจะถึงพรุ่งนี้นะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:389
translate english arc1_main_quest3_f7db38f0:

    # hd "En verdad agradezco lo que hiciste por mí hoy"
    hd "ฉันขอบคุณจริงๆ สำหรับเรื่องที่คุณช่วยฉันในวันนี้"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:392
translate english arc1_main_quest3_630d49e3:

    # mn "No es nada"
    mn "เรื่องแค่นี้เอง"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:394
translate english arc1_main_quest3_272e0734:

    # mn "Ya verás lo fuerte que te volverás con el entrenamiento del Sexto Hokage"
    mn "นายรอดูความเก่งที่จะเพิ่มขึ้นจากการฝึกกับโฮคาเงะรุ่นที่หกได้เลย"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:397
translate english arc1_main_quest3_c0aaad89:

    # hd "Aún no cantemos victoria, hagámoslo cuando pasemos la prueba"
    hd "อย่าเพิ่งรีบวางใจเลย เอาไว้ผ่านบททดสอบให้ได้ซะก่อนค่อยคุยเถอะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest3.rpy:401
translate english arc1_main_quest3_ef32de36:

    # mn "Claro jaja, entonces nos vemos mañana"
    mn "นั่นสินะ ฮ่าๆ งั้นพรุ่งนี้เจอกัน"
