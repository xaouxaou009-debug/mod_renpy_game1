# TODO: Translation updated at 2024-03-04 17:48

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:4
translate english main_quest7_3_f85d47f6:

    # sr "Por supuesto"
    sr "แน่นอนอยู่แล้ว"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:6
translate english main_quest7_3_65c8cf22:

    # sr "Vamos al campo de entrenamiento"
    sr "ไปที่สนามฝึกกันเถอะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:9
translate english main_quest7_3_9a3b0d7d:

    # mn "Claro, vamos"
    mn "ได้เลย ไปกันเถอะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:12
translate english main_quest7_3_4f0d3e46:

    # n "[MN] y Sarada se dirigen al campo de entrenamiento"
    n "[MN] และซาราดะมุ่งหน้าไปยังสนามฝึก"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:22
translate english main_quest7_3_5b347dad:

    # sr "Bien, ya estamos aquí"
    sr "เอาล่ะ ถึงแล้ว"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:25
translate english main_quest7_3_92b961dc:

    # mn "Ahora... ¿Cómo entrenarémos la invisibilidad?"
    mn "ทีนี้... เราจะฝึกวิชาล่องหนกันยังไงดีล่ะเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:28
translate english main_quest7_3_a242e4cd:

    # sr "Pues, como cualquier otro jutsu, ¿No?"
    sr "ก็เหมือนกับวิชานินจาทั่วไปนั่นแหละ จริงไหม?"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:30
translate english main_quest7_3_915e2695:

    # sr "Solo úsalo, mientras más lo uses más rápido lo dominarás"
    sr "ก็แค่ใช้มัน ยิ่งใช้บ่อยเท่าไหร่ ก็จะยิ่งเชี่ยวชาญเร็วขึ้นเท่านั้น"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:33
translate english main_quest7_3_1e50bb1a:

    # mn "Oh, si..."
    mn "อ่า จริงด้วยสินะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:37
translate english main_quest7_3_68a74d99:

    # n "Y así... Pasaron los días"
    n "และแล้ว... วันเวลาผ่านไป"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:38
translate english main_quest7_3_6de7df76:

    # n "[MN] iba todas las noches con Sarada a entrenar su {b}Jutsu de invisibilidad{/a}"
    n "[MN] ไปฝึก {b}คาถาล่องหน{/a} กับซาราดะทุกคืน"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:39
translate english main_quest7_3_aece71d9:

    # n "Y mientras lo hacía, mejoró mucho su {b}Control de Chakra{/a}"
    n "และในระหว่างนั้น เขาก็พัฒนา {b}การควบคุมจักระ{/a} ของตัวเองขึ้นมาได้อย่างมากเช่นกัน"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:40
translate english main_quest7_3_408a4f6f:

    # n "Ahora dominando mejor su {b}Karugan{/a}, está listo para la prueba de Zubon..."
    n "Now better mastering his {b}Karugan{/a}, he is ready for Zubon's test..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:50
translate english main_quest7_3_94f7352e:

    # sr "Muy bien, este será nuestro último día de entrenamiento"
    sr "เอาล่ะ วันนี้จะเป็นวันฝึกวันสุดท้ายของเราแล้วนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:52
translate english main_quest7_3_5e2c1460:

    # sr "Así que, espero que estés listo, esta lucha no será como la primera que tuvimos"
    sr "เพราะงั้น ฉันหวังว่านายจะพร้อม การต่อสู้ครั้งนี้จะไม่เหมือนกับครั้งแรกที่เราสู้กันหรอกนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:54
translate english main_quest7_3_6053ae14:

    # sr "Quiero que me muestres que dominaste el {b}Karugan{/a}."
    sr "I want you to show me that you mastered the {b}Karugan{/a}."

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:58
translate english main_quest7_3_5ac6c624:

    # mn "Muy bien, hoy te mostraré mi {b}Nuevo Movimiento{/a}."
    mn "ได้เลย วันนี้ฉันจะแสดง {b}นิว มูฟ{/a} ให้เธอดู"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:67
translate english main_quest7_3_4c6cb48b:

    # n "[MN] se prepara para la lucha"
    n "[MN] เตรียมตัวสำหรับการต่อสู้"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:75
translate english main_quest7_3_after_battle_2364f22a:

    # n "Luego de Acabar la batalla"
    n "หลังจากการต่อสู้สิ้นสุดลง"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:85
translate english main_quest7_3_after_battle_f91fd686:

    # sr "Felicidades, esta vez luchaste mucho mejor que la vez pasada"
    sr "ยินดีด้วยนะ ครั้งนี้นายสู้ได้ดีกว่าครั้งก่อนเยอะเลย"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:87
translate english main_quest7_3_after_battle_b80a9c63:

    # sr "Ciertamente todo el entrenamiento ha dado frutos"
    sr "การฝึกทั้งหมดที่ผ่านมาคงสัมฤทธิ์ผลแล้วสินะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:89
translate english main_quest7_3_after_battle_66232131:

    # sr "Ahora si ya estás listo para la prueba de Zubon"
    sr "ตอนนี้เธอพร้อมสำหรับการทดสอบของซูบงแล้วล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:92
translate english main_quest7_3_after_battle_bf59930c:

    # mn "Muchas gracias Sarada, todo mi progreso ha sido gracias a tí"
    mn "ขอบคุณมากนะซาราดะ ที่ฉันก้าวหน้ามาได้ขนาดนี้ก็เพราะเธอเลย"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:95
translate english main_quest7_3_after_battle_71aa098d:

    # sr "No jaja, todo el mérito es tuyo"
    sr "ไม่หรอก ฮ่าๆ เครดิตทั้งหมดเป็นของนายต่างหากล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:97
translate english main_quest7_3_after_battle_5eeb648b:

    # sr "Ahora creo que ya debes irte, se nos pasó un poco el tiempo, ya es bastante tarde"
    sr "งั้นฉันว่านายควรกลับได้แล้วล่ะ เราใช้เวลาเพลินไปหน่อย ตอนนี้ดึกมากแล้วด้วย"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:100
translate english main_quest7_3_after_battle_a3a2306c:

    # mn "Si, tienes razón"
    mn "อืม นั่นสินะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:103
translate english main_quest7_3_after_battle_a16140fc:

    # sr "Bien, entonces me adelanto y me voy primero, mañana tengo que levantarme temprano"
    sr "งั้นฉันขอตัวกลับก่อนนะ พรุ่งนี้ต้องตื่นเช้าซะด้วยสิ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:106
translate english main_quest7_3_after_battle_20e698f2:

    # mn "Está bien, te veo luego entonces"
    mn "โอเค ไว้เจอกันนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:109
translate english main_quest7_3_after_battle_bf28507b:

    # sr "Nos vemos"
    sr "ไว้เจอกัน"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:112
translate english main_quest7_3_after_battle_1b9a44f1:

    # n "Sarada se va del campo de entrenamiento"
    n "ซาราดะเดินออกจากสนามฝึก"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:116
translate english main_quest7_3_after_battle_a1d3c8b8:

    # mn "Aaah, jamás creí que podía darle batalla a Sarada"
    mn "อ่าห์ ไม่เคยคิดเลยนะเนี่ยว่าจะได้สู้กับซาราดะจริงๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:119
translate english main_quest7_3_after_battle_58d95f12:

    # mn "Supongo que estoy avanzando"
    mn "ฉันคงกำลังพัฒนาขึ้นสินะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:121
translate english main_quest7_3_after_battle_043fc9a6:

    # mn "Debo seguir así"
    mn "ต้องรักษามาตรฐานแบบนี้ไว้ให้ได้"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:125
translate english main_quest7_3_after_battle_ae667afd:

    # mn "¿Hmm?"
    mn "หืม?"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:128
translate english main_quest7_3_after_battle_4b0bdbd1:

    # mn "¿Quién será?"
    mn "ใครกันนะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:142
translate english main_quest7_3_after_battle_15f677c9:

    # mn "Así que será mañana..."
    mn "งั้นก็เอาไว้พรุ่งนี้สินะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:146
translate english main_quest7_3_after_battle_695138ff:

    # mn "Maldita sea, tengo que irme rápido a dormir"
    mn "แย่ล่ะ รีบไปนอนดีกว่า"

# TODO: Translation updated at 2024-11-29 23:49

# game/scripts/History/PrincipalStory/Arco1/main_quest7_3.rpy:4
translate english main_quest7_3_0210ee62:

    # sr "Por supuesto" with dissolve1
    sr "แน่นอนอยู่แล้ว!" with dissolve1
