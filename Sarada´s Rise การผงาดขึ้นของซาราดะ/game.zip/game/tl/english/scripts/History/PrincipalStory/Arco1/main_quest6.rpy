# TODO: Translation updated at 2024-03-04 17:48

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:4
translate english main_quest6_65fcd2be:

    # mn "De hecho... Te estaba buscando"
    mn "อันที่จริง... ฉันกำลังตามหาเธออยู่พอดีเลย"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:6
translate english main_quest6_b7385478:

    # mn "Quería que me siguieras enseñando como usar mejor mi Sharingan"
    mn "ฉันอยากให้เธอช่วยสอนวิธีใช้เนตรวงแหวนให้เก่งขึ้นอีกหน่อยน่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:9
translate english main_quest6_bd505e46:

    # sr "Mmmm..."
    sr "อืม..."

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:11
translate english main_quest6_907395bf:

    # sr "Te tengo una pregunta..."
    sr "ฉันมีเรื่องจะถามเธอหน่อย..."

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:13
translate english main_quest6_45c9e434:

    # sr "¿Qué tal se te dan los genjutsus?"
    sr "เธอถนัดเรื่องคาถาภาพลวงตาแค่ไหนกัน?"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:16
translate english main_quest6_7a2b11df:

    # mn "Pues... Domino los básicos diría yo"
    mn "ก็... น่าจะพอใช้พื้นฐานได้คล่องแล้วล่ะมั้ง"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:19
translate english main_quest6_ecbbbc5c:

    # sr "Ya veo... Entonces no sabes que el Sharingan también te da acceso a un pequeño repertorio de Genjutsu"
    sr "งั้นเหรอ... งั้นเธอก็คงยังไม่รู้สินะว่าเนตรวงแหวนเนี่ย มันใช้คาถาภาพลวงตาพื้นฐานได้อีกหลายท่าเลย"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:23
translate english main_quest6_094ad747:

    # mn "Eh, no lo sabía"
    mn "เอ๊ะ ฉันไม่รู้มาก่อนเลยนะเนี่ย"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:26
translate english main_quest6_d3b61a3b:

    # mn "¿Como cuales?"
    mn "อย่างเช่นท่าไหนบ้างล่ะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:49
translate english main_quest6_38c86c8e:

    # mn "¿Qué?"
    mn "อะไรนะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:52
translate english main_quest6_341d5e62:

    # d "Oye, [MN]"
    d "เฮ้ [MN]"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:55
translate english main_quest6_322ad384:

    # mn "Y-Yuna..."
    mn "ย-ยูนะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:58
translate english main_quest6_1fc0884a:

    # d "Discúlpame por tardarme"
    d "ขอโทษทีที่มาสายนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:59
translate english main_quest6_8c6373c9:

    # d "Me atrasé por ayudarle a mi mamá con la mudanza"
    d "ฉันมัวแต่ช่วยแม่ขนของย้ายบ้านอยู่น่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:61
translate english main_quest6_38c86c8e_1:

    # mn "¿Qué?"
    mn "อะไรนะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:63
translate english main_quest6_38ebb361:

    # yn "¿Qué sucede?"
    yn "มีอะไรเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:66
translate english main_quest6_e7000c82:

    # mn "No, nada..."
    mn "เปล่า ไม่มีอะไร..."

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:68
translate english main_quest6_be32f7f5:

    # mn "Es solo que..."
    mn "ก็แค่..."

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:69
translate english main_quest6_c7084470:

    # mn "(Algo aquí no me cuadra)"
    mn "(มีบางอย่างแปลกๆ แฮะ)"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:71
translate english main_quest6_e5d318f5:

    # yn "¿Ya pediste algo?"
    yn "พวกเธอสั่งอะไรกันไปหรือยังเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:73
translate english main_quest6_f926d76f:

    # yn "¿O me estabas esperando?"
    yn "รึว่ารอฉันกันอยู่เหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:76
translate english main_quest6_b96df3f3:

    # ay "Eh, no... Acabo de llegar... Supongo"
    ay "เอ่อ เปล่าจ่ะ... ฉันเพิ่งมาถึงเนี่ย... น่าจะนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:79
translate english main_quest6_6ea76f25:

    # yn "Muy bien, entonces... Ayame, ya pediremos nuestra órden"
    yn "งั้นเหรอ... งั้นอายาเมะ เดี๋ยวเราไปสั่งของกันเถอะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:84
translate english main_quest6_fdc081a0:

    # ay "Claro, ¿Qué pedirán?"
    ay "ได้สิ แล้วพวกเธอจะสั่งอะไรกันล่ะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:87
translate english main_quest6_ab15ec37:

    # yn "Pediremos lo de siempre"
    yn "เดี๋ยวพวกเราสั่งเหมือนเดิมละกัน"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:90
translate english main_quest6_97c75329:

    # ay "A la órden"
    ay "รับทราบ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:95
translate english main_quest6_b3ecb4b5:

    # yn "Yo los pagaré esta vez"
    yn "เดี๋ยวรอบนี้ฉันเลี้ยงเอง"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:98
translate english main_quest6_b9f3a165:

    # mn "¿Qué? No, no permitiré eso"
    mn "หา? ไม่เอาหรอก ฉันไม่ยอมให้เธอเลี้ยงหรอกน่า"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:101
translate english main_quest6_b577e92a:

    # yn "Tranquilo, no es un problema para mí pagar la comida por hoy"
    yn "ไม่ต้องห่วงน่า วันนี้ฉันจ่ายค่าอาหารเอง ไม่มีปัญหาอยู่แล้ว"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:104
translate english main_quest6_2df8ec9d:

    # mn "No es eso, es sólo qué..."
    mn "ไม่ใช่เรื่องนั้นซะหน่อย แต่ว่า..."

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:107
translate english main_quest6_c1abfc6e:

    # "(*Celular vibrando*)"
    "(*เสียงโทรศัพท์มือถือสั่น*)"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:109
translate english main_quest6_761c4045:

    # yn "¿Eso es...?"
    yn "นั่นมัน...?"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:111
translate english main_quest6_ec35d6a6:

    # yn "¡¿Un teléfono?!"
    yn "โทรศัพท์เหรอ?!"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:114
translate english main_quest6_a4bca366:

    # mn "Sí... debe ser"
    mn "อืม... น่าจะใช่นะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:117
translate english main_quest6_5d4bb4bc:

    # yn "¡Enseñamelo!"
    yn "ขอดูหน่อยสิ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:120
translate english main_quest6_e44686d5:

    # mn "Ah, claro..."
    mn "อ่า ได้สิ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:122
translate english main_quest6_02a8bd03:

    # n "[MN] le presta a Yuna su teléfono"
    n "[MN] ยื่นโทรศัพท์ให้ยูนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:124
translate english main_quest6_c603755e:

    # yn "¡Wow... Es un último modelo!"
    yn "โห... รุ่นล่าสุดเลยนี่นา!"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:126
translate english main_quest6_fbec2965:

    # yn "Acércate un segundo"
    yn "เข้ามาใกล้ๆ แป๊บนึงสิ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:129
translate english main_quest6_76c7960a:

    # mn "¿Para qué?"
    mn "เอาไปทำไมเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:132
translate english main_quest6_f9631bcc:

    # yn "¡Hay que tomarnos una foto!"
    yn "พวกเราต้องถ่ายรูปกันหน่อยแล้ว!"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:134
translate english main_quest6_55f41aaf:

    # yn "Querrás hacerlo para antes que termine el día, créeme"
    yn "เธอจะต้องอยากถ่ายก่อนหมดวันแน่ เชื่อฉันสิ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:137
translate english main_quest6_d957c28a:

    # mn "¿Qué pasará cuando termine el día?"
    mn "จะเกิดอะไรขึ้นเหรอพอหมดวันไปแล้วเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:140
translate english main_quest6_c657f69f:

    # yn "Vamos, haz una pose para la foto"
    yn "น่า เร็วเข้า โพสท่าถ่ายรูปหน่อยสิ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:143
translate english main_quest6_33e3f64e:

    # mn "E-Está bien, está bien"
    mn "ด-ได้ๆ ๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:148
translate english main_quest6_04ef6a96:

    # mn "¿Lo hago bien?"
    mn "ฉันทำถูกท่าใช่ไหมเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:152
translate english main_quest6_5cec0024:

    # yn "Lo haces perfecto..."
    yn "เธอทำได้เป๊ะมากเลย..."

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:156
translate english main_quest6_75050f58:

    # mn "¿Sabes?"
    mn "เธอนี่รู้ไหม?"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:159
translate english main_quest6_abdc4041:

    # mn "Por alguna razón siento que..."
    mn "ไม่รู้ทำไม อยู่ๆ ฉันก็รู้สึกเหมือนกับว่า..."

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:176
translate english main_quest6_7b49a8b0:

    # mn "¡Aah!"
    mn "อ๊าก!"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:183
translate english main_quest6_8701d992:

    # sr "Bien, ya estás de vuelta"
    sr "โอเค กลับมาแล้วสินะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:185
translate english main_quest6_722662d3:

    # sr "¿Qué tal estuvo?"
    sr "เป็นไงบ้างล่ะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:188
translate english main_quest6_89fe90f8:

    # mn "E-Eso..."
    mn "ม-เมื่อกี้...นั่น..."

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:190
translate english main_quest6_7735a196:

    # mn "¿Qué fue lo que hiciste?"
    mn "เธอทำอะไรลงไปเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:192
translate english main_quest6_db83fcef:

    # sr "Te atrapé en un Genjutsu"
    sr "ฉันก็ขังนายไว้ในคาถาภาพลวงตาไงล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:194
translate english main_quest6_27f2e301:

    # sr "Puedo hacer que veas lo que yo quiera, o incluso hacerte vivir nuevamente algún recuerdo"
    sr "ฉันจะทำให้นายเห็นอะไรตามที่ต้องการก็ได้ หรือแม้แต่ให้ย้อนกลับไปสัมผัสความทรงจำเดิมอีกครั้งก็ได้นะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:196
translate english main_quest6_8e0a2365:

    # sr "Esta vez me aseguré que fuera un recuerdo feliz"
    sr "แต่รอบนี้ฉันมั่นใจนะว่าเป็นความทรงจำที่มีความสุข"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:198
translate english main_quest6_78f84afc:

    # sr "No tengo la menor idea de que viste, pero gracias a que te atrapé, pude copilar algo de información sobre ti"
    sr "ฉันไม่รู้หรอกนะว่านายเห็นอะไรไปบ้าง แต่เพราะฉันจับนายได้เนี่ยแหละ ทำให้ฉันได้ข้อมูลเกี่ยวกับนายมาเพียบเลยล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:201
translate english main_quest6_006ec39b:

    # mn "¿Información?"
    mn "ข้อมูลเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:203
translate english main_quest6_57cae985:

    # mn "¿Qué información?"
    mn "ข้อมูลอะไรล่ะนั่น?"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:208
translate english main_quest6_5a82dfc8:

    # sr "Ahora sé, que tienes calzoncillos de corazones, hacen que te veas aún más rudo"
    sr "ตอนนี้ฉันรู้แล้วล่ะว่านายใส่กางเกงในลายหัวใจ ยิ่งทำให้นายดูแข็งแกร่งเข้าไปใหญ่เลยนะเนี่ย"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:214
translate english main_quest6_e54fb81d:

    # mn "¡O-Oye, Sarada!"
    mn "เ-เฮ้ย ซาราดะ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:216
translate english main_quest6_1cd75f8a:

    # sr "Jajaja, deberías de ver tu cara"
    sr "ฮ่าๆๆ อยากให้นายได้เห็นหน้าตัวเองตอนนี้จัง"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:220
translate english main_quest6_af690b4e:

    # mn "Sarada, ¿Qué significa esto?"
    mn "ซาราดะ นี่มันหมายความว่ายังไงกันเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:223
translate english main_quest6_68cbd71a:

    # sr "Tienes que aprender a usar los Genjutsu del Sharingan"
    sr "นายต้องเรียนรู้วิธีใช้คาชาภาพลวงตาของเนตรวงแหวนนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:225
translate english main_quest6_ca378d88:

    # sr "Te puede dar una gran ventaja en combate"
    sr "มันช่วยให้ได้เปรียบในการต่อสู้มากๆ เลยล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:227
translate english main_quest6_703949f5:

    # sr "Sólo con establecer contacto visual, un poco de chakra y enfocarte en lo que quieres que tu enemigo vea"
    sr "แค่สบตากัน ใช้จักระนิดหน่อย แล้วก็เพ่งสมาธิไปที่สิ่งที่นายอยากให้ศัตรูเห็นก็พอ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:230
translate english main_quest6_a9b50da4:

    # mn "C-Claro..."
    mn "อ-อ๋อ... งั้นเหรอ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:233
translate english main_quest6_c2641cf3:

    # sr "Lo dominarás por tu cuenta, no te preocupes"
    sr "เดี๋ยวนายก็เก่งขึ้นได้เองแหละ น่า ไม่ต้องห่วงหรอก"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:235
translate english main_quest6_9a6d9552:

    # sr "Fuera de eso, no hay mucho más acerca del Sharingan que pueda enseñarte"
    sr "นอกเหนือจากนี้ ฉันก็ไม่มีอะไรจะสอนเกี่ยวกับเนตรวงแหวนให้อีกแล้วล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:238
translate english main_quest6_bbd3b859:

    # mn "Entiendo, supongo que el resto depende de mí"
    mn "เข้าใจแล้ว ที่เหลือก็คงต้องขึ้นอยู่กับตัวฉันสินะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:241
translate english main_quest6_603d98bd:

    # sr "Así es"
    sr "ถูกต้องแล้วล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:244
translate english main_quest6_71ad30f1:

    # sr "Por cierto, ya puedes subirte el pantalon jaja"
    sr "ว่าแต่ นายดึงกางเกงขึ้นได้แล้วนะ ฮ่าๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:247
translate english main_quest6_b94611b8:

    # mn "¡Ah, c-cierto!"
    mn "อะ อ๋อ เออจริงด้วย!"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:252
translate english main_quest6_50b899c7:

    # "[MN] se sube los pantalones..."
    "[MN] ดึงกางเกงขึ้นสวม..."

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:257
translate english main_quest6_73806718:

    # mn "L-Listo..."
    mn "พ-พร้อมแล้ว..."

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:260
translate english main_quest6_7d0782b7:

    # sr "Bien jaja"
    sr "ดีมาก ฮ่าๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:262
translate english main_quest6_00862bef:

    # sr "Ahora, ¿Qué hay de tu otro ojo?"
    sr "ทีนี้ แล้วตาอีกข้างล่ะเป็นยังไงบ้าง?"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:264
translate english main_quest6_7f98c30d:

    # sr "¿Ya lo dominas?"
    sr "ควบคุมมันได้หรือยังล่ะเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:267
translate english main_quest6_ea155df3:

    # mn "No... Aún no soy capaz de activarlo a voluntad..."
    mn "ยังเลย... ฉันยังเปิดใช้งานมันตามใจชอบไม่ได้เลย..."

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:270
translate english main_quest6_56920035:

    # sr "Entiendo..."
    sr "งั้นเหรอ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:272
translate english main_quest6_932ea69c:

    # sr "¿Sabes? Me da mucha curiosidad saber de lo que es capaz el Karugan"
    sr "รู้อะไรไหม? ฉันอยากรู้จริงๆ เลยนะว่าคารูกันเนี่ยมันมีความสามารถอะไรบ้าง"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:275
translate english main_quest6_de3e757b:

    # sr "¿Qué te parece si para la próxima nos enfocamos en él?"
    sr "งั้นคราวหน้าเรามาลองเน้นเรื่องนี้กันดีไหมล่ะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:277
translate english main_quest6_b65f7def:

    # sr "Dos cabezas piensan mejor que una, tal vez con mi ayuda puedas terminar de entenderlo"
    sr "สองหัวย่อมดีกว่าหัวเดียว บางทีถ้าฉันช่วย อาจจะทำให้นายเข้าใจมันได้ดีขึ้นก็ได้นะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:280
translate english main_quest6_7a0a19c8:

    # mn "Eso estaría genial, me encantaría que me ayudaras"
    mn "เยี่ยมเลย งั้นรบกวนเธอช่วยฉันหน่อยนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:283
translate english main_quest6_5b3e8ab2:

    # sr "Bueno, Entonces nos vemos mañana por la mañana"
    sr "งั้นไว้เจอกันพรุ่งนี้นะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:286
translate english main_quest6_a23853c1:

    # mn "¿Ya te vas?"
    mn "จะกลับแล้วเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:289
translate english main_quest6_c876a35e:

    # sr "Si, tengo que ir a la tienda de Tenten"
    sr "อืม ฉันต้องไปร้านของเท็นเท็นน่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:292
translate english main_quest6_090c780f:

    # mn "¿La tienda de Tenten?"
    mn "ร้านของเท็นเท็นงั้นเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:295
translate english main_quest6_5f2e2a77:

    # sr "Sí, ella tiene todo tipo de armas ninja, necesito comprar equipo para mi próxima misión"
    sr "ใช่ ที่นั่นมีอาวุธนินทร์สารพัดเลย ฉันต้องไปซื้ออุปกรณ์สำหรับภารกิจหน้าน่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:297
translate english main_quest6_b6f5e25f:

    # sr "Te aconsejo que vayas en algún momento por si necesitas mejorar o comprar más herramientas"
    sr "ฉันแนะนำให้นายแวะไปดูสักหน่อยนะ เผื่อจะต้องอัปเกรดหรือซื้ออุปกรณ์เพิ่มน่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:300
translate english main_quest6_29e3be9c:

    # mn "Lo tendré en mente"
    mn "อืม จะจำไว้ละกัน"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:303
translate english main_quest6_cafac1ed:

    # sr "Nos vemos entonces, te espero aquí mañana"
    sr "งั้นแค่นี้ก่อนนะ เดี๋ยวฉันรอนายอยู่ที่นี่พรุ่งนี้"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:307
translate english main_quest6_100a5279:

    # mn "Nos vemos"
    mn "แล้วเจอกัน"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:311
translate english main_quest6_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:313
translate english main_quest6_da407b01:

    # mn "Ese Genjutsu de Sarada..."
    mn "ภาพลวงตาของซาราดะอันนั้น..."

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:315
translate english main_quest6_1095836d:

    # mn "Así que un recuerdo feliz..."
    mn "มันเป็นความทรงจำที่มีความสุขจริงๆ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:318
translate english main_quest6_5383a916:

    # mn "Una parte de mí no quisiera recordar"
    mn "ส่วนหนึ่งในตัวฉันก็ไม่อยากจะจำมันเลย"

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:319
translate english main_quest6_cde8e6e8:

    # mn "Pero... la otra la otra parte..."
    mn "แต่... อีกส่วนหนึ่ง..."

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:323
translate english main_quest6_32462c4b_1:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:325
translate english main_quest6_6048802d:

    # mn "Jamás dejará de hacerlo..."
    mn "กลับหยุดคิดถึงมันไม่ได้เลย..."


# game/scripts/History/PrincipalStory/Arco1/main_quest6.rpy:4
translate english main_quest6_d78890e8:

    # mn "De hecho... Te estaba buscando" with dissolve1
    mn "จริงๆ แล้ว... ฉันกำลังตามหาเธออยู่พอดีเลย" with dissolve1
