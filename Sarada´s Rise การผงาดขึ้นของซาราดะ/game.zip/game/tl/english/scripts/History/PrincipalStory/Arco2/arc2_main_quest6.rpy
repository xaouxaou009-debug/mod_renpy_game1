# TODO: Translation updated at 2024-12-01 21:25

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:6
translate english arc2_main_quest6_3debe9ce:

    # n "Es viernes al Medio Día, y [MN] se dirige hacia la casa de Sarada y Sakura"
    n "ตอนนี้เป็นเวลาเที่ยงวันของวันศุกร์ และ [MN] กำลังมุ่งหน้าไปยังบ้านของซาราดะและซากุระ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:7
translate english arc2_main_quest6_9944bab4:

    # n "[MN] entra a la casa y es recibido por Sarada"
    n "[MN] เดินเข้าบ้านไปและได้รับการต้อนรับจากซาราดะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:19
translate english arc2_main_quest6_e8577c13:

    # mn "Hola Sarada, buenos días"
    mn "สวัสดีซาราดะ อรุณสวัสดิ์"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:20
translate english arc2_main_quest6_a6c74d58:

    # sr "[MN]! Justo a tiempo, pasa, Mamá está terminando de arreglarse"
    sr "[MN]! มาได้เวลาพอดีเลย เข้ามาข้างในก่อนสิ แม่ใกล้จะแต่งตัวเสร็จแล้วล่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:21
translate english arc2_main_quest6_38adb02f:

    # sr "No debería tardar en llegar"
    sr "อีกแป๊บเดียวก็คงเสร็จแล้วล่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:22
translate english arc2_main_quest6_8a05f293:

    # sr "Podémos esperarla en la Sala si gustas"
    sr "ถ้าเธออยาก จะไปรอที่ห้องนั่งเล่นก่อนก็ได้นะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:23
translate english arc2_main_quest6_dfe13314:

    # mn "Claro"
    mn "ได้สิ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:26
translate english arc2_main_quest6_247b03e4:

    # n "[MN] se dirige a la Sala de estar con Sarada para esperar a que Sakura termine de alistarse"
    n "[MN] เดินไปที่ห้องนั่งเล่นกับซาราดะเพื่อรอให้ซากุระเตรียมตัวให้เสร็จ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:27
translate english arc2_main_quest6_255e678e:

    # n "Unos minutos después, Sakura hace presencia"
    n "อีกไม่กี่นาทีต่อมา ซากุระก็ปรากฏตัวขึ้น"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:38
translate english arc2_main_quest6_bc670ba2:

    # sk "[MN], buenos días"
    sk "[MN] อรุณสวัสดิ์จ้ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:39
translate english arc2_main_quest6_54163871:

    # sk "Siento la demora, ¿Los hice esperar mucho?"
    sk "ขอโทษที่ให้รอนะ ฉันทำให้รอนานหรือเปล่าจ๊ะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:40
translate english arc2_main_quest6_7adf01fd:

    # mn "Para nada, acabo de llegar"
    mn "ไม่เลยครับ ผมเพิ่งมาถึงเอง"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:41
translate english arc2_main_quest6_d8b9cc38:

    # sk "Bien, entonces, ¿Qué tal si nos vamos ya?"
    sk "งั้นเราไปกันเลยดีไหมจ๊ะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:42
translate english arc2_main_quest6_9ed612dd:

    # sr "Bien, vámonos!"
    sr "งั้นก็ไปกันเลย!"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:45
translate english arc2_main_quest6_bb953730:

    # n "Luego de que Sakura aparece, todos parten hacia las {b}Aguas Termales{/a}"
    n "หลังจากซากุระปรากฏตัว ทั้งหมดก็มุ่งหน้าไปยัง {b}บ่อน้ำร้อน{/a}"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:56
translate english arc2_main_quest6_2fdbedb2:

    # sk "Llegamos, hace mucho que no tengo la oportunidad de venir aquí"
    sk "ถึงสักที นานมากเลยนะเนี่ยที่แม่ไม่ได้มีโอกาสมาที่นี่เลย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:57
translate english arc2_main_quest6_92c4939e:

    # sr "Yo tampoco, con todo el trabajo que he tenido últimamente no he podido"
    sr "หนูก็เหมือนกันค่ะ ช่วงนี้งานยุ่งมากจนไม่ได้มาเลย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:59
translate english arc2_main_quest6_eac2bfbf:

    # sr "No puedo esperar para relajarme"
    sr "อดใจรอที่จะผ่อนคลายไม่ไหวแล้วล่ะค่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:61
translate english arc2_main_quest6_58489ce0:

    # mn "Creo que soy el único que nunca ha ido a un lugar como este jaja..."
    mn "ผมว่าผมน่าจะเป็นคนเดียวที่ไม่เคยมาที่แบบนี้เลยมั้งครับเนี่ย ฮ่า..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:66
translate english arc2_main_quest6_8f2ba430:

    # sk "¿En serio? ¿Nunca has estado en unas aguas termales antes?"
    sk "จริงเหรอ? เธอไม่เคยมาบ่อน้ำร้อนมาก่อนเลยเหรอน่ะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:67
translate english arc2_main_quest6_75956039:

    # mn "Nunca... No tengo idea de cómo va esto jaja..."
    mn "ไม่เคยเลยครับ... ผมไม่รู้เลยว่าต้องทำยังไงบ้าง ฮ่า..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:70
translate english arc2_main_quest6_2e4e5ef2:

    # sr "Bueno jaja, es más simple de lo que parece, déjame te explico"
    sr "งั้นเหรอ ฮ่าๆ มันง่ายกว่าที่คิดไว้นะ เดี๋ยวฉันอธิบายให้ฟังเอง"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:76
translate english arc2_main_quest6_85ca373f:

    # n "Sarada y Sakura le explican a [MN] las reglas básicas y como funcionan las aguas termales"
    n "ซาราดะและซากุระอธิบายกฎพื้นฐานและวิธีใช้บริการบ่อน้ำร้อนให้ [MN] ฟัง"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:79
translate english arc2_main_quest6_a230a342:

    # sr "Y así es como funciona, ¿Es simple no?"
    sr "ก็ประมาณนี้แหละ ง่ายใช่ไหมล่ะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:80
translate english arc2_main_quest6_be6e331d:

    # mn "Si, ahora entiendo jaja... No hay pérdida"
    mn "ครับ ตอนนี้เข้าใจแล้วล่ะ ฮ่า... ไม่มีทางหลงแน่นอน"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:81
translate english arc2_main_quest6_c6be666b:

    # sr "Bien, entonces aquí es donde nos separamos"
    sr "งั้นตรงนี้ก็คงต้องแยกย้ายกันสินะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:82
translate english arc2_main_quest6_c105eedc:

    # sr "Tú vas por allá el vestuario para hombres, es el que está en la izquierda y luego sales a las aguas termales de hombre o a las mixtas"
    sr "เธอไปห้องเปลี่ยนเสื้อผ้าชายตรงนู้นเลยนะ ทางซ้ายมือ แล้วค่อยออกไปบ่อน้ำร้อนชายหรือบ่อรวมก็ได้"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:83
translate english arc2_main_quest6_ad4426cc:

    # sk "Nosotras irémos a las aguas de mujeres, más tarde nos reunimos aquí"
    sk "พวกเราจะไปบ่อน้ำร้อนหญิงนะ เดี๋ยวค่อยมาเจอกันตรงนี้จ้ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:84
translate english arc2_main_quest6_bb153b00:

    # mn "De acuerdo, entonces nos vemos luego"
    mn "รับทราบครับ งั้นเดี๋ยวเจอกันครับ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:87
translate english arc2_main_quest6_569779ad:

    # n "Sakura y Sarada se despiden y se dirigen hacia el vestuario femenino, mientras [MN] se dirige al vestidor de hombres"
    n "ซากุระและซาราดะกล่าวลาแล้วมุ่งหน้าไปยังห้องเปลี่ยนเสื้อผ้าหญิง ส่วน [MN] เดินไปที่ห้องเปลี่ยนเสื้อผ้าชาย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:88
translate english arc2_main_quest6_9385a42c:

    # n "-{b}Mientras tanto en el Vestidor de Mujeres{/a}-"
    n "-{b}ในขณะเดียวกัน ณ ห้องเปลี่ยนเสื้อผ้าหญิง{/a}-"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:89
translate english arc2_main_quest6_36ffba97:

    # n "Sarada y Sakura se preparaban para salir a las termas"
    n "ซาราดะและซากุระกำลังเตรียมตัวเพื่อลงแช่น้ำร้อน"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:97
translate english arc2_main_quest6_7082eaba:

    # sr "No puedo creerlo, al fin un momento para respirar..."
    sr "ไม่อยากจะเชื่อเลย ในที่สุดก็ได้มีเวลาหายใจหายคอสักที..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:98
translate english arc2_main_quest6_4b1551cc:

    # sr "Y sin tener que pensar en entrenamientos o en los preparativos de los Exámenes"
    sr "แถมยังไม่ต้องมาคอยคิดเรื่องฝึกซ้อมหรือเตรียมตัวสอบเลยด้วย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:99
translate english arc2_main_quest6_dc073890:

    # n "Mientras ambas hablaban, poco a pocos se iban privando de su ropa..."
    n "ขณะที่พวกเธอกำลังคุยกัน ก็ค่อยๆ ถอดเสื้อผ้าออก..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:103
translate english arc2_main_quest6_6212c177:

    # sk "*Suspira* Si..." with dissolve1
    sk "*ถอนหายใจ* นั่นสินะ..." with dissolve1

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:104
translate english arc2_main_quest6_b373ccef:

    # sk "Hace semanas que no tenemos ni un rato para relajarnos"
    sk "หลายสัปดาห์แล้วที่เราไม่ได้มีเวลาพักผ่อนแบบนี้เลย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:105
translate english arc2_main_quest6_ff16473d:

    # sk "Entre las horas extra en el hospital y todo tu entrenamiento con [MN] y los preparativos de los Exámenes Chunin..."
    sk "ทั้งเวลาเข้าเวรที่โรงพยาบาลที่เพิ่มขึ้น การฝึกซ้อมทั้งหมดของลูกกับ [MN] และการเตรียมตัวสอบจูนิน..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:106
translate english arc2_main_quest6_06d35a50:

    # sr "Sí, me ha absorbido completamente"
    sr "นั่นสินะคะ เล่นเอาซะหมดแรงไปเลย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:109
translate english arc2_main_quest6_fd70648f:

    # sr "Aunque, no me arrepiento, [MN] ha mejorado mucho estas semanas" with dissolve1
    sr "แต่ว่าหนูก็ไม่ได้เสียใจหรอกนะ ช่วงหลายสัปดาห์นี้ [MN] พัฒนาขึ้นเยอะเลยล่ะค่ะ" with dissolve1

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:110
translate english arc2_main_quest6_67e04bf6:

    # sr "Aunque tengo que admitir que entrenar con él ha sido agotador..."
    sr "แต่ก็ต้องยอมรับเลยว่าการฝึกกับเขานี่เล่นเอาเหนื่อยเอาเรื่องเหมือนกัน..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:111
translate english arc2_main_quest6_f800a962:

    # sr " Tú tampoco has tenido descanso, ¿Cierto?"
    sr "ลูกเองก็ไม่ได้พักผ่อนเลยเหมือนกันสินะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:116
translate english arc2_main_quest6_b3df12ab:

    # sk "Ni un solo día..." with dissolve1
    sk "ไม่ได้พักเลยสักวัน..." with dissolve1

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:117
translate english arc2_main_quest6_505f0b1a:

    # sk "Pero es parte del trabajo, aunque ya necesitaba un momento de calma, esto es un lujo"
    sk "แต่มันก็เป็นส่วนหนึ่งของงานนั่นแหละ ถึงแม่จะอยากได้ช่วงเวลาสงบๆ สักหน่อย แต่การได้มาทำแบบนี้ก็ถือเป็นความสุขหรูหราเลยล่ะนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:118
translate english arc2_main_quest6_aef2a475:

    # sr "Bueno, es un pequeño capricho que nos pudímos dar, Después de tantas semanas de entrenamientos y trabajo... Creo que ambas lo merecemos"
    sr "นั่นสินะคะ ถือว่าเป็นรางวัลเล็กๆ น้อยๆ ให้กับตัวเอง หลังจากฝึกซ้อมและทำงานมาหลายสัปดาห์... หนูว่าพวกเราสมควรได้รับมันแล้วล่ะค่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:120
translate english arc2_main_quest6_ab13bcb3:

    # n "Mientras ambas charlaban, ambas se iban desvistiendo poco a poco"
    n "ระหว่างที่พวกเธอกำลังคุยกัน ก็ค่อยๆ ถอดเสื้อผ้าออกทีละนิด..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:121
translate english arc2_main_quest6_d67a9ac3:

    # n "Hasta quedar completamente desnudas..."
    n "จนกระทั่งเปลือยเปล่าไร้ซึ่งอาภรณ์..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:135
translate english arc2_main_quest6_5b0f3024:

    # sr "Me gusta como está mi cabello hoy"
    sr "ฉันชอบทรงผมของตัวเองวันนี้จังเลยค่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:137
translate english arc2_main_quest6_d6044b39:

    # sr "Aunque he dudado mucho si dejarmelo así más tiempo, no sé si dejarlo corto o largo" with dissolve1
    sr "แม้ว่าฉันจะลังเลอยู่ว่าควรจะไว้แบบนี้ต่อไปอีกหน่อยดีไหม ระหว่างไว้สั้นหรือไว้รยาวดีน่ะค่ะ" with dissolve1

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:138
translate english arc2_main_quest6_d9d98107:

    # sk "Yo te lo voy muy bien, ya sea con el cabello largo o corto"
    sk "ลูกดูดีมากเลยนะ ไม่ว่าจะไว้ผมยาวหรือผมสั้นก็ตาม"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:140
translate english arc2_main_quest6_98578e86:

    # sk "Aún así, cada día estás más hermosa Hija"
    sk "ถึงอย่างนั้น ทุกวันนี้ลูกก็ยิ่งดูสวยขึ้นเรื่อยๆ เลยนะจ๊ะ ลูกสาวของแม่"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:144
translate english arc2_main_quest6_20b77af1:

    # sr "M-mamá, no digas eso... Me haces sentir avergonzada"
    sr "มะ-แม่คะ อย่าพูดแบบนั้นสิคะ... หนูเขินนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:145
translate english arc2_main_quest6_0b244e1d:

    # sk "Pero es la verdad"
    sk "แต่ว่ามันคือเรื่องจริงนี่จ๊ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:146
translate english arc2_main_quest6_f12b65d6:

    # sk "Eres una joven hermosa, fuerte y muy capaz"
    sk "ลูกเป็นผู้หญิงที่งดงาม แข็งแกร่ง และมีความสามารถมากๆ เลยนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:147
translate english arc2_main_quest6_81e6e9ab:

    # sk "Mira que con tu edad eres la primera candidata a convertirte en la próxima Hokage"
    sk "ดูสิ ในวัยเท่านี้ ลูกก็เป็นตัวเก็งอันดับหนึ่งที่จะได้เป็นโฮคาเงะคนต่อไปแล้วนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:148
translate english arc2_main_quest6_c3189687:

    # sk "Todos estos años te haz esforzado mucho para llegar a este punto"
    sk "ตลอดหลายปีที่ผ่านมา ลูกทำงานหนักมาตลอดเพื่อมาให้ถึงจุดนี้นะจ๊ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:151
translate english arc2_main_quest6_da840978:

    # sk "Me siento muy orgullosa de ti..." with dissolve1
    sk "แม่ภูมิใจในตัวลูกจริงๆ..." with dissolve1

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:153
translate english arc2_main_quest6_9d0e2314:

    # sr "Gracias Mamá..."
    sr "ขอบคุณค่ะแม่..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:155
translate english arc2_main_quest6_c2126337:

    # sk "Como pasa el tiempo... Ya eres toda una adulta..."
    sk "เวลาผ่านไปเร็วเหลือเกิน... ตอนนี้ลูกโตเป็นสาวเต็มตัวแล้วสินะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:156
translate english arc2_main_quest6_c0c6d6e6:

    # sk "Mírate, ya toda una mujer..."
    sk "ดูสิเนี่ย โตเป็นสาวเต็มตัวแล้วจริงๆ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:161
translate english arc2_main_quest6_b46298bb:

    # sk "¡Solo mira como has crecido aquí!" with vpunch
    sk "ดูตรงนี้สิว่าลูกโตขึ้นขนาดไหนแล้ว!" with vpunch

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:162
translate english arc2_main_quest6_04c4796d:

    # sr "¡M-Mamá!"
    sr "มะ-แม่คะ!"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:163
translate english arc2_main_quest6_a191ac30:

    # sr "¡¿Q-Qué haces?!"
    sr "ะ-ทำอะไรอยู่เนี่ย?!"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:164
translate english arc2_main_quest6_267813ce:

    # sk "Solo estoy apreciando mi obre maestra, solo míralos"
    sk "แม่ก็แค่กำลังชื่นชมผลงานชิ้นเอกของตัวเองอยู่ ดูพวกมันสิ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:165
translate english arc2_main_quest6_1c6c25c3:

    # sk "Mmm Son tan suaves y firmes..."
    sk "อืมนุ่มแถมยังเต่งตึงด้วย...ไซส์ได้รูปจริงๆ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:166
translate english arc2_main_quest6_1c721966:

    # sr "N-No los toques así... Se siente raro..."
    sr "ะ-อย่ามาจับแบบนั้นสิคะ... มันรู้สึกแปลกๆ นะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:167
translate english arc2_main_quest6_14cd54cb:

    # sk "¿Como, así?"
    sk "แบบนี้เหรอ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:168
translate english arc2_main_quest6_e87e8fa1:

    # sr "M-Mamá"
    sr "มะ-แม่คะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:169
translate english arc2_main_quest6_6aa77867:

    # sk "¿Sabes que tienes los pechos más hermosos del mundo?"
    sk "ลูกรู้ไหมว่าลูกมีหน้าอกที่สวยที่สุดในโลกเลยนะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:170
translate english arc2_main_quest6_520ebf21:

    # sk "Míralos... Son perfectos, tan suaves y firmes"
    sk "ดูพวกมันสิ... สมบูรณ์แบบมาก ทั้งนุ่มแล้วก็เต่งตึง"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:171
translate english arc2_main_quest6_7e77cfd9:

    # sr "Mamá, por favor ya basta..."
    sr "แม่คะ พอได้แล้วค่ะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:172
translate english arc2_main_quest6_68744034:

    # sk "Está bien jaja, ya me detengo"
    sk "จ้าๆ ฮ่าๆ แม่หยุดแล้วจ้ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:182
translate english arc2_main_quest6_e8e50b72:

    # sk "Bueno, ¿Qué tal si salimos ya?"
    sk "งั้นเราออกไปกันเลยดีไหม?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:183
translate english arc2_main_quest6_2679970b:

    # sr "Si, ya vámonos..."
    sr "ค่ะ ไปกันเถอะค่ะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:187
translate english arc2_main_quest6_0ee3dbdc:

    # n "Sarada y Sakura salen de los baños de mujeres y se dirigen hacia las termas"
    n "ซาราดะกับซากุระเดินออกจากห้องอาบน้ำหญิงแล้วมุ่งหน้าไปยังบ่อน้ำพุร้อน"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:199
translate english arc2_main_quest6_eda580ad:

    # sk "Aaah... Aue bien se siente el ambiente en este lugar"
    sk "อ่า... บรรยากาศที่นี่ดีจังเลยนะเนี่ย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:201
translate english arc2_main_quest6_818f60ca:

    # sk "¿Estás lista para entrar Sarada?"
    sk "พร้อมจะลงไปแช่กันหรือยังจ๊ะ ซาราดะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:203
translate english arc2_main_quest6_c609be9d:

    # sr "Por supuesto, lo he estado esperando desde que llegamos"
    sr "แน่นอนอยู่แล้วค่ะ หนูตั้งตารออันนี้มาตั้งแต่ตอนที่เรามาถึงเลยล่ะค่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:205
translate english arc2_main_quest6_35b90c2c:

    # sk "Muy bien, entonces vamos adentro"
    sk "งั้นก็ลงไปข้างในกันเถอะจ้ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:208
translate english arc2_main_quest6_48c20fed:

    # n "Sarada y Sakura entran a las termas para relajarse finalmente"
    n "ซาราดะกับซากุระก้าวลงสู่น้ำพุร้อนเพื่อผ่อนคลายอย่างเต็มที่ในที่สุด"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:220
translate english arc2_main_quest6_04e383ac:

    # sr "Aaaah"
    sr "อ่าาาห์"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:222
translate english arc2_main_quest6_6fe19805:

    # sr "Justo necesitaba esto... Estaba exhausta..."
    sr "หนูต้องการแบบนี้จริงๆ เลย... เหนื่อยล้าสุดๆ ไปเลยล่ะค่ะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:224
translate english arc2_main_quest6_f51419aa:

    # sk "No me sorprende, después de tantas semanas de trabajo"
    sk "ก็ไม่แปลกหรอกจ้ะ เล่นทำงานมาตั้งหลายสัปดาห์นี่นะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:227
translate english arc2_main_quest6_83d784a4:

    # sk "Ahora ya tenemos nuestro un momento de respiro... Así que a disfrutarlo"
    sk "ตอนนี้ในที่สุดพวกเราก็ได้พักหายใจหายคอบ้างแล้ว... งั้นมาผ่อนคลายกันเถอะนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:230
translate english arc2_main_quest6_8919da45:

    # n "Ambas permanecieron en silencio por un momento"
    n "ทั้งสองคนเงียบกันไปครู่หนึ่ง"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:231
translate english arc2_main_quest6_27e49d25:

    # n "Dejando que el agua aliviara el peso del cansancio y estrés acumulado de tantas semanas sin descanso"
    n "ปล่อยให้สายน้ำช่วยบรรเทาความเหนื่อยล้าและความเครียดที่สะสมมาตลอดหลายสัปดาห์ที่ไม่ได้พักผ่อน"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:235
translate english arc2_main_quest6_16278896:

    # sr "..."
    sr "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:238
translate english arc2_main_quest6_4ad350c6:

    # sr "¿Sabes?"
    sr "แม่รู้ไหมคะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:240
translate english arc2_main_quest6_02396a67:

    # sr "Estuve pensando..."
    sr "หนูคิดว่า..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:241
translate english arc2_main_quest6_1157c164:

    # sr "Las cosas han cambiado mucho desde que encontramos a [MN], ¿No lo crees?"
    sr "อะไรๆ เปลี่ยนแปลงไปเยอะเลยนะตั้งแต่ที่เราเจอ [MN] ว่าไหมคะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:244
translate english arc2_main_quest6_7bd25342:

    # sk "¿Cambiado en qué sentido?"
    sk "เปลี่ยนไปยังไงเหรอจ๊ะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:246
translate english arc2_main_quest6_d761c2f0:

    # sr "En todo supongo... Al principio, no sabía qué esperar de él"
    sr "ทุกอย่างเลยมั้งคะ... ตอนแรกหนูก็ไม่รู้เหมือนกันว่าจะคาดหวังอะไรจากเขาดี"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:248
translate english arc2_main_quest6_96fc4d5e:

    # sr "Era tan... Distante..."
    sr "เขาดู... เยชาห่างเหินเสียเหลือเกิน..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:251
translate english arc2_main_quest6_fdcb5fe1:

    # sr "Pero poco a poco, ha demostrado que tiene una fuerza increíble y una voluntad que no deja de sorprenderme"
    sr "แต่ทีละเล็กทีละน้อย เขาก็แสดงให้เห็นถึงความแข็งแกร่งอันน่าเหลือเชื่อและความมุ่งมั่นที่ไม่เคยหยุดทำให้หนูทึ่งเลยค่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:254
translate english arc2_main_quest6_07611e0f:

    # sr "Aún con todo lo que le pasó..."
    sr "แม้ว่าทุกสิ่งที่เกิดขึ้นกับเขาจะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:257
translate english arc2_main_quest6_0585dbbb:

    # sk "Si... Él ha pasado por mucho..."
    sk "นั่นสิคะ... เขาต้องเผชิญอะไรมาเยอะมาก..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:259
translate english arc2_main_quest6_a89ea0d5:

    # sk "Nadie podría salir de un lugar como ese laboratorio sin cicatrices..."
    sk "ไม่มีใครหลุดพ้นจากสถานที่อย่างห้องทดลองนั้นมาได้โดยไม่มีแผลเป็นหรอก..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:260
translate english arc2_main_quest6_83d78414:

    # sk "Lo que más me impresiona es cómo con el tiempo empezó a abrirse a nosotras..."
    sk "สิ่งที่ทำให้แม่ประทับใจที่สุดก็คือ เมื่อเวลาผ่านไป เขาเริ่มที่จะเปิดใจให้พวกเรา..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:264
translate english arc2_main_quest6_77f8cde9:

    # sk "Y a ti especialmente Sarada... Eres muy especial para él..."
    sk "และโดยเฉพาะกับลูกนะ ซาราดะ... ลูกมีความหมายกับเขามากทีเดียว..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:266
translate english arc2_main_quest6_76860f3b:

    # sr "N-No es... No es nada especial..."
    sr "ม-ไม่ใช่สักหน่อยค่ะ... ไม่ได้มีอะไรพิเศษเลยค่ะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:267
translate english arc2_main_quest6_1d8e69f0:

    # sr "Solo le estoy ayudándo a entrenar, eso es todo..."
    sr "หนูก็แค่ช่วยเขาฝึกซ้อมเท่านั้นเองค่ะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:270
translate english arc2_main_quest6_a639aa8c:

    # sk "Claro, claro jaja... Solo entrenando"
    sk "จ้าๆ ฮ่าๆ... แค่ฝึกซ้อมสินะคะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:273
translate english arc2_main_quest6_229a1b3c:

    # sk "Pero hay algo más, ¿No? ¿De verdad no sientes más por él?"
    sk "แต่ว่ามันมีอะไรมากกว่านั้นใช่ไหมล่ะจ๊ะ? ลูกไม่ได้รู้สึกอะไรมากกว่านั้นกับเขาจริงๆ หรือจ๊ะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:275
translate english arc2_main_quest6_7b9eaaec:

    # sr "N-No lo sé... No sé si es amor lo que siento la verdad..."
    sr "หนู-หนูก็ไม่รู้ค่ะ... พูดตามตรงหนูก็ไม่รู้ว่าสิ่งที่หนูรู้สึกอยู่นี่มันคือความรักหรือเปล่า..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:278
translate english arc2_main_quest6_0f62afab:

    # sr "Solo... No quiero que sienta que está solo, nadie debería pasar por lo que él pasó"
    sr "หนูแค่... ไม่อยากให้เขาต้องรู้สึกโดดเดี่ยวค่ะ ไม่มีใครควรจะต้องมาเจอเรื่องแบบที่เขาต้องเผชิญหรอกค่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:280
translate english arc2_main_quest6_5256a96a:

    # sr "De verdad quiero ayudarlo..."
    sr "หนูอยากจะช่วยเขาจริงๆ นะคะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:283
translate english arc2_main_quest6_639b733f:

    # sk "..."
    sk "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:286
translate english arc2_main_quest6_b171aad5:

    # sk "También estoy orgullosa de ti por eso Sarada..."
    sk "แม่ภูมิใจในตัวลูกเรื่องนั้นเหมือนกันนะ ซาราดะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:290
translate english arc2_main_quest6_5b965862:

    # sk "De verdad que has crecido mucho, no solo como kunoichi, sino como persona..."
    sk "ลูกเติบโตขึ้นมากจริงๆ ไม่ใช่แค่ในฐานะนินจาหญิง แต่ในฐานะคนคนหนึ่งด้วย..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:292
translate english arc2_main_quest6_6edc9cc0:

    # sk "Sigue así, y serás una de los mejores Hokages que ha tenido la Aldea de la Hoja"
    sk "ตั้งใจเข้าล่ะ แล้วลูกจะต้องกลายเป็นหนึ่งในโฮคาเงะที่ยอดเยี่ยมที่สุดที่หมู่บ้านโคโนฮะเคยมีมาแน่ๆ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:294
translate english arc2_main_quest6_9d0e2314_1:

    # sr "Gracias Mamá..."
    sr "ขอบคุณค่ะแม่..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:295
translate english arc2_main_quest6_f23df545:

    # sr "Tú y el Séptimo han sido mi mayor ejemplo a seguir..."
    sr "คุณแม่กับท่านรุ่นที่เจ็ดคือไอดอลที่ใหญ่ที่สุดของหนูเลยค่ะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:297
translate english arc2_main_quest6_03d17058:

    # sk "¿Ah, sí? Bueno, me alegra escuchar eso, aunque has sido tú sola has recorrido tu propio camino"
    sk "งั้นเหรอจ๊ะ? แม่ดีใจนะที่ได้ยินแบบนั้น ถึงแม้ว่าลูกจะเดินในเส้นทางของตัวเองด้วยลำแข้งของลูกเองก็เถอะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:299
translate english arc2_main_quest6_29c2ce08:

    # sk "Tú tomaste las decisiones que te han llevado a ser la persona que eres ahora"
    sk "ลูกเป็นคนตัดสินใจเลือกทางเดินที่ทำให้ลูกกลายเป็นคนอย่างทุกวันนี้เองนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:300
translate english arc2_main_quest6_46ac0226:

    # sr "Mamá..."
    sr "คุณแม่..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:304
translate english arc2_main_quest6_d8ece1b0:

    # sk "Por cierto... Quiería mencionarte algo de [MN]..."
    sk "ว่าแต่... แม่มีเรื่องเกี่ยวกับ [MN] อยากจะพูดถึงหน่อยน่ะจ๊ะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:307
translate english arc2_main_quest6_11d052e9:

    # sk "Debo admitir que hay algo que me preocupa..."
    sk "แม่ต้องยอมรับเลยว่ามีบางเรื่องที่แม่เป็นห่วงอยู่..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:308
translate english arc2_main_quest6_c6480bfc:

    # sk "Aunque ya está mucho mejor, aún guarda mucho dolor dentro de sí..."
    sk "ถึงแม้ว่าเขาจะอาการดีขึ้นมากแล้ว แต่เขาก็ยังแบกรับความเจ็บปวดไว้ข้างในใจอีกเยอะเลย..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:310
translate english arc2_main_quest6_61caf9ff:

    # sr "¿Porqué lo dices?"
    sr "ทำไมแม่ถึงพูดแบบนั้นล่ะคะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:312
translate english arc2_main_quest6_639b733f_1:

    # sk "..."
    sk "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:314
translate english arc2_main_quest6_d81073d9:

    # sk "Verás..."
    sk "ก็คือ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:315
translate english arc2_main_quest6_35e59b6e:

    # sk "Hace un tiempo, [MN] y yo tuvimos una conversación en la que se abrió conmigo como nunca antes...."
    sk "เมื่อไม่นานมานี้ [MN] กับแม่เคยคุยกันเรื่องหนึ่ง ตอนนั้นเขาเปิดใจคุยกับแม่แบบที่ไม่เคยเป็นมาก่อนเลย..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:316
translate english arc2_main_quest6_4632a2a6:

    # sk "Fue... difícil para él"
    sk "มันเป็นเรื่องที่... ยากสำหรับเขามากเลยล่ะจ๊ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:317
translate english arc2_main_quest6_4ce9aa19:

    # sr "¿Qué fue lo que te dijo?"
    sr "เขาบอกอะไรแม่เหรอคะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:318
translate english arc2_main_quest6_fce8e7d8:

    # sk "Me dijo que saber lo que le ocurrió a su familia, a su linaje, ha sido un golpe enorme para él..."
    sk "เขาบอกแม่ว่า การได้รู้เรื่องราวที่เกิดขึ้นกับครอบครัวและตระกูลของเขามันเป็นความสูญเสียครั้งใหญ่สำหรับเขาเลยล่ะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:319
translate english arc2_main_quest6_6863667b:

    # sk "Se siente atrapado entre el deseo de honrar su legado y la confusión de no saber cómo hacerlo"
    sk "เขารู้สึกสับสนระหว่างความต้องการที่จะเชิดชูเกียรติวงศ์ตระกูลกับความไม่รู้ว่าจะทำมันยังไงดี"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:321
translate english arc2_main_quest6_3cc15d82:

    # sk "La idea de estar solo, sin nadie más de su sangre, lo abruma..."
    sk "ความคิดที่ว่าต้องอยู่ตัวคนเดียวโดยไม่มีคนในสายเลือดเดียวกันเหลืออยู่เลยมันทำให้เขารู้สึกเคว้งคว้างมาก..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:322
translate english arc2_main_quest6_9b92b6ca:

    # sk "De verdad es algo que le afectó..."
    sk "มันเป็นเรื่องที่กระทบกระเทือนจิตใจเขาจริงๆ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:324
translate english arc2_main_quest6_16278896_1:

    # sr "..."
    sr "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:326
translate english arc2_main_quest6_8e194995:

    # sr "No sabía que se sentía así... Normalmente es alegre y fuerte..."
    sr "หนูไม่รู้เลยนะคะว่าเขารู้สึกแบบนั้น... ปกติเขาออกจะร่าเริงและเข้มแข็งแท้ๆ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:327
translate english arc2_main_quest6_92ef0d4a:

    # sk "Parece fuerte y de verdad lo es, pero también es humano Sarada..."
    sk "เขาดูเข้มแข็ง และเขาก็เป็นแบบนั้นจริงๆ แต่เขาก็เป็นมนุษย์คนหนึ่งเหมือนกันนะ ซาราดะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:329
translate english arc2_main_quest6_ef950c4e:

    # sk "Yo le dije que centrarse en su futuro es lo mejor que puede hacer, porque de nada sirve que se lamente del pasado"
    sk "แม่บอกเขาไปว่าการโฟกัสกับอนาคตคือสิ่งที่ดีที่สุดที่เขาทำได้ เพราะการมานั่งคร่ำครวญถึงอดีตมันไม่ได้ช่วยอะไรเลย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:331
translate english arc2_main_quest6_9710169a:

    # sk "Le sugerí que una vez sea Chunin, pida permiso a Naruto para investigar más sobre su clan y encontrar las respuestas que busca"
    sk "แม่แนะนำว่าพอเขาได้เป็นจูนินแล้ว เขากลองไปขออนุญาตจากนารูโตะเพื่อสืบหาข้อมูลเกี่ยวกับตระกูลของตัวเองเพิ่มเติมและหาคำตอบที่เขากำลังตามหาดู"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:332
translate english arc2_main_quest6_d2b47d93:

    # sk "Pero también le advertí que eso solo será posible si continúa esforzándose y logra hacerse más fuerte"
    sk "แต่แม่ก็เตือนเขาไปเหมือนกันว่ามันจะเป็นไปได้ก็ต่อเมื่อเขายังคงตั้งใจฝึกซ้อมและเก่งขึ้นกว่าเดิมเท่านั้น"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:334
translate english arc2_main_quest6_3b580629:

    # sk "Y por esto te estoy contando esto..."
    sk "และนั่นคือเหตุผลที่แม่เล่าเรื่องนี้ให้ลูกฟัง..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:335
translate english arc2_main_quest6_d0e7c8e4:

    # sk "Quiero que lo ayudes Sarada..."
    sk "แม่แค่อยากให้ลูกช่วยเขาหน่อยนะ ซาราดะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:336
translate english arc2_main_quest6_4ab5ed40:

    # sk "No puedes dejarlo solo... No podémos dejar que se pierda en la oscuridad..."
    sk "ลูกจะปล่อยให้เขาอยู่คนเดียวไม่ได้... เราจะปล่อยให้เขาหลงทางไปในความมืดไม่ได้เด็ดขาด..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:338
translate english arc2_main_quest6_639b733f_2:

    # sk "..."
    sk "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:341
translate english arc2_main_quest6_2d22212a:

    # sr "No tienes por qué pedírmelo, le ayudaré a que logre alcazar su objetivo, estaré ahí siempre que me necesite"
    sr "แม่ไม่ต้องขอหรอกค่ะ หนูจะช่วยให้เขาบรรลุเป้าหมายเองค่ะ หนูจะอยู่ข้างๆ เสมอเวลาที่เขาต้องการ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:343
translate english arc2_main_quest6_ea90199f:

    # sr "Si puedo ser una luz en su camino, entonces no dudaré en hacerlo"
    sr "ถ้าหนูสามารถเป็นแสงสว่างนำทางให้เขาได้ หนูจะไม่ลังเลเลยค่ะที่จะทำมัน"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:345
translate english arc2_main_quest6_639b733f_3:

    # sk "..."
    sk "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:349
translate english arc2_main_quest6_ac942358:

    # sk "Gracias Sarada... De verdad te lo agradezco..."
    sk "ขอบใจนะ ซาราดะ... แม่ซาบซึ้งใจจริงๆ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:352
translate english arc2_main_quest6_b78678e9:

    # sk "Pero también quiero que sepas que estás aquí para apoyarlo y guiarlo, más no quiero que cargues con su dolor..."
    sk "แต่แม่ก็อยากให้ลูกรู้ไว้ด้วยนะ ว่าลูกอยู่ที่นี่เพื่อคอยสนับสนุนและชี้นำเขา แต่แม่ไม่อยากให้ลูกต้องแบกรับความเจ็บปวดของเขาแทนหรอกนะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:354
translate english arc2_main_quest6_5012fe5a:

    # sr "Lo entiendo Mamá, gracias por contarme esto..."
    sr "หนูเข้าใจแล้วค่ะคุณแม่ ขอบคุณที่เล่าเรื่องนี้ให้หนูฟังนะคะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:356
translate english arc2_main_quest6_4ebacb85:

    # sk "*suspiro* Gracias Sarada... Ahora me quitaste un gran peso de encima..."
    sk "*ถอนหายใจ* ขอบใจนะ ซาราดะ... ลูกช่วยแบ่งเบาภาระในใจแม่ไปได้เยอะเลย..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:359
translate english arc2_main_quest6_27bbea75:

    # sk "Ahora, basta de preocupaciones, ¿No crees? Estamos aquí para relajarnos"
    sk "เอาล่ะ เลิกกังวลเรื่องพวกนี้กันได้แล้ว ว่าไหมจ๊ะ? เรามาที่นี่เพื่อพักผ่อนกันนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:362
translate english arc2_main_quest6_a6857fa5:

    # n "Ambas cerraron los ojos y dejaron que el calor del agua les aliviara el cuerpo y la mente"
    n "พวกเธอทั้งสองหลับตาลงและปล่อยให้ความอบอุ่นของสายน้ำช่วยผ่อนคลายทั้งร่างกายและจิตใจ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:363
translate english arc2_main_quest6_65bdf8dd:

    # n "Aliviando el peso de sus preocupaciones... Al menos por un rato"
    n "ช่วยบรรเทาความหนักอึ้งจากความกังวลในใจ... อย่างน้อยก็ในตอนนี้"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:364
translate english arc2_main_quest6_e86257ac:

    # n "Mientras tanto, en las aguas termales para hombres, [MN] se preparaba para relajarse también"
    n "ในขณะเดียวกัน ทางฝั่งบ่อน้ำร้อนชาย [MN] ก็กำลังเตรียมตัวที่จะผ่อนคลายเช่นกัน"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:376
translate english arc2_main_quest6_2ee0ba4e:

    # mn "Vaya... No hay nadie aquí"
    mn "โห... ไม่มีคนอยู่เลยแฮะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:378
translate english arc2_main_quest6_438bb386:

    # mn "Debe de ser por la hora, llegamos bastante temprano"
    mn "สงสัยจะเป็นเพราะเวลาแหละมั้ง เรามากันค่อนข้างเช้าเลยนี่นา"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:380
translate english arc2_main_quest6_27ac589f:

    # mn "Aaah, mejor para mí, todo esto para relajarme yo solo"
    mn "อ่าห์ ดีสำหรับเราเลย ที่นี่เป็นของเราคนเดียวจะได้นอนแช่พักผ่อนตามสบาย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:382
translate english arc2_main_quest6_ed6c7a72:

    # mn "Me preocupaba que hubiera mucha gente, no acostumbro que me vean así"
    mn "ตอนแรกก็กังวลว่าจะมีคนเยอะซะอีก ฉันไม่ค่อยชินกับการแก้ผ้าต่อหน้าคนอื่นเท่าไหร่ด้วยสิ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:385
translate english arc2_main_quest6_ba2dc707:

    # n "[MN] entra a las aguas termales y se recuesta, dejándose llevar y disfrutando el momento"
    n "[MN] เดินลงบ่อน้ำร้อนแล้วเอนกายพิงขอบ ปล่อยตัวปล่อยใจให้เพลิดเพลินไปกับช่วงเวลานี้"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:389
translate english arc2_main_quest6_b85567a8:

    # mn "Hah... Esto sí que se siente bien..." with fade
    mn "ฮ่า... สบายตัวชะมัด..." with fade

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:390
translate english arc2_main_quest6_9f5e0f01:

    # mn "Por fin un momento de relajación..."
    mn "ในที่สุดก็ได้พักผ่อนหย่อนใจสักที..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:391
translate english arc2_main_quest6_93eb0557:

    # mn "A veces, me olvido de cómo se siente estar en calma..."
    mn "บางครั้งฉันก็ลืมไปแล้วแฮะว่าความสงบสุขเนี่ยมันรู้สึกยังไง..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:392
translate english arc2_main_quest6_e8652812:

    # mn "Con todo esto de los Exámenes... No me he podido dar tiempo para descansar..."
    mn "มัวแต่ยุ่งกับเรื่องสอบนู่นนี่... จนแทบไม่มีเวลาได้พักผ่อนเลย..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:393
translate english arc2_main_quest6_92d3536a:

    # mn "Mmm... Los Exámenes Chunin... Ya están a la vuelta de la esquina..."
    mn "อืม... การสอบจูนิน... ใกล้เข้ามาทุกทีแล้วสินะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:394
translate english arc2_main_quest6_c86cb549:

    # mn "Todo depende de pasarlos..."
    mn "ทุกอย่างมันขึ้นอยู่กับการสอบผ่านนี่แหละ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:395
translate english arc2_main_quest6_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:396
translate english arc2_main_quest6_37fd4d30:

    # mn "Los últimos días han sido muy pesados con el entrenamiento..."
    mn "ช่วงสองสามวันที่ผ่านมานี้ฝึกซ้อมกันหนักหน่วงเอาเรื่องเลย..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:397
translate english arc2_main_quest6_d726c4cc:

    # mn "Pero sé que he mejorado, y debo pasarlos para encontrar las respuestas que busco..."
    mn "แต่ฉันรู้ว่าตัวเองเก่งขึ้นแล้ว และฉันต้องสอบผ่านให้ได้เพื่อตามหาคำตอบที่ต้องการ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:398
translate english arc2_main_quest6_860008df:

    # mn "Es tan solo el primer paso..."
    mn "นี่มันก็แค่วิถีก้าวแรกเท่านั้น..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:399
translate english arc2_main_quest6_32462c4b_1:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:400
translate english arc2_main_quest6_242d1da2:

    # mn "Pero..."
    mn "แต่ว่า..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:401
translate english arc2_main_quest6_f38a4842:

    # mn "¿De verdad estoy listo? ¿Puedo cargar con el peso de un clan que ni siquiera recuerdo...?"
    mn "ฉันพร้อมจริงๆ แล้วเหรอ? ฉันจะแบกรับน้ำหนักของตระกูลที่ตัวเองแทบไม่หลงเหลือความทรงจำอยู่เลยเนี่ยนะไหวเหรอ...?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:402
translate english arc2_main_quest6_32462c4b_2:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:403
translate english arc2_main_quest6_e7474ad1:

    # mn "El Clan Karui... Mi clan... Todo lo que sé es que fue destruido por los {b}Akatsuki{/a}, nada más..."
    mn "ตระกูลคารุอิ... ตระกูลของฉัน... สิ่งเดียวที่ฉันรู้ก็คือมันถูกทำลายโดย {b}แสงอุษา{/a} แค่นั้นเอง..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:404
translate english arc2_main_quest6_848365d3:

    # mn "Ni el símbolo que nos representaba, ni las tierras que llamamos hogar, ni siquiera nuestras costumbres..."
    mn "ไม่เหลือแม้แต่สัญลักษณ์ประจำตระกูล ดินแดนที่เราเรียกว่าบ้าน หรือกระทั่งธรรมเนียมปฏิบัติ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:405
translate english arc2_main_quest6_123e0f42:

    # mn "Es como si todo hubiera desaparecido..."
    mn "ราวกับว่าทุกสิ่งทุกอย่างมันหายสาบสูญไปหมดแล้ว..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:406
translate english arc2_main_quest6_32462c4b_3:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:407
translate english arc2_main_quest6_5d476787:

    # mn "Todo... Salvo yo..."
    mn "ทุกสิ่งทุกอย่าง... ยกเว้นตัวฉัน..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:408
translate english arc2_main_quest6_242d1da2_1:

    # mn "Pero..."
    mn "แต่ว่า..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:409
translate english arc2_main_quest6_3557fcad:

    # mn "Pero... ¿Quién soy yo, entonces?"
    mn "แต่ว่า... แล้วฉันเป็นใครกันล่ะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:410
translate english arc2_main_quest6_40f45613:

    # mn "No tengo recuerdos de antes de despertar... ¿Quién era yo antes?"
    mn "ฉันไม่มีความทรงจำก่อนที่จะตื่นขึ้นมาเลย... แล้วก่อนหน้านั้นฉันคือใครกัน?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:411
translate english arc2_main_quest6_5f7b0228:

    # mn "¿Soy solo el último de un clan extinto?"
    mn "ฉันเป็นแค่คนสุดท้ายของตระกูลที่สูญพันธุ์ไปแล้วงั้นเหรอ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:412
translate english arc2_main_quest6_d7906020:

    # mn "¿Una reliquia sin propósito que ha sobrevivido cuando todo lo demás ha sido borrado?"
    mn "เศษซากไร้จุดหมายที่รอดชีวิตมาได้ในตอนที่ทุกอย่างถูกลบหายไปงั้นเหรอ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:413
translate english arc2_main_quest6_32462c4b_4:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:414
translate english arc2_main_quest6_ae8b3042:

    # n "El peso de esas preguntas han perseguido a [MN] desde que tuvo conciencia de su linaje"
    n "น้ำหนักของคำถามเหล่านั้นตามหลอกหลอน [MN] มาโดยตลอดตั้งแต่วันที่รู้เรื่องสายเลือดของตัวเอง"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:415
translate english arc2_main_quest6_172c3423:

    # n "El vacío que lo rodeaba era oscuro, profundo..."
    n "ความว่างเปล่าที่รายล้อมรอบตัวช่างมืดมิดและล้ำลึก..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:416
translate english arc2_main_quest6_631fc8c3:

    # n "Pero, de algún modo, se sintió más ligero al confrontarlo"
    n "แต่ถึงอย่างนั้น เขากลับรู้สึกโล่งใจขึ้นมาบ้างเมื่อได้เผชิญหน้ากับมัน"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:417
translate english arc2_main_quest6_6cd5f3eb:

    # mn "No puedo recordar sus rostros... Ni su voz, ni sus enseñanzas... Todo está vacío..."
    mn "ฉันจำใบหน้าของพวกเขาไม่ได้เลย... ทั้งเสียงพูด หรือคำสอน... ทุกอย่างว่างเปล่าไปหมด..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:418
translate english arc2_main_quest6_242d1da2_2:

    # mn "Pero..."
    mn "แต่ว่า..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:419
translate english arc2_main_quest6_19ca61db:

    # mn "No puedo dejar que ese vacío me consuma..."
    mn "ฉันจะปล่อยให้ความว่างเปล่านั้นกลืนกินตัวเองไม่ได้..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:420
translate english arc2_main_quest6_f841026e:

    # mn "No quiero ser solo una sombra de un pasado que no puedo cambiar"
    mn "ฉันไม่อยากเป็นแค่เงาของอดีตที่เปลี่ยนแปลงไม่ได้หรอกนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:421
translate english arc2_main_quest6_f8f9275e:

    # mn "Ahora tengo un propósito..."
    mn "ตอนนี้ฉันมีเป้าหมายแล้ว..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:422
translate english arc2_main_quest6_7d88c631:

    # mn "Convertirme en Chunin, encontrar respuestas, saber quién era y de dónde provengo..."
    mn "การเป็นจูนิน หาคำตอบ เรียนรู้ว่าตัวฉันเองคือใคร และมาจากไหน..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:423
translate english arc2_main_quest6_76b70ccb:

    # mn "No importa cuán poco sepa del Clan Karui..."
    mn "ต่อให้ฉันจะรู้เรื่องเกี่ยวกับตระกูลคารุอิ น้อยนิดแค่ไหนก็ตาม..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:424
translate english arc2_main_quest6_5eec7859:

    # mn "No importa si el mundo ya ha olvidado su existencia, porque aunque no pueda traer de vuelta lo que perdí..."
    mn "ต่อให้โลกใบนี้จะลืมเลือนการมีอยู่ของมันไปแล้วก็ไม่เป็นไร เพราะถึงแม้ฉันจะเอาสิ่งที่สูญเสียไปกลับคืนมาไม่ได้..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:425
translate english arc2_main_quest6_beb42a9e:

    # mn "Puedo construir algo nuevo, algo que honre lo que fueron, pero también lo que puedo llegar a ser..."
    mn "แต่ฉันก็สามารถสร้างสิ่งใหม่ขึ้นมาได้ สิ่งที่ให้เกียรติอดีตของพวกเขา และในขณะเดียวกันก็เป็นสิ่งที่ตัวฉันเองสามารถก้าวไปถึงได้..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:426
translate english arc2_main_quest6_84822b29:

    # mn "Si soy el último Karui..."
    mn "ถ้าฉันคือคนสุดท้ายของตระกูลคารุอิ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:427
translate english arc2_main_quest6_17c258be:

    # mn "Entonces soy yo quien tiene el poder para decidir el destino del Clan"
    mn "งั้นก็ขึ้นอยู่กับฉันแล้วล่ะที่จะเป็นคนกำหนดชะตากรรมของตระกูล"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:428
translate english arc2_main_quest6_bdbe5eb6:

    # mn "La responsabilidad recae en mí..."
    mn "ภาระหน้าที่นี้ตกเป็นของฉัน..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:429
translate english arc2_main_quest6_1c7e48ae:

    # mn "No puedo quedarme de brazos cruzados"
    mn "ฉันจะยืนดูอยู่เฉยๆ ไม่ได้หรอก"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:430
translate english arc2_main_quest6_0e73a72d:

    # mn "Quiero a restaurar mi clan..."
    mn "ฉันอยากจะฟื้นฟูตระกูลขึ้นมา..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:431
translate english arc2_main_quest6_2d6f2818:

    # mn "Pero no como una reliquia sin propósito"
    mn "แต่ไม่ใช่ในฐานะเศษซากไร้จุดหมาย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:432
translate english arc2_main_quest6_232eef4a:

    # mn "Sino como alguien que recuerden en el futuro, alquien que estuvo vivo"
    mn "แต่ในฐานะคนที่ผู้คนจะจดจำในอนาคต คนที่เคยมีชีวิตอยู่จริงๆ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:433
translate english arc2_main_quest6_a3d1b565:

    # mn "Quiero dejar huella en este mundo..."
    mn "ฉันอยากจะทิ้งร่องรอยของตัวเองไว้บนโลกใบนี้..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:434
translate english arc2_main_quest6_2b1e433f:

    # n "Mientras [MN] reflexionaba sobre sus sueños"
    n "ขณะที่ [MN] กำลังครุ่นคิดถึงความฝันของตัวเอง"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:435
translate english arc2_main_quest6_24eeb7cd:

    # n "Sus pensamientos se dirigieron a quienes han estado a su lado"
    n "ความคิดของเขาก็หันไปหาผู้คนที่คอยเคียงข้างมาตลอด"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:436
translate english arc2_main_quest6_f896d641:

    # n "Sarada, Sakura, Naruto y los que creían en él"
    n "ซาราดะ, ซากุระ, นารูโตะ และเหล่าผู้คนที่เชื่อมั่นในตัวเขา"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:437
translate english arc2_main_quest6_85af6fe1:

    # n "Había más que solo un vacío..."
    n "ที่นั่นมีอะไรมากกว่าแค่ความว่างเปล่า..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:438
translate english arc2_main_quest6_7e8f9d3a:

    # n "La oportunidad de contruir un futuro..."
    n "โอกาสในการสร้างอนาคต..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:439
translate english arc2_main_quest6_4aa3ecb7:

    # n "Aún había esperanza en él..."
    n "ความหวังยังคงหลงเหลืออยู่ในตัวพวกเขา..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:440
translate english arc2_main_quest6_004b72b7:

    # mn "Además, ya no estoy solo..."
    mn "อีกอย่าง ฉันไม่ได้ตัวคนเดียวอีกต่อไปแล้ว..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:441
translate english arc2_main_quest6_5f798ba5:

    # mn "Hay personas que creen en mí, personas que han depositado su confianza en mí..."
    mn "มีผู้คนที่เชื่อมั่นในตัวฉัน มีคนที่มอบความไว้วางใจให้ฉัน..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:442
translate english arc2_main_quest6_4efeedee:

    # mn "No los puedo decepcionar"
    mn "ฉันจะทำให้พวกเขาผิดหวังไม่ได้"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:445
translate english arc2_main_quest6_49278d3b:

    # mn "Los exámenes son solo el comienzo"
    mn "การสอบนี่เป็นแค่จุดเริ่มต้นเท่านั้น"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:446
translate english arc2_main_quest6_9945ef0e:

    # mn "Un paso para encontrar respuestas, y sea cual sea el legado que mi clan dejó..."
    mn "ก้าวหนึ่งเพื่อไปหาคำตอบ และมรดกใดๆ ก็ตามที่ตระกูลของฉันทิ้งเอาไว้..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:450
translate english arc2_main_quest6_a1368170:

    # mn "Seré yo quien decida qué hacer con él" with fade
    mn "ฉันนี่แหละจะเป็นคนตัดสินใจเองว่าจะทำยังไงกับมันต่อ" with fade

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:451
translate english arc2_main_quest6_c8e14d28:

    # n "Al decir esto, [MN] emergió del agua"
    n "เมื่อพูดจบ [MN] ก็ก้าวขึ้นมาจากผืนน้ำ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:452
translate english arc2_main_quest6_8cde756b:

    # n "Sintiendo cómo el calor que rodeaba su cuerpo parecía disipar el peso de sus pensamientos"
    n "รู้สึกได้ว่าไออุ่นรอบตัวช่วยปัดเป่าความหนักอึ้งในความคิดให้จางหายไป"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:453
translate english arc2_main_quest6_ad069b80:

    # n "Cuando abrió los ojos, estos reflejaban un brillo sin igual, una chispa de determinación que no estaba allí antes"
    n "ยามที่เปิดตาขึ้น แววตาของเขากลับสะท้อนประกายแสงอันเจิดจ้า ประกายแห่งความมุ่งมั่นที่ไม่เคยมีมาก่อน"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:454
translate english arc2_main_quest6_55d55d0a:

    # n "El peso de su pasado, que antes lo ahogaba, seguía presente... Pero ahora se sentía diferente"
    n "น้ำหนักแห่งอดีตที่เคยฉุดรั้งเขาไว้จนแทบจมดิ่ง ยังคงอยู่... แต่ตอนนี้มันรู้สึกแตกต่างออกไป"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:455
translate english arc2_main_quest6_2e8cafcf:

    # n "Ya no era solo una carga que debía soportar"
    n "มันไม่ใช่แค่ภาระที่เขาจำต้องแบกรับอีกต่อไป"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:456
translate english arc2_main_quest6_b778cdec:

    # n "Se había transformado en algo más"
    n "แต่มันได้แปรเปลี่ยนเป็นอย่างอื่นแล้ว"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:457
translate english arc2_main_quest6_1b7dd791:

    # n "Era un compromiso, una promesa que había hecho consigo mismo"
    n "มันคือพันธะสัญญา คือคำสัญญาที่ให้ไว้กับตัวเอง"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:458
translate english arc2_main_quest6_2e46010a:

    # n "Una promesa de buscar respuestas, de honrar lo que quedaba de su linaje y de construir algo nuevo"
    n "คำสัญญาที่จะแสวงหาคำตอบ ให้เกียรติสิ่งที่หลงเหลืออยู่ของสายเลือด และสร้างสรรค์สิ่งใหม่ขึ้นมา"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:459
translate english arc2_main_quest6_183283bc:

    # n "La promesa de no dejarse definir por un pasado que no recordaba, sino de forjar su propio Camino Ninja"
    n "คำสัญญาที่จะไม่ยอมให้ตนเองถูกกำหนดด้วยอดีตที่จำไม่ได้ แต่จะสร้างวิถีนินจาของตนเองขึ้นมาต่างหาก"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:460
translate english arc2_main_quest6_ca5c6bd0:

    # mn "Si soy el último... Entonces seré yo quien escriba la próxima historia del Clan Karui"
    mn "หากฉันคือคนสุดท้าย... งั้นฉันนี่แหละจะเป็นคนเขียนบทต่อไปของตระกูลคารุอิเอง"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:461
translate english arc2_main_quest6_54051697:

    # mn "Este será mi Camino Ninja!"
    mn "นี่แหละคือวิถีนินจาของฉัน!"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:462
translate english arc2_main_quest6_64e8adb3:

    # n "[MN] respiró profundamente, dejando que el aire fresco llenara sus pulmones"
    n "[MN] สูดหายใจเข้าลึกๆ ปล่อยให้อากาศบริสุทธิ์เติมเต็มปอด"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:463
translate english arc2_main_quest6_d3c11382:

    # n "Sentía cómo la incertidumbre que antes lo consumía retrocedía, dando paso a una nueva claridad"
    n "เขารู้สึกได้ว่าความลังเลใจที่เคยกัดกินจิตใจค่อยๆ 🢡 เลือนหายไป หลีกทางให้ความปลอดโปร่งครั้งใหม่"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:464
translate english arc2_main_quest6_2b86f82f:

    # n "No sería fácil, el camino estaba lleno de incógnitas y desafíos, pero estaba decidido a enfrentarlos"
    n "มันคงไม่ใช่งานง่าย เส้นทางนี้เต็มไปด้วยความไม่แน่นอนและความท้าทาย แต่เขาก็ตั้งใจแน่วแน่ที่จะเผชิญหน้ากับมัน"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:465
translate english arc2_main_quest6_62540636:

    # n "Por primera vez en mucho tiempo, sintió que tenía algo por lo que luchar"
    n "เป็นครั้งแรกในรอบนานมาก ที่เขารู้สึกว่าตัวเองมีบางอย่างให้ต้องต่อสู้เพื่อมัน"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:466
translate english arc2_main_quest6_4f928efe:

    # mn "No importa cuánto tiempo tome... Lo haré cueste lo que cueste..."
    mn "ไม่ว่าจะต้องใช้เวลานานแค่ไหน... ฉันก็จะทำมัน ต่อให้ต้องแลกด้วยอะไรก็ตาม..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:467
translate english arc2_main_quest6_e5a61477:

    # n "Con esa resolución firmemente arraigada en su corazón, [MN] dejó las aguas termales"
    n "ด้วยความมุ่งมั่นที่ฝังรากลึกอยู่ในหัวใจ [MN] จึงเดินออกจากบ่อน้ำพุร้อน"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:471
translate english arc2_main_quest6_f635fa5e:

    # n "El calor del agua había aliviado sus músculos, pero el fuego que ardía en su interior lo mantenía despierto"
    n "ไอน้ำอุ่นช่วยคลายกล้ามเนื้อของเขา แต่เปลวไฟที่โหมกระหน่ำอยู่ข้างในกลับทำให้เขายังคงตื่นตัว"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:472
translate english arc2_main_quest6_3326b198:

    # n "A cada paso que daba, sentía cómo el peso de su promesa lo impulsaba hacia adelante, más fuerte y más decidido que nunca"
    n "ในทุกๆ ก้าวที่เดิน เขารู้สึกได้ว่าน้ำหนักแห่งคำสัญญาคอยผลักดันให้ก้าวไปข้างหน้า แข็งแกร่งและเด็ดเดี่ยวมากกว่าที่เคย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:473
translate english arc2_main_quest6_a20cefa7:

    # "..."
    "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:478
translate english arc2_main_quest6_8389981a:

    # n "-{b}Momentos Después{/a}-"
    n "-{b}ต่อมาไม่นาน{/a}-"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:489
translate english arc2_main_quest6_0b5f1308:

    # sr "Debo admitir que esto fue una maravillosa idea"
    sr "ต้องยอมรับเลยว่า นี่เป็นความคิดที่ดีจริงๆ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:491
translate english arc2_main_quest6_5c86f473:

    # sr "Me siento muy bien... De verdad necesitaba esto"
    sr "รู้สึกดีจริงๆ เลย... ฉันต้องการการแบบนี้จริงๆ แหละ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:493
translate english arc2_main_quest6_2c431330:

    # sr "¿Tú como estás, qué te pareció tu primera visita a las Aguas Termales?"
    sr "แล้วเธอล่ะ? คิดยังไงกับการมาแช่น้ำพุร้อนครั้งแรกบ้าง?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:494
translate english arc2_main_quest6_aac315cc:

    # mn "Pues... No sé como describirlo..."
    mn "อืม... ฉันก็ไม่รู้จะอธิบายยังไงดี..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:496
translate english arc2_main_quest6_c0221049:

    # mn "Estar ahí dentro... En las termas... Fue una experiencia única..."
    mn "การได้ไปอยู่ในนั้น... ในบ่อน้ำนั่น... มันเป็นประสบการณ์ที่แปลกใหม่ดี..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:498
translate english arc2_main_quest6_ecc8eb7f:

    # mn "Me siento mejor, renovado, como un hombre nuevo"
    mn "ฉันรู้สึกดีขึ้น สดชื่นขึ้น เหมือนได้เกิดใหม่เป็นคนละคนเลย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:500
translate english arc2_main_quest6_dd43f2a3:

    # mn "Estoy listo para superar cualquier desafío que se me ponga enfrente"
    mn "ตอนนี้ฉันพร้อมที่จะก้าวข้ามทุกความท้าทายที่จะเข้ามาแล้วล่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:503
translate english arc2_main_quest6_436e4d0b:

    # sk "Me alegra escuchar eso, parece que realmente te hizo muy bien venir aquí"
    sk "ดีใจที่ได้ยินแบบนั้นนะ ดูท่าว่าการมาที่นี่จะช่วยเธอได้เยอะเลย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:505
translate english arc2_main_quest6_7305971c:

    # sk "Los próximos días serán duros, pero con esa actitud, estoy segura de que saldrás adelante"
    sk "อีกไม่กี่วันข้างหน้านี้คงจะหนักหนาสาหัสแน่ แต่ด้วยทัศนคติแบบนั้น ฉันมั่นใจว่าเธอต้องผ่านมันไปได้แน่"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:509
translate english arc2_main_quest6_5312512f:

    # sr "Por cierto [MN], ¿Cómo están Yuna y Hideo?"
    sr "ว่าแต่ [MN] ยูนะกับฮิเดโอะเป็นยังไงบ้างเหรอ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:511
translate english arc2_main_quest6_21fec975:

    # sr "Ya sabemos que tu has mejorado mucho y que estás listo, ¿Pero y ellos? Recuerda que la primera fase del Exámen es por Equipos"
    sr "พวกเรารู้ดีว่าเธอเก่งขึ้นมากและพร้อมแล้ว แต่คนอื่นล่ะ? จำไว้นะว่าการสอบรอบแรกต้องเน้นเป็นทีม"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:515
translate english arc2_main_quest6_5a4202b1:

    # mn "Pues... Realmente no sé mucho sobre su entrenamiento"
    mn "อืม... ฉันไม่ค่อยรู้เรื่องการฝึกซ้อมของพวกเขาเท่าไหร่หรอก"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:517
translate english arc2_main_quest6_ea0912ef:

    # mn "Solo sé que a los dos los estaba entrenando {b}Zubon-Sensei{/a}"
    mn "ฉันรู้แค่ว่าทั้งสองคนกำลังฝึกฝนอยู่ภายใต้การดูแลของ {b}อาจารย์ซูบง{/a}"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:520
translate english arc2_main_quest6_68a1736c:

    # sk "Zubon... Espero Yuna esté bien con él..."
    sk "ซูบงงั้นเหรอ... หวังว่ายูนะจะไปกันได้ดีกับเขานะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:523
translate english arc2_main_quest6_18b6bd22:

    # mn "No se preocupe jaja... Yuna sabe manejarlo bastante bien..."
    mn "ไม่ต้องห่วงหาสะ... ยูนะรู้วิธีรับมือกับเขาค่อนข้างดีเลยล่ะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:526
translate english arc2_main_quest6_62866fb6:

    # sr "¿Y qué tal su trabajo en equipo, ya han mejorado?"
    sr "แล้วเรื่องการทำงานเป็นทีมล่ะ พวกเขาดีขึ้นบ้างไหม?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:528
translate english arc2_main_quest6_c74f7ded:

    # mn "Pues... Yuna sigue siendo... ¿Inpulsiva?... Siempre quiere llevar la delantera, y por eso hemos tenido nuestros roces"
    mn "อืม... ยูนะก็ยัง... ใจร้อนอยู่มั้ง?... เธออยากจะเป็นผู้นำอยู่เรื่อย และนั่นก็ทำให้พวกเรามีปากเสียงกันบ้าง"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:529
translate english arc2_main_quest6_81f0cf77:

    # mn "Es como si estuviéramos en una competencia constante, y a veces se le olvida que no todo es fuerza bruta"
    mn "เหมือนพวกเราแข่งกันอยู่ตลอดเวลา และบางครั้งเธอก็ลืมไปว่าไม่ใช่ทุกเรื่องที่จะใช้กำลังตัดสินได้ซะหน่อย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:530
translate english arc2_main_quest6_beecb50b:

    # sr "¿Y qué hay de Hideo? ¿Sigue siendo el... cómo decirlo... el {b}Comodín{/a} del equipo?"
    sr "แล้วฮิเดโอะล่ะ? เขายังคง... จะพูดว่าไงดีล่ะ... เป็น {b}ไพ่ตาย{/a} ของทีมอยู่หรือเปล่า?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:533
translate english arc2_main_quest6_c80e30d4:

    # mn "Jaja... Hideo..., bueno, es Hideo"
    mn "ฮ่าๆ... ฮิเดโอะเหรอ... ก็ หมอนั่นแหละฮิเดโอะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:536
translate english arc2_main_quest6_4426d91d:

    # mn "Aunque últimamente se ha esfuerzado más de lo normal"
    mn "แต่พักหลังมานี้ เขาตั้งใจมากกว่าปกติแฮะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:537
translate english arc2_main_quest6_9ff8399f:

    # mn "Tiene un poco más de coraje y ha aprendido unos cuantos jutsus nuevos"
    mn "มีความกล้าขึ้นนิดหน่อยแถมยังเรียนรู้วิชานินจาใหม่ๆ มาด้วยล่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:538
translate english arc2_main_quest6_bfa72fe0:

    # mn "No sé si habrá aprendido algo nuevo en el entrenamiento con Yuna y Zubon-Sensei"
    mn "ฉันไม่รู้เหมือนกันว่าเขาได้เรียนรู้อะไรใหม่ๆ ระหว่างฝึกกับยูนะและอาจารย์ซูบงบ้างหรือเปล่า"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:540
translate english arc2_main_quest6_28c9c7a9:

    # mn "Es mejor de lo que parece, pero aún tiene mucho que aprender, al menos ya no tropieza tanto con sus propios pies"
    mn "หมอนั่นเก่งกว่าที่เห็นแหละ แต่ก็ยังต้องเรียนรู้อึกเยอะ อย่างน้อยๆ ตอนนี้ก็ไม่ค่อยสะดุดขาตัวเองล้มบ่อยเท่าไหร่แล้วล่ะนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:541
translate english arc2_main_quest6_61803b8b:

    # mn "Ahora ya es un poco más útil que antes jaja..."
    mn "ตอนนี้มีประโยชน์มากกว่าแต่ก่อนนิดหน่อยล่ะมั้ง ฮ่าๆ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:543
translate english arc2_main_quest6_599dd4ca:

    # sk "Qué alentador..."
    sk "ช่างเป็นคำชมที่น่าประทับใจเสียจริง..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:544
translate english arc2_main_quest6_25f426a0:

    # sr "Bueno, ahí es donde entra tu liderazgo, si puedes manejar a esos dos, seguro que puedes manejar cualquier cosa"
    sr "งั้นก็นั่นแหละคือหน้าที่ความเป็นผู้นำของเธอ ถ้าเธอรับมือสองคนนั้นไหว ฉันมั่นใจว่าเธอจัดการได้ทุกเรื่องแน่"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:546
translate english arc2_main_quest6_f733dba8:

    # sk "Solo asegúrate de que no terminen dándose de golpes entre ustedes, y recuerda lo que los llevará lejos es el trabajo en equipo"
    sk "แค่คอยระวังอย่าให้พวกเขากัดกันเองก็พอ และจำไว้ด้วยล่ะว่าสิ่งที่จะพาพวกเธอไปได้ไกลคือการทำงานเป็นทีม"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:547
translate english arc2_main_quest6_ca8c8d14:

    # mn "Sí, eso nos quedó claro en el Examen de Zubon-Sensei..."
    mn "ครับ เรื่องนั้นพวกเราซึ้งใจดีเลยตอนสอบกับซูบง-เซนเซย์..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:549
translate english arc2_main_quest6_029d9910:

    # mn "Pero definitivamente necesitamos practicar mucho más"
    mn "แต่พวกเราก็ยังต้องฝึกกันอีกเยอะเลยล่ะครับ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:552
translate english arc2_main_quest6_e26c25f7:

    # mn "Yuna y yo... Tenemos nuestros problemas, y Hideo... Bueno, aún sigue siendo Hideo... Aunque espero equivocarme"
    mn "ตัวฉันกับยูนะ... เรายังมีปัญหาคาใจกันอยู่ ส่วนฮิเดโอะ... ก็ยังคงเป็นฮิเดโอะตามเคย... แม้ว่าฉันจะหวังว่าฉันคิดผิดก็เถอะนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:553
translate english arc2_main_quest6_f259861e:

    # sr "Entonces, hay trabajo por hacer aún... Pero si alguien puede sacarles todo el potencial, ese eres tú [MN], estoy segura de ello"
    sr "งั้นก็ยังเหลือเรื่องที่ต้องจัดการอีกสินะ... แต่ถ้าจะมีใครดึงศักยภาพสูงสุดของพวกเขาออกมาได้ล่ะก็ ต้องเป็นเธอแน่ๆ [MN] ฉันมั่นใจเลย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:555
translate english arc2_main_quest6_628692b5:

    # mn "Sí, haré lo mejor que pueda para ser un mejor líder, si no puedo dominar a estos dos"
    mn "ครับ ผมจะพยายามอย่างเต็มที่เพื่อเป็นผู้นำที่ดีขึ้น ถ้าแค่สองคนนี้ผมยังคุมให้อยู่หมัดไม่ได้..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:557
translate english arc2_main_quest6_d31888e2:

    # mn "¿Cómo se supone que puedo liderar algo más grande?"
    mn "แล้วผมจะไปนำพาสิ่งที่ยิ่งใหญ่กว่านี้ได้ยังไงล่ะครับ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:559
translate english arc2_main_quest6_c5e4d778:

    # mn "Si quiero restaurar mi clan algún día... Debo demostrar que puedo guiar a quienes están a mi lado"
    mn "ถ้าสักวันหนึ่งผมอยากจะฟื้นฟูตระกูลขึ้นมา... ผมก็ต้องพิสูจน์ให้เห็นว่าผมสามารถชี้นำคนที่อยู่เคียงข้างได้"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:560
translate english arc2_main_quest6_8887ac99:

    # mn "Ser un verdadero líder no solo significa ser fuerte, sino ser alguien en quien confíen y que pueda guiarlos hacia un mejor camino"
    mn "การเป็นผู้นำที่แท้จริงไม่ได้หมายถึงแค่การมีความแข็งแกร่งอย่างเดียว แต่ต้องเป็นคนที่พวกเขากล่าวไว้ใจและนำทางไปสู่หนทางที่ดีขึ้นได้ด้วย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:563
translate english arc2_main_quest6_639b733f_4:

    # sk "..."
    sk "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:565
translate english arc2_main_quest6_2c3f5c47:

    # sr "Así es, y no olvides que estarás forjando ese futuro paso a paso, así que no tengas miedo de dar el siguiente, ¿Entendido?"
    sr "พูดได้ดีนี่ และอย่าลืมล่ะว่าเธอจะค่อยๆ สร้างอนาคตนั้นทีละก้าว ดังนั้นอย่ากลัวที่จะก้าวต่อไปข้างหน้า เข้าใจไหม?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:568
translate english arc2_main_quest6_7b3e85db:

    # sk "También recuerda que aquí estarémos para ayudarte y apoyarte en todo lo que necesites"
    sk "อีกอย่าง จำไว้ด้วยนะว่าพวกเราจะคอยอยู่ช่วยและสนับสนุนเธอในทุกๆ เรื่องที่เธอต้องการเสมอ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:569
translate english arc2_main_quest6_9b72d43c:

    # mn "Gracias, de verdad, por siempre estar ahí para mí..."
    mn "ขอบคุณจริงๆ ครับที่คอยอยู่เคียงข้างผมมาตลอด..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:571
translate english arc2_main_quest6_cdd24b4c:

    # sk "No es nada, es un placer"
    sk "เรื่องแค่นี้เอง ฉันยินดีอยู่แล้วล่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:573
translate english arc2_main_quest6_a0bddc29:

    # sr "Estarémos en las finales para verte, ¿Lo sabes verdad? Así que asegúrate de darnos un buen espectáculo jaja"
    sr "พวกเราจะไปรอดูเธอในรอบชิงชนะเลิศนะ รู้ใช่ไหมล่ะ? เพราะงั้นช่วยโชว์ฟอร์มเจ๋งๆ ให้พวกเราดูด้วยล่ะ ฮ่าๆ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:575
translate english arc2_main_quest6_4e56918c:

    # mn "Claro jajaja, no voy a decepcionarlas"
    mn "แน่นอนครับ ฮ่าๆๆ ผมไม่ทำให้พวกพี่ผิดหวังแน่"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:577
translate english arc2_main_quest6_996cbcdb:

    # sk "Bien, entonces te deseamos mucha suerte [MN]"
    sk "งั้นก็ขอให้ [MN] โชคดีนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:578
translate english arc2_main_quest6_1e610cce:

    # sk "Sabémos que serás capaz de lidiar con todo lo que está por venir"
    sk "พวกเราเชื่อว่าเธอจะต้องรับมือกับทุกสิ่งที่กำลังจะเข้ามาได้แน่"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:582
translate english arc2_main_quest6_190373e9:

    # n "Con una última charla, [MN] se despidió de Sarada y Sakura, llevando consigo sus palabras de aliento mientras se preparaba para el próximo desafío que lo esperaba..."
    n "หลังจากการพูดคุยครั้งสุดท้าย [MN] ก็บอกลาซาราดะและซากุระ พร้อมกับเก็บคำพูดให้กำลังใจเหล่านั้นติดตัวไปขณะที่เตรียมพร้อมเผชิญหน้ากับความท้าทายต่อไปที่รออยู่..."

# TODO: Translation updated at 2024-12-20 07:52

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:138
translate english arc2_main_quest6_d37f7987:

    # sk "Yo te lo veo muy bien, ya sea con el cabello largo o corto"
    sk "ไม่ว่าจะผมยาวหรือผมสั้นเธอก็ดูดีหมดเลยนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:164
translate english arc2_main_quest6_eeeb29e0:

    # sk "Solo estoy apreciando mi obra maestra, solo míralos"
    sk "ฉันก็แค่ชื่นชมผลงานชิ้นเอกของตัวเอง ดูพวกเขาสิ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:199
translate english arc2_main_quest6_d17a165e:

    # sk "Aaah... Que bien se siente el ambiente en este lugar"
    sk "อ่าา... บรรยากาศตรงนี้รู้สึกดีจังเลยนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:438
translate english arc2_main_quest6_cc4effbf:

    # n "La oportunidad de construir un futuro..."
    n "โอกาสในการสร้างอนาคต..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:528
translate english arc2_main_quest6_1a3108bd:

    # mn "Pues... Yuna sigue siendo... ¿Impulsiva?... Siempre quiere llevar la delantera, y por eso hemos tenido nuestros roces"
    mn "อืม... ยูนะก็ยัง... ใจร้อนอยู่มั้ง?... เธออยากจะเป็นผู้นำอยู่เรื่อย และนั่นก็ทำให้พวกเรามีปากเสียงกันบ้าง"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest6.rpy:536
translate english arc2_main_quest6_848f5464:

    # mn "Aunque últimamente se ha esforzado más de lo normal"
    mn "ถึงช่วงนี้เขาจะตั้งใจกว่าปกติก็เถอะนะ"
