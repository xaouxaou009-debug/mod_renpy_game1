# TODO: Translation updated at 2024-12-01 21:25

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:5
translate english arc2_main_quest3_673ad199:

    # n "Luego de recibir un mensaje de Naruto, [MN] entra a la oficina del Hokage"
    n "หลังจากได้รับข้อความจากนารูโตะ [MN] ก็เดินเข้าไปในห้องทำงานของโฮคาเงะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:14
translate english arc2_main_quest3_6a313c08:

    # mn "Buen día Séptimo Hokage, ¿Me necesitaba para algo?"
    mn "สวัสดีครับท่านโฮคาเงะรุ่นที่ 7 มีเรื่องอะไรให้ผมช่วยหรือเปล่าครับ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:16
translate english arc2_main_quest3_ff14a8b2:

    # nt "[MN], llegas justo a tiempo, necesito hablar contigo sobre algo"
    nt "[MN] มาพอดีเลย ฉันมีเรื่องอยากจะคุยกับเธอน่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:17
translate english arc2_main_quest3_664aeb76:

    # nt "Ya estarás al tanto de los exámenes Chunin, así que no me extenderé en explicaciones"
    nt "เธอคงจะรู้เรื่องการสอบจูหนินอยู่แล้วสินะ งั้นฉันจะไม่พูดรายละเอียดเยอะก็แล้วกัน"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:19
translate english arc2_main_quest3_ae674f60:

    # nt "Tu maestro Zubon, luego de años sin recomendar su equipo, los recomendara este año"
    nt "ซูบง อาจารย์ของเธอ หลังจากที่ไม่เคยเสนอชื่อลูกทีมมาหลายปี ปีนี้เขาจะส่งพวกเธอเข้าสอบแล้วล่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:20
translate english arc2_main_quest3_03c9985d:

    # nt "Dijo que su entrenamiento ya ha acabado y ya están listos para los exámenes..."
    nt "เขาบอกว่าการฝึกฝนของพวกเธอสมบูรณ์แล้ว และพร้อมสำหรับการสอบ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:21
translate english arc2_main_quest3_08824675:

    # mn "Así es, hace poco Zubon-Sensei nos hizo un exámen para evaluarnos como equipo"
    mn "ใช่ครับ เมื่อเร็วๆ นี้อาจารย์ซูบงเพิ่งให้บททดสอบเพื่อประเมินพวกเราในฐานะทีมมาครับ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:22
translate english arc2_main_quest3_72c4f895:

    # nt "Hmm... ¿Porqué los recomendó hasta ahora?"
    nt "อืม... ทำไมจู่ๆ เขาถึงเพิ่งมาแนะนำให้พวกเธอสอบตอนนี้ล่ะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:24
translate english arc2_main_quest3_e1bf454d:

    # mn "Ah... Fue porque nuestro trabajo en equipo era casi nulo jaja... Pero ya estamos bien"
    mn "อ่า... ก็เพราะว่าก่อนหน้านี้พวกเราแทบไม่มีการทำงานเป็นทีมเลยน่ะครับ ฮ่าๆ... แต่ตอนนี้พวกเราโอเคแล้วล่ะครับ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:25
translate english arc2_main_quest3_c00cd2dc:

    # mn "Entre todos logramos vencer a Zubon-Sensei en el exámen que nos hizo"
    mn "พวกเราช่วยกันจนสามารถเอาชนะอาจารย์ซูบงได้ในบททดสอบที่เขาให้มาเลยนะครับ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:26
translate english arc2_main_quest3_90e4ae9f:

    # nt "Entiendo..."
    nt "งั้นเหรอ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:27
translate english arc2_main_quest3_38e28f63:

    # nt "También quiero saber cómo vas con el {b}Karugan{/a} y el {b}Sharingan{/a}, ¿Ya has aprendido a dominarlos?"
    nt "ฉันก็อยากรู้เหมือนกันว่าช่วงนี้เป็นยังไงบ้างกับ {b}คารูกัน{/a} และ {b}เนตรวงแหวน{/a} เธอควบคุมมันได้คล่องขึ้นหรือยังล่ะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:29
translate english arc2_main_quest3_f0102073:

    # mn "Bueno, no diría que los he dominado al cien por ciento, pero ya puedo usarlos de una manera más eficiente"
    mn "อืม จะว่าเชี่ยวชาญร้อยเปอร์เซ็นต์เลยก็ยังไม่ใช่หรอครับ แต่ตอนนี้ผมใช้มันได้มีประสิทธิภาพมากขึ้นแล้วล่ะครับ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:30
translate english arc2_main_quest3_fec18bf9:

    # mn "Sarada aceptó a entrenarme para usarlos más eficientemente, con ella aprendí a activar el {b}Karugan{/a} y a usar más eficientemente el {b}Sharingan{/a}"
    mn "ซาราดะยอมช่วยฝึกให้ผมใช้มันได้อย่างมีประสิทธิภาพมากขึ้นครับ ได้เธอช่วยนี่แหละ ทำให้ผมเปิดใช้งาน {b}คารูกัน{/a} และใช้ {b}เนตรวงแหวน{/a} ได้คล่องขึ้นเยอะเลย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:31
translate english arc2_main_quest3_672bcffc:

    # nt "..."
    nt "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:33
translate english arc2_main_quest3_35f75605:

    # nt "¿Sabes? Nunca creí que existiera un Dojutsu como el tuyo"
    nt "รู้ไหม? ฉันไม่เคยคิดเลยนะว่าจะมีเนตรสังสาระหรือเนตรพิเศษแบบของเธออยู่บนโลกนี้ด้วย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:34
translate english arc2_main_quest3_325a4eb5:

    # nt "Tampoco creí que el usuario de un Dojutsu pudiera ser capaz de ser portador de otro Dojutsu completamente diferente"
    nt "แล้วก็ไม่เคยคิดมาก่อนเลยว่า นินจาคนหนึ่งจะสามารถใช้เนตรพิเศษอีกรูปแบบที่แตกต่างกันโดยสิ้นเชิงได้ด้วย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:35
translate english arc2_main_quest3_83cca008:

    # nt "Muy pocos ninjas han sido capaces de lograr esa hazaña"
    nt "มีนินจาน้อยคนมากเลยนะที่จะทำเรื่องแบบนั้นได้เนี่ย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:36
translate english arc2_main_quest3_427b2f26:

    # nt "Sasuke era portador de un {b}Mangekyo Shaingan Eterno{/a} y un {b}Rinnegan{/a}"
    nt "ซาสึเกะเป็นผู้ครอบครอง {b}เนตรวงแหวนกระจกเงาหมื่นวิถีนิรันดร์{/a} และ {b}เนตรสังสาระ{/a}"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:38
translate english arc2_main_quest3_0b731184:

    # nt "Aunque es una verdadera lástima que haya perdido su {b}Rinnegan{/a} en la batalla contra {b}Ishiki Ootsutsuki{/a}"
    nt "ถึงแม้ว่ามันจะน่าเสียดายจริงๆ ที่เขาต้องสูญเสีย {b}เนตรสังสาระ{/a} ไปในการต่อสู้กับ {b}โอทสึสึกิ อิชิกิ{/a} ก็ตาม"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:40
translate english arc2_main_quest3_4021347d:

    # nt "Afortunadamente, luego de ese incidente volvió la {b}Paz{/a} a la aldea"
    nt "โชคดีที่หลังจากเหตุการณ์นั้น {b}ความสงบสุข{/a} ก็กลับคืนสู่หมู่บ้านอีกครั้ง"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:42
translate english arc2_main_quest3_ed312803:

    # nt "A lo que quiero llegar es..."
    nt "สิ่งที่ฉันพยายามจะบอกก็คือ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:43
translate english arc2_main_quest3_25106522:

    # nt "Eres realmente uno en un millón, eres increíble"
    nt "เธอเป็นหนึ่งในล้านจริงๆ เธอนี่สุดยอดไปเลยนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:44
translate english arc2_main_quest3_5502cecb:

    # mnn "..."
    mnn "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:46
translate english arc2_main_quest3_f509ecf3:

    # mn "Quizás pueda ser por los experimentos que hizo {b}Shin{/a} conmigo..."
    mn "อาจจะเป็นเพราะการทดลองที่ {b}ชิน{/a} เคยทำกับผมไว้ล่ะมั้ง..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:47
translate english arc2_main_quest3_e9b42672:

    # nt "Oh, este..."
    nt "อ่า... อืม..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:48
translate english arc2_main_quest3_1051f0b3:

    # nt "Siento haber tocado el tema, de veras, sé que es algo de lo que no te gusta hablar"
    nt "ฉันขอโทษที่พูดถึงเรื่องนี้นะ จริงๆ นะ ฉันรู้ว่ามันเป็นเรื่องที่เธอไม่อยากพูดถึงเท่าไหร่"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:50
translate english arc2_main_quest3_2c69e050:

    # mn "No se preocupe, estoy bien"
    mn "ไม่ต้องห่วงครับ ผมไม่เป็นไร"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:51
translate english arc2_main_quest3_672bcffc_1:

    # nt "..."
    nt "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:52
translate english arc2_main_quest3_cf2922d0:

    # nt "Bueno, ¿Entonces ya te sientes capaz de entrar a los exámenes Chunin?"
    nt "งั้นเหรอ แล้วเธอรู้สึกพร้อมสำหรับการสอบจูหนินแล้วหรือยังล่ะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:53
translate english arc2_main_quest3_e5a72e28:

    # nt "Este año serán muy duros, no serán tan fáciles como los años anteriores"
    nt "ปีนี้การสอบจะโหดหินมากๆ เลยนะ ไม่ง่ายเหมือนหลายๆ ปีที่ผ่านมาหรอก"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:56
translate english arc2_main_quest3_c3bb8789:

    # mn "Sí, pasaré los exámenes y me convertiré en un Chunin"
    mn "ครับ ผมจะผ่านการสอบและกลายเป็นจูหนินให้ได้ครับ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:57
translate english arc2_main_quest3_672bcffc_2:

    # nt "..."
    nt "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:59
translate english arc2_main_quest3_d723cb0e:

    # nt "¿Qué es lo que harás cuando ya seas un Chunin?"
    nt "แล้วถ้าได้เป็นจูหนินแล้ว เธอวางแผนจะทำอะไรต่อไปล่ะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:61
translate english arc2_main_quest3_5502cecb_1:

    # mnn "..."
    mnn "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:63
translate english arc2_main_quest3_82caf736:

    # mn "Voy a restablecer mi Clan."
    mn "ผมจะฟื้นฟูตระกูลของผมขึ้นมาใหม่ครับ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:65
translate english arc2_main_quest3_e6a12a7d:

    # nt "¡Ah!" with vpunch
    nt "อ๊ะ!" with vpunch

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:66
translate english arc2_main_quest3_add1c597:

    # mn "Mi meta será dominar el {b}Karugan{/a} y buscar más información sobre mi Clan"
    mn "เป้าหมายของผมคือการฝึกฝนเนตร {b}คารูกัน{/a} ให้เชี่ยวชาญ และหาข้อมูลเพิ่มเติมเกี่ยวกับตระกูลของผมครับ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:68
translate english arc2_main_quest3_f76ea1af:

    # mn "Pero, para eso quería pedirle permiso de ir al {b}Laboratorio de Shin{/a} y buscar información ahí"
    mn "แต่สำหรับเรื่องนั้น ฉันอยากขออนุญาตไปที่ {b}ห้องทดลองของชิน{/a} เพื่อค้นหาข้อมูลที่นั่นหน่อยค่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:69
translate english arc2_main_quest3_407840c3:

    # mn "Estoy casi seguro que ahí debe haber más información de la que posee Orochimaru"
    mn "ผมค่อนข้างมั่นใจว่าที่นั่นน่าจะมีข้อมูลมากกว่าที่โอโรจิมารุมีอยู่ซะอีกครับ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:70
translate english arc2_main_quest3_cc81768c:

    # nt "Mmm..."
    nt "อืม..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:72
translate english arc2_main_quest3_4a0508a4:

    # nt "Si eso es lo que deseas, no puedo cortarte las alas"
    nt "ถ้ามันเป็นสิ่งที่เธอต้องการ ฉันก็คงขัดขวางเธอไม่ได้หรอกนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:73
translate english arc2_main_quest3_5987fe7f:

    # nt "Si pasas los exámenes Chunin tendrás mi permiso para ir"
    nt "ถ้าเธอผ่านการสอบจูหนินได้ ฉันก็จะอนุญาตให้เธอไปได้เลย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:74
translate english arc2_main_quest3_b036ad22:

    # mn "¿De veras? ¡Muchas Gracias!"
    mn "จริงเหรอครับ? ขอบคุณมากๆ เลยครับ!"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:75
translate english arc2_main_quest3_f94f82b8:

    # nt "De veras jajaja"
    nt "จริงสิ ฮ่าๆๆๆ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:76
translate english arc2_main_quest3_d91df1df:

    # nt "En fin, también te hice venir por otra cosa"
    nt "ว่าแต่อันที่จริง ที่ฉันเรียกเธอมาวันนี้ก็มีอีกเรื่องหนึ่งด้วยเหมือนกัน"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:77
translate english arc2_main_quest3_aca340f8:

    # mn "Claro, ¿Qué necesita?"
    mn "ครับ มีอะไรให้ผมช่วยเหรอครับ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:78
translate english arc2_main_quest3_672bcffc_3:

    # nt "..."
    nt "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:79
translate english arc2_main_quest3_54cd592c:

    # nt "Quiero ver con mis propios ojos cuanto has mejorado"
    nt "ฉันอยากจะเห็นกับตาตัวเองซะหน่อยว่าเธอเก่งขึ้นขนาดไหนแล้ว"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:80
translate english arc2_main_quest3_5802953f:

    # nt "Quiero que tengamos una batalla"
    nt "ฉันอยากจะลองประลองฝีมือกับเธอดูหน่อย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:81
translate english arc2_main_quest3_42d746e4:

    # mn "¡¿Q-Qué?!" with vpunch
    mn "ว-ว่าไงนะครับ?!" with vpunch

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:82
translate english arc2_main_quest3_186e0f55:

    # mn "¿D-De verdad? ¡Estaría encantado!"
    mn "จ-จริงเหรอครับ? ด้วยความยินดีเลยครับ!"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:83
translate english arc2_main_quest3_e1e0068a:

    # nt "Jeje, ¿Vamos entonces? No puedo esperar a ver tus avances"
    nt "งั้นเหรอ ถ้างั้นเราไปกันเลยดีกว่าไหม? ฉันชักจะรอูดูพัฒนาการของเธอไม่ไหวแล้วสิ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:84
translate english arc2_main_quest3_5a5333a4:

    # mn "¿Ahora? Claro, vámos"
    mn "ตอนนี้เลยเหรอครับ? ได้เลยครับ ไปกันเถอะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:88
translate english arc2_main_quest3_a20cefa7:

    # "..."
    "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:89
translate english arc2_main_quest3_6262e7b3:

    # n "Luego de la propuesta de Naruto hacia [MN] para tener un duelo, ambos se dirigen al campo de entrenamiento"
    n "หลังจากที่นารูโตะเอ่ยปากชวน [MN] ประลอง ทั้งคู่ก็พากันมุ่งหน้าไปยังสนามฝึกซ้อม"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:99
translate english arc2_main_quest3_fdb2c640:

    # n "El sol estaba en el punto más alto, y en un lado del campo, {b}Naruto Uzumaki, el Séptimo Hokage{/a}"
    n "ดวงอาทิตย์ลอยอยู่ตรงจุดสูงสุด ท่ามกลางสนามฝึกซ้อมฝั่งหนึ่งคือ {b}อุซุมากิ นารูโตะ โฮคาเงะรุ่นที่เจ็ด{/a}"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:100
translate english arc2_main_quest3_c5b9faf3:

    # n "Se encontraba de pie, con sus ojos llenos de un brillo sin igual y con una sonrisa de oreja a oreja"
    n "เขายืนอยู่ตรงนั้น แววตาเต็มไปด้วยประกายความตื่นเต้นที่หาใครเทียบไม่ได้ พร้อมกับรอยยิ้มกว้างบนใบหน้า"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:101
translate english arc2_main_quest3_23947202:

    # n "Está deseoso de tener un duelo con [MN] para probar su potencial"
    n "เขากระตือรือร้นที่จะได้ประลองฝีมือกับ [MN] เพื่อทดสอบศักยภาพของเจ้าตัว"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:105
translate english arc2_main_quest3_47fb50f5:

    # n "Al otro lado, se encontraba [MN], un joven aspirante a Chunin"
    n "ส่วนอีกด้านหนึ่งคือ [MN] ผู้เข้าสอบจูหนินหนุ่ม"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:106
translate english arc2_main_quest3_028abca4:

    # n "A diferencia del 7mo Hokage, se encuentra ansioso, observando con mucho cuidado al Hokage..."
    n "ต่างจากโฮคาเงะรุ่นที่เจ็ด เขาดูมีความกังวลอยู่บ้างและคอยเฝ้ามองโฮคาเงะอย่างระมัดระวัง..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:107
translate english arc2_main_quest3_e9ded361:

    # n "Pero, eso no quiere decir que no desea enfrentarse al Hokage"
    n "แต่นั่นไม่ได้หมายความว่าเขาไม่อยากเผชิญหน้ากับท่านโฮคาเงะหรอกนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:108
translate english arc2_main_quest3_d65ad825:

    # n "Para [MN] es un honor luchar contra su ídolo y aprender de él..."
    n "สำหรับ [MN] แล้ว นี่คือเกียรติยศที่ได้ต่อสู้กับไอดอลของตัวเองและได้เรียนรู้จากเขา..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:112
translate english arc2_main_quest3_7c3b3f99:

    # nt "[MN]..."
    nt "[MN]..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:113
translate english arc2_main_quest3_07edb118:

    # nt "No quiero que te contengas, ¿Entiendes?"
    nt "ฉันไม่ต้องการให้เธอออมมือนะ เข้าใจไหม?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:114
translate english arc2_main_quest3_33941478:

    # nt "Aunque ya esté viejo, no significa que no tenga mis trucos bajo la manga"
    nt "ถึงฉันจะแก่ลงแล้ว แต่ก็ไม่ได้แปลว่าไม่มีลูกเล่นซ่อนไว้หรอกนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:115
translate english arc2_main_quest3_e084964f:

    # nt "Quiero que uses todo lo que tienes conmigo, tanto tu {b}Karugan{/a} como tu {b}Sharingan{/a}"
    nt "ฉันอยากให้เธอเอาทุกอย่างที่มีมาใช้สู้กับฉัน ทั้ง {b}คารูกัน{/a} และ {b}เนตรวงแหวน{/a} ของเธอเลย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:116
translate english arc2_main_quest3_f4777136:

    # nt "Este combate será una gran oportunidad para aprender de mí, así que pesta mucha atención"
    nt "การต่อสู้ครั้งนี้จะเป็นโอกาสดีที่จะได้เรียนรู้จากฉัน ตั้งใจดูให้ดีล่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:119
translate english arc2_main_quest3_06c26dd9:

    # mn "¡Si señor, Usaré todo lo que he aprendido hasta ahora!" with vpunch
    mn "รับทราบครับ ผมจะเอาทุกอย่างที่เรียนรู้มาทั้งหมดใช้เต็มที่เลย!" with vpunch

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:120
translate english arc2_main_quest3_d7398258:

    # n "[MN] asintió con determinación, consciente de la gravedad de las palabras de Naruto"
    n "[MN] พยักหน้ารับด้วยความมุ่งมั่น ตระหนักถึงความหมายอันหนักแน่นในคำพูดของนารูโตะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:121
translate english arc2_main_quest3_faafc681:

    # n "Estaba decidido a demostrarle al {b}Séptimo Hokage{/a} cuánto ha mejorado"
    n "เขาตั้งใจแน่วแน่ที่จะแสดงให้ {b}โฮคาเงะรุ่นที่เจ็ด{/a} ได้เห็นว่าเขาพัฒนาขึ้นมากแค่ไหน"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:126
translate english arc2_main_quest3_3532c628:

    # nt "Muy bien... Entonces..."
    nt "งั้นล่ะก็... เริ่มเลยนะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:127
translate english arc2_main_quest3_c5bf9f58:

    # nt "¡AQUÍ VAMOS!"
    nt "ลุยล่ะนะ!"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:136
translate english before_naruto_battle_4c6cb48b:

    # n "[MN] se prepara para la lucha"
    n "[MN] เตรียมพร้อมสำหรับการต่อสู้"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:145
translate english after_naruto_battle_f07105b5:

    # mn "¡A-Aún no he acabado!"
    mn "พ-ผมยังไม่ยอมแพ้หรอกนะครับ!"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:146
translate english after_naruto_battle_93cdbb80:

    # mn "A-Aún puedo pelear..."
    mn "ผ-ผมยังสู้ไหว..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:149
translate english after_naruto_battle_9e35ee24:

    # mn "(Maldición...)" with dissolve1
    mn "(บ้าเอ๊ย...)" with dissolve1

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:150
translate english after_naruto_battle_df55f9dd:

    # mn "(El poder del Séptimo Hokage... Es descomunal...)"
    mn "(พลังของท่านโฮคาเงะรุ่นที่เจ็ด... มันเหนือชั้นเกินไปจริงๆ...)"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:151
translate english after_naruto_battle_b05c11a2:

    # mn "(Parece que solo está jugando conmigo...)"
    mn "(ดูเหมือนว่าเขาจะแค่เล่นสนุกกับเราอยู่สินะ...)"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:152
translate english after_naruto_battle_6fb45478:

    # mn "(Mierda... Al menos... Tengo que llevar algo de esta pelea...)"
    mn "(เวรเอ๊ย... อย่างน้อยที่สุด... เราก็ต้องเก็บเกี่ยวอะไรบางอย่างจากการต่อสู้ครั้งนี้ให้ได้...)"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:153
translate english after_naruto_battle_da5b0236:

    # mn "(Si pudiera {b}Copiar{/a} algún jutsu con mi {b}Sharingan{/a} como Sarada me enseñó)"
    mn "(ถ้าเราสามารถ {b}คัดลอก{/a} คาถาด้วย {b}เนตรวงแหวน{/a} เหมือนที่ซาราดะสอนล่ะก็)"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:154
translate english after_naruto_battle_ea601e9a:

    # mn "(Tengo que prestar mucha atención a sus siguientes movimientos)"
    mn "(เราต้องคอยสังเกตการเคลื่อนไหวครั้งต่อไปของเขาให้ดี)"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:156
translate english after_naruto_battle_4b0c058b:

    # nt "¿Sabes? Me sorprende que aún sigas de pie"
    nt "รู้ไหม? ฉันประหลาดใจจริงๆ นะเนี่ยที่เธอยังยืนอยู่ได้เนี่ย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:157
translate english after_naruto_battle_e1e2cc32:

    # nt "Eso significa que tienes una gran fuerza de voluntad..."
    nt "นั่นหมายความว่าเธอมีความมุ่งมั่นที่ยอดเยี่ยมมากเลย..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:158
translate english after_naruto_battle_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:159
translate english after_naruto_battle_5a8c1cda:

    # mn "P-Por favor Séptimo... Atáqueme con su mejor jutsu"
    mn "ท-ท่านโฮคาเงะครับ... ช่วยโจมตีผมด้วยคาถาที่ดีที่สุดของท่านเลยครับ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:160
translate english after_naruto_battle_672bcffc:

    # nt "..."
    nt "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:161
translate english after_naruto_battle_32462c4b_1:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:162
translate english after_naruto_battle_0d18e4fb:

    # nt "Muy bien..."
    nt "งั้นเหรอ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:163
translate english after_naruto_battle_0be4483a:

    # nt "Este es un jutsu que creé yo mismo, y lo usé para luchar contra Kaguya Ootsutsuki"
    nt "นี่คือคาถาที่ฉันคิดค้นขึ้นมาเอง และฉันก็เคยใช้มันต่อสู้กับ โอโอซึสึกิ คางูยะ มาแล้วด้วยนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:164
translate english after_naruto_battle_adaa5069:

    # nt "¿Estás seguro que quieres que te ataque con él?"
    nt "แน่ใจแล้วเหรอว่าอยากให้ฉันใช้มันโจมตีใส่น่ะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:166
translate english after_naruto_battle_32462c4b_2:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:167
translate english after_naruto_battle_66bed46e:

    # mn "¡S-Sí!..."
    mn "พ-ครับ!..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:168
translate english after_naruto_battle_7d13d1ca:

    # nt "Muy bien, después no lo vayas a lamentar"
    nt "งั้นก็ได้ อย่ามาเสียใจทีหลังล่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:170
translate english after_naruto_battle_1e030f53:

    # nt "¡AQUÍ VOY!" with vpunch
    nt "ลุยล่ะนะ!" with vpunch

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:175
translate english after_naruto_battle_08f0eac7:

    # "¡!"
    "!"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:177
translate english after_naruto_battle_fe3589d2:

    # mn "Muy bien, ahora es el momento"
    mn "เอาล่ะ จังหวะนี้แหละ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:180
translate english after_naruto_battle_fb390cac:

    # mn "¡Sharingan!" with vpunch
    mn "เนตรวงแหวน!" with vpunch

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:181
translate english after_naruto_battle_287729a6:

    # nt "Jejeje... Perfecto, tienes que ver atentamente"
    nt "หึๆๆ... ดีมาก ตั้งใจดูให้ดีล่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:182
translate english after_naruto_battle_f19e3037:

    # nt "¡Jutsu Sexy!" with vpunch
    nt "คาถายั่วยวน!" with vpunch

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:183
translate english after_naruto_battle_37529391:

    # mn "¿Q-Qué?"
    mn "อ-อะไรนะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:187
translate english after_naruto_battle_82ab7fca:

    # mn "¡AAAH!" with hpunch
    mn "อ๊ากกก!" with hpunch

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:188
translate english after_naruto_battle_b4d7c92d:

    # nk "Oh... [MN]"
    nk "อ๊ะ... [MN]"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:189
translate english after_naruto_battle_0a85e118:

    # nk "Ven"
    nk "มาสิ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:190
translate english after_naruto_battle_b439a816:

    # nk "Ven y tóca mis senos..."
    nk "มาสัมผัสหน้าอกของฉันสิ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:191
translate english after_naruto_battle_1d8556e4:

    # nk "Por favor... Estoy tan caliente..."
    nk "ได้โปรด... ฉันรู้สึกร้อนเหลือเกิน..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:195
translate english after_naruto_battle_2f70de4b:

    # mn "¡AAAAHH!" with vpunch
    mn "อ๊ากกกกก!" with vpunch

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:196
translate english after_naruto_battle_0f8ff342:

    # nk "Muy bien... Parece que aún tengo mi encanto después de tantos años"
    nk "ให้ตายสิ... ดูเหมือนว่าฉันจะยังมีเสน่ห์อยู่เหมือนเดิมหลังจากผ่านมาหลายปีนะเนี่ย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:200
translate english after_naruto_battle_7cf28961:

    # n "Luego de la derrota de [MN]..."
    n "หลังจาก [MN] พ่ายแพ้..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:210
translate english after_naruto_battle_eb4eaff7:

    # mn "Maldición... ¿Cómo fui capaz de perder contra un jutsu así?"
    mn "เวรเอ๊ย... เราแพ้คาถางี่เง่าแบบนั้นได้ยังไงเนี่ย?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:212
translate english after_naruto_battle_71dbee44:

    # nt "Jajaja, debiste ver tu cara jajaja"
    nt "ฮ่าๆๆๆ เธอรอดูกใบหน้าตัวเองเมื่อกี้ไม่ได้จริงๆ ฮ่าๆๆๆ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:215
translate english after_naruto_battle_5502cecb:

    # mnn "..."
    mnn "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:217
translate english after_naruto_battle_75be3413:

    # mn "No es gracioso..."
    mn "มันไม่เห็นจะตลกเลยนะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:218
translate english after_naruto_battle_2be95e48:

    # nt "Bueno, eso te servirá como una lección de mi parte"
    nt "เอาล่ะ ถือว่านี่เป็นบทเรียนจากฉันก็แล้วกัน"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:220
translate english after_naruto_battle_3d3dae47:

    # nt "En una batalla, tus enemigos pueden recurrir a ataques sucios para derrotarte"
    nt "ในการต่อสู้ ศัตรูของเธออาจจะใช้เล่ห์เหลี่ยมสกปรกเพื่อเอาชนะเธอก็ได้นะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:222
translate english after_naruto_battle_d5afdb6b:

    # mn "S-Si... Es solo que no creí que el Hokage me haría algo así..."
    mn "พ-ครับ... เพียงแต่ผมไม่คิดเลยว่าท่านโฮคาเงะจะทำอะไรแบบนั้นกับผม..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:224
translate english after_naruto_battle_0efe559e:

    # nt "Jajaja, hacía mucho no hacía ese jutsu"
    nt "ฮ่าๆๆๆ นานมากแล้วเหมือนกันนะที่ฉันไม่ได้ใช้คาถานั้นน่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:226
translate english after_naruto_battle_463caf2f:

    # mn "¿Era verdad que lo usó en la pelea contra Kagura Ootsutsuki?"
    mn "นี่เรื่องจริงเหรอครับที่คุณใช้มันตอนสู้กับ โอโอซึสึกิ คางูยะ จริงๆ น่ะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:227
translate english after_naruto_battle_fe87745b:

    # nt "Si, no mentía"
    nt "จริงสิ ฉันไม่ได้โกหกซะหน่อย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:228
translate english after_naruto_battle_a906af7d:

    # nt "Usé el jutsu sexy para distraerla y acertarle un buen golpe"
    nt "ฉันใช้คาถายั่วยวนเพื่อเบี่ยงเบนความสนใจของเธอ แล้วก็หาจังหวะโจมตีเข้าเต็มๆ น่ะสิ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:229
translate english after_naruto_battle_cda11871:

    # mn "Vaya... Nadie pensaría que funcionaría con algo así"
    mn "โห... คงไม่มีใครคิดหรอกครับว่าจะใช้มุกแบบนั้นได้ผลด้วย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:230
translate english after_naruto_battle_19157a27:

    # nt "Jajaja, que buenos tiempos, de veras!"
    nt "ฮ่าๆๆๆ มันเป็นช่วงเวลาที่ดีจริงๆ นะ!"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:231
translate english after_naruto_battle_5ebd1d14:

    # nt "*suspiro* Bueno, este duelo no solo te sirvió a tí"
    nt "*ถอนหายใจ* เอาล่ะ การประลองครั้งนี้ไม่ได้มีประโยชน์แค่กับเธออย่างเดียวนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:232
translate english after_naruto_battle_47226e7f:

    # nt "Me sirvió para ver cuanto has mejorado"
    nt "แต่มันยังช่วยให้ฉันได้เห็นว่าเธอพัฒนาขึ้นมากแค่ไหนด้วย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:233
translate english after_naruto_battle_e9978f8a:

    # nt "Puedo ver que ya tienes un mejor manejo de tus dos {b}Dojutsu{/a}"
    nt "ฉันเห็นว่าเธอควบคุม {b}เนตรวิถี{/a} ทั้งสองข้างได้ดีขึ้นแล้วสินะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:234
translate english after_naruto_battle_f8c3996e:

    # nt "¿Has estado entrenando bien cierto?"
    nt "เธอฝึกฝนมาเป็นอย่างดีเลยสินะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:236
translate english after_naruto_battle_ee9fbc05:

    # mn "Oh, si, he estado entrenando muy duro para dominarlos a la perfección"
    mn "อ๋อ ครับ ผมฝึกฝนอย่างหนักเลยล่ะครับเพื่อให้ควบคุมมันได้อย่างสมบูรณ์แบบ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:237
translate english after_naruto_battle_a636043a:

    # nt "Se hecha de ver mucho en el campo de batalla"
    nt "มันแสดงออกมาให้เห็นชัดเจนเลยตอนอยู่สนามรบ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:239
translate english after_naruto_battle_b97446f7:

    # nt "Has mejorado mucho, aunque no quiero que por eso te confíes en los Exámenes Chunin"
    nt "เธอเก่งขึ้นมากก็จริง แต่ฉันไม่อยากให้เธอชะล่าใจจนเกินไปในการสอบจูยูนนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:240
translate english after_naruto_battle_7a23d0b4:

    # nt "Porque seas fuerte no significa que no existan tipos más fuertes que tú"
    nt "การที่เธอเก่งไม่ได้หมายความว่าจะไม่มีคนที่เก่งกว่าเธอหรอกนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:241
translate english after_naruto_battle_9d11e1f7:

    # mn "Entendido Séptimo, gracias por el consejo"
    mn "เข้าใจแล้วครับท่านรุ่นที่เจ็ด ขอบคุณสำหรับคำแนะนำครับ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:243
translate english after_naruto_battle_b1f10ae1:

    # nt "Bien, quiero verte triunfar en los próximos exámenes, así que no me decepciones, ¿Entendido?"
    nt "เอาล่ะ ฉันอยากเห็นเธอประสบความสำเร็จในการสอบที่จะถึงนี้ เพราะงั้นอย่าทำให้ฉันผิดหวังล่ะ เข้าใจไหม?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:244
translate english after_naruto_battle_662fc4b5:

    # nt "Te tengo fé"
    nt "ฉันเชื่อมั่นในตัวเธอนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:245
translate english after_naruto_battle_257f245e:

    # mn "S-Séptimo..."
    mn "ท-ท่านรุ่นที่เจ็ด..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:246
translate english after_naruto_battle_692e9d24:

    # mn "L-Le juro que así será!" with vpunch
    mn "ผ-ผมขอสัญญาเลยครับว่าจะไม่ทำให้ผิดหวัง!" with vpunch

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:247
translate english after_naruto_battle_a36a7d33:

    # nt "¡Perfecto entonces!"
    nt "เยี่ยมไปเลย!"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:248
translate english after_naruto_battle_782cf549:

    # nt "Los Exámenes comenzarán en unas semanas, así que aprovecha a hacer todos los preparativos necesarios"
    nt "การสอบจะเริ่มในอีกไม่กี่สัปดาห์นี้แล้ว เพราะฉะนั้นใช้เวลานี้เตรียมตัวให้พร้อมทุกอย่างซะล่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:249
translate english after_naruto_battle_ea3781f6:

    # nt "Mejora todo tu equipo y entrena todo lo posible, estos exámenes serán duros"
    nt "อัปเกรดอุปกรณ์ทั้งหมดแล้วก็ฝึกซ้อมให้เต็มที่ การสอบครั้งนี้ไม่ง่ายแน่ๆ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:250
translate english after_naruto_battle_edadee1b:

    # mn "¡Entendido Séptimo!"
    mn "เข้าใจแล้วครับท่านรุ่นที่เจ็ด!"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:252
translate english after_naruto_battle_8153fe06:

    # nt "Por cierto... Antes de irme, quiero decirte algo... Es importante"
    nt "อ้อ... ก่อนฉันจะไป มีเรื่องนึงที่อยากจะบอกเธอ... มันเป็นเรื่องสำคัญนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:255
translate english after_naruto_battle_46877d2e:

    # mnn "¿Mmm?"
    mnn "หืม?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:256
translate english after_naruto_battle_3c75ebf3:

    # nt "En las finales de los Exámenes..."
    nt "ในการสอบรอบสุดท้าย..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:257
translate english after_naruto_battle_55c50974:

    # nt "Me gustaría que no usaras tu {b}Invisibilidad{/a}"
    nt "ฉันอยากขอให้เธออย่าใช้คาถา{b}ล่องหน{/a}ของเธอนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:258
translate english after_naruto_battle_270f83a0:

    # nt "Cientos de personas de la demás aldeas te estarán observando, así que lo mejor será guardarlo solo cuando no te estén observando"
    nt "ผู้คนจากหมู่บ้านอื่นเป็นร้อยๆ คนจะรอดูเธออยู่ เพราะงั้นเก็บมันไว้ใช้ตอนที่ไม่มีใครจับตาดูอยู่จะดีกว่า"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:259
translate english after_naruto_battle_d577347d:

    # nt "Creo que ya sabes porqué"
    nt "ฉันว่าเธอคงรู้เหตุผลดีอยู่แล้วสินะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:260
translate english after_naruto_battle_e551470d:

    # mn "Si, entiendo... Todos sabrán del {b}Karugan{/a} y es mejor evitar problemas"
    mn "ครับ ผมเข้าใจแล้ว... ทุกคนคงจะรู้เรื่อง {b}คารูกัน{/a} กันหมด หลีกเลี่ยงปัญหาไว้ก่อนน่าจะดีกว่า"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:262
translate english after_naruto_battle_2d1d714d:

    # nt "Así es, aunque no te estoy diciendo que no la uses en las otras etapas de los exámenes, solo evita ser visto"
    nt "ถูกต้อง ถึงฉันจะไม่ได้บอกว่าห้ามใช้ในรอบอื่นก็เถอะ แค่ระวังอย่าให้ใครเห็นก็พอ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:264
translate english after_naruto_battle_2c9f23f7:

    # mn "Así será Señor Séptimo, no dejaré que nadie lo sepa, se lo juro"
    mn "รับทราบครับท่านรุ่นที่เจ็ด ผมจะไม่ให้ใครรู้เด็ดขาด สาบานเลยครับ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:265
translate english after_naruto_battle_358b0b6a:

    # nt "Bien, ahora ya estoy más aliviado"
    nt "ดีล่ะ ค่อยโล่งใจหน่อย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:266
translate english after_naruto_battle_1afbe81d:

    # nt "Ahora, creo que ya debo irme"
    nt "งั้นฉันคงต้องไปละนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:269
translate english after_naruto_battle_fae58e1b:

    # nt "Tengo que volver al trabajo..."
    nt "ต้องกลับไปเคลียร์งานต่อแล้วล่ะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:270
translate english after_naruto_battle_115a1870:

    # nt "Maldición... El trabajo..."
    nt "ให้ตายสิ... งานเนี่ย..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:271
translate english after_naruto_battle_cdce14d2:

    # mn "¿Tiene mucho trabajo pendiente?"
    mn "งานค้างเยอะเหรอครับ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:272
translate english after_naruto_battle_a805e455:

    # nt "Un poco... Como {b}Shikamaru no está en la aldea{/a}, he estado trabajando de más últimamente"
    nt "นิดหน่อยน่ะ... พอดีช่วงนี้ {b}ชิกามารุไม่อยู่หมู่บ้าน{/a} ฉันเลยต้องทำงานล้นมือเลยช่วงนี้"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:273
translate english after_naruto_battle_d9e24cf8:

    # mn "¿No está en la aldea?"
    mn "ไม่อยู่ในหมู่บ้านเหรอครับ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:274
translate english after_naruto_battle_90bdf208:

    # nt "No, salió por eso de los preparativos de los Exámenes Chunin, volverá en unas semanas con su familia"
    nt "อืม เขาออกไปเตรียมตัวเรื่องการสอบจูหนินน่ะ จะกลับมาพร้อมครอบครัวในอีกไม่กี่สัปดาห์นี้แหละ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:275
translate english after_naruto_battle_1bb34dac:

    # mn "Entiendo..."
    mn "เข้าใจแล้วครับ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:276
translate english after_naruto_battle_0c386772:

    # mn "Siento que se haya retrasado por mi culpa..."
    mn "ขอโทษด้วยนะครับที่ทำให้งานต้องล่าช้าเพราะผม..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:278
translate english after_naruto_battle_cc2f24cd:

    # nt "Oh, no te preocupes, no es nada"
    nt "อ๋อ ไม่ต้องคิดมากหรอก เรื่องแค่นี้เอง"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:279
translate english after_naruto_battle_7e8be221:

    # nt "Yo fui quien te llamó, así que no hay problema"
    nt "ฉันเป็นคนเรียกเธอมาเอง เพราะงั้นไม่มีปัญหาหรอก"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:280
translate english after_naruto_battle_72ec984d:

    # nt "De veras, no es algo que no pueda controlar"
    nt "อีกอย่าง มันไม่ใช่เรื่องที่ฉันจะรับมือไม่ไหวซะหน่อย"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:281
translate english after_naruto_battle_2ab0d582:

    # mn "Bueno..."
    mn "เอ่อ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:282
translate english after_naruto_battle_d0a6a63d:

    # nt "Ahora, ya debo irme..."
    nt "เอาล่ะ ฉันต้องไปก่อนนะ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:283
translate english after_naruto_battle_04699ff4:

    # nt "La próxima vez que peleemos, seguro serás más fuerte, lo sé"
    nt "ไว้คราวหน้าที่เราสู้กัน เธอน่าจะเก่งขึ้นกว่าเดิมแน่ ฉันรู้ดี"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:284
translate english after_naruto_battle_cc4852c7:

    # nt "Así que sigue adelante, [MN]... Que tu {b}Camino Ninja no se detenga{/a}"
    nt "งั้นก็สู้ต่อไปล่ะ [MN]... อย่าให้{b}วิถีแห่งนินจา{/a}ของเธอต้องหยุดลงล่ะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:287
translate english after_naruto_battle_5502cecb_1:

    # mnn "..."
    mnn "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:288
translate english after_naruto_battle_e0aedc5a:

    # mn "Así será Señor Séptimo, no lo defraudaré"
    mn "รับทราบครับท่านรุ่นที่เจ็ด ผมจะไม่ทำให้ผิดหวังแน่นอนครับ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:289
translate english after_naruto_battle_1a3d8367:

    # nt "Bien, ansío verlo"
    nt "ดีมาก ฉันจะรอดูนะ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:290
translate english after_naruto_battle_096fc6a0:

    # nt "Nos vemos"
    nt "ไว้เจอกัน"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:295
translate english after_naruto_battle_9548ef64:

    # n "Naruto se va del campo de entrenamiento"
    n "นารูโตะเดินออกจากสนามฝึกซ้อมไป"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:298
translate english after_naruto_battle_5502cecb_2:

    # mnn "..."
    mnn "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:299
translate english after_naruto_battle_88a3b845:

    # mn "El Sépimo Hokage es increíble..."
    mn "ท่านโฮคาเงะรุ่นที่เจ็ดเนี่ยสุดยอดจริงๆ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:300
translate english after_naruto_battle_e62d42e9:

    # mn "Parecía estar jugando conmigo..."
    mn "เหมือนกับว่าเขาแค่ออมมือเล่นกับเราอยู่เลย..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:301
translate english after_naruto_battle_5502cecb_3:

    # mnn "..."
    mnn "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:302
translate english after_naruto_battle_3d527f4e:

    # mn "Y ese jutsu... Dios..."
    mn "แถมวิชานั้นอีก... ให้ตายสิ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:303
translate english after_naruto_battle_3c48704a:

    # mn "Gracias a que activé mi {b}Sharingan{/a} pude verlo perfectamente..."
    mn "โชคดีที่ฉันเปิดเนตร{b}เนตรวงแหวน{/a}ไว้ เลยมองเห็นได้อย่างสมบูรณ์แบบ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:304
translate english after_naruto_battle_5502cecb_4:

    # mnn "..."
    mnn "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:305
translate english after_naruto_battle_29510145:

    # mn "Yo... ¿Podré replicarlo?"
    mn "เรา... จะก๊อปปี้มันมาใช้ได้ไหมนะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:306
translate english after_naruto_battle_2113411d:

    # mn "Sin duda... Es un jutsu interesante..."
    mn "ไม่ต้องสงสัยเลย... เป็นวิชาที่น่าสนใจจริงๆ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:307
translate english after_naruto_battle_57732298:

    # mn "Con los clones de sombra puede ser algo... Peculiar..."
    mn "พอมันมารวมกับวิชาแยกเงา... คงเป็นอะไรที่... พิเศษสุดๆ..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:308
translate english after_naruto_battle_5502cecb_5:

    # mnn "..."
    mnn "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:309
translate english after_naruto_battle_2a91b474:

    # mn "No, no es momento de pensar en eso por ahora"
    mn "ไม่สิ ตอนนี้ยังไม่ใช่เวลามาคิดเรื่องนั้น"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:310
translate english after_naruto_battle_883d89e2:

    # mn "Yo... ¿Algún día seré así de fuerte?"
    mn "เรา... จะแข็งแกร่งได้ถึงขนาดนั้นไหมนะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:311
translate english after_naruto_battle_5502cecb_6:

    # mnn "..."
    mnn "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:312
translate english after_naruto_battle_7e0ee409:

    # mn "Aún si no llego a ser así de fuerte, no me detendré..."
    mn "ต่อให้จะไม่ได้แข็งแกร่งขนาดนั้น ฉันก็จะไม่หยุดอยู่แค่นี้หรอก..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest3.rpy:315
translate english after_naruto_battle_54db0b5b:

    # mn "Mi {b}Camino Ninja{/a} no se detendrá aquí..."
    mn "{b}วิถีนินจา{/a} ของผมจะไม่หยุดอยู่แค่นี้หรอก..."

