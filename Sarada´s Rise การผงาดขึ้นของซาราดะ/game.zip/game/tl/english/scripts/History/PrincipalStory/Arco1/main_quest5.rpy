# TODO: Translation updated at 2024-03-04 17:48

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:4
translate english main_quest5_2204cfe1:

    # mn "Solo vine a entrenar un poco, ¿Tú igual?"
    mn "ฉันแค่มาฝึกซ้อมนิดหน่อยน่ะ เธอเองก็ด้วยเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:7
translate english main_quest5_4c4a03ec:

    # sr "Si, suelo venir a esta hora a entrenar un poco"
    sr "ใช่ค่ะ ปกติเวลานี้ฉันก็จะมาซ้อมนิดๆ หน่อยๆ อยู่แล้ว"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:9
translate english main_quest5_d6907623:

    # sr "Hace mucho que no te veía por aquí"
    sr "ฉันไม่ค่อยเห็นเธอที่นี่มานานเลยนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:12
translate english main_quest5_e18dd320:

    # mn "Debe ser porqué venimos en horarios distintos, normalmente entreno de noche"
    mn "คงเป็นเพราะเรามากันคนละเวลาล่ะมั้ง ปกติฉันจะมาซ้อมตอนกลางคืนน่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:15
translate english main_quest5_262114ae:

    # sr "Claro, debe ser eso"
    sr "งั้นเหรอคะ คงจะเป็นแบบนั้นสินะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:18
translate english main_quest5_3000a061:

    # mn "Bueno, entonces te dejo que entrenes tranquilamente"
    mn "งั้นฉันไม่กวนเวลาฝึกของเธอแล้วกันนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:21
translate english main_quest5_853cdd99:

    # sr "Mmm..."
    sr "อืม..."

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:23
translate english main_quest5_463c7b0c:

    # sr "Tengo una mejor idea, ¿Que tal si tenemos un combate?"
    sr "ฉันมีไอเดียที่ดีกว่านั้นค่ะ เรามาลองประลองกันสักตั้งไหมล่ะคะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:26
translate english main_quest5_7de8d24f:

    # mn "¿Un combate?"
    mn "ประลองเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:29
translate english main_quest5_6d20c1e7:

    # sr "Si, hace mucho que no te veo luchar"
    sr "ใช่ค่ะ ฉันไม่ได้เห็นฝีมือการต่อสู้ของคุณมานานแล้วนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:31
translate english main_quest5_508da533:

    # sr "Quiero saber si has mejorado"
    sr "ฉันแค่อยากรู้ว่าฝีมือเธอพัฒนาขึ้นแค่ไหนแล้วน่ะค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:33
translate english main_quest5_c232acf6:

    # sr "Y de paso mostrarte en lo que estoy entrenando"
    sr "แล้วก็ถือโอกาสโชว์วิชาที่ฉันกำลังฝึกอยู่ให้ดูด้วย"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:36
translate english main_quest5_4a2f1146:

    # mn "Eehh, no lo sé"
    mn "อืม... ฉันก็ไม่แน่ใจแฮะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:38
translate english main_quest5_343c5fcb:

    # mn "Siento que aún no estoy a tu nivel"
    mn "ฉันรู้สึกว่าตัวเองยังฝีมือไม่ถึงขั้นเธอหรอก"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:41
translate english main_quest5_69417a80:

    # sr "Pues solo hay una forma de comprobarlo, ¿sabes?"
    sr "งั้นก็มีทางเดียวที่จะพิสูจน์นะคะ รู้ไหม?"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:44
translate english main_quest5_a8f1574e:

    # mn "Está bien jaja"
    mn "ก็ได้ ฮ่าๆๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:46
translate english main_quest5_aa1965fa:

    # mn "Hagámoslo"
    mn "เอาเลยสิ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:49
translate english main_quest5_4d070189:

    # sr "Eso es lo que quería oír"
    sr "นั่นแหละค่ะที่อยากฟัง"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:51
translate english main_quest5_1b476699:

    # sr "Muy bien, prepárate"
    sr "เอาล่ะ เตรียมตัวให้ดีนะคะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:73
translate english main_quest5_after_battle_7d1de944:

    # mn "(¡Agh!)"
    mn "(อึก!)"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:74
translate english main_quest5_after_battle_9eb262fc:

    # mn "(¡M-Mi espada!)"
    mn "(ด-ดาบของฉัน!)"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:75
translate english main_quest5_after_battle_46f0f3e7:

    # sr "Esto era lo que estaba practicando"
    sr "นี่แหละค่ะคือสิ่งที่ฉันกำลังฝึกอยู่"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:76
translate english main_quest5_after_battle_afb60b73:

    # mn "¿Manipulación de la naturaleza de chakra?"
    mn "การผสานคุณสมบัติจักระเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:82
translate english main_quest5_after_battle_16066948:

    # sr "Es útil, pensaba en usar un kunai, pero bajaste la guardia y aproveché para hacerlo con tu espada"
    sr "มีประโยชน์มากเลยล่ะค่ะ ตอนแรกฉันกะว่าจะใช้คุไนนะ แต่เธอเผลอเปิดช่องว่างซะก่อน ฉันก็เลยฉวยโอกาสทำมันกับดาบของเธอซะเลย"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:84
translate english main_quest5_after_battle_ce73d80e:

    # mn "(Es similar a lo que Yuna y Zubon hacen, con la diferencia de que Sarada lo hace atraves de sus armas)"
    mn "(คล้ายกับที่ยูนะกับซูบงทำเลยแฮะ ต่างกันตรงที่ซาราดะใช้มันผ่านทางอาวุธของเธอนี่สิ)"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:85
translate english main_quest5_after_battle_24118fb9:

    # mn "(No me cabe la menor duda de que es impresionante)"
    mn "(ปฏิเสธไม่ได้เลยจริงๆ ว่าเธอน่าทึ่งขนาดไหน)"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:87
translate english main_quest5_after_battle_78b4a502:

    # sr "Ven, levántate"
    sr "มานี่ค่ะ ลุกขึ้นเถอะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:89
translate english main_quest5_after_battle_43a9c022:

    # n "Sarada ayuda a [MN] a levantarse"
    n "ซาราดะช่วยพยุง [MN] ให้ลุกขึ้น"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:98
translate english main_quest5_after_battle_cba38246:

    # sr "Esa fue una buena pelea"
    sr "เป็นการต่อสู้ที่ดีมากเลยค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:100
translate english main_quest5_after_battle_7445e26a:

    # sr "Sin embargo, noté varias cosas que debes mejorar..."
    sr "แต่ว่านะ ฉันสังเกตเห็นหลายจุดเลยล่ะที่เธอต้องปรับปรุง..."

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:103
translate english main_quest5_after_battle_f2963d01:

    # mn "¿Qué cosas?"
    mn "เรื่องไหนบ้างเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:106
translate english main_quest5_after_battle_40bb21ee:

    # sr "No usas todo el potencial del Sharingan"
    sr "เธอไม่ได้ใช้ศักยภาพที่แท้จริงของเนตรวงแหวนเลยค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:108
translate english main_quest5_after_battle_75698ce0:

    # sr "Parece que solo lo usas para reforzar tus jutsus"
    sr "ดูเหมือนว่าเธอจะใช้มันแค่เพื่อเสริมพลังวิชานินจาของตัวเองเท่านั้นนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:111
translate english main_quest5_after_battle_d2481433:

    # mn "Si, luego de hacer un ataque intento taparlo nuevamente"
    mn "อื้ม พอโจมตีเสร็จแล้วฉันก็พยายามปิดเนตรเอาไว้ก่อนน่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:113
translate english main_quest5_after_battle_6334ed53:

    # mn "De lo contrario me consume mucho chakra"
    mn "ไม่อย่างนั้นมันจะกินจักระฉันเยอะมากเลยล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:115
translate english main_quest5_after_battle_6756b1bf:

    # mn "De por sí está activo todo el tiempo, por lo que la única manera de que no consuma todo mi chakra es no usarlo"
    mn "เพราะมันทำงานอยู่ตลอดเวลา ทางเดียวที่จะไม่ให้มันสูบจักระฉันจนหมด ก็คือการเลิกใช้มันซะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:118
translate english main_quest5_after_battle_51cbc73b:

    # sr "Y es por eso que no te has dado cuenta de que el Sharingan es para mucho más que solo eso"
    sr "และนั่นแหละคือสาเหตุที่ทำให้เธอไม่รู้ว่าเนตรวงแหวนมันทำอะไรได้มากกว่านั้นเยอะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:120
translate english main_quest5_after_battle_44f7683d:

    # sr "Le tienes miedo, y así no podrás aprovecharlo"
    sr "เธอกำลังกลัวเนตรวงแหวนของตัวเองอยู่ต่างหากล่ะคะ แล้วแบบนี้จะไปดึงศักยภาพมันออกมาได้ยังไง"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:122
translate english main_quest5_after_battle_e4beee87:

    # sr "Liberalo ahora y te lo mostraré"
    sr "ปล่อยมันออกมาตอนนี้เลยค่ะ เดี๋ยวฉันจะทำให้ดู"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:125

translate english main_quest5_after_battle_a6bae7d5:

    # mn "C-Claro"
    mn "ก-ก็ได้..."

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:127
translate english main_quest5_after_battle_6e35802a:

    # n "[MN] se quita la banda"
    n "[MN] ถอดผ้าคาดตาออก"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:131
translate english main_quest5_after_battle_eaaa2458:

    # sr "Bien, ahora mantenlo así por unos momentos"
    sr "เอาล่ะ ตอนนี้คงสภาพนั้นไว้สักครู่ค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:133
translate english main_quest5_after_battle_b3bf57e4:

    # sr "Entiendo que le tengas miedo al consumo de chakra pero ten en cuenta que no se va a esfumar por dejarlo más tiempo"
    sr "ฉันเข้าใจว่าเธอกลัวเรื่องการสิ้นเปลืองจักระ แต่จำไว้นะคะว่ามันจะไม่หมดไปหรอกถ้าเธอเปิดมันไว้นานขึ้นหน่อย"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:135
translate english main_quest5_after_battle_a9c630b1:

    # sr "Además, pierdes tiempo al destapar y destapar tu Sharingan"
    sr "อีกอย่าง เธอเสียเวลาไปกับการเปิดและปิดเนตรวงแหวนของตัวเองด้วยนะคะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:137
translate english main_quest5_after_battle_4ffe34ac:

    # sr "Ese tiempo puede ser decisivo en una pelea"
    sr "เวลาช่วงนั้นอาจเป็นตัวตัดสินแพ้ชนะในการต่อสู้ได้เลย"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:140
translate english main_quest5_after_battle_10f1a6ae:

    # mn "S-Sí... Tienes razón"
    mn "จ-จริงด้วยสินะ... เธอพูดถูก"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:143
translate english main_quest5_after_battle_342693a9:

    # n "{b}Unos minutos más tarde{/a}"
    n "{b}ไม่กี่นาทีต่อมา{/a}"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:146
translate english main_quest5_after_battle_e21b389e:

    # sr "¿Y bien, cómo te sientes?"
    sr "เป็นยังไงบ้างคะ รู้สึกยังไงบ้าง?"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:148
translate english main_quest5_after_battle_63722c58:

    # sr "¿Sientes que el Sharingan drena tu chakra como tú creías?"
    sr "รู้สึกว่าเนตรวงแหวนสูบจักระของเธอเหมือนอย่างที่คิดไว้ไหมล่ะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:151
translate english main_quest5_after_battle_0c66db78:

    # mn "No... Aunque si me siento un poco incomodo"
    mn "ไม่นะ... ถึงจะรู้สึกอึดอัดอยู่นิดหน่อยก็เถอะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:154
translate english main_quest5_after_battle_0e00bd30:

    # sr "¿Porqué?"
    sr "ทำไมล่ะคะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:157
translate english main_quest5_after_battle_a6f357e3:

    # mn "No acostumbro a mostrar este lado de mi rostro"
    mn "ฉันไม่ค่อยชอบเปิดหน้าด้านนี้ให้ใครเห็นเท่าไหร่หรอกนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:159
translate english main_quest5_after_battle_79992cb9:

    # mn "Puede sonar estúpido... Pero no me gusta ese lado..."
    mn "ฟังดูงี่เง่าสินะ... แต่ฉันไม่ชอบหน้าด้านนี้เลย..."

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:161
translate english main_quest5_after_battle_f16a3b51:

    # mn "Esta cicatriz... Es horrible"
    mn "แผลเป็นนี่... มันดูแย่มากเลยล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:164
translate english main_quest5_after_battle_7c4c5f4f:

    # sr "Oye..."
    sr "เดี๋ยวสิ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:172
translate english main_quest5_after_battle_8b198875:

    # sr "No digas eso"
    sr "อย่าพูดแบบนั้นสิคะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:175
translate english main_quest5_after_battle_82efc8b0:

    # mn "Eeh, ¿Q-Qué haces?"
    mn "อ๊ะ ท-ทำอะไรน่ะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:181
translate english main_quest5_after_battle_63afb6a3:

    # sr "A mí me gusta"
    sr "ฉันชอบออกนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:186
translate english main_quest5_after_battle_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:188
translate english main_quest5_after_battle_666b2e83:

    # sr "Jeje"
    sr "ฮ่าๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:190
translate english main_quest5_after_battle_ec12948a:

    # sr "Te hace ver muy rudo"
    sr "มันทำให้เธอดูเป็นคนแกร่งขึ้นตั้งเยอะเลยล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:193
translate english main_quest5_after_battle_2f9c8896:

    # mn "¿Enserio lo crees? Jajaja"
    mn "งั้นเหรอ คิดงั้นจริงๆ เหรอเนี่ย? ฮ่าๆๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:196
translate english main_quest5_after_battle_74938391:

    # sr "Si, enserio jaja"
    sr "ใช่ค่ะ พูดจริงนะเนี่ย ฮ่าๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:198
translate english main_quest5_after_battle_7879fa71:

    # sr "Puede servirte para provocarle miedo a tus enemigos"
    sr "เอาไปใช้ขู่ศัตรูให้กลัวได้ด้วยนะรู้ไหม"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:201
translate english main_quest5_after_battle_6a03cb62:

    # mn "Jajaja"
    mn "ฮ่าๆๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:204
translate english main_quest5_after_battle_7c915c6d:

    # sr "¿Lo ves? No es para tanto"
    sr "เห็นไหมล่ะคะ? มันไม่ได้แย่ขนาดนั้นสักหน่อย"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:206
translate english main_quest5_after_battle_5dcff62c:

    # sr "Incluso puedes sacarle provecho"
    sr "แถมเธอเอามาใช้ประโยชน์ได้ด้วยนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:209
translate english main_quest5_after_battle_ee2b820d:

    # mn "Si, entiendo tu punto"
    mn "อืม เข้าใจที่เธอจะสื่อแล้วล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:212
translate english main_quest5_after_battle_981449a0:

    # sr "Bueno, creo que nos desviamos un poco"
    sr "งั้น... รู้สึกว่าเราจะออกนอกเรื่องกันไปหน่อยสินะคะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:214
translate english main_quest5_after_battle_e06b9759:

    # sr "¿Te sientes mal por tener el Sharingan descubierto?"
    sr "รู้สึกแย่หรือเปล่าคะที่ความลับเรื่องเนตรวงแหวนถูกจับได้น่ะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:217
translate english main_quest5_after_battle_61b5225e:

    # mn "Pues... Realmente me siento bien"
    mn "ก็... เอาจริงๆ รู้สึกโล่งใจมากกว่านะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:220
translate english main_quest5_after_battle_b3f4d3c8:

    # sr "Yo te recomendaría... Usar el Sharingan solo si es necesario, si solo lo vas a usar por un breve periodo de tiempo..."
    sr "ฉันขอแนะนำว่า... ให้ใช้เนตรวงแหวนเท่าที่จำเป็นก็พอนะคะ ถ้าจะใช้แค่ช่วงสั้นๆ ล่ะก็..."

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:222
translate english main_quest5_after_battle_f3179992:

    # sr "Mejor no lo uses"
    sr "ไม่ใช้เลยจะดีกว่าค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:224
translate english main_quest5_after_battle_bebf6d30:

    # sr "Si tienes un mayor gasto al usarlo de esa manera"
    sr "ไม่อย่างนั้นมันจะเปลืองพลังงานมากเกินไป"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:226
translate english main_quest5_after_battle_71bf8e2f:

    # sr "No te digo tampoco que lo uses en peleas largas"
    sr "ไม่ได้หมายความว่าให้ใช้ในการต่อสู้ที่ยาวนานด้วยหรอกนะคะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:228
translate english main_quest5_after_battle_fe705b08:

    # sr "Pero tampoco solo para hacer un ataque"
    sr "แต่ก็ไม่ใช่ว่าใช้แค่โจมตีครั้งเดียวแล้วจบเหมือนกันค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:231
translate english main_quest5_after_battle_1bb34dac:

    # mn "Entiendo..."
    mn "เข้าใจแล้ว..."

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:233
translate english main_quest5_after_battle_4a812312:

    # mn "Entonces... ¿De qué otra forma puedo sacar ventaja con el Sharingan?"
    mn "งั้น... ฉันจะเอาความสามารถของเนตรวงแหวนมาใช้ให้เกิดประโยชน์ยังไงได้อีกบ้างล่ะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:238
translate english main_quest5_after_battle_171619c1:

    # sr "Mira esto"
    sr "ดูนี่นะคะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:248
translate english main_quest5_after_battle_97fc28f9:

    # sr "Intenta imitarlo"
    sr "ลองทำท่าทางตามนี้ดูค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:255
translate english main_quest5_after_battle_8ec20197:

    # sr "Ahora intentalo tú"
    sr "คราวนี้ตาเธอบ้างแล้วค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:258
translate english main_quest5_after_battle_357daac6:

    # mn "Bien, aquí voy"
    mn "โอเค เอาล่ะนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:263
translate english main_quest5_after_battle_37529391:

    # mn "¿Q-Qué?"
    mn "อ-อะไรนะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:264
translate english main_quest5_after_battle_d5e4d2d7:

    # mn "L-Lo hice todo a la perfección"
    mn "พ-ฉันทำทุกอย่างเป๊ะเลยนะเนี่ย"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:265
translate english main_quest5_after_battle_6dfc88a1:

    # sr "El Sharingan es capaz analizar y copiar todos los movimientos de tu oponente"
    sr "เนตรวงแหวนมีความสามารถในการวิเคราะห์และคัดลอกการเคลื่อนไหวของคู่ต่อสู้ได้ทั้งหมดเลยค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:266
translate english main_quest5_after_battle_ee369ec1:

    # sr "Con esto puedes replicar casi cualquier jutsu"
    sr "ด้วยวิธีนี้ทำให้เธอสามารถเลียนแบบวิชานินจาได้แทบทุกชนิดเลยล่ะค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:277
translate english main_quest5_after_battle_8ee86ade:

    # sr "Lo único que no puedes copiar son Jutsus que requieren un Kekkei Genkai o los Jutsus de Invocación"
    sr "สิ่งเดียวที่ไม่สามารถคัดลอกได้ก็คือวิชานินจาที่ต้องใช้ขีดจำกัดสายเลือดหรือคาถาอัญเชิญค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:280
translate english main_quest5_after_battle_71e11b4b:

    # mn "Increíble, te juro que no me había dado cuenta de esto"
    mn "เหลือเชื่อจริงแฮะ สาบานเลยว่าฉันไม่เคยรู้เรื่องนี้มาก่อนเลย"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:282
translate english main_quest5_after_battle_3aa748ff:

    # mn "Las posiciones de manos que hice, ¿De qué Jutsu son?"
    mn "ท่าประสานอินที่ฉันทำเมื่อกี้ มันคือคาถาอะไรเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:285
translate english main_quest5_after_battle_91d45a9c:

    # sr "Estas son las pociciones de manos para hacer el Chidori"
    sr "นั่นคือท่าประสานอินสำหรับใช้คาถาพันปีศาจ... เอ๊ย พันนกกระเรียน— พันปักษาค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:287
translate english main_quest5_after_battle_7a4efff2:

    # sr "Realmente, si te lo propones, puedes aprender y usar bien el Chidori"
    sr "เอาเข้าจริง ถ้าเธอตั้งใจล่ะก็ จะต้องเรียนรู้และใช้งานพันปักษานั่นได้ดีแน่ๆ เลยค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:289
translate english main_quest5_after_battle_93aca836:

    # sr "Es una técnica con gran poder destructivo"
    sr "แถมมันยังเป็นวิชาที่มีพลังทำลายล้างสูงมากด้วยนะคะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:291
translate english main_quest5_after_battle_a14e1bc0:

    # sr "Y también de gran velocidad, y aunque esa puede ser una desventaja para alguien normal"
    sr "แถมยังมีความเร็วสูงมากด้วย ถึงแม้ว่านั่นอาจจะเป็นข้อเสียสำหรับคนทั่วไปก็เถอะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:293
translate english main_quest5_after_battle_44587527:

    # sr "Tú al tener el Sharingan no tienes esa desventaja"
    sr "แต่เพราะมีเนตรวงแหวน เธอเลยไม่มีข้อเสียเปรียบเรื่องนั้นยังไงล่ะคะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:296
translate english main_quest5_after_battle_f3397734:

    # mn "Ya veo..."
    mn "งั้นเหรอ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:301
translate english main_quest5_after_battle_0eaec5a9:

    # mn "Pero... Realmente me gustaría más aprender la técnica del 7mo Hokage"
    mn "แต่ว่า... ฉันอยากเรียนวิชาของท่านโฮคาเงะรุ่นที่ 7 มากกว่าแฮะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:303
translate english main_quest5_after_battle_2be012ef:

    # mn "Me causa ilusión... Aprender la técnica del Séptimo Hokage"
    mn "ตื่นเต้นชะมัด... ที่จะได้เรียนรู้วิชาของท่านโฮคาเงะรุ่นที่ 7 เนี่ย"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:306
translate english main_quest5_after_battle_4c12615c:

    # sr "Entiendo ese sentimiento"
    sr "ฉันเข้าใจความรู้สึกนั้นเลยค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:308
translate english main_quest5_after_battle_04b99a99:

    # sr "El Rasengan es una técnica muy poderosa"
    sr "กระสุนวงจักรเป็นวิชาที่ทรงพลังมากๆ เลยล่ะค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:312
translate english main_quest5_after_battle_b277f0c0:

    # mn "Me haría con una condición"
    mn "ฉันมีเงื่อนไขอยู่อย่างหนึ่งนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:314
translate english main_quest5_after_battle_82344427:

    # mn "Si tú eres quien me la enseñe"
    mn "ก็คือถ้าเธอเป็นคนสอนฉันล่ะก็นะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:317
translate english main_quest5_after_battle_8009460c:

    # sr "Cuenta conmigo para eso jaja"
    sr "เรื่องนั้นวางใจฉันได้เลยค่ะ ฮ่าๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:320
translate english main_quest5_after_battle_be72f917:

    # sr "Bueno, me encantaría seguirte enseñando pero quedé salir con Chocho"
    sr "อืม ฉันก็อยากจะสอนต่ออยู่หรอกนะคะ แต่ฉันดันนัดออกไปข้างนอกกับโจโจไว้แล้วน่ะสิคะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:322
translate english main_quest5_after_battle_1b353545:

    # sr "Espero verte otro día aquí a la misma hora para poder seguirte enseñando"
    sr "หวังว่าวันหลังเราจะได้เจอกันที่เดิมเวลานี้ เพื่อที่ฉันจะได้สอนเธอต่อได้นะคะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:325
translate english main_quest5_after_battle_5bae2292:

    # mn "Claro, intentaré venir pronto"
    mn "ได้เลย เดี๋ยวฉันจะพยายามมาให้เร็วเลยนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:328
translate english main_quest5_after_battle_69a6e1a4:

    # sr "Bien, nos vemos luego entonces"
    sr "งั้นไว้เจอกันนะคะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:333
translate english main_quest5_after_battle_28122b27:

    # mn "Es increíble que a pesar del pasar de los años Sarada siga ayudándome"
    mn "ไม่อยากจะเชื่อเลยแฮะว่าต่อให้เวลาจะผ่านไปนานแค่ไหน ซาราดะก็ยังคอยช่วยเหลือฉันอยู่ตลอดเลย"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:335
translate english main_quest5_after_battle_de5d3e42:

    # mn "De verdad agradezco esto que me enseñó"
    mn "ขอบคุณสำหรับทุกอย่างที่สอนฉันจริงๆ นะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:338
translate english main_quest5_after_battle_6a43ddbd:

    # mn "De ser posible vendré mañana para seguir entrenando con ella"
    mn "ถ้าเป็นไปได้พรุ่งนี้ฉันจะมาฝึกกับเธอต่ออีกละกัน"

translate english strings:

    # game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:298
    old "Me interesa más el Rasengan"
    new "ฉันสนใจกระสุนวงจักรมากกว่าแฮะ"

    # game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:298
    old "Me interesa el Chidori"
    new "ฉันสนใจพันปักษามากกว่าแฮะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest5.rpy:4
translate english main_quest5_20603b95:

    # mn "Solo vine a entrenar un poco, ¿Tú igual?" with dissolve1
    mn "ฉันแค่แวะมาฝึกซ้อมนิดหน่อยน่ะ เธอเองก็ด้วยเหรอ?" with dissolve1
