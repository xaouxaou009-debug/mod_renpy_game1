# TODO: Translation updated at 2024-03-04 17:48

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:9
translate english tenten_quest1_e159f2c4:

    # mn "Hace tiempo no paso por la tienda de Tenten"
    mn "ฉันไม่ได้แวะไปร้านของเท็นเท็นมาสักพักแล้วแฮะ"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:11
translate english tenten_quest1_2fdd6e59:

    # mn "No me vendría mal comprar equipamiento"
    mn "ลองแวะไปซื้ออุปกรณ์สักหน่อยก็ไม่เสียหายนะ"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:13
translate english tenten_quest1_f222ac12:

    # n "[MN] entra a la tienda de Tenten"
    n "[MN] เดินเข้าไปในร้านของเท็นเท็น"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:19
translate english tenten_quest1_64f492be:

    # mn "Hola, buen día"
    mn "สวัสดี อรุณสวัสดิ์"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:21
translate english tenten_quest1_f111e485:

    # tt "¡Bienvenido!"
    tt "ยินดีต้อนรับจ้า!"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:23
translate english tenten_quest1_734c85d2:

    # tt "Un momento por favor... Voy enseguida"
    tt "รอสักครู่นะ... เดี๋ยวฉันจัดการให้"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:26
translate english tenten_quest1_9fd2fdd9:

    # mn "(¿Qué estará haciendo?)"
    mn "(เขากำลังทำอะไรอยู่น่ะ?)"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:30
translate english tenten_quest1_9e6a2e7b:

    # mn "Eeh, ¿Puedo ayudar en algo?"
    mn "เฮ้ ให้ฉันช่วยอะไรหน่อยไหม?"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:32
translate english tenten_quest1_db821270:

    # tt "Aah, gracias jaja"
    tt "อ่า ขอบใจนะ ฮ่าๆ"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:33
translate english tenten_quest1_8a7b71fe:

    # tt "Pero ya lo tengo resuelto"
    tt "แต่ฉันจัดการเรียบร้อยแล้วล่ะ"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:38
translate english tenten_quest1_b55b8fc9:

    # tt "[MN], ¿Qué tal?"
    tt "[MN] เป็นยังไงบ้างจ๊ะ?"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:40
translate english tenten_quest1_150cf4d8:

    # tt "Hace mucho no vienes a la tienda"
    tt "เธอไม่ได้แวะมาที่ร้านนานเลยนะ"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:42
translate english tenten_quest1_3d17f3ce:

    # tt "¿Te habías olvidado de cambiar tu equipo?"
    tt "เธอไม่ได้แวะมาที่ร้านนานเลยนะ?"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:45
translate english tenten_quest1_fc36329c:

    # mn "Un poco jaja, creo que ya es momento de una actualización"
    mn "นิดหน่อยครับ ฮ่าๆ ผมว่าถึงเวลาต้องอัปเกรดหน่อยแล้วล่ะ"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:49
translate english tenten_quest1_890be0bf:

    # tt "¿Hmm?"
    tt "หืม?"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:53
translate english tenten_quest1_0f0c04d2:

    # mn "Eeeh... ¿Pasó algo?"
    mn "ฮะ... เกิดอะไรขึ้นเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:56
translate english tenten_quest1_7f5c932c:

    # tt "¿Siempre tuviste el ojo de ese color?"
    tt "ตาสีนั่น... เธอมีตาสีนั้นมาตั้งแต่แรกเลยเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:60
translate english tenten_quest1_ddac219c:

    # tt "Déjame adivinar, es una nueva moda"
    tt "ขอเดานะ เทรนด์ใหม่ไรงี้สินะ"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:63
translate english tenten_quest1_e15377e4:

    # tt "Ay estos jóvenes, y justo cuando acababa la moda de los cinturones"
    tt "เฮ้อวัยรุ่นสมัยนี้นี่นะ ทั้งๆที่แฟชั่นคาดเข็มขัดหลายเส้นเพิ่งจะซาไปแท้ๆ"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:66
translate english tenten_quest1_3381f501:

    # mn "Eh, no realmente"
    mn "เอ่อ ก็ไม่เชิงหรอกครับ"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:68
translate english tenten_quest1_4763d940:

    # mn "Es una larga historia, pasaron muchas cosas..."
    mn "มันเรื่องยาวน่ะครับ มีเรื่องหลายอย่างเกิดขึ้นเลย..."

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:71
translate english tenten_quest1_6c986104:

    # tt "¿Enserio? Cuenta cuenta"
    tt "จริงเหรอ? เล่าให้ฟังหน่อยสิๆ"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:74
translate english tenten_quest1_c8d632a6:

    # mn "B-Bueno..."
    mn "ก-ก็ได้ครับ..."

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:76
translate english tenten_quest1_b662405e:

    # n "[MN] le cuenta a Tenten la historia de su Clan, omitindo el tema de la invisibilidad"
    n "[MN] เล่าเรื่องราวความเป็นมาของตระกูลให้เท็นเท็นฟัง โดยเว้นเรื่องคาถาล่องหนเอาไว้"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:82
translate english tenten_quest1_ac2a644f:

    # tt "Vaya..."
    tt "โห..."

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:84
translate english tenten_quest1_cc16d73a:

    # tt "Tienes mucha suerte"
    tt "เธอเนี่ยโชคดีจริงๆ เลยนะ"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:86
translate english tenten_quest1_20b0b2eb:

    # tt "Los {b}Dojutsu{/a} son muy poderosos"
    tt "พวก{b}เนตรวิชา{/a}นี่ทรงพลังมากเลยล่ะนะ"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:88
translate english tenten_quest1_4a32e34a:

    # tt "En la aldea hay dos familias con Dojutsus muy poderosos"
    tt "ในหมู่บ้านของเรามีตระกูลที่มีเนตรวิชาที่ทรงพลังอยู่สองตระกูลด้วยกัน"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:90
translate english tenten_quest1_592a1bce:

    # tt "Que son el Clan Uchiha con el Sharingan"
    tt "นั่นก็คือตระกูลอุจิวะที่มีเนตรวงแหวน"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:93
translate english tenten_quest1_e2640305:

    # tt "Y... El Hyuga con el Byakugan..."
    tt "แล้วก็... ตระกูลฮิวงะที่มีเนตรสีขาว..."

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:96
translate english tenten_quest1_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:99
translate english tenten_quest1_9d411f9b:

    # tt "Aunque creo que ya lo sabías jaja"
    tt "แม้ว่าฉันคิดว่าเธอน่าจะรู้อยู่แล้วล่ะนะ ฮ่าๆ"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:102
translate english tenten_quest1_4f1c06b8:

    # tt "Eres muy cercano a ellos"
    tt "ก็เธอกลุ่มนั้นเขาสนิทกับเธอจะตาย"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:104
translate english tenten_quest1_75b6dae2:

    # tt "Pero bueno, dime, ¿A qué has venido?"
    tt "แต่ว่านะ เล่ามาซิ ว่าทำไมวันนี้ถึงมาหาฉันได้ล่ะ?"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:106
translate english tenten_quest1_4e495356:

    # tt "¿Necesitas que cambie o mejore algo?"
    tt "มีอะไรอยากให้ฉันช่วยปรับปรุงหรือซ่อมแซมตรงไหนไหม?"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:109
translate english tenten_quest1_18ac789b:

    # mn "No estoy seguro, vine para que le hicieras una revisión a mi equipo"
    mn "ก็ไม่เชิงครับ ผมแค่อยากมาให้ช่วยเช็คอุปกรณ์ให้หน่อยน่ะครับ"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:112
translate english tenten_quest1_f704a3c6:

    # tt "Perfecto, pásamelo entonces"
    tt "เยี่ยมเลย งั้นส่งมาให้ฉันดูซิ"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:114
translate english tenten_quest1_d55a51c8:

    # n "Tenten le hecha un vistazo al equipo de [MN]"
    n "เท็นเท็นตรวจสอบอุปกรณ์ของ [MN]"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:118
translate english tenten_quest1_8110b4bd:

    # tt "..."
    tt "..."

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:120
translate english tenten_quest1_94daa32e:

    # tt "Realmente no sé como es que ha durado tanto"
    tt "ฉันล่ะสงสัยจริงๆ ว่ามันทนใช้มาจนถึงตอนนี้ได้ยังไงเนี่ย"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:123
translate english tenten_quest1_67bd759d:

    # mn "¿Tan mal está?"
    mn "มันแย่ขนาดนั้นเลยเหรอครับ?"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:126
translate english tenten_quest1_9312c936:

    # tt "¿Mal?"
    tt "แย่เหรอ?"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:128
translate english tenten_quest1_2c2b0426:

    # tt "Tu equipo está pésimo"
    tt "อุปกรณ์ของเธอเนี่ยแย่สุดๆ ไปเลยนะ"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:130
translate english tenten_quest1_8c9bb873:

    # tt "Solo mira como está la espada que te hice"
    tt "ลองดูดาบเล่มที่ฉันทำให้เธอดูล่ะสิ"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:132
translate english tenten_quest1_dda3d118:

    # tt "¿Acaso golpeas rocas con ella?"
    tt "นี่เธอเอาไปฟาดกับก้อนหินมาเหรอเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:134
translate english tenten_quest1_8d9342f7:

    # tt "Es un milagro que aún esté de una pieza..."
    tt "ถือว่าเป็นปาฏิหาริย์แล้วมั้งที่มันยังไม่หักเป็นสองท่อนน่ะ..."

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:137
translate english tenten_quest1_2e97abfd:

    # mn "Jaja..."
    mn "ฮ่าๆ..."

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:139
translate english tenten_quest1_aec1ed65:

    # mn "¿Es broma cierto?"
    mn "ล้อเล่นใช่ไหมเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:142
translate english tenten_quest1_08b1a51f:

    # tt "¿Crees que estoy de broma?"
    tt "คิดว่าฉันล้อเล่นอยู่รึไง?"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:145
translate english tenten_quest1_da129e46:

    # mn "N-No..."
    mn "ป-เปล่าครับ..."

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:148
translate english tenten_quest1_13be119f:

    # tt "Mira, justo ahora tengo mucho trabajo, pero cuando me desocupe te escribiré para hacerte una nueva espada"
    tt "ฟังนะ ตอนนี้ฉันงานยุ่งมากเลย ไว้ว่างเมื่อไหร่เดี๋ยวฉันติดต่อไปแล้วกัน จะทำดาบเล่มใหม่ให้เธอเอง"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:150
translate english tenten_quest1_96004142:

    # tt "Mientras tanto..."
    tt "ระหว่างนี้..."

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:152
translate english tenten_quest1_d8d42f3d:

    # tt "Dame un momento"
    tt "รอแป๊บนะ"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:155
translate english tenten_quest1_b737e1ef:

    # n "Tenten va a traer algo"
    n "เท็นเท็นเดินไปหยิบของบางอย่างมา"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:159
translate english tenten_quest1_ad30b7b9:

    # tt "Ten, este es un pergamino de ataque"
    tt "นี่จ่ะ คัมภีร์เสริมพลังโจมตี"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:161
translate english tenten_quest1_09ccdc6e:

    # tt "Usa esto y el arma hará un poco mejor su trabajo, y durará un poco más"
    tt "เอาอันนี้ไปใช้ซะ แล้วอาวุธจะใช้งานได้ดีขึ้นแถมพังยากขึ้นอีกนิดหน่อยด้วย"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:165
translate english tenten_quest1_8d2489f5:

    # tt "Por esta vez no te cobraré, es un regalo"
    tt "รอบนี้จะไม่คิดเงินนะ ถือว่าเป็นของขวัญละกัน"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:168
translate english tenten_quest1_53e3808f:

    # tt "Aunque siento que debería cobrarte por el estado en el que dejaste el arma que te hice"
    tt "แม้ว่าฉันจะแอบอยากคิดเงินค่าสภาพอาวุธที่ฉันทำให้อยู่เหมือนกันนะเนี่ย"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:171
translate english tenten_quest1_9c6d29a8:

    # mn "Jeje..."
    mn "แหะๆ..."

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:173
translate english tenten_quest1_8a68080e:

    # mn "Muchas gracias Tenten"
    mn "ขอบคุณมากครับเท็นเท็น"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:176
translate english tenten_quest1_20e89586:

    # tt "Agradédemelo pateándole el trasero a Zubon"
    tt "อยากขอบคุณฉันล่ะก็ ไปอัดก้นเจ้าซูบงให้คว่ำเลยไป"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:178
translate english tenten_quest1_b1911637:

    # tt "Ese pervertido..."
    tt "ไอ้ตาแก่ลามกนั่น..."

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:180
translate english tenten_quest1_8df9bde3:

    # tt "No aprendas cosas malas de él, ¿Entendido?"
    tt "อย่าไปเรียนรู้นิสัยแย่ๆ จากเขาเชียวล่ะ เข้าใจไหม?"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:183
translate english tenten_quest1_aa246933:

    # mn "Créeme, no quiero hacerlo..."
    mn "เชื่อผมเถอะครับ ว่าผมไม่อยากเลียนแบบเลย..."

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:186
translate english tenten_quest1_afe2597d:

    # tt "Perfecto, entonces estarémos en contacto"
    tt "เยี่ยม ไว้มีอะไรค่อยติดต่อกันนะ"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:189
translate english tenten_quest1_7042518a:

    # mn "Bien, muchas gracias Tenten"
    mn "ครับ ขอบคุณมากครับเท็นเท็น"

# game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:193
translate english tenten_quest1_df8d8f19:

    # n "[MN] sale de la tienda de Tenten"
    n "[MN] เดินออกจากร้านของเท็นเท็น"

translate english strings:

    # game/scripts/History/PrincipalStory/Arco1/tenten_quest1.rpy:163
    old "+1 Pergamino de Ataque"
    new "+1 คัมภีร์เสริมพลังโจมตี"
