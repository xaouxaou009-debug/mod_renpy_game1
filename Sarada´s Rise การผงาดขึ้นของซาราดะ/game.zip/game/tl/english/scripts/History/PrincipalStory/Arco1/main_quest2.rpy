

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:6
translate english main_quest2_afe896b0:

    # n "[MN] llega al campo de entrenamiento"
    n "[MN] มาถึงค่ายฝึกซ้อม"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:11
translate english main_quest2_1b39ad9e:

    # hd "¡Me rindo, me rindo!"
    hd "ยอมแล้ว ๆ ฉันยอมแล้ว!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:12
translate english main_quest2_168bb526:

    # hd "¡Q-Quítenme a este Monstruo!"
    hd "อ-เอาปีศาจตัวนี้ออกไปจากฉันที!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:13
translate english main_quest2_132ca112:

    # yn "Hideo..."
    yn "ฮิเดโอะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:14
translate english main_quest2_39af8c5b:

    # zb "Bien, ya fue suficiente, tú ganas esta vez Yuna..."
    zb "โอเค พอแค่นี้แหละ รอบนี้เธอนะยูนะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:24
translate english main_quest2_41e8027c:

    # hd "Aah..."
    hd "อ๊า..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:30
translate english main_quest2_6f38611f:

    # mn "¿Qué están haciendo?"
    mn "กำลังทำอะไรอยู่เนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:34
translate english main_quest2_eab4dd60:

    # hd "¡[MN]!"
    hd "[MN]!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:38
translate english main_quest2_a4285e4d:

    # yn "Vaya..."
    yn "ว้าว..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:41
translate english main_quest2_2f36425a:

    # zb "El fiestas locas por fin se dignó a venir"
    zb "แม่ตัวปาร์ตี้สุดเหวี่ยงในที่สุดก็ยอมโผล่หัวมาจนได้สินะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:44
translate english main_quest2_f8566538:

    # mn "Sensei... Sólo lo acompañé una vez"
    mn "เซนเซย์... ผมเคยร่วมวงกับคุณแค่ครั้งเดียวเองนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:47
translate english main_quest2_6f806fb5:

    # zb "Pero nos divertirmos, ¿No?"
    zb "แต่พวกเราสนุกกันใช่ไหมล่ะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:50
translate english main_quest2_a5e13e2d:

    # zb "Alégrate, ese día te hicieron hombre"
    zb "จงยินดีซะเถอะ วันนั้นแหละที่นายจะได้กลายเป็นลูกผู้ชาย"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:54
translate english main_quest2_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:58
translate english main_quest2_2581939d:

    # zb "Oh ¿O acaso fue... Yuna...?"
    zb "หืม หรือว่าจะ... ยูนะ...?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:62
translate english main_quest2_518dfa84:

    # yn "¡Pudrase Sensei!"
    yn "ไปตายซะเถอะ เซนเซย์!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:67
translate english main_quest2_3cf5fa9b:

    # hd "¿Hmm?"
    hd "อื้ม?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:71
translate english main_quest2_10ce6880:

    # hd "Oye, ¿Qué tienes el ojo?"
    hd "เฮ้ ตาของนายเป็นอะไรน่ะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:75
translate english main_quest2_5fb2b217:

    # hd "¿Lo tienes amarillo?"
    hd "ทำไมมันถึงเป็นสีเหลืองล่ะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:78
translate english main_quest2_0644d3f6:

    # yn "¿?"
    yn "?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:80
translate english main_quest2_7e4691bd:

    # zb "Oh, ¡Es cierto! ¿Qué te pasó?"
    zb "โอ้ ให้ตายสิ! ไปโดนอะไรมาเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:83
translate english main_quest2_c0831b72:

    # mn "Es una larga historia..."
    mn "มันเรื่องยาว..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:87
translate english main_quest2_1b2ac895:

    # n "[MN] le cuenta a todos lo que pasó respecto a su clan y el Karugan"
    n "[MN] เล่าให้ทุกคนฟังถึงเรื่องราวที่เกิดขึ้นระหว่างเขากับตระกูลคารูกัน"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:90
translate english main_quest2_33d841e3:

    # mn "Y eso sería todo..."
    mn "ก็ประมาณนี้แหละ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:92
translate english main_quest2_73ff6995:

    # yn "..."
    yn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:94
translate english main_quest2_c45eee4b:

    # hd "Vaya... Estoy sin palabras"
    hd "โห... พูดไม่ออกเลยแฮะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:97
translate english main_quest2_4ef1aca2:

    # zb "Mira el lado bueno, no se te ve mal"
    zb "มองในแง่ดีสิ มันก็ไม่ได้ดูแย่กับนายหรอกนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:100
translate english main_quest2_32462c4b_1:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:102
translate english main_quest2_90aee022:

    # mn "Cambiando el tema, ¿Por qué estaban peleando?"
    mn "เปลี่ยนเรื่องเถอะ ทำไมพวกเธอถึงสู้กันล่ะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:105
translate english main_quest2_388c6a20:

    # hd "El Sensei quería comprobar quién es el más fuerte de nosotros..."
    hd "เซนเซย์อยากเช็กดูว่าพวกเราใครแข็งแกร่งที่สุดน่ะสิ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:108
translate english main_quest2_f84db874:

    # zb "Sí, a comparación de otros equipos ustedes se están atrasando mucho por conseguir el rango de -chunin-"
    zb "ใช่แล้ว ถ้าเทียบกับทีมอื่นแล้วพวกเธอยังตามหลังเรื่องการสอบเลื่อนขั้นเป็น -จูนิน- อยู่เยอะเลย"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:111
translate english main_quest2_0dbedcb2:

    # yn "Eso es porque usted no ha mandado la solicitud para que hagamos el examen"
    yn "ก็เพราะว่าคุณยังไม่ได้ส่งเรื่องขอให้พวกเราไปสอบเลยต่างหากเล่า"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:114
translate english main_quest2_0500f028:

    # zb "Los exámenes chunin no deben tomarse a la ligera, debo de estar 100 por ciento seguro que están listos para hacerlos"
    zb "การสอบจูนินไม่ใช่เรื่องที่จะมองข้ามได้ง่าย ๆ ฉันต้องมั่นใจร้อยเปอร์เซ็นต์ว่าพวกเธอพร้อมจริง ๆ ซะก่อน"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:117
translate english main_quest2_65f33949:

    # zb "Es por eso que les dije que vinieran el día de hoy, quiero comprobar sus habilidades en combate"
    zb "นั่นแหละคือเหตุผลที่ฉันเรียกให้พวกเธอมาวันนี้ ฉันอยากจะทดสอบทักษะการต่อสู้ของพวกเธอน่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:120
translate english main_quest2_1bb34dac:

    # mn "Entiendo..."
    mn "เข้าใจแล้ว..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:125
translate english main_quest2_eaee663e:

    # zb "Ejem... Hideo, tú debes de esforzarte más, parecía que ni siquiera lo estabas intentando..."
    zb "แฮ่ม... ฮิเดโอะ นายควรพยายามให้มากกว่านี้นะ เหมือนนายไม่ได้เอาจริงเลยด้วยซ้ำ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:129
translate english main_quest2_be982cab:

    # hd "Yuna es muy fuerte Sensei..."
    hd "ก็ยูนะแข็งแกร่งมากเลยนี่ครับ เซนเซย์..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:132
translate english main_quest2_8cdef554:

    # zb "La fuerza no lo es todo"
    zb "พละกำลังไม่ใช่ทุกอย่างหรอกนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:134
translate english main_quest2_9cd835bf:

    # zb "Siempre debes de encontrar la manera de contrarrestar los ataques del enemigo"
    zb "พวกเธอต้องหาวิธีรับมือกับการโจมตีของศัตรูอยู่เสมอ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:138
translate english main_quest2_58ec376c:

    # mn "No debes tomarte a Yuna a la ligera"
    mn "นายไม่ควรประมาทยูนะเลยนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:142
translate english main_quest2_76f27a05:

    # mn "Te sorprendería saber de lo que es capaz..."
    mn "นายจะต้องทึ่งกับสิ่งที่เธอทำได้แน่..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:146
translate english main_quest2_5f93f0f9:

    # yn "¿Tienes algo que decir?"
    yn "มีอะไรจะพูดอีกไหมล่ะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:150
translate english main_quest2_9329e686:

    # mn "Creo que ya dije suficiente..."
    mn "ฉันว่าฉันพูดพอแล้วล่ะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:153
translate english main_quest2_9380fde4:

    # yn "Tch... Maldito idiota..."
    yn "ชิ... ไอ้บ้าเอ๊ย..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:156
translate english main_quest2_9154e268:

    # mn "Deberías comportarte, estamos frente al Sensei"
    mn "ทำตัวดี ๆ หน่อยสิ พวกเราอยู่ต่อหน้าเซนเซย์อยู่นะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:160
translate english main_quest2_f0399548:

    # yn "Me da igual, no creas que he olvidado la humillación que me hiciste pasar"
    yn "ฉันไม่สนใจหรอก อย่าคิดนะว่าฉันจะลืมความอัปยศที่นายทำกับฉันไว้น่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:163
translate english main_quest2_433ef4ba:

    # zb "Hey, hey, la tensión subió mucho aquí"
    zb "เฮ้ ๆ บรรยากาศเริ่มตึงเครียดกันใหญ่แล้วนะเนี่ย"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:166
translate english main_quest2_85f77a5d:

    # hd "Cálmense un poco, no tienen que pelear así..."
    hd "ใจเย็น ๆ หน่อยน่า พวกเธอไม่ต้องถึงกับสู้กันขนาดนั้นก็ได้..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:169
translate english main_quest2_c9087e26:

    # yn "La idea era que pelearamos de todos modos, ¿No?"
    yn "ยังไงเป้าหมายของเราก็คือต้องสู้กันอยู่แล้วไม่ใช่เหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:172
translate english main_quest2_63fd0035:

    # mn "¿Quieres pelear conmigo?"
    mn "เธออยากจะสู้กับฉันงั้นเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:175
translate english main_quest2_3a42206a:

    # yn "No tienes ni idea de las ganas que tengo de molerte a golpes"
    yn "นายไม่รู้หรอกว่าฉันอยากจะซัดนายให้หมอบขนาดไหน"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:178
translate english main_quest2_c4062704:

    # zb "Jajaja está bien"
    zb "ฮ่า ๆ ๆ เอาล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:180
translate english main_quest2_728b9f0f:

    # zb "Debo de comprobar las habilidades de [MN] también"
    zb "ฉันเองก็ต้องเช็กฝีมือของ [MN] เหมือนกัน"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:183
translate english main_quest2_2c17a145:

    # hd "Sensei, esto no va salir bien..."
    hd "เซนเซย์ เรื่องนี้ท่าจะไม่ค่อยดีแน่เลยครับ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:186
translate english main_quest2_b94a9f50:

    # zb "Shhhh..."
    zb "ชูว์..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:188
translate english main_quest2_b4417b13:

    # zb "Quiero ver hasta donde llega todo este drama..."
    zb "ฉันอยากรู้นักว่าละครฉากนี้มันจะไปจบที่ตรงไหน..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:191
translate english main_quest2_7ca12b98:

    # mn "No esperaba que tuviera que pelear contigo, pero ya que insistes"
    mn "ฉันไม่คิดเลยว่าจะต้องมาสู้กับเธอ แต่ในเมื่อเธอขอร้องล่ะก็"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:193
translate english main_quest2_f8f2cf3d:

    # yn "Sé un hombre y dame un combate decente, ¿Quieres?"
    yn "ทำตัวให้สมเป็นลูกผู้ชายแล้วสู้กับฉันให้มันสมศักดิ์ศรีหน่อยสิยะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:195
translate english main_quest2_0e029ff0:

    # mn "Será un placer patear tu trase..."
    mn "ฉันยินดีมากที่จะได้อัดเธอให้คว่ำ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:200
translate english main_quest2_4b8cb021:

    # mn "¡¡!!"
    mn "!!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:201
translate english main_quest2_19b28b86:

    # n "Sin que [MN] pudiera reaccionar, Yuna le da un puñetazo en la cara"
    n "ก่อนที่ [MN] จะทันได้ตั้งตัว ยูนะก็ซัดหมัดเข้าที่ใบหน้าของเขาเต็มแรง"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:204
translate english main_quest2_38472f58:

    # yn "¿Acaso no lo viste venir?"
    yn "มองไม่เห็นการโจมตีเมื่อกี้รึไง?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:208
translate english main_quest2_b4706c6e:

    # mn "(Maldición, ni siquiera pude ver cuando se movió...)"
    mn "(เวรเอ๊ย ฉันมองตามการเคลื่อนไหวของเธอไม่ทันด้วยซ้ำ...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:209
translate english main_quest2_e37d891d:

    # mn "(¿Usó su {b}Kekkei Genkai{/a} para convertir su mano en acero?)"
    mn "(เธอใช้ {b}ขีดจำกัดสายเลือด{/a} ทำให้มือกลายเป็นเหล็กงั้นเหรอ?)"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:210
translate english main_quest2_dfb95393:

    # mn "(¿Desde cuándo puede hacerlo?)"
    mn "(ตั้งแต่เมื่อไหร่กันที่เธอทำแบบนั้นได้?)"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:214
translate english main_quest2_e0473f8a:

    # yn "¡¿Qué estás esperando para luchar?!"
    yn "มัวรออะไรอยู่เล่า สู้สิยะ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:215
translate english main_quest2_ce47ec7f:

    # mn "(¡Mierda!)"
    mn "(เวรเอ๊ย!)"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:226
translate english main_quest2_0db7bb1e:

    # mn "(¿Y desde cuando se volvió tan rápida?)"
    mn "(แล้วตั้งแต่เมื่อไหร่กันที่เธอเร็วขนาดนี้เนี่ย?)"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:228
translate english main_quest2_2e174ef3:

    # mn "(Será mejor que me ponga a luchar en serio o voy a terminar perdiendo este combate)"
    mn "(ฉันรีบเอาจริงดีกว่า ไม่งั้นได้แพ้การต่อสู้ครั้งนี้แน่)"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:233
translate english main_quest2_4c6cb48b:

    # n "[MN] se prepara para la lucha"
    n "[MN] ตั้งท่าเตรียมพร้อมสำหรับการต่อสู้"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:240
translate english main_quest2_after_battle_848dcebd:

    # yn "¡Tch!"
    yn "ชิ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:246
translate english main_quest2_after_battle_94279ed8:

    # yn "¡Ya estoy harta de esto!"
    yn "ฉันชักจะทนไม่ไหวแล้วนะ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:250
translate english main_quest2_after_battle_04faecfc:

    # n "¡Yuna salta, y se prepara para lanzar su ataque definitivo!"
    n "ยูนะกระโดดขึ้นไปบนฟ้า และเตรียมใช้ท่าไม้ตายของเธอ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:251
translate english main_quest2_after_battle_bbfd2dca:

    # mn "¡!"
    mn "!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:252
translate english main_quest2_after_battle_f7f46a9c:

    # hd "S-Sensei... ¿Yuna hará ese ataque?"
    hd "จ-เซนเซย์... ยูนะจะใช้ท่านั้นจริง ๆ เหรอครับ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:253
translate english main_quest2_after_battle_1b7d4b93:

    # zb "Si, usará el {b}Estilo de Acero: Shurikens de Acero{/a}"
    zb "ใช่แล้วล่ะ เธอจะใช้ {b}คาถาเหล็ก: ชูริเค็นเหล็ก{/a}"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:254
translate english main_quest2_after_battle_ead4e3d4:

    # zb "Un jutsu que Yuna ha estado practicando, consiste en moldear shurikens en sus manos"
    zb "มันคือวิชานินจาที่ยูนะฝึกฝนมา โดยการหลอมเหล็กให้กลายเป็นชูริเค็นที่มือของเธอเอง"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:255
translate english main_quest2_after_battle_82d191cf:

    # zb "Es un Jutsu mortal, porque el acero creado a partir de su {b}Kekkei Genkai{/a} es más resistente que el normal"
    zb "มันเป็นวิชานินจาที่อันตรายถึงชีวิตเลยล่ะ เพราะเหล็กที่สร้างมาจาก{b}ขีดจำกัดสายเลือด{/a}ของเธอนั้นมีความแข็งแกร่งกว่าเหล็กทั่วไปซะอีก"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:256
translate english main_quest2_after_battle_57cc54fd:

    # zb "Además de que Yuna es capaz de manejarlos a su gusto mientras no lleguen a su objetivo"
    zb "แถมยูนะยังสามารถควบคุมมันได้ตามใจชอบจนกว่าจะพุ่งไปถึงเป้าหมายด้วยนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:257
translate english main_quest2_after_battle_26b82862:

    # hd "Maldición, en qué pensará Yuna al usar ese Jutsu contra [MN]"
    hd "ให้ตายสิ ยูนะกำลังคิดบ้าอะไรอยู่เนี่ยถึงได้ใช้วิชานั้นกับ [MN]"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:258
translate english main_quest2_after_battle_009eb1d7:

    # mn "¡Tch!"
    mn "ชิ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:259
translate english main_quest2_after_battle_beba3553:

    # mn "(¡Maldición, si uno de esos acierta me matará!)"
    mn "(เวรเอ๊ย ถ้าโดนไอ้พวกนั้นเข้าล่ะก็ ฉันได้ตายแหง ๆ!)"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:260
translate english main_quest2_after_battle_4a87e5e8:

    # mn "(Bloquear eso no es una opción)"
    mn "(จะใช้วิธีบล็อกไม่ได้เด็ดขาด)"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:261
translate english main_quest2_after_battle_b3e412fd:

    # yn "(Jeh, bloquea esto, bastardo)"
    yn "(หึ รับการโจมตีนี้ไปซะไอ้เวร)"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:262
translate english main_quest2_after_battle_de634652:

    # mn "(Está loca, debo esquivarlos...)"
    mn "(ยัยนี่มันสติหลุดไปแล้ว ฉันต้องหลบให้ได้...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:266
translate english main_quest2_after_battle_7045f30a:

    # yn "¡Toma esto!"
    yn "รับนี่ไปซะ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:267
translate english main_quest2_after_battle_7c91f0c5:

    # mn "(Mierda, Mierda...)"
    mn "(เวรเอ๊ย เวรเอ๊ย...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:281
translate english main_quest2_after_battle_c7c0be52:

    # yn "¿Q-Qué?"
    yn "อ-อะไรกันน่ะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:282
translate english main_quest2_after_battle_848dcebd_1:

    # yn "¡Tch!"
    yn "ชิ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:286
translate english main_quest2_after_battle_73ff6995:

    # yn "..."
    yn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:288
translate english main_quest2_after_battle_120a087b:

    # yn "¿Dónde carajos está?"
    yn "ยัยนี่หายหัวไปไหนวะเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:289
translate english main_quest2_after_battle_fd07c9a4:

    # yn "Acaba de desaparecer en mi cara..."
    yn "จู่ ๆ ก็หายไปต่อหน้าต่อตาซะงั้น..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:296
translate english main_quest2_after_battle_ae5cbf2f:

    # mn "¡Sharingan!"
    mn "เนตรวงแหวน!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:297
translate english main_quest2_after_battle_0a9f7fc0:

    # yn "¡!"
    yn "!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:300
translate english main_quest2_after_battle_8cf28be7:

    # mn "{b}Estilo de Fuego:{/a}"
    mn "{b}คาถาไฟ:{/a}"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:301
translate english main_quest2_after_battle_83337e18:

    # yn "¡M-Mierda!"
    yn "ซ-ซวยแล้ว!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:309
translate english main_quest2_after_battle_9877afa6:

    # mn "{b}¡Majestuosa Llama Destructora!{/a}"
    mn "{b}วิชาเพลิงทำลายล้างมหันตภัย!{/a}"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:310
translate english main_quest2_after_battle_78110004:

    # yn "¡Agh!"
    yn "อัก!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:311
translate english main_quest2_after_battle_a07d3ae6:

    # hd "¡¿V-Vió eso, Sensei?!"
    hd "จ-เซนเซย์เห็นเมื่อกี้ไหมครับ?!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:312
translate english main_quest2_after_battle_3e747526:

    # hd "De un momento a otro [MN] se volvió invisible para esquivar y atacar a Yuna con su mejor jutsu"
    hd "จู่ ๆ [MN] ก็หายตัวไปเพื่อหลบและสวนกลับยูนะด้วยวิชานินจาที่ดีที่สุดของเจ้าตัวพริบตาเดียวเลยครับ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:313
translate english main_quest2_after_battle_7790fbf8:

    # zb "Sí, tal parece que lo de hacerse invisible no era broma después de todo"
    zb "นั่นสิ ดูเหมือนว่าการหายตัวได้นั่นจะไม่ใช่เรื่องล้อเล่นจริง ๆ ด้วยแฮะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:314
translate english main_quest2_after_battle_6365da28:

    # zb "Tal vez no te diste cuenta por lo rápido que fue, pero parece que [MN] lo activó de manera inconsciente"
    zb "เธออาจจะไม่ได้สังเกตเพราะมันเร็วมาก แต่ดูเหมือนว่า [MN] จะเผลอเปิดใช้มันโดยไม่รู้ตัวน่ะสิ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:323
translate english main_quest2_after_battle_b494a512:

    # zb "Mmm... Eso me genera una duda..."
    zb "อืม... นั่นทำให้ฉันสงสัยอยู่อย่างหนึ่งเลยนะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:326
translate english main_quest2_after_battle_3b8668ae:

    # hd "¿A qué se refiere?"
    hd "หมายความว่ายังไงเหรอครับ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:329
translate english main_quest2_after_battle_7c8c1e2e:

    # zb "Sí es un {b}Kekkei Genkai{/a} significa que debe usar chakra para activarlo..."
    zb "ถ้ามันเป็น{b}ขีดจำกัดสายเลือด{/a}ล่ะก็ นั่นหมายความว่าจะต้องใช้จักระในการเปิดใช้งานมันสินะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:331
translate english main_quest2_after_battle_7dee5007:

    # zb "Y en este combate [MN] ha usado tanto el {b}Sharingan{/a}, como el {b}Estilo de Fuego{/a} y su nuevo {b}Karugan{/a}"
    zb "และในการต่อสู้ครั้งนี้ [MN] ก็ใช้ทั้ง {b}เนตรวงแหวน{/a} {b}คาถาไฟ{/a} และ {b}คารุกัน{/a} อันใหม่ของเจ้าตัวด้วย"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:333
translate english main_quest2_after_battle_bc5ee687:

    # zb "Mi duda es... ¿Qué tanto se desgastará usando todo eso?"
    zb "คำถามของฉันคือ... การใช้ทั้งหมดนั่นจะทำให้ร่างกายรับภาระหนักขนาดไหนกันนะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:346
translate english main_quest2_after_battle_35d1153b:

    # mn "Haah..."
    mn "อ่าา..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:347
translate english main_quest2_after_battle_eab4dd60:

    # hd "¡[MN]!"
    hd "[MN]!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:348
translate english main_quest2_after_battle_b004b0cc:

    # mn "(Mierda... Usé demasiado Chakra...)"
    mn "(เวรเอ๊ย... ฉันใช้จักระเปลืองไปหน่อยแฮะ...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:349
translate english main_quest2_after_battle_ae78f80b:

    # mn "(La invisibilidad me salvó, al Yuna perderme de vista pude esquivar el ataque)"
    mn "(การล่องหนช่วยชีวิตฉันเอาไว้ พอตอนที่ยูนะมองไม่เห็นฉัน ฉันก็เลยหลบการโจมตีนั้นได้)"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:350
translate english main_quest2_after_battle_27ce6bc2:

    # mn "(Pero al usar el {b}Sharingan{/a} y la {b}Llama Destructora{/a} también quedé muy exhausto...)"
    mn "(แต่พอใช้ {b}เนตรวงแหวน{/a} กับ {b}เพลิงทำลายล้าง{/a} ด้วย มันเลยทำให้ฉันหมดแรงเอาซะมาก ๆ เหมือนกัน...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:351
translate english main_quest2_after_battle_605f8f2b:

    # zb "Creo que ahí está la respuesta..."
    zb "คิดว่านั่นน่าจะเป็นคำตอบแล้วล่ะนะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:353
translate english main_quest2_after_battle_d6e96ef4:

    # n "Yuna aparece luego de recibir el ataque de [MN]"
    n "ยูนะปรากฏตัวขึ้นหลังจากโดนการโจมตีของ [MN] เข้าไปเต็ม ๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:361
translate english main_quest2_after_battle_ac512cf0:

    # mn "Jeh... Mírate..."
    mn "หึ... ดูสภาพแกสิ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:363
translate english main_quest2_after_battle_73ff6995_1:

    # yn "..."
    yn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:365
translate english main_quest2_after_battle_c3790a81:

    # mn "Te ves horrible..."
    mn "ดูแย่เป็นบ้าเลยนะเนี่ย..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:369
translate english main_quest2_after_battle_0a9f7fc0_1:

    # yn "¡!"
    yn "!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:371
translate english main_quest2_after_battle_252184a8:

    # yn "¡Bastardo infeliz!"
    yn "ไอ้บ้านี่เอ๊ย!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:373
translate english main_quest2_after_battle_a98e3080:

    # yn "¡Tú eres el que parece una mierda en este momento!"
    yn "แกต่างหากล่ะที่ดูแย่อยู่ตอนนี้เนี่ย!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:376
translate english main_quest2_after_battle_133eb993:

    # n "En un rápido movimiento, Yuna y [MN] se abalanzaron entre sí para acabar la batalla"
    n "ด้วยการเคลื่อนไหวอันรวดเร็ว ยูนะและ [MN] พุ่งเข้าใส่กันเพื่อตัดสินการต่อสู้"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:382
translate english main_quest2_after_battle_3d0f447a:

    # zb "Bien, bien, ya vi suficiente"
    zb "พอ ๆ ๆ ฉันดูพอละ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:385
translate english main_quest2_after_battle_08f0eac7:

    # "¡!"
    "!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:392
translate english main_quest2_after_battle_bbfd2dca_1:

    # mn "¡!"
    mn "!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:396
translate english main_quest2_after_battle_848dcebd_2:

    # yn "¡Tch!"
    yn "จิส์!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:400
translate english main_quest2_after_battle_afbcdeea:

    # zb "Muy bien jovenes, hoy han dado un gran espectáculo"
    zb "ทำได้ดีมากพวกเธอ วันนี้โชว์ฟอร์มกันได้ยอดเยี่ยมจริง ๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:401
translate english main_quest2_after_battle_d07acc21:

    # zb "Me gustó mucho su pequeña discusión de pareja"
    zb "ฉันชอบการเถียงกันกุ๊กกิ๊กแบบคู่รักของพวกเธอจริง ๆ นะเนี่ย"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:415
translate english main_quest2_after_battle_ec8d5b59:

    # zb "Yuna usó todo lo que le enseñé y [MN] demostró sus nuevas habilidades"
    zb "ยูนะงัดทุกอย่างที่ฉันสอนไปใช้อย่างเต็มที่ ส่วน [MN] ก็แสดงทักษะใหม่ ๆ ให้เห็น"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:418
translate english main_quest2_after_battle_2956b97d:

    # zb "Jajaja, ¡Este es el poder de la Juventud que tanto quería ver en ustedes!"
    zb "ฮ่า ๆ ๆ นี่แหละคือพลังแห่งวัยหนุ่มสาวที่ฉันอยากเห็นจากพวกเธอที่สุด!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:422
translate english main_quest2_after_battle_e0dadced:

    # hd "¡Si, lo hicieron muy bien!"
    hd "นั่นสิครับ พวกเขาสู้ได้ดีมากเลย!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:427
translate english main_quest2_after_battle_3847db83:

    # zb "Hideo... A tí te falta aprender mucho... Lo haces fatal"
    zb "ฮิเดโอะ... นายยังต้องเรียนรู้อีกเยอะเลยนะ... ฝีมือยังแย่อยู่เลย"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:430
translate english main_quest2_after_battle_142d0632:

    # zb "Aprende algo de ellos..."
    zb "หัดเรียนรู้อะไรจากพวกเขาสะบ้างสิ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:433
translate english main_quest2_after_battle_536ff88e:

    # hd "L-Lo siento..."
    hd "ผ-ผมขอโทษครับ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:435
translate english main_quest2_after_battle_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:439
translate english main_quest2_after_battle_48ce496d:

    # mn "¿Todo lo que le enseñó a Yuna?"
    mn "ทุกอย่างที่สอนยูนะงั้นเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:442
translate english main_quest2_after_battle_4c2df5c7:

    # mn "¿Acaso la entrenó o algo parecido?"
    mn "นี่นายเป็นคนฝึกให้เธอรึไง?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:445
translate english main_quest2_after_battle_b5c49e10:

    # zb "Creo que te tomó por sorpresa ¿Cierto? Yuna ha mejorado mucho"
    zb "ฉันว่าเธอเล่นงานเธอเข้าซะตั้งตัวไม่ทันเลยล่ะสิ? ยูนะพัฒนาขึ้นเยอะเลยนะเนี่ย"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:447
translate english main_quest2_after_battle_4e02c2f5:

    # zb "Ella se acercó y me hizo una petición"
    zb "เธอเข้ามาหาฉันแล้วก็ยื่นข้อเสนอมาน่ะสิ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:450
translate english main_quest2_after_battle_226e2dd2:

    # zb "Pensé que sería algo más sexual"
    zb "ตอนแรกฉันก็นึกว่าเธอจะมาแนวเซ็กซี่กว่านี้ซะอีก"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:452
translate english main_quest2_after_battle_411e8804:

    # zb "Pero en cambio me pidió enseñarle a hacer su Taijutsu más letal"
    zb "แต่กลับกลายเป็นว่าเธอขอให้ฉันช่วยสอนวิธีทำให้กระบวนท่าวิชาต่อสู้ของเธอมันถึงตายยิ่งขึ้นต่างหาก"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:454
translate english main_quest2_after_battle_49de1e35:

    # hd "Oh ¿Se refiere a usar su naturaleza de chakra luchando cuerpo a cuerpo?"
    hd "อ๋อ หมายถึงการใช้ธาตุจักระตอนสู้มือเปล่าสินะครับ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:458
translate english main_quest2_after_battle_f3996f01:

    # zb "Exactamente, un punto para Hideo"
    zb "ถูกต้องแล้ว เอาไปเลยหนึ่งคะแนนสำหรับฮิเดโอะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:460
translate english main_quest2_after_battle_86e575bc:

    # hd "Jeje..."
    hd "แหะๆ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:464
translate english main_quest2_after_battle_5fc9fafb:

    # zb "Verás, yo domino 2 naturalezas de chakra"
    zb "ก็อย่างที่เห็น ฉันน่ะเชี่ยวชาญจักระถึง 2 ธาตุเลยนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:467
translate english main_quest2_after_battle_55687e9e:

    # zb "Viento y tierra"
    zb "ธาตุลมกับธาตุดินยังไงล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:469
translate english main_quest2_after_battle_04a37a37:

    # zb "Logré la manera de reforzar mi Taijutsu combinando ambas naturalezas de chakra"
    zb "ฉันเลยคิดค้นวิธีเพิ่มความแข็งแกร่งให้วิชาไทจุสึด้วยการผสมผสานจักระทั้งสองธาตุเข้าด้วยกัน"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:471
translate english main_quest2_after_battle_592180cc:

    # zb "Las manipulo por todo mi cuerpo para hacerlo más pesado o ligero según lo necesite"
    zb "ฉันควบคุมมันไว้ทั่วร่างกายเพื่อปรับให้มันหนักขึ้นหรือเบาลงได้ตามต้องการ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:475
translate english main_quest2_after_battle_6712524a:

    # zb "Yuna logró hacer lo mismo pero usando su {b}Estilo de Acero{/a}"
    zb "ยูนะเองก็ทำแบบเดียวกันได้สำเร็จ แต่ใช้ {b}คาถาเหล็ก{/a} ของเธอเอง"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:477
translate english main_quest2_after_battle_10080dbe:

    # zb "Logró hacer jutsus cuerpo a cuerpo como el {b}Brazo de Acero{/a}"
    zb "เธอใช้คาถานินจาระยะประชิดอย่าง {b}แขนเหล็ก{/a} ได้ด้วย"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:479
translate english main_quest2_after_battle_57d53709:

    # zb "Y también a distancia, el {b}Shuriken de Acero{/a}"
    zb "แถมยังใช้โจมตีระยะไกลอย่าง {b}ดาวกระจายเหล็ก{/a} ได้อีกต่างหาก"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:482
translate english main_quest2_after_battle_eacde7cc:

    # zb "Aunque, pude observar que aún le falta mucho que aprender"
    zb "ถึงอย่างนั้น ฉันก็ยังเห็นว่าเธอยังต้องเรียนรู้อีกเยอะเลยล่ะนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:485
translate english main_quest2_after_battle_a7103d26:

    # hd "A mí me parece increíble que hayas logrado hacer eso"
    hd "ผมว่ามันเหลือเชื่อมากเลยนะครับที่คุณทำแบบนั้นได้"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:490
translate english main_quest2_after_battle_8bc9fa37:

    # yn "Awww, muchas gracias Hideo"
    yn "แหม... ขอบคุณมากเลยนะฮิเดโอะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:493
translate english main_quest2_after_battle_6d78ea64:

    # yn "Debería compensarte por ser tan halagador..."
    yn "งั้นฉันควรจะตอบแทนที่ชมกันซะหน่อยดีไหมนะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:496
translate english main_quest2_after_battle_e4d8e9ad:

    # hd "¿Eh?"
    hd "หา?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:499
translate english main_quest2_after_battle_cd83f6e7:

    # yn "¿No te gustaría... Tocárme?"
    yn "ไม่อยากลอง... สัมผัสฉันหน่อยเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:502
translate english main_quest2_after_battle_52ff6cfe:

    # hd "¡¿Q-Qué..? Claro que no...!"
    hd "อ-อะไรนะ..? ไม่เอาด้วยหรอ!..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:505
translate english main_quest2_after_battle_c26c83c4:

    # yn "Jaja, Tú te lo pierdes..."
    yn "ฮ่าๆ นายพลาดของดีแล้วล่ะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:509
translate english main_quest2_after_battle_5d2c1c74:

    # mn "Qué perra eres..."
    mn "ยัยตัวร่วนเอ๊ย..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:512
translate english main_quest2_after_battle_8d218589:

    # yn "¿Celoso?"
    yn "อิจฉาเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:515
translate english main_quest2_after_battle_1568d048:

    # mn "Ni un poco..."
    mn "นิดเดียวก็ไม่..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:518
translate english main_quest2_after_battle_53a388fa:

    # zb "Bueno, ya que Hideo no quiso, ¿Puedo aceptar yo tu oferta?"
    zb "งั้นในเมื่อฮิเดโอะไม่อยากได้ ฉันรับข้อเสนอแทนได้ไหมล่ะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:521
translate english main_quest2_after_battle_9b205484:

    # yn "No."
    yn "ไม่ค่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:524
translate english main_quest2_after_battle_060230a7:

    # zb "Bueno, lo intenté"
    zb "ช่วยไม่ได้แฮะ ลองดูแล้วนะเนี่ย"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:526
translate english main_quest2_after_battle_32462c4b_1:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:531
translate english main_quest2_after_battle_ade057a2:

    # zb "Por cierto [MN], ¿Ya sabes cómo activar tu nuevo jutsu?"
    zb "ว่าแต่ [MN] รู้วิธีใช้คาถาใหม่ของตัวเองรึยังล่ะเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:535
translate english main_quest2_after_battle_bc38d884:

    # mn "Solo tengo una vaga idea"
    mn "ฉันก็แค่พอมีไอเดียคร่าวๆ ล่ะนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:537
translate english main_quest2_after_battle_251e1203:

    # mn "La primea vez que lo hice fue de manera inconsciente"
    mn "ตอนที่ทำได้ครั้งแรกมันทำไปโดยไม่รู้ตัวน่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:540
translate english main_quest2_after_battle_949c744d:

    # zb "Interesante... ¿No puedes hacerlo conscientemente?"
    zb "น่าสนใจแฮะ... แล้วตอนนี้ตั้งใจทำมันให้เกิดขึ้นเองไม่ได้เหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:543
translate english main_quest2_after_battle_1bf3a932:

    # mn "Ayer practiqué, y pude hacerlo pero me costó un poco"
    mn "เมื่อวานลองฝึกดูแล้วก็ทำได้นะ แต่ว่ามันค่อนข้างยากนิดหน่อย"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:545
translate english main_quest2_after_battle_0084ce6a:

    # mn "Tengo que seguir practicando para dominarlo"
    mn "คงต้องฝึกต่อไปเรื่อยๆ ถึงจะควบคุมได้คล่องล่ะนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:548
translate english main_quest2_after_battle_6c722af6:

    # zb "En este combate que tuviste con Yuna, ¿Lo hiciste a voluntad?"
    zb "แล้วในการต่อสู้กับยูนะเมื่อกี้ นายตั้งใจใช้มันตามใจชอบรึเปล่าล่ะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:551
translate english main_quest2_after_battle_5a83256d:

    # mn "No... Por alguna razón se activa de manera involuntaria"
    mn "เปล่า... ไม่รู้ทำไมจู่ๆ มันก็ทำงานขึ้นมาเองซะงั้น"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:553
translate english main_quest2_after_battle_6ad2d6b2:

    # zb "Hmm..."
    zb "อืม..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:555
translate english main_quest2_after_battle_b4fd1629:

    # zb "Muy bien"
    zb "ดีล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:558
translate english main_quest2_after_battle_be751e9f:

    # zb "Ahora, les tengo una noticia a todos"
    zb "งั้นฉันมีข่าวมาแจ้งให้พวกเธอทุกคนรู้ด้วยล่ะนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:561
translate english main_quest2_after_battle_78315b08:

    # yn "¿Dejará de ser un mujeriego?"
    yn "เลิกทำตัวเจ้าชู้สักทีได้ไหม?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:565
translate english main_quest2_after_battle_f0a24667:

    # zb "No me pidas que deje de ser hombre"
    zb "อย่าขอให้ฉันเลิกเป็นผู้ชายเลยน่า"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:567
translate english main_quest2_after_battle_37e2c867:

    # zb "Ejem, la noticia es..."
    zb "แฮ่ม ข่าวที่ว่าก็คือ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:572
translate english main_quest2_after_battle_3c2c5ba0:

    # zb "Que mandaré la solicitud para que puedan participar en los exámenes chunin..."
    zb "ฉันจะส่งใบสมัครให้พวกเธอได้เข้าร่วมสอบจูนิน..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:575
translate english main_quest2_after_battle_a3e72693:

    # hd "¿¡L-Lo dice en serio?!"
    hd "จ-จริงเหรอเนี่ย?!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:580
translate english main_quest2_after_battle_fa3e38db:

    # zb "Siempre y cuando puedan pasar mi prueba"
    zb "ตราบใดที่พวกเธอทุกคนสามารถผ่านบททดสอบของฉันไปได้นะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:584
translate english main_quest2_after_battle_80982b52:

    # mn "¿Prueba?"
    mn "บททดสอบงั้นเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:587
translate english main_quest2_after_battle_7bd35d5d:

    # zb "Los 3 tendrán que trabajar en equipo para poder asestarme un golpe"
    zb "ทั้ง 3 คนจะต้องร่วมมือกันเป็นทีมเพื่อโจมตีฉันให้ได้สักครั้ง"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:590
translate english main_quest2_after_battle_ff0e082e:

    # yn "¿Cuál es el truco?"
    yn "มีเงื่อนไขอะไรแอบแฝงอีกรึเปล่าเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:592
translate english main_quest2_after_battle_c3624c29:

    # zb "Esta vez no se las dejaré fácil jejeje"
    zb "ครั้งนี้ฉันไม่ยอมออมมือให้ง่ายๆ เหมือนเคยหรอกนะ หึๆๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:595
translate english main_quest2_after_battle_d55a4854:

    # zb "Usaré todo lo que tengo para no dejar que me golpeen"
    zb "ฉันจะงัดทุกอย่างที่มีมาใช้เพื่อไม่ให้พวกเธอแตะตัวฉันได้เลยล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:597
translate english main_quest2_after_battle_dc70cde2:

    # zb "Usaré mis dos naturalezas si es necesario"
    zb "ถ้าจำเป็น ฉันก็จะใช้ธาตุทั้งสองของฉันด้วยเหมือนกัน"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:600
translate english main_quest2_after_battle_29acbfb2:

    # mn "Suena a todo un desafío, me gusta"
    mn "ฟังดูท้าทายดีนี่ ชักชอบแล้วสิ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:603
translate english main_quest2_after_battle_a784056b:

    # zb "Deberán de entrenar más y ponerse de acuerdo en una estrategia para pasar mi prueba"
    zb "พวกเธอต้องไปฝึกฝนให้หนักขึ้นแล้วก็ตกลงวางแผนกันให้ดีถึงจะผ่านบททดสอบของฉันได้"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:607
translate english main_quest2_after_battle_32db747a:

    # hd "Me parece bien"
    hd "ฟังดูเข้าท่าดีนะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:610
translate english main_quest2_after_battle_ab7d83cf:

    # yn "A mí igual"
    yn "ฉันด้วย"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:614
translate english main_quest2_after_battle_d1c112a9:

    # mn "(Esto es lo que buscaba...)"
    mn "(นี่แหละคือสิ่งที่ฉันตามหาอยู่...)"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:615
translate english main_quest2_after_battle_7a1c7bbf:

    # mn "(No es solo derrotar al Sensei, también debo de mejorar para ganar los exámenes chunin)"
    mn "(ไม่ใช่แค่เรื่องเอาชนะอาจารย์เท่านั้น ฉันยังต้องเก่งขึ้นเพื่อคว้าชัยชนะในการสอบจูนินด้วย)"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:616
translate english main_quest2_after_battle_c94a9119:

    # mn "(Solo así podré demostrarle a Sarada que soy más que un ninja de Rango D)"
    mn "(มีแค่ทางนี้เท่านั้นแหละ ถึงจะพิสูจน์ให้ซาราดะเห็นได้ว่าฉันไม่ใช่แค่นินจาઅดับ D)"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:621
translate english main_quest2_after_battle_b7786462:

    # zb "Bien, entonces no tengo nada más que decir"
    zb "เอาล่ะ งั้นฉันก็ไม่มีอะไรจะพูดแล้วล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:623
translate english main_quest2_after_battle_6344d728:

    # zb "Vayan a casa y descansen si quieren"
    zb "อยากจะกลับบ้านไปพักผ่อนกันก่อนก็ได้นะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:625
translate english main_quest2_after_battle_b6d4f174:

    # zb "Yo les haré saber mediante un mensaje cuándo será la prueba"
    zb "เดี๋ยวฉันจะส่งข้อความไปบอกเองว่าจะทดสอบกันเมื่อไหร่"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:630
translate english main_quest2_after_battle_6167f306:

    # zb "¡Así que arriba esos ánimos, déjenme ver en sus rostros el poder de la Juventud!"
    zb "เพราะงั้นฮึดสู้กันเข้าล่ะ แสดงพลังแห่งวัยหนุ่มให้ฉันเห็นบนหน้าพวกเธอทีสิ!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:632
translate english main_quest2_after_battle_94e9348d:

    # zb "..."
    zb "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:634
translate english main_quest2_after_battle_e845ac73:

    # hd "¡Cuídense chicos!"
    hd "ไว้เจอกันนะทุกคน!"

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:644
translate english main_quest2_after_battle_94e9348d_1:

    # zb "..."
    zb "..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:646
translate english main_quest2_after_battle_7a648ae2:

    # zb "Ay, malditos niños malcriados..."
    zb "เฮ้อ เจ้าเด็กพวกนี้นี่... ช่างเอาแต่ใจซะจริง..."

# game/scripts/History/PrincipalStory/Arco1/main_quest2.rpy:329
translate english main_quest2_after_battle_3b0cd4f4:

    # zb "Sí es un Jutsu significa que debe usar chakra para activarlo..."
    zb "ถ้ามันเป็น {b}ขีดจำกัดสายเลือด{/a} ล่ะก็ หมายความว่าเธอต้องใช้จักระเพื่อปลุกมันสินะ..."
