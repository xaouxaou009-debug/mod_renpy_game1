

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:11
translate english main_quest1_3_afe896b0:

    # n "[MN] llega al campo de entrenamiento"
    n "[MN] มาถึงค่ายฝึกซ้อม"

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:23
translate english main_quest1_3_e1a0aef2:

    # mn "¿Zubon-Sensei?"
    mn "อาจารย์ซูบงเหรอ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:25
translate english main_quest1_3_fa9a4ce0:

    # mn "Parece que no hay nadie"
    mn "ดูเหมือนว่าจะไม่มีใครอยู่เลยแฮะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:27
translate english main_quest1_3_6ee10563:

    # mn "Le enviaré un mensaje a ver que pasó"
    mn "ฉันลองส่งข้อความไปถามดูหน่อยดีกว่าว่าเกิดอะไรขึ้น"

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:36
translate english main_quest1_1_9bcf37fb:

    # mn "Bien, ahora tengo que esperar a que me conteste"
    mn "เอาล่ะ ตอนนี้ก็ต้องรอเขาตอบกลับมาสินะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:40
translate english main_quest1_1_02572a69:

    # mn "Conociéndolo, a esta hora quizás esté en el burdel"
    mn "นิสัยอย่างเขา ป่านนี้คงอยู่แถวสถานเริงรมย์แหงๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:43
translate english main_quest1_1_6b1a8e37:

    # mn "Seguro está ocupado"
    mn "เขาอาจจะกำลังยุ่งอยู่ล่ะมั้ง"

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:45
translate english main_quest1_1_3c0df37b:

    # mn "Entonces..."
    mn "งั้นก็..."

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:47
translate english main_quest1_1_c8486733:

    # mn "¿Qué debería hacer?"
    mn "ฉันควรทำอะไรต่อดีล่ะเนี่ย?"

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:52
translate english main_quest1_1_118d3ba7:

    # mn "Ahora que lo pienso, podría investigar sobre este Jutsu nuevo"
    mn "ลองคิดดูอีกที ฉันน่าจะใช้เวลานี้ศึกษาคาถาใหม่นี่สักหน่อยดีกว่า"

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:54
translate english main_quest1_1_c2f218aa:

    # mn "Puede serme de mucha utilidad si llego a dominarlo"
    mn "ถ้าฝึกจนเชี่ยวชาญได้ มันคงจะมีประโยชน์กับฉันมากแน่ๆ"

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:56
translate english main_quest1_1_af25e8fb:

    # n "Luego de no ver a nadie en el campo de entrenamiento"
    n "หลังจากที่ไม่พบใครเลยที่สนามฝึกซ้อม"

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:57
translate english main_quest1_1_f633e6f8:

    # n "[MN] decide tomarse el tiempo para practicar su Jutsu de Invisibilidad"
    n "[MN] จึงตัดสินใจใช้เวลาฝึกฝนคาถาพรางตัวของตัวเอง"

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:65
translate english main_quest1_1_675b4bb1:

    # mn "Ah..."
    mn "ฮืม..."

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:67
translate english main_quest1_1_9702152c:

    # mn "Joder sí... Creo que ya lo entiendo mejor..."
    mn "เยส... ฉันว่าตอนนี้ฉันเข้าใจมันดีขึ้นแล้วล่ะ..."

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:69
translate english main_quest1_1_198bffd1:

    # mn "He podido hacerme invisible por muy poco tiempo"
    mn "ฉันเริ่มทำให้ตัวเองล่องหนได้เป็นช่วงเวลาสั้นๆ แล้ว"

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:71
translate english main_quest1_1_12c5627d:

    # mn "Aunque ahora me duele bastante la vista"
    mn "ถึงแม้ว่าตอนนี้ตาของฉันจะปวดไปหมดแล้วก็เถอะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:73
translate english main_quest1_1_bf902605:

    # mn "Joder, y tenía que ser mi único ojo bueno"
    mn "ให้ตายสิ ทำไมต้องมาเป็นตาข้างที่ดีเพียงข้างเดียวของฉันด้วยเนี่ย"

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:75
translate english main_quest1_1_12485ca8:

    # mn "Agh..."
    mn "อึก..."

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:77
translate english main_quest1_1_d4baf99a:

    # mn "Vaya, ya se ha hecho demasiado tarde"
    mn "ว้าว ดึกขนาดนี้แล้วเหรอเนี่ย"

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:79
translate english main_quest1_1_4a572661:

    # mn "Y Zubon-Sensei no vino, ¿Me habrá contestado?"
    mn "แล้วอาจารย์ซูบงก็ไม่มา แล้วเขาตอบฉันหรือยังนะ?"

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:82
translate english main_quest1_1_4aa7ada1:

    # mn "Ah, parece que hizo un Grupo"
    mn "อ่า ดูเหมือนเขาจะสร้างกลุ่มแชทขึ้นมาสินะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:100
translate english main_quest1_2_93c4a7c7:

    # mn "*suspiro* Tendré que verla mañana..."
    mn "*ถอนหายใจ* เอาไว้พรุ่งนี้ค่อยดูแล้วกัน..."

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:102
translate english main_quest1_2_ccbca656:

    # mn "Bueno, no hay de otra"
    mn "เฮ้อ ช่วยไม่ได้แฮะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:105
translate english main_quest1_2_bc6a3ddf:

    # mn "Y Zubon-Sensei no vino hoy"
    mn "แถมวันนี้อาจารย์ซูบงก็ไม่ยอมมาอีก"

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:107
translate english main_quest1_2_298e2f70:

    # mn "Al menos hoy no perdí el día, ya que ya comienzo a comprender mejor este nuevo Jutsu"
    mn "แต่อย่างน้อยวันนี้ก็ไม่ได้เสียเปล่าล่ะนะ เพราะฉันเริ่มเข้าใจคาถาใหม่นี่ดีขึ้นบ้างแล้ว"

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:109
translate english main_quest1_2_2165bc60:

    # mn "Bueno, creo que ya no tengo nada que hacer aquí"
    mn "งั้นฉันว่าอยู่ที่นี่ต่อก็คงไม่มีอะไรทำแล้วล่ะ"

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:111
translate english main_quest1_2_6c06f553:

    # mn "Mejor me voy, tengo que ir a bañarme"
    mn "กลับดีกว่า ต้องไปอาบน้ำซะหน่อยแล้ว"

# game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:119
translate english main_quest1_2_f46c8540:

    # n "[MN] se va del campo de entrenamiento"
    n "[MN] ออกจากค่ายฝึกซ้อม"

translate english strings:

    # game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:49
    old "Entrenar el jutsu de Invisibilidad"
    new "ฝึกฝนคาถาพรางตัว"

    # game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:83
    old "Si usas móvil puedes hacerlo con el dedo"
    new "ถ้าใช้มือถือ คุณสามารถใช้นิ้วเลื่อนได้เลย"

    # game/scripts/History/PrincipalStory/Arco1/main_quest1.rpy:84
    old "Usa el ratón o la barra para desplazarte por el Chat"
    new "ใช้เมาส์หรือแถบเลื่อนเพื่อเลื่อนดูข้อความในแชท"
