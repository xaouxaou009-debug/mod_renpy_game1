# TODO: Translation updated at 2024-12-01 21:25

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest2.rpy:11
translate english arc2_main_quest2_2_46877d2e:

    # mnn "¿Mmm?"
    mnn "หืม?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest2.rpy:12
translate english arc2_main_quest2_2_72b7fb41:

    # mn "Un mensaje, ¿De quién será?"
    mn "ข้อความเหรอ ใครกันนะที่ส่งมา?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest2.rpy:14
translate english arc2_main_quest2_2_436a27be:

    # n "[MN] revisa de quién es el mensaje"
    n "[MN] ตรวจดูว่าข้อความมาจากใคร"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest2.rpy:15
translate english arc2_main_quest2_2_45882ad7:

    # mn "¡Aaah!" with vpunch
    mn "อ๊าห์!" with vpunch

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest2.rpy:18
translate english arc2_main_quest2_2_cd268525:

    # mn "U-Un mensaje del Séptimo Hokage..."
    mn "ข-ข้อความจากท่านโฮคาเงะรุ่นที่เจ็ด..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest2.rpy:19
translate english arc2_main_quest2_2_5502cecb:

    # mnn "..."
    mnn "..."

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest2.rpy:22
translate english arc2_main_quest2_2_f5e310a0:

    # mn "Mmm... ¿Para qué me necesitará?"
    mn "อืม... ท่านเรียกพบเราด้วยเรื่องอะไรกันนะ?"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest2.rpy:23
translate english arc2_main_quest2_2_51261685:

    # mn "Bueno, sea lo que sea, ahí estaré"
    mn "ช่างเถอะ จะเรื่องอะไรก็ช่าง ฉันจะไปเดี๋ยวนี้แหละ"

# game/scripts/History/PrincipalStory/Arco2/arc2_main_quest2.rpy:25
translate english arc2_main_quest2_2_fcdba863:

    # mn "Ya me iré a dormir para levantarme temprano"
    mn "เข้านอนตอนนี้เลยดีกว่า จะได้ตื่นแต่เช้า"

