# TODO: Translation updated at 2024-11-05 21:25

# game/scripts/History/PrincipalStory/Prologo.rpy:4
translate english Prologo_a20cefa7:

    # "..."
    "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:5
translate english Prologo_112e19b6:

    # d "Hace tiempo..."
    d "นานมาแล้ว..."

# game/scripts/History/PrincipalStory/Prologo.rpy:6
translate english Prologo_3e6aa7b5:

    # d "Mi padre, mi madre, el Séptimo Hokage y yo nos enfrentamos a cierto enemigo..."
    d "พ่อของฉัน แม่ของฉัน ท่านโฮคาเงะรุ่นที่ 7 และตัวฉัน... พวกเราเคยต้องเผชิญหน้ากับศัตรูอยู่คนหนึ่ง"

# game/scripts/History/PrincipalStory/Prologo.rpy:14
translate english Prologo_f782e122:

    # d "Se hacía llamar {color=#e62348}Shin Uchiha{/a}..."
    d "มันเรียกตัวเองว่า {color=#e62348}อุจิวะ ชิน{/a}..."

# game/scripts/History/PrincipalStory/Prologo.rpy:15
translate english Prologo_cdbaf5ff:

    # d "Era un loco obsesionado con el poder del {color=#e62348}Sharingan{/a}"
    d "เขาเป็นคนสติวิปลาสที่หมกมุ่นอยู่กับพลังของเนตร{color=#e62348}วงแหวน{/a}"

# game/scripts/History/PrincipalStory/Prologo.rpy:26
#translate english Prologo_7c055dd8:

    # d "Era un tipo despreciable, usaba a sus {color=#f3c271}hijos{/a} como simples herramientas para lograr un fin"
    #d "He was a despicable man, he used his {color=#f3c271}children{/a} as mere tools to achieve his goals"

# game/scripts/History/PrincipalStory/Prologo.rpy:27
translate english Prologo_5f4b8b47:

    # d "Tenía pensado {color=#f3c271}cumplir la voluntad de Itachi Uchiha{/a}, el hermano de mi padre, y mi tío"
    d "ตอนแรกฉันตั้งใจจะ{color=#f3c271}สานต่อเจตนารมณ์ของอุจิวะ อิทาจิ{/a} พี่ชายของพ่อ และเป็นคุณลุงของฉัน"

# game/scripts/History/PrincipalStory/Prologo.rpy:28
translate english Prologo_be7f4d9b:

    # d "Pero por lo que mi padre mencionó, realmente no quería hacer la voluntad de Itachi... Porque ni siquiera era su voluntad"
    d "แต่จากที่พ่อเล่าให้ฟัง เขาไม่ได้อยากจะทำตามเจตนารมณ์ของอิทาจิจริงๆ หรอก... เพราะนั่นไม่ใช่เจตนารมณ์ของเขาด้วยซ้ำ"

# game/scripts/History/PrincipalStory/Prologo.rpy:39
translate english Prologo_29ca81bc:

    # d "Por suerte, trabajando en equipo con el Séptimo Hokage y mi familia, logramos derrotarlo"
    d "โชคดีที่พวกเราผนึกกำลังร่วมกับท่านโฮคาเงะรุ่นที่ 7 และครอบครัว จนสามารถเอาชนะเขาได้"

# game/scripts/History/PrincipalStory/Prologo.rpy:40
translate english Prologo_dc51fde1:

    # d "Dejando a todos sus clones sin un líder o meta que seguir"
    d "ทำให้ร่างโคลนทั้งหมดของเขาต้องไร้ซึ่งผู้นำและเป้าหมายในการดำเนินชีวิต"

# game/scripts/History/PrincipalStory/Prologo.rpy:51
translate english Prologo_a63440c6:

    # d "El Séptimo Hokage se compadeció de ellos y dijo que podrían recibir hospedaje en el orfanato de la aldea"
    d "ท่านโฮคาเงะรุ่นที่ 7 เกิดความเวทนาและบอกว่าพวกเขาสามารถเข้ารับการดูแลที่สถานเลี้ยงเด็กกำพร้าในหมู่บ้านได้"

# game/scripts/History/PrincipalStory/Prologo.rpy:52
translate english Prologo_20fa95e3:

    # d "No sin antes preguntarles si habían más como ellos en algún otro lado"
    d "ก่อนหน้านั้นท่านได้ลองถามพวกเขาก่อนว่ายังมีคนอื่นๆ แบบพวกเขาอยู่ที่อื่นอีกไหม"

# game/scripts/History/PrincipalStory/Prologo.rpy:57
translate english Prologo_8edb6d54:

    # d "Estos le contestaron que probablemente había algún que otro más en el escondite de Shin"
    d "พวกเขาตอบว่าน่าจะยังมีคนอื่นๆ อยู่ในรังลับของชินอีก"

# game/scripts/History/PrincipalStory/Prologo.rpy:58
translate english Prologo_3f395e56:

    # d "Guiandonos así a dicho escondite"
    d "พร้อมกับนำทางพวกเราไปยังสถานที่หลบซ่อนแห่งนั้น"

# game/scripts/History/PrincipalStory/Prologo.rpy:60
translate english Prologo_4d004d0b:

    # d "Una vez ahí..."
    d "พอไปถึง..."

# game/scripts/History/PrincipalStory/Prologo.rpy:61
translate english Prologo_a20cefa7_1:

    # "..."
    "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:70
translate english Prologo_eab4b488:

    # d "Encontramos en su mayoría cosas repulsivas..."
    d "สิ่งที่เราพบส่วนใหญ่มีแต่พวกน่าขยะแขยง..."

# game/scripts/History/PrincipalStory/Prologo.rpy:71
translate english Prologo_4c97b745:

    # d "Varias cápsulas que en su interior albergaban sujetos de prueba sin vida"
    d "แคปซูลหลายอันบรรจุร่างทดลองที่ไร้ชีวิตเอาไว้ข้างใน"

# game/scripts/History/PrincipalStory/Prologo.rpy:72
translate english Prologo_b897ccc7:

    # d "Algunos ni siquiera parecían humanos"
    d "บางร่างดูไม่เหมือนมนุษย์ด้วยซ้ำ"

# game/scripts/History/PrincipalStory/Prologo.rpy:73
translate english Prologo_662edb74:

    # d "Honestamente pensé que todos estaban así"
    d "สารภาพตามตรงเลยว่าฉันคิดว่าทุกคนจะเป็นแบบนั้นซะอีก"

# game/scripts/History/PrincipalStory/Prologo.rpy:74
translate english Prologo_51c4a263:

    # d "Pero uno de ellos terminó siendo la excepción"
    d "แต่กลับมีอยู่คนหนึ่งที่เป็นข้อยกเว้น"

# game/scripts/History/PrincipalStory/Prologo.rpy:85
translate english Prologo_3dca8ae9:

    # d "había un chico..."
    d "มีเด็กผู้ชายคนหนึ่ง..."

# game/scripts/History/PrincipalStory/Prologo.rpy:86
translate english Prologo_bde01897:

    # d "Aparentaba ser de mi edad, fue liberado de la última cápsula"
    d "ดูท่าทางน่าจะรุ่นราวคราวเดียวกับฉัน เขาถูกปล่อยตัวออกมาจากแคปซูลสุดท้าย"

# game/scripts/History/PrincipalStory/Prologo.rpy:97
translate english Prologo_e0491c66:

    # d "Este cayó al suelo inconsciente"
    d "เขาร่วงลงไปนอนหมดสติอยู่กับพื้น"

# game/scripts/History/PrincipalStory/Prologo.rpy:98
translate english Prologo_096493a7:

    # d "El Hokage pudo confirmar que tenía pulso, así que lo llevamos a una camilla"
    d "ท่านโฮคาเงะตรวจดูแล้วยืนยันว่าเขายังมีชีพจรอยู่ พวกเราจึงช่วยกันหิ้วตัวเขาขึ้นเปลสนาม"

# game/scripts/History/PrincipalStory/Prologo.rpy:109
translate english Prologo_b9e73fcc:

    # d "Con la ayuda del conocimiento medicinal de mi madre..."
    d "ด้วยความช่วยเหลือจากความรู้เรื่องการแพทย์ของแม่ฉัน"

# game/scripts/History/PrincipalStory/Prologo.rpy:120
translate english Prologo_ac54ed3a:

    # d "Pudo recobrar la consciencia"
    d "ในที่สุดเขาก็ได้สติฟื้นคืนขึ้นมา"

# game/scripts/History/PrincipalStory/Prologo.rpy:121
translate english Prologo_adf8d93a:

    # d "Este se mostró confundido y aterrado ante nuestra presencia"
    d "เด็กคนนี้ทั้งสับสนและหวาดกลัวพวกเราที่มีท่าทีคุกคาม"

# game/scripts/History/PrincipalStory/Prologo.rpy:122
translate english Prologo_f6a31f01:

    # d "Pero el Hokage logró calmarlo, diciéndole que nadie iba a lastimarlo"
    d "แต่ท่านโฮคาเงะก็สามารถเกลี้ยกล่อมให้เขาใจเย็นลงได้ โดยบอกว่าไม่มีใครคิดจะทำร้ายเขาหรอกนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:123
translate english Prologo_f7aa6dc0:

    # d "Este levantó su cabeza... Dándonos a todos una no muy grata sorpresa..."
    d "เขาเงยหน้าขึ้น... และนั่นก็ทำให้พวกเราทุกคนต้องประหลาดใจแบบไม่ค่อยน่ารื่นรมย์เท่าไหร่..."

# game/scripts/History/PrincipalStory/Prologo.rpy:135
translate english Prologo_2ded7504:

    # d "Al parecer, era portador de un {color=#e62348}Sharingan{/a} en uno de sus ojos"
    d "ดูเหมือนว่าดวงตาข้างหนึ่งของเขาจะเบิกเนตร{color=#e62348}วงแหวน{/a}เอาไว้"

# game/scripts/History/PrincipalStory/Prologo.rpy:136
translate english Prologo_a20cefa7_2:

    # "..."
    "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:137
translate english Prologo_e4f56b48:

    # d "Mi madre le preguntó cuál era su nombre"
    d "แม่ของฉันจึงลองถามชื่อของเขาดู"

# game/scripts/History/PrincipalStory/Prologo.rpy:139
translate english Prologo_6e58fd00:

    # d "Pero aparentemente no lo recordaba,puede que haya sido por la tortura que le hizo pasar Shin para sus experimentos"
    d "แต่ดูเหมือนว่าเขาจะจำไม่ได้ อาจจะเป็นผลมาจากการถูกชินทรมานระหว่างทำการทดลองก็เป็นได้"

# game/scripts/History/PrincipalStory/Prologo.rpy:142
translate english Prologo_1b148f43:

    # d "Mi padre aconsejó al Séptimo llevarlo a la aldea para interrogarlo y saber si decía la verdad"
    d "พ่อของฉันแนะนำให้ท่านรุ่นที่ 7 พาตัวเขากลับหมู่บ้านเพื่อสอบปากคำและดูว่าเขาพูดความจริงหรือเปล่า"

# game/scripts/History/PrincipalStory/Prologo.rpy:143
translate english Prologo_12759afe:

    # d "Cosa que al final pasó, pero no fue de gran ayuda"
    d "ซึ่งสุดท้ายก็ทำแบบนั้นแหละ แต่ก็ไม่ได้ช่วยอะไรมากนัก"

# game/scripts/History/PrincipalStory/Prologo.rpy:144
translate english Prologo_cc19cf4a:

    # d "Luego fue llevado al hospital, dónde fue diagnosticado con amnesia"
    d "จากนั้นเขาก็ถูกส่งตัวไปที่โรงพยาบาล ซึ่งแพทย์วินิจฉัยว่าเขามีอาการสูญเสียความทรงจำ"

# game/scripts/History/PrincipalStory/Prologo.rpy:145
translate english Prologo_b581b31d:

    # d "Esto ocurriendo tal vez por todo el maltrato que recibió por parte de Shin"
    d "บางทีนี่อาจจะเป็นเพราะการปฏิบัติอันโหดร้ายทั้งหมดที่เขาได้รับมาจากชินก็เป็นได้"

# game/scripts/History/PrincipalStory/Prologo.rpy:146
translate english Prologo_7499a3dd:

    # d "Luego de eso querían mandarlo al orfanato junto con los clones de Shin"
    d "หลังจากนั้นพวกเขาตั้งใจจะส่งตัวเขาไปที่สถานเลี้ยงเด็กกำพร้าพร้อมกับพวกพ้องร่างโคลนของชิน"

# game/scripts/History/PrincipalStory/Prologo.rpy:147
translate english Prologo_1aedb2fe:

    # d "Pero este les tenía tanto miedo, que al final el Séptimo le asignó un alojamiento en la aldea"
    d "แต่เขากลัวพวกนั้นเอามากๆ จนสุดท้ายท่านรุ่นที่ 7 เลยจัดสรรที่พักอาศัยในหมู่บ้านให้เขาแทน"

# game/scripts/History/PrincipalStory/Prologo.rpy:148
translate english Prologo_7ed0505c:

    # d "El Séptimo también me pidió que lo visitara de vez en cuando, para que no estuviera sólo"
    d "ท่านรุ่นที่ 7 ยังขอร้องให้ฉันแวะไปเยี่ยมเขาเป็นครั้งคราวด้วย เพื่อที่เขาจะได้ไม่รู้สึกเหงา"

# game/scripts/History/PrincipalStory/Prologo.rpy:149
translate english Prologo_cb4ff6ea:

    # d "Parecía identificarse con él..."
    d "ท่านดูจะรู้สึกคุ้นเคยและเข้าใจตัวตนของอีกฝ่ายเป็นพิเศษ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:158
translate english Prologo_71b3a7c7:

    # d "Por lo que me terminé volviendo cercana a él"
    d "สุดท้ายฉันก็เลยได้สนิทสนมกับเขาไปด้วย"

# game/scripts/History/PrincipalStory/Prologo.rpy:159
translate english Prologo_968b2e9f:

    # d "En un principio era algo tímido y desconfiado"
    d "ช่วงแรกๆ เขาค่อนข้างขี้อายและไม่ค่อยไว้วางใจใครเท่าไหร่"

# game/scripts/History/PrincipalStory/Prologo.rpy:160
translate english Prologo_f1e9c1af:

    # d "Pero una vez nos ganamos su confianza resultó ser muy amable"
    d "แต่พอพวกเราเริ่มชนะใจเขาได้ เขาก็กลายเป็นคนที่ดีมากๆ เลยล่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:171
translate english Prologo_98343b45:

    # d "Hablábamos de muchas cosas, incluso lo invitaba de vez en cuando a cenar junto a mi familia"
    d "พวกเราคุยกันหลายเรื่องเลย ฉันยังเคยชวนเขามาทานมื้อค่ำกับครอบครัวของฉันเป็นครั้งคราวด้วยนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:172
translate english Prologo_ed62f952:

    # d "Se volvió muy cercano a nosotras"
    d "เขาเริ่มสนิทชิดเชื้อกับครอบครัวของเรามาก"

# game/scripts/History/PrincipalStory/Prologo.rpy:174
translate english Prologo_a20cefa7_3:

    # "..."
    "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:175
translate english Prologo_7b491901:

    # d "Un día lo encontré un poco triste, y le pregunté que le pasaba"
    d "มีอยู่ันหนึ่งฉันเห็นเขาดูเศร้าๆ ไป ก็เลยลองถามดูว่าเป็นอะไรหรือเปล่า"

# game/scripts/History/PrincipalStory/Prologo.rpy:176
translate english Prologo_c4adc4cf:

    # d "Me preguntó si el me parecía raro, ya que no tenía nombre"
    d "เขาถามฉันว่าเขาดูแปลกไหมที่ตัวเองไม่มีชื่อเรียกเหมือนคนอื่น"

# game/scripts/History/PrincipalStory/Prologo.rpy:177
translate english Prologo_fe6cc85d:

    # d "Pensé que sería triste no tenerlo, así que lo animé"
    d "ฉันคิดว่าการไม่มีชื่อเลยมันคงเป็นเรื่องที่น่าเศร้าสินะ ก็เลยช่วยพูดให้กำลังใจเขาไป"

# game/scripts/History/PrincipalStory/Prologo.rpy:178
translate english Prologo_e2da4a50:

    # d "Y le dije que él podía elegir su nombre"
    d "แล้วฉันก็บอกเขาว่า เขาสามารถเลือกตั้งชื่อให้ตัวเองได้เลยนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:179
translate english Prologo_7a9c4c37:

    # d "Él se animó y estuvo pensando en muchos nombres"
    d "เขาตื่นเต้นใหญ่เลยแถมยังนั่งคิดชื่อตั้งมากมาย"

# game/scripts/History/PrincipalStory/Prologo.rpy:180
translate english Prologo_4db4d23d:

    # d "Hasta que por fin lo eligió"
    d "จนในที่สุดเขาก็เลือกได้ชื่อหนึ่งออกมา"

# game/scripts/History/PrincipalStory/Prologo.rpy:186
translate english character_name_selected_e29c66a4:

    # "Por favor coloca un nombre"
    "กรุณาใส่ชื่อ"

# game/scripts/History/PrincipalStory/Prologo.rpy:191
translate english character_name_selected_646e693f:

    # d "Le pregunté porqué ese nombre..."
    d "ฉันเลยลองถามเขาดูว่าทำไมถึงเลือกชื่อนั้น..."

# game/scripts/History/PrincipalStory/Prologo.rpy:196
translate english character_name_selected_ee96b4c2:

    # d "Mostrando también un gran interés por ser un ninja"
    d "แถมเขายังแสดงความสนใจอย่างมากที่จะเป็นนินจาด้วย"

# game/scripts/History/PrincipalStory/Prologo.rpy:197
translate english character_name_selected_b0ceada0:

    # d "Le recomendé que se esforzara para que pudiera presentar el examen en la academia ninja"
    d "ฉันเลยแนะนำให้เขาพยายามเข้า จะได้ไปสอบเข้าสถาบันนินจาได้"

# game/scripts/History/PrincipalStory/Prologo.rpy:198
translate english character_name_selected_d05ac47d:

    # d "Pidiéndome ayuda para entrenar, le terminé enseñando lo necesario para que aprobara el examen"
    d "เขาขอให้ฉันช่วยฝึกฝนให้อย่างจริงจัง สุดท้ายฉันเลยต้องคอยสอนพื้นฐานที่จำเป็นในการสอบผ่านให้กับเขา"

# game/scripts/History/PrincipalStory/Prologo.rpy:207
translate english character_name_selected_44857b83:

    # d "Mostrando ya no solo interés, sino también potencial para ser un ninja"
    d "เขาไม่ได้แสดงแค่ความสนใจเท่านั้น แต่ยังมีแววและศักยภาพที่จะเป็นนินจาได้ด้วย"

# game/scripts/History/PrincipalStory/Prologo.rpy:208
translate english character_name_selected_467f2151:

    # d "Al final aprobó el examen y se convirtió en Genin"
    d "และในที่สุดเขาก็สอบผ่านจนได้เป็นเกะนิน"

# game/scripts/History/PrincipalStory/Prologo.rpy:209
translate english character_name_selected_bce214e2:

    # d "En dónde le fue asignado un equipo"
    d "ซึ่งเขาถูกจัดให้อยู่ในทีมเดียวกัน"

# game/scripts/History/PrincipalStory/Prologo.rpy:220
translate english character_name_selected_434b3711:

    # d "Su Sensei {color=#f3c271}Zubon{/a}, y sus dos compañeros, {color=#f3c271}Hideo{/a} y {color=#f3c271}Yuna{/a}"
    d "โดยมีอาจารย์ประจำทีมคือ {color=#f3c271}ซูบง{/a} และเพื่อนร่วมทีมอีกสองคนคือ {color=#f3c271}ฮิเดโอะ{/a} กับ {color=#f3c271}ยูนะ{/a}"

# game/scripts/History/PrincipalStory/Prologo.rpy:221
translate english character_name_selected_b66a3208:

    # d "Poco a poco terminó adaptándose y volviéndose uno más de la aldea"
    d "ทีละเล็กทีละน้อย เขาก็ปรับตัวจนกลายเป็นส่วนหนึ่งของหมู่บ้านเราไปในที่สุด"

# game/scripts/History/PrincipalStory/Prologo.rpy:223
translate english character_name_selected_a20cefa7_1:

    # "..."
    "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:224
translate english character_name_selected_7cec982c:

    # d "Hoy en día..."
    d "ในปัจจุบันนี้..."

# game/scripts/History/PrincipalStory/Prologo.rpy:227
translate english character_name_selected_567169e8:

    # d "Es todo un hombre, no es para nada ese chico tímido que fue alguna vez, o eso parece"
    d "เขาเติบโตเป็นชายหนุ่มเต็มตัวแล้ว ไม่ใช่เด็กผู้ชายขี้อายคนเดิมในอดีตอีกต่อไป... หรืออย่างน้อยก็ดูเหมือนจะเป็นแบบนั้นนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:228
translate english character_name_selected_1db2c194:

    # d "Iré a visitarlo para charlar con él, como en los viejos tiempos"
    d "ฉันจะไปเยี่ยมเขาสักหน่อย ไปนั่งคุยกันเหมือนวันวานเก่าๆ"

# game/scripts/History/PrincipalStory/Prologo.rpy:229
translate english character_name_selected_100928e2:

    # d "Espero no esté ocupado"
    d "หวังว่าเขาคงไม่ยุ่งอยู่นะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:232
translate english character_name_selected_a20cefa7_2:

    # "..."
    "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:233
translate english character_name_selected_0fd4d656:

    # "......"
    "......"

# game/scripts/History/PrincipalStory/Prologo.rpy:234
translate english character_name_selected_e1eb59fe:

    # n "-EN LA ACTUALIDAD-"
    n "-ปัจจุบัน-"

# game/scripts/History/PrincipalStory/Prologo.rpy:235
translate english character_name_selected_a20cefa7_3:

    # "..."
    "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:236
translate english character_name_selected_93cf0365:

    # mn "Oh..."
    mn "อืม..."

# game/scripts/History/PrincipalStory/Prologo.rpy:240
translate english character_name_selected_ee0ace93:

    # mn "Vaya.."
    mn "ว้าว..."

# game/scripts/History/PrincipalStory/Prologo.rpy:241
translate english character_name_selected_38a5d262:

    # mn "Con que ella hizo eso..."
    mn "งั้นเธอว์ก็ทำแบบนั้นเหรอเนี่ย..."

# game/scripts/History/PrincipalStory/Prologo.rpy:242
translate english character_name_selected_81f7ca0b:

    # mn "¿Y apretó su...?"
    mn "แถมยังบีบตรงนั้นของเธอ...?"

# game/scripts/History/PrincipalStory/Prologo.rpy:243
translate english character_name_selected_79242173:

    # mn "Me pregunto que se habría sentido hacer eso... Lástima que no pude haberlo intentado cuando tenía oportunidad..."
    mn "ชักสงสัยจังแฮะว่าถ้าทำแบบนั้นมันจะรู้สึกยังไง... น่าเสียดายชะมัดที่ตอนมีโอกาสดันไม่ได้ลองดู..."

# game/scripts/History/PrincipalStory/Prologo.rpy:246
translate english character_name_selected_b919c54d:

    # "{b}Alguien toca la puerta{/b}"
    "{b}มีเสียงเคาะประตู@{/b}"

# game/scripts/History/PrincipalStory/Prologo.rpy:247
translate english character_name_selected_f023f1d7:

    # mn "¡¿Eh, q-quién es?!"
    mn "หา ใครมาเคาะประตูเอาป่านนี้เนี่ย?!"

# game/scripts/History/PrincipalStory/Prologo.rpy:248
translate english character_name_selected_a5d7cd39:

    # sr "Soy yo, Sarada"
    sr "ฉันเอง ซาราดะจ้ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:249
translate english character_name_selected_88e122cb:

    # mn "(Mierda...)"
    mn "(ซวยแล้ว...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:250
translate english character_name_selected_1ba8a0da:

    # sr "¿Estás ocupado?"
    sr "ยุ่งอยู่หรือเปล่า?"

# game/scripts/History/PrincipalStory/Prologo.rpy:251
translate english character_name_selected_c147e2c2:

    # mn "Eh... ¡N-No!, voy en un momento..."
    mn "เอ่อ... ม-ไม่ยุ่ง! เดี๋ยวฉันออกไปเปิดให้เดี๋ยวนี้แหละ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:252
translate english character_name_selected_abfc44c0:

    # n "[MN] se cambió y escondió el libro lo más rápido posible"
    n "[MN] เปลี่ยนเสื้อผ้าและซ่อนหนังสืออย่างรวดเร็วที่สุด"

# game/scripts/History/PrincipalStory/Prologo.rpy:259
translate english character_name_selected_e1590592:

    # mn "Listo... ¡Ahora abro!"
    mn "เสร็จแล้ว... จะเปิดประตูแล้วนะ!"

# game/scripts/History/PrincipalStory/Prologo.rpy:263
translate english character_name_selected_94810809:

    # mn "(Joder... Casi me atrapa...)"
    mn "(ให้ตายสิ... เกือบไปแล้วมั้ยล่ะ...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:269
translate english character_name_selected_4bdce36e:

    # n "[MN] abre la puerta, dejando entrar a Sarada"
    n "[MN] เปิดประตูแล้วปล่อยให้ซาราดะเดินเข้ามา"

# game/scripts/History/PrincipalStory/Prologo.rpy:275
translate english character_name_selected_807610b5:

    # mn "Hola, ¿Qué tal, Sarada? Disculpa que me haya tardado..."
    mn "อ้าว ซาราดะ เป็นไงมาไงเนี่ย? โทษทีนะที่ให้รอซะนาน..."

# game/scripts/History/PrincipalStory/Prologo.rpy:278
translate english character_name_selected_eb2870c4:

    # sr "No te preocupes por eso"
    sr "ไม่ต้องคิดมากหรอกจ้ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:281
translate english character_name_selected_ddc0d9a0:

    # mn "¿A qué debo esta agradable visita?"
    mn "ลมอะไรหอบเธอมาถึงนี่ได้ล่ะเนี่ย?"

# game/scripts/History/PrincipalStory/Prologo.rpy:284
translate english character_name_selected_b5b878c7:

    # sr "Acabo de llegar de una misión, y quería pasar a saludarte"
    sr "ฉันเพิ่งกลับมาจากทำภารกิจน่ะ เลยอยากแวะมาทักทายสักหน่อย"

# game/scripts/History/PrincipalStory/Prologo.rpy:287
translate english character_name_selected_177faa85:

    # mn "Genial, ¿Y cómo te fue?, ¿No te ocurrió nada?"
    mn "เยี่ยมเลย แล้วเป็นไงบ้าง? ไม่มีอะไรแย่เกิดขึ้นกับเธอใช่ไหม?"

# game/scripts/History/PrincipalStory/Prologo.rpy:290
translate english character_name_selected_a251872f:

    # sr "No fue nada que no pudiera manejar"
    sr "ก็ไม่มีอะไรที่ฉันรับมือไม่ไหวหรอกนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:293
translate english character_name_selected_96a52d7d:

    # mn "Bueno, eso es evidente, tú eres increible"
    mn "แหงอยู่แล้ว ก็เธอน่ะเก่งจะตายนี่นา"

# game/scripts/History/PrincipalStory/Prologo.rpy:296
translate english character_name_selected_0e850a53:

    # sr "Jeje, no es para tanto"
    sr "คิกคิก เรื่องแค่นี้เองน่า"

# game/scripts/History/PrincipalStory/Prologo.rpy:298
translate english character_name_selected_0ffb8736:

    # sr "Bueno..."
    sr "ว่าแต่..."

# game/scripts/History/PrincipalStory/Prologo.rpy:300
translate english character_name_selected_29e42389:

    # sr "¿Qué tal te va a tí?"
    sr "ช่วงนี้เป็นยังไงบ้างล่ะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:302
translate english character_name_selected_0611a956:

    # sr "¿Sigues haciendo misiones de rango D?"
    sr "ยังรับทำภารกิจระดับ D อยู่หรือเปล่า?"

# game/scripts/History/PrincipalStory/Prologo.rpy:305
translate english character_name_selected_fe65b44b:

    # mn "Si... De algo tengo que comer jaja"
    mn "อือ... ก็ต้องหาเงินมากินมาใช้บ้างล่ะนะ ฮ่าๆ"

# game/scripts/History/PrincipalStory/Prologo.rpy:308
translate english character_name_selected_cd827254:

    # sr "En eso tienes razón... Aunque si solo lo haces por dinero..."
    sr "นั่นก็จริง... ถึงทำแค่วิธีนั้นเพื่อหาเงินก็เถอะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:310
translate english character_name_selected_9f44fd93:

    # sr "También podrías ayudar a otras personas en la aldea a cambio de algo de dinero"
    sr "เธอน่าจะลองไปช่วยงานคนอื่นในหมู่บ้านเพื่อแลกกับเงินบ้างก็ได้นะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:313
translate english character_name_selected_8b287ff9:

    # mn "No es mala idea, así puedo matar un poco más el tiempo a la espera de una misión de mayor rango"
    mn "ก็ไม่เลวนะ ถือซะว่าฆ่าเวลาตอนรอภารกิจระดับสูงกว่านี้ไปด้วยในตัว"

# game/scripts/History/PrincipalStory/Prologo.rpy:316
translate english character_name_selected_d13e4d5e:

    # sr "Me alegra que lo tengas en cuenta"
    sr "ดีใจนะที่เธอคิดแบบนั้นน่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:319
translate english character_name_selected_5065d38d:

    # mn "Por cierto ¿Como está tu madre?"
    mn "ว่าแต่ แม่ของเธอเป็นยังไงบ้างล่ะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:322
translate english character_name_selected_ac9f701f:

    # sr "¿Por qué no vas a verla por ti mismo?, seguro le daría gusto verte"
    sr "ทำไมไม่ลองแวะไปหาท่านด้วยตัวเองดูล่ะ? ท่านต้องดีใจแน่เลยที่ได้เจอเธออีกครั้ง"

# game/scripts/History/PrincipalStory/Prologo.rpy:325
translate english character_name_selected_68b077df:

    # mn "Sí, tienes razón... Tal vez lo haga luego"
    mn "อืม เธอก พูดถูก... ไว้ว่างๆ ค่อยแวะไปก็แล้วกัน"

# game/scripts/History/PrincipalStory/Prologo.rpy:328
translate english character_name_selected_349f601c:

    # sr "¿Estás bien? Te noto un poco agitado"
    sr "เป็นอะไรหรือเปล่า? ดูลุกลี้ลุกลนพิกลนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:332
translate english character_name_selected_83a06f2f:

    # mn "(¿Se dió cuenta?)"
    mn "(ยัยนี่สังเกตเห็นเหรอเนี่ย?)"

# game/scripts/History/PrincipalStory/Prologo.rpy:335
translate english character_name_selected_d3dc9519:

    # mn "Oh, sí, sí.. es que estaba haciendo un poco de ejercicio aquí..."
    mn "อ๋อ ใช่ๆ... พอดีฉันกำลังออกกำลังกายอยู่นิดหน่อยน่ะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:338
translate english character_name_selected_ccd44fc5:

    # sr "Ya veo... Así que aún te sigues manteniendo en forma"
    sr "งั้นเหรอ... แสดงว่าเธอยยังรักษาร่างกายให้ฟิตอยู่สินะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:341
translate english character_name_selected_0e9b1d9f:

    # mn "En forma... Sí..."
    mn "ฟิต... ใช่แล้ว..."

# game/scripts/History/PrincipalStory/Prologo.rpy:343
translate english character_name_selected_cd034fa5:

    # mn "Por ahora, ¿Qué tal si vamos a comer a Ichiraku? Para ponernos al día"
    mn "งั้นตอนนี้ เราไปหาอะไรกินที่อิจิราคุดีไหม? ไปนั่งคุยอัปเดตเรื่องต่างๆ กันหน่อย"

# game/scripts/History/PrincipalStory/Prologo.rpy:346
translate english character_name_selected_107f3510:

    # sr "Bien, me gusta la idea"
    sr "เอาสิ ฉันชอบไอเดียนี้เหมือนกัน"

# game/scripts/History/PrincipalStory/Prologo.rpy:348
translate english character_name_selected_f29bae33:

    # sr "Tengo un poco de tiempo libre, así que no hay problema"
    sr "ฉันพอมีเวลาว่างอยู่ ไม่มีปัญหาอยู่แล้วล่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:351
translate english character_name_selected_6ba3d00d:

    # mn "Bien, entonces lo mejor será irnos ya, solo dame un momento para estar listo"
    mn "งั้นเราไปกันตอนนี้เลยดีกว่า รอแป๊บเดียวนะ ขอฉันเตรียมตัวสักครู่"

# game/scripts/History/PrincipalStory/Prologo.rpy:355
translate english character_name_selected_1e764614:

    # sr "De acuerdo"
    sr "ได้จ้ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:357
translate english character_name_selected_a131e229:

    # sr "Te espero afuera miestras"
    sr "งั้นฉันไปรอข้างนอกก่อนนะ ระหว่างนี้"

# game/scripts/History/PrincipalStory/Prologo.rpy:360
translate english character_name_selected_86ce38fd:

    # n "Sarada sale del departamento"
    n "ซาราดะเดินออกจากห้องพักไป"

# game/scripts/History/PrincipalStory/Prologo.rpy:362
translate english character_name_selected_34cb155b:

    # mn "Joder... Eso estuvo cerca"
    mn "ให้ตายสิ... เกือบไปแล้วไหมล่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:364
translate english character_name_selected_ceb8769e:

    # mn "Un poco más y me descubre..."
    mn "อีกนิดเดียวก็เกือบโดนจับได้แล้วเชียว..."

# game/scripts/History/PrincipalStory/Prologo.rpy:366
translate english character_name_selected_50f37ce0:

    # mn "Bueno, me vestiré rápidamente, no quiero hacerla esperar"
    mn "เอาล่ะ รีบแต่งตัวดีกว่า ไม่อยากปล่อยให้เธอรอนาน"

# game/scripts/History/PrincipalStory/Prologo.rpy:371
translate english character_name_selected_eebdf2ba:

    # n "[MN] se prepara y sale de casa junto a Sarada, para ambos dirigirse a Ichiraku Ramen"
    n "[MN] เตรียมตัวเสร็จแล้วก็ออกจากบ้านไปกับซาราดะ ทั้งคู่มุ่งหน้าไปยังร้านราเม็งอิจิราคุ"

# game/scripts/History/PrincipalStory/Prologo.rpy:388
translate english character_name_selected_d2f3f798:

    # sr "Mmm... El ramen de Ichiraku Ramen es el mejor"
    sr "อื้ม... ราเม็งของร้านอิจิราคุเนี่ยอร่อยที่สุดเลย"

# game/scripts/History/PrincipalStory/Prologo.rpy:389
translate english character_name_selected_7ab85ff6:

    # mn "Ooh si..."
    mn "นั่นสิ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:391
translate english character_name_selected_f2931cee:

    # mn "Y que lo digas, desde que llegué a la aldea este siempre ha sido mi restaurante favorito"
    mn "จริงด้วย ตั้งแต่ฉันมาที่หมู่บ้านนี้ ที่นี่ก็เป็นร้านโปรดของฉันมาตลอดเลยล่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:395
translate english character_name_selected_1b558f35:

    # sr "Eso pude notar luego de comerte tantos tazones"
    sr "สังเกตจากที่ซัดไปซะหลายชามนั่นแหละนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:398
translate english character_name_selected_5ed6db3d:

    # mn "Jajaja, es que es inevitable no comer tantos tazones de Ramen"
    mn "ฮ่าๆๆ ก็มันอดใจไม่ให้กินราเม็งหลายๆ ชามได้ซะที่ไหนล่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:400
translate english character_name_selected_50f2a33c:

    # mn "Uff.. estoy que reviento..."
    mn "อื๋อ... แน่นท้องจะตายอยู่แล้ว..."

# game/scripts/History/PrincipalStory/Prologo.rpy:402
translate english character_name_selected_301def01:

    # sr "Jajaja..."
    sr "ฮ่าๆๆ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:404
translate english character_name_selected_1b9fc9b7:

    # mn "Tengo que salir más seguido contigo, realmente disfruto mucho tu compañía"
    mn "ฉันน่าจะชวนเธอออกมาเที่ยวด้วยกันบ่อยๆ นะเนี่ย อยู่กับเธอแล้วสนุกจริงๆ เลย"

# game/scripts/History/PrincipalStory/Prologo.rpy:407
translate english character_name_selected_2ec51f55:

    # sr "El sentimiento es mutuo"
    sr "ฉันก็รู้สึกเหมือนกันจ่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:425
translate english character_name_selected_8b54f21e:

    # sr "Y... Quisiera quedarme un poco más, pero ya tengo que irme"
    sr "งั้น... ฉันอยากจะอยู่ต่ออีกสักหน่อยนะ แต่ต้องไปแล้วล่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:435
translate english character_name_selected_62868ee4:

    # mn "Está bien, fue un gusto haber pasado el rato contigo"
    mn "อื้ม ดีใจที่ได้มาเที่ยวด้วยกันนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:438
translate english character_name_selected_136b1983:

    # sr "Igualmente"
    sr "เช่นกันจ่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:441
translate english character_name_selected_dfdab6e6:

    # sr "Hasta luego"
    sr "ไว้เจอกันนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:444
translate english character_name_selected_f9857bc1:

    # n "Sarada se despide con una sonrisa"
    n "ซาราดะกล่าวลาพร้อมกับรอยยิ้ม"

# game/scripts/History/PrincipalStory/Prologo.rpy:447
translate english character_name_selected_201d9475:

    # mn "Es una buena amiga..."
    mn "เป็นเพื่อนที่ดีจริงๆ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:449
translate english character_name_selected_10365187:

    # ay "Vaya... Así que le tienes el ojo encima..."
    ay "โฮห... เล็งยัยนั่นไว้สินะเนี่ย..."

# game/scripts/History/PrincipalStory/Prologo.rpy:450
translate english character_name_selected_a5eb1bf5:

    # mn "¿Mmm?"
    mn "หืมน์?"

# game/scripts/History/PrincipalStory/Prologo.rpy:481
translate english character_name_selected_f6bae0e8:

    # mn "¿Yo?"
    mn "ฉันเนี่ยนะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:484
translate english character_name_selected_6f602591:

    # ay "Sí, a Sarada"
    ay "ใช่ ก็ซาราดะไงล่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:487
translate english character_name_selected_93aa89cd:

    # mn "¿Qué? Naaah..."
    mn "หา? เปล่าซะหน่อย..."

# game/scripts/History/PrincipalStory/Prologo.rpy:489
translate english character_name_selected_34de67b4:

    # mn "Sarada y yo solo somos... Amigos"
    mn "ฉันกับซาราดะเป็นแค่... เพื่อนกัน"

# game/scripts/History/PrincipalStory/Prologo.rpy:492
translate english character_name_selected_07a76f54:

    # ay "¿Y eso qué tiene? Ese es el punto de partida..."
    ay "แล้วมันเสียหายตรงไหนล่ะ? นั่นมันก็แค่จุดเริ่มต้น..."

# game/scripts/History/PrincipalStory/Prologo.rpy:494
translate english character_name_selected_6a65ea56:

    # ay "Sé honesto conmigo, ¿Después de tantos años no sientes nada más que amistad por ella?"
    ay "พูดความจริงกับฉันมาซิ รู้จักกันมาตั้งหลายปี ไม่เคยรู้สึกอะไรเกินเพื่อนเลยจริงดิ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:497
translate english character_name_selected_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:499
translate english character_name_selected_3e91a61d:

    # mn "T-Tal vez... No lo sé..."
    mn "อ-อาจจะ... ฉันก็ไม่รู้เหมือนกัน..."

# game/scripts/History/PrincipalStory/Prologo.rpy:502
translate english character_name_selected_d267b7ff:

    # ay "¡Lo sabía!"
    ay "รู้อยู่แล้วเชียว!"

# game/scripts/History/PrincipalStory/Prologo.rpy:505
translate english character_name_selected_22f21fed:

    # mn "Oye, dije -Tal vez- realmente no estoy seguro..."
    mn "เดี๋ยวสิ ฉันบอกว่า -อาจจะ- ต่างหาก ยังไม่แน่ใจสักหน่อย..."

# game/scripts/History/PrincipalStory/Prologo.rpy:508
translate english character_name_selected_0cbdcd47:

    # ay "Entiendo, entiendo... Aún indeciso jeje"
    ay "เข้าใจแล้วๆ... ยังลังเลอยู่สินะเนี่ย ฮิฮิ"

# game/scripts/History/PrincipalStory/Prologo.rpy:510
translate english character_name_selected_5a996065:

    # ay "Ella ha crecido mucho también eh, seguro que ya se fija un poco más en los chicos"
    ay "แถมพักนี้เธอก็โตเป็นสาวขึ้นเยอะเลยด้วยนะ ฉันพนันได้เลยว่าช่วงนี้เธอต้องเริ่มสนใจพวกผู้ชายขึ้นมาบ้างแล้วแหละ"

# game/scripts/History/PrincipalStory/Prologo.rpy:512
translate english character_name_selected_09f8c195:

    # ay "Yo digo que si te interesa puedes intentar mostrar tu lado seductor con ella"
    ay "ฉันว่านะ ถ้าสนใจล่ะก็ ลองโชว์เสน่ห์มัดใจเธอหน่อยเป็นไง"

# game/scripts/History/PrincipalStory/Prologo.rpy:515
translate english character_name_selected_ac594416:

    # mn "¿A qué te refieres con -Lado seductor-?"
    mn "โชว์เสน่ห์ที่ว่านี่หมายถึง... อะไรล่ะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:518
translate english character_name_selected_3c12014c:

    # ay "Conquístala, ya sabes... Coquetearle, darle regalos, incluso podrías invitarla a una cita..."
    ay "พิชิตใจเธอยังไงล่ะ รู้จักไหม... หยอดคำหวานใส่ หาของขวัญให้ หรือจะชวนเธอไปเดทก็ได้นะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:523
translate english character_name_selected_8b260cb8:

    # mn "(No creo que Sarada sea fácil de conquistar... O si yo sea su tipo...)"
    mn "(ฉันว่าซาราดะไม่ได้จีบติดง่ายๆ ขนาดนั้นหรอกมั้ง... หรือฉันจะไม่ใช่สเปกเธอเลยวะเนี่ย...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:526
translate english character_name_selected_c485fb29:

    # mn "Ahh, no estoy tan seguro si Sarada sea el tipo de chica que le gustan esas cosas..."
    mn "อ่า ฉันไม่ค่อยแน่ใจเท่าไหร่หรอกนะว่าซาราดะจะเป็นผู้หญิงที่ชอบอะไรแบบนั้นน่ะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:528
translate english character_name_selected_00152c3f:

    # mn "Y si fuera el caso, yo tampoco es que sepa mucho sobre coquetear y esas cosas"
    mn "แล้วต่อให้ใช่ขึ้นมาจริงๆ ฉันก็ไม่ค่อยรู้เรื่องเกี่ยวกับการจีบสาวอะไรพวกนั้นด้วยสิ"

# game/scripts/History/PrincipalStory/Prologo.rpy:531
translate english character_name_selected_d3849f9e:

    # ay "Espera, ¿No tenías novia antes?, ¿Cómo la conquistaste a ella?"
    ay "เดี๋ยวนะ นายเคยมีแฟนมาก่อนไม่ใช่เหรอ? ไปจีบเขายังไงล่ะนั่น?"

# game/scripts/History/PrincipalStory/Prologo.rpy:534
translate english character_name_selected_6e9c342a:

    # mn "Pues, realmente ella me conquistó a mí"
    mn "ก็... พูดตามตรงเลยนะ คือฝ่ายนั้นเป็นคนเข้ามาจีบฉันเองต่างหากล่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:537
translate english character_name_selected_b6aa6c27:

    # mn "Tú ya sabes como era cuando llegué a la aldea, era bastante callado, y solo hablaba con Sarada"
    mn "ก็น่าจะรู้อยู่แล้วนี่ว่าตอนที่ฉันมาถึงหมู่บ้านใหม่ ๆ มันค่อนข้างเงียบเหงา แล้วฉันก็คุยอยู่กับแค่ซาราดะคนเดียว"

# game/scripts/History/PrincipalStory/Prologo.rpy:539
translate english character_name_selected_706784ee:

    # mn "Y no sé que vió en mí y empezó a acercarse"
    mn "แล้วก็ไม่รู้เหมือนกันว่าเธอเห็นอะไรในตัวฉัน ถึงได้เริ่มเข้ามาตีสนิทก่อน"

# game/scripts/History/PrincipalStory/Prologo.rpy:541
translate english character_name_selected_c89d177c:

    # mn "Pero actualmente estoy solo, terminé con ella hace un tiempo"
    mn "แต่ตอนนี้ฉันโสดแล้วล่ะ เพิ่งเลิกกับเธอไปได้สักพักแล้วด้วย"

# game/scripts/History/PrincipalStory/Prologo.rpy:543
translate english character_name_selected_a9f82d0e:

    # mn "Pero no, no sé como coquetear"
    mn "แต่เอาเถอะ ฉันไม่รู้วิธีจีบใครหรอกนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:546
translate english character_name_selected_7222e45a:

    # ay "Ya veo..."
    ay "งั้นเหรอ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:548
translate english character_name_selected_1579c39e:

    # ay "Pero descuida, tal vez yo... "
    ay "แต่ก็ไม่ต้องห่วงไปหรอก บางทีฉัน..."

# game/scripts/History/PrincipalStory/Prologo.rpy:553
translate english character_name_selected_430a9c1b:

    # ay "Tal vez... Yo pueda ayudarte un poco con eso, siempre y cuando estés de acuerdo..."
    ay "บางที... ฉันอาจจะช่วยนายเรื่องนั้นได้บ้างนะ ถ้าไม่ว่าอะไรล่ะก็นะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:556
translate english character_name_selected_6a7b1dfa:

    # mn "Mmm..."
    mn "อืม..."

# game/scripts/History/PrincipalStory/Prologo.rpy:559
translate english character_name_selected_01382cf3:

    # mn "Aún no sé si esté listo para otra relación"
    mn "ฉันไม่รู้เหมือนกันว่าตอนนี้ตัวเองพร้อมจะมีความรักครั้งใหม่หรือยัง"

# game/scripts/History/PrincipalStory/Prologo.rpy:561
translate english character_name_selected_feba7fa0:

    # mn "La última terminó mal"
    mn "ครั้งล่าสุดนี่จบไม่ค่อยสวยสักเท่าไหร่ด้วยสิ"

# game/scripts/History/PrincipalStory/Prologo.rpy:564
translate english character_name_selected_f9d3ffb2:

    # ay "[MN], ¿Cuánto tiempo llevas desde que terminaste con tu ex?"
    ay "[MN] เลิกกับแฟนเก่าไปนานแค่ไหนแล้วเนี่ย?"

# game/scripts/History/PrincipalStory/Prologo.rpy:566
translate english character_name_selected_6a7b1dfa_1:

    # mn "Mmm..."
    mn "อืม..."

# game/scripts/History/PrincipalStory/Prologo.rpy:568
translate english character_name_selected_babdbb8a:

    # mn "Creo que hace 2 meses"
    mn "น่าจะสักสองเดือนก่อนมั้ง"

# game/scripts/History/PrincipalStory/Prologo.rpy:571
translate english character_name_selected_838cc566:

    # ay "Entonces... ¿Estás solo hace 2 meses?"
    ay "งั้น... ก็นั่งเหงาคนเดียวมาสองเดือนแล้วเหรอ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:573
translate english character_name_selected_b8ee5397:

    # ay "¿Ella no te hace falta? Estuvieron juntos por mucho tiempo..."
    ay "ไม่คิดถึงเธอหน่อยเหรอ? คบกันตั้งนานแท้ๆ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:575
translate english character_name_selected_91bfea64:

    # ay "¿No te sientes solo?"
    ay "ไม่รู้สึกเหงาบ้างเลยรึไง?"

# game/scripts/History/PrincipalStory/Prologo.rpy:580
translate english character_name_selected_32462c4b_1:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:582
translate english character_name_selected_85caf454:

    # ay "Oh, lo siento, no quería meterme donde no debía"
    ay "อ๊ะ ขอโทษที ฉันไม่ได้ตั้งใจจะก้าวก่ายเรื่องส่วนตัวเกินไปหรอกนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:584
translate english character_name_selected_32462c4b_2:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:586
translate english character_name_selected_ed890103:

    # mn "No te preocupes... Ya no tiene importancia"
    mn "ไม่ต้องห่วง... ช่างมันเถอะ ตอนนี้มันไม่สำคัญอีกต่อไปแล้วล่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:589
translate english character_name_selected_dda069db:

    # mn "Y... Sobre lo de tu propuesta, lo tendré en mente"
    mn "แล้วก็... เรื่องที่เธอเสนอมา ฉันจะเก็บไปคิดดูแล้วกัน"

# game/scripts/History/PrincipalStory/Prologo.rpy:594
translate english character_name_selected_56affdda:

    # ay "Bueno, está bien, si cambias de parecer, aquí estaré"
    ay "งั้นก็ไม่เป็นไร ถ้าเกิดเปลี่ยนใจเมื่อไหร่ ฉันอยู่ตรงนี้นะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:598
translate english character_name_selected_a32aed55:

    # mn "Claro, nos vemos luego"
    mn "อ่าไว้เจอกัน"

# game/scripts/History/PrincipalStory/Prologo.rpy:602
translate english character_name_selected_845628dc:

    # ay "Hasta pronto"
    ay "แล้วเจอกันนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:605
translate english character_name_selected_4b5a5cb6:

    # n "[MN] sale de Ichiraku para volver a su casa"
    n "[MN] เดินออกจากร้านอิจิราคุเพื่อกลับบ้าน"

# game/scripts/History/PrincipalStory/Prologo.rpy:612
translate english character_name_selected_43a24f8c:

    # mn "Aaah... Al fin en casa..."
    mn "ฮ้า... ถึงบ้านสักที..."

# game/scripts/History/PrincipalStory/Prologo.rpy:614
translate english character_name_selected_32462c4b_3:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:616
translate english character_name_selected_a6f1f02d:

    # mn "Ayame hizo una pregunta muy rara hoy..."
    mn "วันนี้อายะเมะถามเรื่องแปลกพิลึกแฮะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:618
translate english character_name_selected_b60f1081:

    # mn "¿Por qué de la nada me preguntó por ella...?"
    mn "อยู่ดีๆ ทำไมถึงถามเรื่องเธอกับฉันขึ้นมาล่ะเนี่ย..."

# game/scripts/History/PrincipalStory/Prologo.rpy:620
translate english character_name_selected_32462c4b_4:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:627
translate english character_name_selected_159c52d8:

    # mn "(A decir verdad... Solía ser muy distinto de lo que soy ahora)"
    mn "(อันที่จริง... ฉันเมื่อก่อนกับตอนนี้ต่างกันลิบลับเลยนะ)"

# game/scripts/History/PrincipalStory/Prologo.rpy:628
translate english character_name_selected_89acbb69:

    # mn "(Era inexpresivo, callado, y muy raro)"
    mn "(ทั้งไร้อารมณ์ เงียบขรึม แล้วก็แปลกคนสุดๆ)"

# game/scripts/History/PrincipalStory/Prologo.rpy:630
translate english character_name_selected_c76f966b:

    # mn "(No sabía donde estaba, qué me había pasado... Ni quien era...)"
    mn "(ฉันไม่รู้ด้วยซ้ำว่าตัวเองอยู่ที่ไหน เกิดอะไรขึ้นกับตัวเอง... หรือแม้แต่ว่าตัวเองเป็นใคร...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:631
translate english character_name_selected_2cb14cca:

    # mn "(Incluso ahora no sé muchas cosas, como quién era, o de donde provengo)"
    mn "(จนถึงตอนนี้ก็ยังมีหลายเรื่องที่ไม่รู้ อย่างเช่นตัวตนที่แท้จริงของฉัน หรือว่าฉันมาจากไหนกันแน่)"

# game/scripts/History/PrincipalStory/Prologo.rpy:632
translate english character_name_selected_2aec188d:

    # mn "(Si tenía padres... O hermanos...)"
    mn "(ถ้าฉันมีพ่อแม่... หรือพี่น้องล่ะก็...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:633
translate english character_name_selected_85b77973:

    # mn "(...)"
    mn "(...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:634
translate english character_name_selected_e1f995c7:

    # mn "(Antes habían personas que me veían mal...)"
    mn "(เมื่อก่อนเคยมีคนดูถูกเหงียดหยามฉันอยู่บ่อยๆ...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:635
translate english character_name_selected_8a67c259:

    # mn "(Los únicos que me trataban bien, eran el Séptimo Hokage, Sarada y su Familia...)"
    mn "(คนกลุ่มเดียวที่ปฏิบัติต่อฉันอย่างดี ก็มีท่านโฮคาเงะรุ่นที่ 7, ซาราดะกับครอบครัวของเธอ...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:636
translate english character_name_selected_337f5eba:

    # mn "(Y ella...)"
    mn "(แล้วก็ผู้หญิงคนนั้น...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:640
translate english character_name_selected_c38f2216:

    # mn "Agh, no quiero pensar en ella"
    mn "โธ่เว้ย ไม่อยากจะนึกถึงเธอคนนั้นเลยให้ตายสิ"

# game/scripts/History/PrincipalStory/Prologo.rpy:642
translate english character_name_selected_85b77973_1:

    # mn "(...)"
    mn "(...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:644
translate english character_name_selected_00ed7ace:

    # mn "(Ayame me preguntó si me sentía solo)"
    mn "(อายะเมะถามฉันว่า รู้สึกเหงาบ้างไหมสินะ)"

# game/scripts/History/PrincipalStory/Prologo.rpy:645
translate english character_name_selected_85b77973_2:

    # mn "(...)"
    mn "(...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:647
translate english character_name_selected_c30643ca:

    # mn "(Y es un poco triste admitirlo... Pero sí...)"
    mn "(แล้วมันก็ค่อนข้างน่าเศร้าที่จะยอมรับ... แต่ก็นั่นแหละ...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:649
translate english character_name_selected_f3766c69:

    # mn "(Realmente si me siento solo a veces...)"
    mn "(บางครั้งฉันก็รู้สึกเหงาขึ้นมาจริงๆ นั่นแหละ...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:650
translate english character_name_selected_1d2f7d89:

    # mn "(Debido a eso, empecé a buscar una forma de entretenerme cuando estoy en casa)"
    mn "(เพราะเหตุผลนั้น ฉันเลยเริ่มมองหาวิธีสร้างความบันเทิงให้ตัวเองเวลาอยู่บ้าน)"

# game/scripts/History/PrincipalStory/Prologo.rpy:651
translate english character_name_selected_f22b047b:

    # mn "(Empecé a leer libros, creo que fue gracias a ellos que empecé a ser alguien de mente abierta y con ganas de experimentar muchas cosas)"
    mn "(ฉันเริ่มหันมาอ่านหนังสือ คิดว่าคงเป็นเพราะพวกมันนั่นแหละที่ทำให้ฉันกลายเป็นคนใจกว้างขึ้น และอยากออกไปสัมผัสประสบการณ์อะไรตั้งหลายอย่าง)"

# game/scripts/History/PrincipalStory/Prologo.rpy:653
translate english character_name_selected_24853412:

    # mn "(Leí muchos libros con historias, anécdotas y personalidades diferentes)"
    mn "(ฉันอ่านหนังสือมาหลายเล่มที่มีเรื่องราว เกร็ดเล็กเกร็ดน้อย และบุคลิกตัวละครที่แตกต่างกันไป)"

# game/scripts/History/PrincipalStory/Prologo.rpy:654
translate english character_name_selected_d1d23e02:

    # mn "(Las cuales me dieron muchos modelos a seguir y empecé a moldear mi personalidad para intentar ser diferente)"
    mn "(ซึ่งมันทำให้ฉันมีไอดอลในดวงใจหลายคน และเริ่มหล่อหลอมบุคลิกตัวเองให้พยายามดูแตกต่างออกไป)"

# game/scripts/History/PrincipalStory/Prologo.rpy:655
translate english character_name_selected_66ec6a1f:

    # mn "(Aunque ahora uno de esos libros está despertando un sentimiento que pocas veces había sentido antes)"
    mn "(ถึงแม้ว่าตอนนี้ หนึ่งในหนังสือพวกนั้นกำลังปลุกเร้าความรู้สึกที่ฉันแทบจะไม่เคยสัมผัสมาก่อนขึ้นมาซะแล้ว)"

# game/scripts/History/PrincipalStory/Prologo.rpy:661
translate english character_name_selected_af2ca843:

    # mn "¿Dónde fue que dejé ese libro?"
    mn "ฉันเอาหนังสือเล่มนั้นไปไว้ไหนนะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:665
translate english character_name_selected_e27f66fb:

    # mn "Oh, aquí está"
    mn "อ่า อยู่นี่เอง"

# game/scripts/History/PrincipalStory/Prologo.rpy:668
translate english character_name_selected_19f85071:

    # mn "Me llamó la atención que fuera para mayores de edad"
    mn "ฉันรู้สึกสะดุดตากับการที่มันเป็นหนังสือสำหรับผู้ใหญ่เนี่ยแหละ"

# game/scripts/History/PrincipalStory/Prologo.rpy:670
translate english character_name_selected_5c318c9b:

    # mn "Y desde que lo comencé a leer hizo que brotara en mi, una curiosidad por saber más sobre las mujeres y cómo relacionarse con ellas"
    mn "และนับตั้งแต่เริ่มอ่านมัน ความอยากรู้อยากเห็นเกี่ยวกับผู้หญิงและวิธีเข้าหาพวกเธอ... ก็เริ่มผุดขึ้นในใจฉัน"

# game/scripts/History/PrincipalStory/Prologo.rpy:672
translate english character_name_selected_aae05852:

    # mn "¿A eso se refería Ayame cuando dijo que Sarada probablemente comenzó a fijarse en los chicos?"
    mn "นั่นคือสิ่งที่อายะเมะหมายถึงตอนที่บอกว่าซาราดะเริ่มสนใจพวกผู้ชายแล้วงั้นเหรอ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:674
translate english character_name_selected_c49239f0:

    # mn "¿Le estará pasando lo mismo que a mí?"
    mn "เรื่องแบบเดียวกันกำลังเกิดขึ้นกับเธอยู่งั้นเหรอ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:678
translate english character_name_selected_bbfd2dca:

    # mn "¡!"
    mn "!"

# game/scripts/History/PrincipalStory/Prologo.rpy:680
translate english character_name_selected_8ef9f1fc:

    # mn "Mierda, se me puso dura de nuevo..."
    mn "ให้ตายสิ ของลับตื่นตัวขึ้นมาอีกแล้ว..."

# game/scripts/History/PrincipalStory/Prologo.rpy:682
translate english character_name_selected_440239a5:

    # mn "Bueno... Solo para que deje de estarlo debo de..."
    mn "ให้ตายสิ... ทางเดียวที่จะทำให้มันสงบลงได้ก็คือ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:684
translate english character_name_selected_e5f20f72:

    # mn "Sí... Seguiré leyendo un poco más..."
    mn "อืม... อ่านต่ออีกนิดดีกว่า..."

# game/scripts/History/PrincipalStory/Prologo.rpy:687
translate english character_name_selected_73449b9b:

    # n "Luego de masturbarse por leer un rato más el libro Icha-Icha, [MN] cae dormido"
    n "หลังจากสำเร็จความความใคร่พร้อมกับอ่านหนังสืออิจาะอิจะต่ออีกสักพัก [MN] ก็หลับไป"

# game/scripts/History/PrincipalStory/Prologo.rpy:694
translate english character_name_selected_befffd7a:

    # mn "Aaaah..."
    mn "อ่าาาห์..."

# game/scripts/History/PrincipalStory/Prologo.rpy:696
translate english character_name_selected_e962dc9b:

    # mn "Otro nuevo día"
    mn "วันใหม่เริ่มต้นขึ้นอีกแล้ว"

# game/scripts/History/PrincipalStory/Prologo.rpy:698
translate english character_name_selected_215f8ec4:

    # mn "Mmm, hoy no tengo planes"
    mn "อืม วันนี้ไม่มีแผนจะทำอะไรเลยแฮะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:700
translate english character_name_selected_10c818f8:

    # mn "Creo que hoy saldré un rato... tal vez visite a la señora Sakura..."
    mn "งั้นวันนี้ออกไปข้างนอกสักหน่อยดีกว่า... บางทีอาจจะแวะไปหาคุณซากุระ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:702
translate english character_name_selected_50674c2f:

    # mn "Sarada dijo que le daría gusto verme, y ya que tengo tiempo libre, puedo pasar a saludar"
    mn "ซาราดะบอกว่าเธอคงดีใจที่จะได้เจอฉัน แล้วในเมื่อฉันมีเวลาว่างพอดี งั้นแวะไปทักทายหน่อยดีกว่า"

# game/scripts/History/PrincipalStory/Prologo.rpy:704
translate english character_name_selected_e2d21dc4:

    # n "[MN] sale de su casa para ir a la residencia Uchiha"
    n "[MN] ออกจากบ้านเพื่อมุ่งหน้าไปยังบ้านตระกูลอุจิฮะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:711
translate english character_name_selected_7cb07a87:

    # mn "Ya tenía mucho tiempo sin ver a la señora Sakura"
    mn "ไม่ได้เจอคุณซากุระนานเลยแฮะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:713
translate english character_name_selected_4d7cad96:

    # mn "Últimamente no he tenido tiempo, me he estado esforzando bastante en los entrenamientos"
    mn "ช่วงนี้ฉันไม่ค่อยมีเวลาเลย มัวแต่ทุ่มเทฝึกซ้อมอย่างหนัก"

# game/scripts/History/PrincipalStory/Prologo.rpy:716
translate english character_name_selected_8be03bed:

    # mn "Bueno, es por aquí"
    mn "เอาล่ะ ไปทางนี้ดีกว่า"

# game/scripts/History/PrincipalStory/Prologo.rpy:718
translate english character_name_selected_74f63841:

    # n "[MN] llega a la residencia Uchiha y toca la puerta, pero nadie sale..."
    n "[MN] เดินทางมาถึงบ้านตระกูลอุจิฮะแล้วเคาะประตู แต่ไม่มีใครออกมาเปิด..."

# game/scripts/History/PrincipalStory/Prologo.rpy:720
translate english character_name_selected_7bc42ffc:

    # n "Pero se escucha un ruido extraño dentro de la casa"
    n "แต่กลับมีเสียงประหลาดดังออกมาจากข้างในบ้าน"

# game/scripts/History/PrincipalStory/Prologo.rpy:721
translate english character_name_selected_aa62df9a:

    # mn "¿Qué fue eso?"
    mn "เสียงอะไรน่ะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:722
translate english character_name_selected_82e820b5:

    # n "En vista que nadie abría y de que un ruido extraño se escuchó adentro de la casa, [MN] procede a abrir la puerta"
    n "เนื่องจากไม่มีใครขานรับแถมยังมีเสียงแปลกๆ ดังมาจากในบ้าน [MN] จึงตัดสินใจลองเปิดประตูเข้าไป"

# game/scripts/History/PrincipalStory/Prologo.rpy:725
translate english character_name_selected_7c5d0405:

    # mn "!!!"
    mn "!!!"

# game/scripts/History/PrincipalStory/Prologo.rpy:726
translate english character_name_selected_51f83752:

    # mn "¡Señorita Sakura, ¿S-Se encuentra bien?!"
    mn "คุณซากุระระ โ-โร่เป็นอะไรรึเปล่าครับเนี่ย?!"

# game/scripts/History/PrincipalStory/Prologo.rpy:727
translate english character_name_selected_6d8ea0fb:

    # sk "Zzz.. Sasuke..."
    sk "คร่อก... ซาสึเกะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:728
translate english character_name_selected_a7311aa0:

    # mn "Oh, solo está dormida..."
    mn "อ่า แค่หลับอยู่หรอกเหรอเนี่ย..."

# game/scripts/History/PrincipalStory/Prologo.rpy:729
translate english character_name_selected_cdbfe03c:

    # mn "¿Pasó toda la noche tomando sake?"
    mn "เธอซดเหล้าสาเกมาตลอดทั้งคืนเลยรึไงเนี่ย?"

# game/scripts/History/PrincipalStory/Prologo.rpy:730
translate english character_name_selected_58662278:

    # mn "Espera.. ¿Por qué está ella...?"
    mn "เดี๋ยวก่อน...ทำไมเธอถึง...?"

# game/scripts/History/PrincipalStory/Prologo.rpy:735
translate english character_name_selected_25b43eec:

    # mn "Casi sin ropa..."
    mn "แทบไม่ได้ใส่อะไรเลย..."

# game/scripts/History/PrincipalStory/Prologo.rpy:736
translate english character_name_selected_32462c4b_5:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:737
translate english character_name_selected_6bed7357:

    # mn "¿Así que este es el cuerpo... de una mujer adulta...?"
    mn "นี่น่ะเหรอ...เรือนร่างของหญิงสาวที่โตเป็นผู้ใหญ่แล้ว...?"

# game/scripts/History/PrincipalStory/Prologo.rpy:738
translate english character_name_selected_d5e62a6b:

    # mn "Es hermoso..."
    mn "งดงามจัง..."

# game/scripts/History/PrincipalStory/Prologo.rpy:739
translate english character_name_selected_ae014432:

    # mn "¿Qué tal si yo...?"
    mn "จะเป็นไรไหมถ้าฉันจะ...?"

# game/scripts/History/PrincipalStory/Prologo.rpy:743
translate english character_name_selected_1084f63a:

    # mn "E-Espera.. ¿Qué estoy diciendo...? ¿Qué cosas sucias estaba apunto de pensar?"
    mn "ด-เดี๋ยวก่อน... ฉันพูดอะไรออกไปเนี่ย...? เมื่อกี้ฉันกำลังจะคิดเรื่องลามกอะไรอยู่ฟะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:744
translate english character_name_selected_4f8efa4a:

    # mn "Ella es la madre de mi amiga... Simplemente debería de llevarla a su cama..."
    mn "เธอเป็นแม่ของเพื่อนฉันนะ... ฉันควรพาเธอนอนบนเตียงดีกว่า..."

# game/scripts/History/PrincipalStory/Prologo.rpy:748
translate english character_name_selected_e675a14c:

    # n "[MN] recoge a Sakura en sus brazos"
    n "[MN] อุ้มซากุระขึ้นมาไว้ในอ้อมแขน"

# game/scripts/History/PrincipalStory/Prologo.rpy:751
translate english character_name_selected_83e74f94:

    # n "Pero [MN] se tropieza con unas botellas de sake que habían en el piso..."
    n "แต่ [MN] ดันสะดุดขวดสาเกที่วางเกลื่อนอยู่บนพื้น..."

# game/scripts/History/PrincipalStory/Prologo.rpy:752
translate english character_name_selected_30ff1503:

    # mn "¡Mierda!"
    mn "เวรเอ๊ย!"

# game/scripts/History/PrincipalStory/Prologo.rpy:754
translate english character_name_selected_2b74cf8f:

    # n "Cayendo en los pechos de Sakura"
    n "ล้มทับหน้าอกของซากุระเข้าเต็มๆ"

# game/scripts/History/PrincipalStory/Prologo.rpy:755
translate english character_name_selected_32462c4b_6:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:756
translate english character_name_selected_3d3b06a9:

    # mn "Estas son..."
    mn "นี่มัน..."

# game/scripts/History/PrincipalStory/Prologo.rpy:758
translate english character_name_selected_65325467:

    # mn "(Se siente cálido...)"
    mn "(รู้สึกอบอุ่นจัง...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:759
translate english character_name_selected_ca5b995f:

    # mn "(Es como estar entre dos nubes...)"
    mn "(ราวกับได้ซบอยู่ท่ามกลางก้อนเมฆสองก้อน...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:760
translate english character_name_selected_7ba17d17:

    # mn "(Ok [MN], basta de tonterías y llevala a la cama)"
    mn "(พอได้แล้ว [MN] เลิกเพ้อเจ้อแล้วพาเธอไปนอนได้แล้ว)"

# game/scripts/History/PrincipalStory/Prologo.rpy:765
translate english character_name_selected_1348b8f9:

    # n "Te levantas y recoges a Sakura entre tus brazos para llevarla a su habitación.."
    n "คุณลุกขึ้นแล้วอุ้มซากุระขึ้นมาไว้ในอ้อมแขนเพื่อพาไปส่งที่ห้องนอน..."

# game/scripts/History/PrincipalStory/Prologo.rpy:771
translate english character_name_selected_2090e48a:

    # mn "Ya ahí debería estar bien..."
    mn "แค่นี้ก็เรียบร้อยแล้วสินะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:772
translate english character_name_selected_0af9f4c4:

    # n "Justo cuando dejas a Sakura en su cama se empiezan a escuchar unas pisadas"
    n "และในจังหวะที่คุณวางซากุระลงบนเตียง เสียงฝีเท้าบางอย่างก็ดังขึ้นมา"

# game/scripts/History/PrincipalStory/Prologo.rpy:773
translate english character_name_selected_446b0110:

    # mn "Mierda, no me digas qué..."
    mn "เวรเอ๊ย อย่าบอกนะว่า..."

# game/scripts/History/PrincipalStory/Prologo.rpy:774
translate english character_name_selected_f1a05eab:

    # sr "Mamá... ¿Estás en casa?"
    sr "คุณแม่คะ... อยู่บ้านหรือเปล่าคะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:775
translate english character_name_selected_c8b0886d:

    # mn "(¡Oh, no, no, no!)"
    mn "(แย่แล้วๆๆ!)"

# game/scripts/History/PrincipalStory/Prologo.rpy:776
translate english character_name_selected_6b04a524:

    # mn "(Si Sarada me ve aquí con su madre pensará lo peor de mí)"
    mn "(ถ้าซาราดะมาเห็นฉันอยู่กับแม่ของเธอในสภาพนี้ เธอต้องคิดไปในทางที่แย่ที่สุดแน่ๆ)"

# game/scripts/History/PrincipalStory/Prologo.rpy:777
translate english character_name_selected_ec4ad477:

    # mn "(Debo esconderme)"
    mn "(ฉันต้องซ่อนตัว)"

# game/scripts/History/PrincipalStory/Prologo.rpy:778
translate english character_name_selected_59cd79ee:

    # mn "(¡Pero no hay sitio dónde esconderse!)"
    mn "(แต่ไม่มีที่ให้ซ่อนเลยนี่หว่า!)"

# game/scripts/History/PrincipalStory/Prologo.rpy:779
translate english character_name_selected_f940c616:

    # sr "¿Qué son estas botellas?"
    sr "ขวดพวกนี้อะไรเนี่ย?"

# game/scripts/History/PrincipalStory/Prologo.rpy:780
translate english character_name_selected_8b37ab94:

    # sr "¿Pasaste toda noche tomando sake de nuevo?"
    sr "นี่แอบดื่มเหล้าสาเกทั้งคืนอีกแล้วเหรอเนี่ย?"

# game/scripts/History/PrincipalStory/Prologo.rpy:781
translate english character_name_selected_09a41f66:

    # mn "(Cada vez está más cerca, ¿Qué mierda hago?)"
    mn "(เสียงฝีเท้าเข้ามาใกล้แล้ว ฉันกำลังทำบ้าอะไรอยู่เนี่ย?)"

# game/scripts/History/PrincipalStory/Prologo.rpy:782
translate english character_name_selected_7aacb977:

    # sr "Y luego la niña soy yo, ¿No?"
    sr "แล้วเด็กผู้หญิงคนนั้นก็คือหนูเองสินะคะเนี่ย?"

# game/scripts/History/PrincipalStory/Prologo.rpy:783
translate english character_name_selected_efee21b7:

    # mn "(¡La ventana!)"
    mn "(หน้าต่าง!)"

# game/scripts/History/PrincipalStory/Prologo.rpy:784
translate english character_name_selected_b01ca5dc:

    # mn "(¡No me queda de otra que salir por la ventana!)"
    mn "(ไม่มีทางเลือกอื่นนอกจากต้องหนีออกทางหน้าต่างแล้ว!)"

# game/scripts/History/PrincipalStory/Prologo.rpy:790
translate english character_name_selected_853ada90:

    # n "[MN] intentó abrir la ventana"
    n "[MN] พยายามจะเปิดหน้าต่าง"

# game/scripts/History/PrincipalStory/Prologo.rpy:791
translate english character_name_selected_52ce3c73:

    # n "Pero esta estaba atascada"
    n "แต่ว่ามันดันติดเปิดไม่ออก"

# game/scripts/History/PrincipalStory/Prologo.rpy:797
translate english character_name_selected_1b56d3fa:

    # n "Lo que provocó que al intentar abrirla con tanta fuerza tropezaras contra el suelo"
    n "ทำให้เขาเสียหลักล้มลงไปกับพื้นตอนที่พยายามออกแรงงัดมันเข้าเต็มแรง"

# game/scripts/History/PrincipalStory/Prologo.rpy:804
translate english character_name_selected_bbfd2dca_1:

    # mn "¡!"
    mn "!"

# game/scripts/History/PrincipalStory/Prologo.rpy:805
translate english character_name_selected_b62845f5:

    # sr "¿Qué fue eso?"
    sr "เสียงอะไรน่ะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:812
translate english character_name_selected_ce47ec7f:

    # mn "(¡Mierda!)"
    mn "(เวรเอ๊ย!)"

# game/scripts/History/PrincipalStory/Prologo.rpy:813
translate english character_name_selected_4df18da8:

    # mn "(Sarada...)"
    mn "(ซาราดะ...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:814
translate english character_name_selected_af07b704:

    # mn "(No pienses mal de mí)"
    mn "(อย่าเพิ่งเข้าใจฉันผิดนะ)"

# game/scripts/History/PrincipalStory/Prologo.rpy:815
translate english character_name_selected_c3699fc9:

    # sr "Mamá, voy a entrar"
    sr "คุณแม่คะ หนูเข้าไปแล้วนะคะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:818
translate english character_name_selected_fb256a11:

    # mn "(¡A-Ahí viene!)"
    mn "(ม-มาแล้ว!)"

# game/scripts/History/PrincipalStory/Prologo.rpy:835
translate english character_name_selected_33b203be:

    # sr "Ahí estás..."
    sr "ให้อย่างนี้สิ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:837
translate english character_name_selected_fca0d22e:

    # sr "Mírate, no tienes vergüenza alguna..."
    sr "ดูตัวเองสิ เธอนี่ไม่รู้จักอายจริง ๆ เลย..."

# game/scripts/History/PrincipalStory/Prologo.rpy:840
translate english character_name_selected_682a85a6:

    # mn "(S-Sabía que reaccionaria así...)"
    mn "(ฉ-ฉันรู้อยู่แล้วเชียวว่าเธอต้องปฏิกิริยาแบบนี้...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:843
translate english character_name_selected_72a7ad9e:

    # sr "Ya tienes edad como para dejar botellas tiradas en la casa mamá"
    sr "โตจนป่านนี้แล้วยังปล่อยให้มีขวดวางเกลื่อนบ้านอีกนะแม่"

# game/scripts/History/PrincipalStory/Prologo.rpy:849
translate english character_name_selected_77be194c:

    # mn "(¿Eh?)"
    mn "(ฮะ?)"

# game/scripts/History/PrincipalStory/Prologo.rpy:851
translate english character_name_selected_4aca6f6b:

    # sk "Zzz.. Zzz..."
    sk "ครอก... ฟี้..."

# game/scripts/History/PrincipalStory/Prologo.rpy:853
translate english character_name_selected_8e81c2ce:

    # sr "Me sorprende que por lo menos esta vez hayas llegado a tu cama..."
    sr "แปลกใจจังเลยนะคะที่อย่างน้อยคราวนี้แม่ก็ลากสังขารมานอนบนเตียงได้..."

# game/scripts/History/PrincipalStory/Prologo.rpy:856
translate english character_name_selected_4d7adc7a:

    # mn "(¡¿Q-Qué está pasando? ¿Por qué está casi desnuda?!)"
    mn "(ก-เกิดอะไรขึ้นเนี่ย? ทำไมเธอถึงเกือบจะแก้ผ้าอยู่แล้วล่ะ?!)"

# game/scripts/History/PrincipalStory/Prologo.rpy:858
translate english character_name_selected_cc461dc9:

    # mn "(¡¿Y por que está ignorandome?!)"
    mn "(แล้วทำไมเธอถึงเมินฉันล่ะเนี่ย?!)"

# game/scripts/History/PrincipalStory/Prologo.rpy:860
translate english character_name_selected_7987b58a:

    # mn "(Un segundo.. ¡Mi cuerpo...!)"
    mn "(เดี๋ยวก่อนนะ.. ร่างกายของฉัน...!)"

# game/scripts/History/PrincipalStory/Prologo.rpy:861
translate english character_name_selected_73e90517:

    # mn "(¡Veo a mi cuerpo trasparente...!)"
    mn "(ทำไมร่างกายฉันมันดูโปร่งแสงแปลกๆ ล่ะเนี่ย...!)"

# game/scripts/History/PrincipalStory/Prologo.rpy:866
translate english character_name_selected_980c3be2:

    # sr "En fin, debo cambiarme"
    sr "ช่างเถอะ ยังไงก็ต้องไปเปลี่ยนชุดก่อน"

# game/scripts/History/PrincipalStory/Prologo.rpy:868
translate english character_name_selected_4bad1a7b:

    # sr "Iré a ver a Chocho antes de ir a la residencia del Hokage"
    sr "เดี๋ยวค่อยแวะไปหาโจโจ้ก่อนไปบ้านท่านโฮคาเงะก็แล้วกัน"

# game/scripts/History/PrincipalStory/Prologo.rpy:870
translate english character_name_selected_700cf446:

    # sr "Nos vemos hasta entonces..."
    sr "ไว้เจอกันนะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:873
translate english character_name_selected_513bf35e:

    # n "Sarada sale nuevamente de la habitación y cierra la puerta"
    n "ซาราดะเดินออกจากห้องไปอีกครั้งแล้วปิดประตู"

# game/scripts/History/PrincipalStory/Prologo.rpy:874
translate english character_name_selected_32462c4b_7:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:878
translate english character_name_selected_88e0c1ec:

    # mn "(¡¿Qué carajos acaba de pasar?!)"
    mn "(เมื่อกี้มันเรื่องบ้าอะไรเนี่ย?!)"

# game/scripts/History/PrincipalStory/Prologo.rpy:879
translate english character_name_selected_f12c21fd:

    # mn "(Mierda, ¿Y qué tengo en el ojo? Me arde mucho)"
    mn "(เวรเอ๊ย มีอะไรเข้าตาเนี่ย? แสบชะมัดเลย)"

# game/scripts/History/PrincipalStory/Prologo.rpy:881
translate english character_name_selected_ac286ec1:

    # n "[MN] encuentra un espejo en la habitación, y decide verse el ojo"
    n "[MN] พบกระจกบานหนึ่งในห้อง แล้วจึงตัดสินใจส่องดูตาของตัวเอง"

# game/scripts/History/PrincipalStory/Prologo.rpy:886
translate english character_name_selected_4fbcd150:

    # mn "¿Ese es...?"
    mn "(นั่นมัน...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:887
translate english character_name_selected_13206721:

    # mn "¿Mi ojo...?"
    mn "(ตาของฉัน...?)"

# game/scripts/History/PrincipalStory/Prologo.rpy:888
translate english character_name_selected_9ad6f6a6:

    # mn "¿Por qué se ve así mi ojo?"
    mn "(ทำไมตาของฉันถึงเป็นแบบนี้ล่ะเนี่ย?)"

# game/scripts/History/PrincipalStory/Prologo.rpy:891
translate english character_name_selected_32462c4b_8:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:892
translate english character_name_selected_c3e548b4:

    # mn "(No sé qué es lo que acaba de pasar)"
    mn "(ฉันไม่รู้เลยว่าเกิดบ้าอะไรขึ้นกับตัวเอง)"

# game/scripts/History/PrincipalStory/Prologo.rpy:893
translate english character_name_selected_04065692:

    # mn "(Pero algo me dice que hice algo para que Sarada no pudiera verme)"
    mn "(แต่สัญชาตญาณมันบอกว่า ฉันเผลอทำอะไรบางอย่างจนทำให้ซาราดะมองไม่เห็นฉัน)"

# game/scripts/History/PrincipalStory/Prologo.rpy:902
translate english character_name_selected_171e37cf:

    # mn "(Dijo que iría a cambiarse)"
    mn "(เมื่อกี้เธอบอกว่าจะไปเปลี่ยนชุดสินะ)"

# game/scripts/History/PrincipalStory/Prologo.rpy:903
translate english character_name_selected_5a218823:

    # mn "(Debería aprovechar para irme ahora antes de que termine)"
    mn "(ฉันน่าจะฉวยโอกาสนี้ชิ่งหนีก่อนที่เธอจะแต่งตัวเสร็จดีกว่า)"

# game/scripts/History/PrincipalStory/Prologo.rpy:904
translate english character_name_selected_6e219983:

    # mn "(Dudo mucho que un milagro así vuelva a salvarme)"
    mn "(ฉันไม่คิดหรอกนะว่าปาฏิหาริย์แบบนี้จะช่วยฉันได้อีกรอบ)"

# game/scripts/History/PrincipalStory/Prologo.rpy:906
translate english character_name_selected_bd18d009:

    # n "Siendo lo más sigiloso posible, [MN] sale de la residencia Uchiha sin ser descubierto"
    n "[MN] พยายามทำตัวให้เงียบที่สุดแล้วแอบออกจากบ้านอุจิวะไปโดยไม่มีใครจับได้"

# game/scripts/History/PrincipalStory/Prologo.rpy:915
translate english character_name_selected_b24c350e:

    # mn "(¿Qué debería hacer ahora?)"
    mn "(ตอนนี้ฉันควรทำยังไงดีล่ะเนี่ย?)"

# game/scripts/History/PrincipalStory/Prologo.rpy:917
translate english character_name_selected_85b77973_3:

    # mn "(...)"
    mn "(...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:919
translate english character_name_selected_bdeaf003:

    # mn "(Creo que debería reportarselo al Hokage...)"
    mn "(ฉันว่าฉันควรไปรายงานท่านโฮคาเงะดีกว่า...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:921
translate english character_name_selected_e8a5ca93:

    # mn "(Él es la única persona que conozco que puede que sepa algo acerca de mi ojo)"
    mn "(ท่านโฮคาเงะน่าจะเป็นคนเดียวที่ฉันรู้จักที่อาจจะรู้เรื่องตาของฉัน)"

# game/scripts/History/PrincipalStory/Prologo.rpy:926
translate english character_name_selected_e045eff1:

    # n "[MN] decide poner rumbo a la residencia del Hokage"
    n "[MN] ตัดสินใจมุ่งหน้าไปยังบ้านพักของโฮคาเงะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:927
translate english character_name_selected_c5dffc2e:

    # n "Y por el camino se da cuenta que todo el mundo se le queda viendo"
    n "และระหว่างทาง เขาก็สังเกตเห็นว่าทุกคนเอาแต่มองมาที่เขา"

# game/scripts/History/PrincipalStory/Prologo.rpy:928
translate english character_name_selected_0ae9bcd0:

    # ""
    ""

# game/scripts/History/PrincipalStory/Prologo.rpy:929
translate english character_name_selected_7cb699d6:

    # n "Llegando finalmente a la oficina del Hokage"
    n "ในที่สุดก็มาถึงห้องทำงานของโฮคาเงะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:940
translate english character_name_selected_725b90ff:

    # nt "¿Dónde estarán esos documentos?"
    nt "เอกสารพวกนั้นมันไปอยู่ไหนนะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:943
translate english character_name_selected_4239ff62:

    # mn "Buenos días, señor Hokage..."
    mn "อรุณสวัสดิ์ครับท่านโฮคาเงะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:947
translate english character_name_selected_e79f80c4:

    # nt "Oh, buenos días, [MN], ¿que te trae por...?"
    nt "โอ้ อรุณสวัสดิ์ [MN] มีธุระอะไรถึงมาหาล่ะเนี่ย...?"

# game/scripts/History/PrincipalStory/Prologo.rpy:953
translate english character_name_selected_254c214e:

    # nt "¡Aah! ¿Qué te pasó en el ojo?"
    nt "อ้าส์! ตาของเธอไปโดนอะไรมาเนี่ย?!"

# game/scripts/History/PrincipalStory/Prologo.rpy:956
translate english character_name_selected_3f47a559:

    # mn "Bueno, justo por eso vine a verlo... Pensé que podría ayudarme"
    mn "คือว่า... นั่นแหละครับที่ผมมาหาท่าน... ผมคิดว่าท่านน่าจะช่วยผมได้"

# game/scripts/History/PrincipalStory/Prologo.rpy:959
translate english character_name_selected_a223d0e6:

    # mn "Yo..."
    mn "ฉัน..."

# game/scripts/History/PrincipalStory/Prologo.rpy:963
translate english character_name_selected_517d7ca6:

    # mn "(Un momento... No puedo decirle la verdad...)"
    mn "(เดี๋ยวก่อน... จะบอกความจริงไม่ได้สินะ...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:965
translate english character_name_selected_9021bf50:

    # mn "(Tendré que improvisar una mentira...)"
    mn "(คงต้องหาเรื่องโกหกกลบเกลื่อนไปก่อน...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:968
translate english character_name_selected_0abb5826:

    # mn "Yo... Me desperté y veía mi cuerpo transparente..."
    mn "คือว่า... ผมตื่นมาแล้วพบว่าร่างกายของตัวเองโปร่งใสไปหมดเลยครับ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:971
translate english character_name_selected_5def33c4:

    # nt "¿Trasparente?"
    nt "โปร่งใสอย่างนั้นเหรอ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:974
translate english character_name_selected_038baef6:

    # mn "Así es... Y fui a verme al espejo pero no podía ver mi reflejo..."
    mn "ครับ... แล้วพอผมไปส่องกระจก ก็มองไม่เห็นเงาตัวเองเลย..."

# game/scripts/History/PrincipalStory/Prologo.rpy:976
translate english character_name_selected_d0a8b3d0:

    # mn "Era como si fuera invisible..."
    mn "เหมือนกับว่าผมล่องหนได้..."

# game/scripts/History/PrincipalStory/Prologo.rpy:978
translate english character_name_selected_ef3ac838:

    # mn "Y luego... Salí y vi a alguien, pero parecía que esa persona no me podía ver a mí..."
    mn "แล้วจากนั้น... ผมก็ออกไปข้างนอกแล้วเจอคนคนหนึ่ง แต่ดูเหมือนว่าเขาจะมองไม่เห็นผม..."

# game/scripts/History/PrincipalStory/Prologo.rpy:981
translate english character_name_selected_58b46560:

    # nt "Entiendo... ¿Y como volviste a la normalidad?"
    nt "อย่างนี้นี่เอง... แล้วเธอกลับคืนร่างเดิมได้ยังไงล่ะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:984
translate english character_name_selected_8957e7a6:

    # mn "Después de un rato me calmé y fue ahí cuando dejé de ser transparente..."
    mn "สักพักพอผมใจเย็นลง ร่างกายก็เลิกโปร่งใสไปเองครับ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:986
translate english character_name_selected_871d8900:

    # mn "Pero cuando volví a verme al espejo, mi ojo ya era amarillo"
    mn "แต่พอผมส่องกระจกดูอีกที ตาของผมก็กลายเป็นสีเหลืองไปซะแล้ว"

# game/scripts/History/PrincipalStory/Prologo.rpy:988
translate english character_name_selected_ade94437:

    # mn "Y decidí venir aquí, pensando en que usted podría ayudarme"
    mn "ผมก็เลยตัดสินใจมาที่นี่ โดยคิดว่าท่านน่าจะช่วยผมได้ครับ"

# game/scripts/History/PrincipalStory/Prologo.rpy:991
translate english character_name_selected_9d537539:

    # nt "Así que invisibilidad..."
    nt "งั้นก็เรื่องคาถาล่องหนสินะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:993
translate english character_name_selected_c2d06cfe:

    # nt "Hmm..."
    nt "อืม..."

# game/scripts/History/PrincipalStory/Prologo.rpy:995
translate english character_name_selected_32150f5e:

    # nt "¿Nadie más te vió el ojo?"
    nt "แล้วมีคนอื่นเห็นตาของเธออีกไหม?"

# game/scripts/History/PrincipalStory/Prologo.rpy:998
translate english character_name_selected_67dad1f5:

    # mn "Por desgracia, terminé siendo el centro de atención..."
    mn "น่าเสียดายที่ผมดันตกเป็นเป้าสายตาซะแล้วล่ะครับ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1001
translate english character_name_selected_524d4a72:

    # nt "Ya veo..."
    nt "อย่างนี้นี่เอง..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1004
translate english character_name_selected_90f622bf:

    # nt "Déjame ver tu ojo..."
    nt "งั้นขอฉันดูตาของเธอหน่อยสิ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1006
translate english character_name_selected_6f7643d8:

    # n "Naruto le hecha un vistazo al ojo de [MN]"
    n "นารูโตะเพ่งมองตาของ [MN]"

# game/scripts/History/PrincipalStory/Prologo.rpy:1013
translate english character_name_selected_ff7aa509:

    # nt "Creo que ya sé que pasa..."
    nt "ฉันว่าฉันพอจะรู้แล้วล่ะว่าเกิดอะไรขึ้น..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1015
translate english character_name_selected_f266031a:

    # nt "Noto un pequeño flujo en tu ojo"
    nt "ฉันสังเกตเห็นการไหลเวียนของจักระแปลกๆ ในตาของเธอนิดหน่อย"

# game/scripts/History/PrincipalStory/Prologo.rpy:1017
translate english character_name_selected_be9df601:

    # nt "Bastante parecido al flujo de chkra de los Uchiha cuando despiertan el Sharingan"
    nt "ค่อนข้างคล้ายกับการไหลเวียนของจักระของตระกูลอุจิวะตอนที่พวกเขาเบิกเนตรวงแหวนเลยล่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1019
translate english character_name_selected_77b262ab:

    # nt "Probablemente... Sea un Kekkei Genkai, heredado del clan del que provienes"
    nt "น่าจะเป็น... ขีดจำกัดสายเลือดที่สืบทอดมาจากตระกูลเดิมของเธอนั่นแหละนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1022
translate english character_name_selected_afad8976:

    # mn "¿Mi clan?"
    mn "ตระกูลของผมเหรอครับ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1025
translate english character_name_selected_50019802:

    # nt "Es la explicación más sencilla"
    nt "มันเป็นคำอธิบายที่ง่ายที่สุดแล้วล่ะนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1027
translate english character_name_selected_b853befd:

    # nt "Así como el Sharingan de los Uchiha, ese ojo es un Kekkei Genkai"
    nt "ก็เหมือนกับเนตรวงแหวนของอุจิวะ ดวงตานั้นเป็นขีดจำกัดสายเลือด"

# game/scripts/History/PrincipalStory/Prologo.rpy:1029
translate english character_name_selected_9420d955:

    # nt "Un Dojutsu para ser más precisos"
    nt "พูดให้ถูกก็คือเนตรสังสาระ เอ้ย เนตรพิเศษสินะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1031
translate english character_name_selected_4e812cd3:

    # nt "Seguramente la invisibilidad sea algún jutsu"
    nt "ส่วนเรื่องการล่องหนก็น่าจะเป็นคาถาอะไรสักอย่าง"

# game/scripts/History/PrincipalStory/Prologo.rpy:1033
translate english character_name_selected_5e07f2ad:

    # nt "Pero para estar seguros..."
    nt "แต่เพื่อความแน่ใจ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1040
translate english character_name_selected_4552aede:

    # n "Entra Sarada a la oficina"
    n "ซาราดะเดินเข้ามาในห้องทำงาน"

# game/scripts/History/PrincipalStory/Prologo.rpy:1042
translate english character_name_selected_e8c56533:

    # sr "Buen día Señor Séptimo"
    sr "สวัสดีค่ะท่านรุ่นที่เจ็ด"

# game/scripts/History/PrincipalStory/Prologo.rpy:1044
translate english character_name_selected_64414f6f:

    # sr "[MN], ¿Qué haces aquí?"
    sr "[MN] มาทำอะไรที่นี่เหรอ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1050
translate english character_name_selected_b41bdbdd:

    # mn "H-Hola Sarada..."
    mn "ซ-สวัสดี ซาราดะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1057
translate english character_name_selected_bda86687:

    # sr "¡¿Q-Qué demonios te pasó en el ojo?!"
    sr "ด-เดี๋ยว เกิดอะไรขึ้นกับตาของนายเนี่ย?!"

# game/scripts/History/PrincipalStory/Prologo.rpy:1059
translate english character_name_selected_6db20aeb:

    # sr "¿A-Alguien te hizo eso?"
    sr "ม-มีใครทำอะไรนายมาเหรอ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1062
translate english character_name_selected_c9c028e5:

    # nt "Creo que no es el caso..."
    nt "ฉันว่าไม่น่าจะใช่แบบนั้นหรอกนะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1065
translate english character_name_selected_8a90a00f:

    # sr "¿Qué?"
    sr "คะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1068
translate english character_name_selected_7d01f808:

    # mn "El Hokage cree que es un Kekkei Genkai"
    mn "ท่านโฮคาเงะคิดว่านี่น่าจะเป็นขีดจำกัดสายเลือดน่ะครับ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1072
translate english character_name_selected_85cd4682:

    # nt "Me alegra que hayas venido, Sarada"
    nt "ดีแล้วล่ะที่เธอมาพอดี ซาราดะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1074
translate english character_name_selected_d65a0244:

    # nt "Necesito que acompañes a [MN] al escondite de Orochimaru"
    nt "ฉันอยากให้เธอช่วยพา [MN] ไปที่ศูนย์หลบภัยของโอโรจิมารุหน่อย"

# game/scripts/History/PrincipalStory/Prologo.rpy:1076
translate english character_name_selected_ee7284ca:

    # nt "Tú eres de las pocas personas que saben su localización"
    nt "เธอเป็นหนึ่งในไม่กี่คนที่รู้ว่ามันอยู่ที่ไหน"

# game/scripts/History/PrincipalStory/Prologo.rpy:1078
translate english character_name_selected_ec793a5b:

    # nt "Él tiene todo tipo de registros y archivos de clanes y las copias sobre los experimentos de Shin Uchiha"
    nt "เขามีบันทึกข้อมูลทุกรูปแบบรวมถึงแฟ้มประวัติของตระกูลต่างๆ และสำเนาการทดลองของชิน อุจิวะด้วย"

# game/scripts/History/PrincipalStory/Prologo.rpy:1080
translate english character_name_selected_b9fe8d97:

    # nt "Sí alguien puede ayudar a [MN], es él"
    nt "ถ้าจะมีใครช่วย [MN] ได้ ก็คงเป็นเขานี่แหละ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1083
translate english character_name_selected_f4c4f2c1:

    # sr "Entendido, señor"
    sr "รับทราบค่ะท่าน"

# game/scripts/History/PrincipalStory/Prologo.rpy:1086
translate english character_name_selected_ebd4c037:

    # nt "Le avisaré de su visita, vayan ahora y tengan mucho cuidado"
    nt "เดี๋ยวฉันจะติดต่อไปแจ้งเขาเรื่องที่พวกเธอจะไป รีบไปกันเถอะแล้วก็ระวังตัวด้วยล่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1091
translate english character_name_selected_72128c1c:

    # mn "Está bien señor, y... Muchas gracias"
    mn "ครับท่าน แล้วก็... ขอบคุณมากครับ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1093
translate english character_name_selected_9f6d4869:

    # nt "Jeje, no es nada"
    nt "เฮะๆ เรื่องเล็กน่า"

# game/scripts/History/PrincipalStory/Prologo.rpy:1095
translate english character_name_selected_86e76ffc:

    # nt "Ahora vayan, es mejor que salgan temprano para que no vuelvan tan tarde"
    nt "ไปกันได้แล้ว ออกเดินทางเร็วหน่อยจะได้ไม่กลับดึกเกินไป"

# game/scripts/History/PrincipalStory/Prologo.rpy:1097
translate english character_name_selected_a8eebdf1:

    # n "Sales junto a Sarada de la oficina del Hokage"
    n "คุณออกจากห้องทำงานของโฮคาเงะพร้อมกับซาราดะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1105
translate english character_name_selected_825cd505:

    # sr "Debemos irnos ya para que no se nos haga tarde, el escondite se encuentra en las afueras de la aldea, cerca del bosque de la hoja"
    sr "เราต้องรีบไปกันแล้วจะได้ไม่สาย ศูนย์หลบภัยนั่นอยู่แถวชานเมือง ใกล้กับป่าแห่งโคโนฮะนี่เอง"

# game/scripts/History/PrincipalStory/Prologo.rpy:1108
translate english character_name_selected_ef92ae41:

    # mn "Está bien, te sigo"
    mn "อืม งั้นฉันนำไปเอง"

# game/scripts/History/PrincipalStory/Prologo.rpy:1111
translate english character_name_selected_f5d687b8:

    # sr "¿Qué te parece si en el camino me cuentas como despertaste ese Jutsu de un día para otro?"
    sr "ระหว่างทางเธอกช่วยเล่าให้ฉันฟังหน่อยสิว่าจู่ๆ นายปลุกคาถานั้นขึ้นมาได้ยังไง?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1114
translate english character_name_selected_478d3e94:

    # mn "C-Claro... No tengo problemas con eso..."
    mn "จ-จะเล่าให้ฟังแน่นอน... เรื่องนั้นไม่มีปัญหาอยู่แล้ว..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1117
translate english character_name_selected_2eaec596:

    # n "En camino al escondite de Orochimaru, [MN] le dice a Sarada su mentira sobre como su ojo se volvió amarillo"
    n "ระหว่างทางไปศูนย์หลบภัยของโอโรจิมารุ [MN] ได้เล่าเรื่องโกหกให้ซาราดะฟังเกี่ยวกับเรื่องที่ตาของเขาเปลี่ยนเป็นสีเหลือง"

# game/scripts/History/PrincipalStory/Prologo.rpy:1130
translate english character_name_selected_17cee95a:

    # mn "Y eso fue lo que pasó..."
    mn "เรื่องก็เป็นแบบนี้แหละ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1131
translate english character_name_selected_41f10758:

    # sr "Vaya... es algo difícil de creer"
    sr "โห... ฟังดูเหลือเชื่อไปหน่อยนะเนี่ย"

# game/scripts/History/PrincipalStory/Prologo.rpy:1132
translate english character_name_selected_b0660926:

    # sr "¿Entonces ahora puedes volverte invisible a voluntad?"
    sr "งั้นตอนนี้ก็ล่องหนตามใจชอบได้แล้วงั้นเหรอ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1133
translate english character_name_selected_bfabe5b6:

    # mn "A voluntad aún no puedo"
    mn "ตามใจชอบเนี่ย ฉันยังทำไม่ได้หรอก"

# game/scripts/History/PrincipalStory/Prologo.rpy:1134
translate english character_name_selected_9860e560:

    # mn "Ni siquiera sabía que podía hacer algo como esto"
    mn "ฉันยังไม่รู้ด้วยซ้ำว่าตัวเองทำอะไรแบบนี้ได้"

# game/scripts/History/PrincipalStory/Prologo.rpy:1135
translate english character_name_selected_c10b7753:

    # mn "Pero, quizás con práctica pueda hacerlo"
    mn "แต่ว่า... ถ้าฝึกฝนดูหน่อยก็น่าจะทำได้แหละนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1136
translate english character_name_selected_fd1ff3f6:

    # mn "Sería muy útil, tanto para el combate como para misiones de infiltración"
    mn "มันคงจะมีประโยชน์มากๆ เลย ทั้งในการต่อสู้แล้วก็ภารกิจแทรกซึม"

# game/scripts/History/PrincipalStory/Prologo.rpy:1137
translate english character_name_selected_e6bd356e:

    # sr "Hacerte invisible..."
    sr "การทำให้ตัวเองล่องหนเนี่ย..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1138
translate english character_name_selected_821239d6:

    # sr "Suena al sueño de un pervertido"
    sr "ฟังดูเหมือนความฝันของพวกโรคจิตเลยแฮะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1139
translate english character_name_selected_36de0c90:

    # sr "¿Sí llegas a dominarlo, crees que te convertirás en una especie de voyeur?"
    sr "ถ้าเกิดนายฝึกจนคล่องแล้ว นายคิดว่าตัวเองจะกลายเป็นพวกชอบแอบดูโรคจิตไรงี้ไหมล่ะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1140
translate english character_name_selected_f96eaede:

    # mn "Sarada..."
    mn "ซาราดะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1141
translate english character_name_selected_358677be:

    # sr "Jajaja.. Solo bromeaba... Ya casi llegamos"
    sr "ฮ่าๆๆ... ล้อเล่นน่า... ถึงแล้วล่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1142
translate english character_name_selected_8581dfe8:

    # mn "Fue más rápido de lo que pensé"
    mn "ถึงเร็วกว่าที่คิดแฮะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1143
translate english character_name_selected_da05f235:

    # sr "Suelo hacer varios encargos aquí, así que conozco los atajos"
    sr "ฉันมักจะรับงานหลายอย่างแถวนี้อยู่แล้วน่ะ ก็เลยรู้ทางลัด"

# game/scripts/History/PrincipalStory/Prologo.rpy:1144
translate english character_name_selected_e4561f94:

    # sr "Mira, es justo aquí"
    sr "นี่ไง อยู่ตรงนี้เอง"

# game/scripts/History/PrincipalStory/Prologo.rpy:1147
translate english character_name_selected_f3e605e1:

    # n "Entras junto a Sarada al escondite de Orochimaru"
    n "คุณเข้ามาในศูนย์หลบภัยของโอโรจิมารุพร้อมกับซาราดะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1156
translate english character_name_selected_32462c4b_9:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1158
translate english character_name_selected_d6fca1cf:

    # sr "¿Hmm?"
    sr "อืมน? อืม?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1162
translate english character_name_selected_8242c578:

    # sr "Oye, ¿Estás bien?"
    sr "เฮ้ เป็นอะไรรึเปล่า?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1165
translate english character_name_selected_b492f364:

    # mn "Ah, si... Es solo que este lugar, se siente familiar a uno no muy agradable para mí..."
    mn "อ๋อ เปล่า... แค่รู้สึกว่าที่นี่มันให้บรรยากาศคุ้นๆ เหมือนกับสถานที่ที่ไม่ค่อยน่าอภิรมย์เท่าไหร่สำหรับฉันน่ะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1168
translate english character_name_selected_16278896:

    # sr "..."
    sr "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1171
translate english character_name_selected_17d5d7a0:

    # sr "Tranquilo, solo vinimos por información"
    sr "ใจเย็นๆ น่า พวกเราแค่มารับข้อมูลเอง"

# game/scripts/History/PrincipalStory/Prologo.rpy:1173
translate english character_name_selected_ee996f44:

    # sr "Una vez que Orochimaru nos diga lo que sabe sobre tu ojo volveremos a la aldea"
    sr "พอโอโรจิมารุบอกสิ่งที่เขารู้เกี่ยวกับตาของนายเสร็จ เราก็จะกลับหมู่บ้านกันทันที"

# game/scripts/History/PrincipalStory/Prologo.rpy:1176
translate english character_name_selected_de89add6:

    # mn "Está bien..."
    mn "อื้ม..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1178
translate english character_name_selected_c352b367:

    # n "Poco a poco se adentran más en el laboratorio"
    n "ทั้งสองคนค่อยๆ เดินลึกเข้าไปข้างในห้องทดลองเรื่อยๆ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1179
translate english character_name_selected_757960f2:

    # n "Y llega alguien a recibirlos"
    n "และก็มีใครบางคนเดินออกมาต้อนรับพวกเขา"

# game/scripts/History/PrincipalStory/Prologo.rpy:1195
translate english character_name_selected_85a2c6cf:

    # kr "Sarada, ¿Cómo has estado?"
    kr "ซาราดะ สบายดีไหม?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1197
translate english character_name_selected_dfa71089:

    # kr "Me avisaron de su llegada para que los recibiera"
    kr "ฉันได้รับแจ้งเรื่องการมาถึงของพวกเธอแล้ว ก็เลยออกมาต้อนรับพวกเธอสองคน"

# game/scripts/History/PrincipalStory/Prologo.rpy:1200
translate english character_name_selected_6fef4457:

    # sr "Karin, muy bien, ¿Tú cómo has estado?"
    sr "คาริน สบายดีมากจ้ะ แล้วเธอเป็นยังไงบ้างล่ะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1203
translate english character_name_selected_726a80f9:

    # kr "Pues, bien dentro de lo que cabe jaja"
    kr "แหมๆ ก็สบายดีอย่างที่เห็นนี่แหละ ฮ่าๆ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1205
translate english character_name_selected_4c7e3a4e:

    # kr "¿Mmm?"
    kr "หืม?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1208
translate english character_name_selected_f20f88ee:

    # kr "Oye, ¿Y quién viene contigo?"
    kr "นี่ ใครมากับเธอด้วยเนี่ย?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1211
translate english character_name_selected_65f19891:

    # sr "Oh si, te lo presento, su nombre es [MN]"
    sr "อ้อ ใช่ ขอแนะนำให้รู้จักนะ เขาชื่อ [MN]"

# game/scripts/History/PrincipalStory/Prologo.rpy:1214
translate english character_name_selected_23a56baf:

    # sr "[MN], ella es Karin Uzumaki, es una gran amiga mía"
    sr "[MN] นี่คือคาริน อุซึมากิ เธอเป็นเพื่อนสนิทของฉันเอง"

# game/scripts/History/PrincipalStory/Prologo.rpy:1217
translate english character_name_selected_0e1e2516:

    # mn "Mucho gusto en conocerla, señorita Karin"
    mn "ยินดีที่ได้รู้จักครับ คุณคาริน"

# game/scripts/History/PrincipalStory/Prologo.rpy:1221
translate english character_name_selected_09ac6eed:

    # kr "Ya veo, entonces tú eres el chico del ojo extraño"
    kr "งั้นเหรอ นายสินะไอ้หนุ่มที่มีตาสประหลาดน่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1223
translate english character_name_selected_c0d852b4:

    # kr "El gusto es mío"
    kr "ยินดีที่ได้รู้จักเช่นกันจ้ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1227
translate english character_name_selected_eafff4f7:

    # mn "(Vaya... Karin es una chica muy linda...)"
    mn "(ว้าว... คารินเป็นผู้หญิงที่น่ารักมากเลยแฮะ...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:1229
translate english character_name_selected_1a097e52:

    # mn "(No esperaba encontrarme a una chica en un sitio como este)"
    mn "(ไม่คิดเลยว่าจะเจอผู้หญิงในสถานที่แบบนี้)"

# game/scripts/History/PrincipalStory/Prologo.rpy:1233
translate english character_name_selected_4581cf59:

    # sr "¿Orochimaru tardará mucho?"
    sr "โอโรจิมารุจะใช้เวลานานไหม?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1236
translate english character_name_selected_812464a4:

    # kr "No lo sé, apenas recibió el informe del Hokage se puso a buscar entre unos documentos"
    kr "ก็ไม่รู้เหมือนกัน พอเขาได้รับรายงานจากท่านโฮคาเงะปุ๊บ เขาก็เริ่มรื้อค้นเอกสารพวกนั้นทันทีเลยล่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1239
translate english character_name_selected_6cadef93:

    # d "Documentos que acabo de encontrar"
    d "เป็นเอกสารที่ฉันเพิ่งเจอน่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1243
translate english character_name_selected_8bd4a600:

    # n "Orochimaru hace acto de presencia en la sala"
    n "โอโรจิมารุปรากฏตัวขึ้นในห้อง"

# game/scripts/History/PrincipalStory/Prologo.rpy:1245
translate english character_name_selected_7496367e:

    # oro "Tú eres [MN], ¿No es así?"
    oro "เธอคือ [MN] สินะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1248
translate english character_name_selected_cc448a98:

    # mn "S-Sí señor..."
    mn "ค-ครับท่าน..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1251
translate english character_name_selected_36fc2319:

    # oro "Cuando recibí el mensaje de Naruto, me pareció algo extraño lo que me describía"
    oro "ตอนที่ฉันได้รับข้อความจากนารูโตะ สิ่งที่เขาอธิบายมามันดูแปลกประหลาดมากเลยล่ะนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1253
translate english character_name_selected_882c1756:

    # oro "¿Un Kekkei Genkai capaz de volver invisible al usuario?"
    oro "ขีดจำกัดสายเลือดที่ทำให้ผู้ใช้ล่องหนได้งั้นเหรอ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1255
translate english character_name_selected_b8565213:

    # oro "Era algo sumamente curioso que tenía que investigar"
    oro "มันเป็นเรื่องที่น่าสนใจสุดๆ จนฉันต้องลองตรวจสอบดูสักหน่อยแล้ว"

# game/scripts/History/PrincipalStory/Prologo.rpy:1257
translate english character_name_selected_56c98952:

    # oro "Y divagando entre unos documentos de Shin Uchiha"
    oro "และระหว่างที่ค้นหาดูในเอกสารของชิน อุจิฮะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1259
translate english character_name_selected_f678bc71:

    # oro "Encontré esto"
    oro "ฉันเจออันนี้แหละ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1268
translate english prologo__743d2133:

    # kr "¿E-Ese es [MN]?"
    kr "น-นั่นมัน [MN] ใช่ไหม?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1271
translate english prologo__d6c8bfc7:

    # oro "Si, ese era tu estado cuando Shin hacía experimentos con él"
    oro "ใช่ นั่นคือสภาพของเธอตอนที่ชินกำลังใช้ทดลองอยู่น่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1274
translate english prologo__623e9f14:

    # mn "¿{color=#f3c271}Ryuta Karui{/a}?"
    mn "{color=#f3c271}รยูตะ คารุย{/a} เหรอ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1278
translate english prologo__741dd1b5:

    # oro "Aparentemente ese es tu nombre real, {color=#f3c271}Ryuta Karui{/a}"
    oro "ดูเหมือนว่านั่นจะเป็นชื่อจริงของเธอนะ {color=#f3c271}รยูตะ คารุย{/a}"

# game/scripts/History/PrincipalStory/Prologo.rpy:1282
translate english prologo__719622cd:

    # mn "¿Y qué es eso de compatibilidad?"
    mn "แล้วไอ้เรื่องความเข้ากันได้นี่มันคืออะไรกันครับ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1284
translate english prologo__5545ef7d:

    # mn "¿A qué se refiere?"
    mn "มันหมายความว่ายังไงเหรอครับ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1287
translate english prologo__4c0bc8b4:

    # oro "No estoy muy seguro, pero ya que estaba estudiando el sharingan y te lo implantó, puedo suponer que es qué tan compatible eras con este"
    oro "ฉันก็ไม่แน่ใจนักหรอกนะ แต่เนื่องจากเขากำลังศึกษาเนตรวงแหวนแล้วนำมันมาปลูกถ่ายใส่ตัวเธอ ฉันก็เลยพอจะเดาได้ว่านั่นคือระดับความเข้ากันได้ที่เธอมีกับมัน"

# game/scripts/History/PrincipalStory/Prologo.rpy:1290
translate english prologo__bf287b61:

    # oro "Aunque es un experimento muy arriesgado, pudiste tener muchas complicaciones, porque la circulación del Chakra para cada Dojutsu es muy distinta"
    oro "ถึงแม้ว่ามันจะเป็นการทดลองที่มีความเสี่ยงสูงมาก และเธออาจจะเจอภาวะแทรกซ้อนหลายอย่างก็ตาม เพราะการไหลเวียนของจักระสำหรับเนตรแต่ละชนิดนั้นแตกต่างกันมากทีเดียว"

# game/scripts/History/PrincipalStory/Prologo.rpy:1293
translate english prologo__f7a951cc:

    # mn "Pero, ¿Porqué querría implantármelo?"
    mn "แต่ทำไมผมถึงอยากจะปลูกถ่ายมันล่ะครับ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1296
translate english prologo__1c4bc736:

    # oro "Puede que Shin estuviera estudiando qué tan compatible es el Sharingan con otros Dojutsu"
    oro "บางทีชินอาจจะกำลังศึกษาอยู่ว่าเนตรวงแหวนมีความเข้ากันได้กับเนตรอื่นๆ มากแค่ไหน"

# game/scripts/History/PrincipalStory/Prologo.rpy:1299
translate english prologo__3751636e:

    # oro "Y si tu Dojutsu tiene el poder de hacerte invisible, Shin estaba tratando de hacerse con eso"
    oro "และถ้าเนตรของคุณมีพลังที่ทำให้ล่องหนได้ ชินก็คงพยายามที่จะครอบครองพลังนั้น"

# game/scripts/History/PrincipalStory/Prologo.rpy:1301
translate english prologo__f5bb0e81:

    # oro "Viéndolo desde el punto de vista de Shin, seía una gran adquisición"
    oro "ถ้ามองจากมุมของชินแล้ว มันคงจะเป็นสิ่งที่คุ้มค่ามากๆ เลยล่ะนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1304
translate english prologo__32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1307
translate english prologo__9583124f:

    # mn "Maldito Shin..."
    mn "ไอ้ชินเวรเอ้ย..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1310
translate english prologo__4a75cb9c:

    # oro "También leí acerca del clan del que provienes..."
    oro "ฉันยังได้อ่านเกี่ยวกับตระกูลที่เธอจากมาด้วยนะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1314
translate english prologo__6fb87993:

    # oro "En unos documentos que le pertenecían a Akatsuki"
    oro "จากเอกสารบางฉบับที่เคยเป็นของแสงอุษา"

# game/scripts/History/PrincipalStory/Prologo.rpy:1318
translate english prologo__60ebe612:

    # mn "¿Akatsuki?"
    mn "แสงอุษาเหรอครับ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1322
translate english prologo__91639e74:

    # sr "¿El grupo terrorista que inició la cuarta guerra ninja?"
    sr "กลุ่มผู้ก่อการร้ายที่เริ่มสงครามโลกนินจาครั้งที่สี่น่ะเหรอ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1326
translate english prologo__64190521:

    # oro "Así es"
    oro "ถูกต้องแล้วล่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1328
translate english prologo__6227bcf3:

    # oro "Akatsuki buscaba poder militar"
    oro "แสงอุษาเคยแสวงหาพลังทางทหาร"

# game/scripts/History/PrincipalStory/Prologo.rpy:1330
translate english prologo__6a4a9946:

    # oro "Y en su búsqueda se encontraron con el clan Karui"
    oro "และในการตามหานั้น พวกเขาได้พบกับตระกูลคารุย"

# game/scripts/History/PrincipalStory/Prologo.rpy:1332
translate english prologo__6b1d2200:

    # oro "Un clan con un Dojutsu que los hacía volverse invisible, a este Dojutsu se le hacía llamar {color=#f3c271}Karugan{/a}"
    oro "ตระกูลที่มีเนตรวิเศษซึ่งทำให้ผู้ใช้สามารถล่องหนได้ เนตรวิเศษนี้มีชื่อว่า {color=#f3c271}คารูกัน{/a}"

# game/scripts/History/PrincipalStory/Prologo.rpy:1334
translate english prologo__cbfdb0e6:

    # oro "Akatsuki intentó persuadir a los miembros del clan para que se unieran, pero estos se negaron a trabajar para el grupo"
    oro "แสงอุษาพยายามเกลี้ยกล่อมให้สมาชิกในตระกูลเข้าร่วม แต่พวกเขาปฏิเสธที่จะทำงานให้กลุ่ม"

# game/scripts/History/PrincipalStory/Prologo.rpy:1339
translate english prologo__709a0b0b:

    # oro "Esto no le gustó a los Akatsuki"
    oro "แสงอุษาไม่ชอบใจเรื่องนั้นเลยสักนิด"

# game/scripts/History/PrincipalStory/Prologo.rpy:1343
translate english prologo__a6562c11:

    # sr "¿Y qué... Sucedió...?"
    sr "แล้ว... เกิดอะไรขึ้น... ล่ะคะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1346
translate english prologo__94cbd90c:

    # oro "Todos fueron asesinados..."
    oro "พวกเขาถูกฆ่าล้างบางทั้งหมด..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1348
translate english prologo__32462c4b_1:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1353
translate english prologo__6d261b79:

    # sr "Bueno... Al menos ya con esto resolvimos el misterio de tu clan. ¿Cierto?"
    sr "งั้น... อย่างน้อยที่สุดเราก็ไขปริศนาเรื่องตระกูลของเธอได้แล้วสินะคะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1355
translate english prologo__32462c4b_2:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1359
translate english prologo__edab90ad:

    # mn "Aún no"
    mn "ยังหรอกครับ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1362
translate english prologo__bbeb34f5:

    # sr "¿A qué te refieres?"
    sr "หมายความว่ายังไงเหรอคะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1365
translate english prologo__9bb3a6f7:

    # mn "Yo sigo con vida, ¿No?"
    mn "ฉันยังรอดชีวิตอยู่ไม่ใช่เหรอ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1367
translate english prologo__2aa1607c:

    # mn "Lo que tal vez signifique que algunos de mi clan sobrevivieron a los Akatsuki"
    mn "ซึ่งมันก็อาจจะหมายความว่ายังมีคนในตระกูลของผมที่รอดชีวิตจากการกวาดล้างของแสงอุษาอยู่น่ะสิครับ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1370
translate english prologo__995d10c1:

    # kr "Mmm, es muy probable"
    kr "อืม เป็นไปได้สูงเลยล่ะนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1373
translate english prologo__debbf7ec:

    # mn "¿Qué dicen los archivos de Shin sobre cómo me encontró"
    mn "แล้วในแฟ้มข้อมูลของชินมีบอกไว้ไหมครับว่าเขาเจอตัวผมได้ยังไง?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1376
translate english prologo__002ca847:

    # oro "No lo dice"
    oro "ไม่มีหรอก"

# game/scripts/History/PrincipalStory/Prologo.rpy:1379
translate english prologo__d1bd8eb2:

    # sr "¿No?"
    sr "เหรอคะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1382
translate english prologo__288d6672:

    # oro "Solo se menciona que eras huérfano"
    oro "ในนั้นระบุแค่ว่าเธอเป็นเด็กกำพร้าเท่านั้นเอง"

# game/scripts/History/PrincipalStory/Prologo.rpy:1385
translate english prologo__32462c4b_3:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1392
translate english prologo__f7b62f2b:

    # oro "Ayudé en lo que pude, si quieres saber algo más tendrás que averiguarlo por tu cuenta"
    oro "ฉันช่วยเท่าที่จะช่วยได้แล้วล่ะนะ ถ้าอยากรู้มากกว่านี้เธอก็ต้องไปสืบหาเอาเองแล้วล่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1394
translate english prologo__50b33698:

    # oro "Mi consejo es que primero aprendas a controlar tu jutsu de insibilidad"
    oro "คำแนะนำของฉันก็คือ... เธอควรจะเรียนรู้วิธีควบคุมเนตรวิเศษที่ทำให้ล่องหนได้นั่นให้ได้ซะก่อน"

# game/scripts/History/PrincipalStory/Prologo.rpy:1397
translate english prologo__e3d8e0a4:

    # mn "Sí, creo que me pondré en ello"
    mn "นั่นสินะครับ งั้นผมคงต้องเริ่มจัดการเรื่องนั้นดูหน่อยแล้ว"

# game/scripts/History/PrincipalStory/Prologo.rpy:1399
translate english prologo__635228e8:

    # mn "Fue de mucha ayuda, Lord Orochimaru, se lo agradezco mucho"
    mn "ท่านโอโรจิมารุช่วยได้มากเลยล่ะครับ ผมซาบซึ้งจริงๆ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1402
translate english prologo__bbdf1b94:

    # oro "Fue un placer ayudar"
    oro "ยินดีที่ได้ช่วยนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1406
translate english prologo__fbf1b899:

    # sr "En ese caso ya podemos irnos"
    sr "ถ้าอย่างนั้นพวกเราก็ไปกันเถอะค่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1410
translate english prologo__a386f3ba:

    # kr "Mientras más tarden en irse, más tarde se hará"
    kr "ยิ่งเธอชักช้า เดี๋ยวก็จะยิ่งดึกเอานะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1415
translate english prologo__ffeb4cd8:

    # mn "Tienes razón, volvamos a la aldea"
    mn "นั่นสินะ กลับหมู่บ้านกันเถอะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1420
translate english prologo__099315a5:

    # kr "Nos vemos chicos"
    kr "ไว้เจอกันนะพวกเธอ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1423
translate english prologo__decd6aab:

    # sr "Nos vemos, hasta otra"
    sr "ไว้เจอกันใหม่โอกาสหน้านะคะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1426
translate english prologo__395ca8a1:

    # n "Luego de salir junto a Sarada del escondite de Orochimaru, ambos se dirigen a Konoha"
    n "หลังจากออกจากศูนย์หลบภัยของโอโรจิมารุพร้อมกับซาราดะ ทั้งคู่ก็มุ่งหน้ากลับโคโนฮะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1439
translate english prologo__16278896:

    # sr "..."
    sr "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1440
translate english prologo__4cc752d1:

    # sr "¿Cómo te sientes?"
    sr "รู้สึกยังไงบ้างเหรอคะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1441
translate english prologo__912bd6df:

    # sr "Hoy... Obtuviste mucha información de golpe"
    sr "วันนี้... นายได้รับข้อมูลรวดเดียวเยอะเลยด้วย"

# game/scripts/History/PrincipalStory/Prologo.rpy:1442
translate english prologo__be9a5fdd:

    # mn "Es... Un sentimiento extraño"
    mn "ก็... รู้สึกแปลกๆ น่ะครับ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1443
translate english prologo__3468d2b2:

    # mn "Por un lado me hizo sentir feliz el saber algo de mi pasado"
    mn "ด้านหนึ่งผมก็ดีใจนะที่ได้รู้เรื่องราวในอดีตของตัวเองบ้าง"

# game/scripts/History/PrincipalStory/Prologo.rpy:1444
translate english prologo__331ce20f:

    # mn "Pero a la vez me deprime un poco el pensar que tal vez sea el ultimo del clan Karui"
    mn "แต่ในขณะเดียวกัน การที่คิดว่าผมอาจจะเป็นคนสุดท้ายของตระกูลคารูกันมันก็ทำให้รู้สึกหดหู่ใจอยู่นิดหน่อยเหมือนกันครับ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1445
translate english prologo__16278896_1:

    # sr "..."
    sr "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1446
translate english prologo__c2038ff9:

    # sr "Entiendo como te sientes"
    sr "ฉันเข้าใจความรู้สึกของนายนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1447
translate english prologo__ad405d16:

    # sr "De no ser por mi padre, yo sería la última con sangre Uchiha que quede con vida"
    sr "ถ้าไม่ใช่เพราะคุณพ่อล่ะก็ ฉันเองก็คงจะเป็นคนสุดท้ายที่มีสายเลือดอุจิวะหลงเหลืออยู่เหมือนกัน"

# game/scripts/History/PrincipalStory/Prologo.rpy:1448
translate english prologo__49450196:

    # sr "Y es un poco triste pensar eso..."
    sr "พอคิดแบบนั้นแล้วมันก็ออกจะเศร้าๆ อยู่นะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1449
translate english prologo__caa4cee6:

    # mn "Oh, lo siento, no sabía que te sentías así"
    mn "อ๊ะ ผมขอโทษด้วยนะครับ ไม่รู้มาก่อนเลยว่าเธอจะรู้สึกแบบนั้นเหมือนกัน"

# game/scripts/History/PrincipalStory/Prologo.rpy:1450
translate english prologo__d6112545:

    # sr "No te preocupes por eso, no es tan grave como lo tuyo"
    sr "ไม่ต้องคิดมากหรอก มันไม่ได้หนักหนาเท่าเรื่องของนายหรอกน่า"

# game/scripts/History/PrincipalStory/Prologo.rpy:1451
translate english prologo__87a5ec3a:

    # sr "Seguro tienes muchas cosas que pensar"
    sr "ฉันแน่ใจว่านายคงมีเรื่องให้ต้องคิดเยอะแยะเลยล่ะสิ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1452
translate english prologo__9f157e1d:

    # sr "Una vez lleguemos a la aldea ve a tu casa a descansar, yo me encargaré de darle el reporte al Hokage"
    sr "พอถึงหมู่บ้านแล้วนายกลับไปพักผ่อนที่บ้านเถอะ เดี๋ยวเรื่องรายงานท่านโฮคาเงะฉันจัดการเอง"

# game/scripts/History/PrincipalStory/Prologo.rpy:1453
translate english prologo__5aac7052:

    # mn "¿Estás segura?"
    mn "แน่ใจเหรอครับ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1454
translate english prologo__a95d8d38:

    # sr "No quiero escuchar un no como respuesta"
    sr "ห้ามปฏิเสธเด็ดขาดนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1455
translate english prologo__179e9f6a:

    # mn "Jaja, en verdad te lo agradezco mucho Sarada"
    mn "ฮ่าๆ ขอบคุณมากๆ เลยนะ ซาราดะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1456
translate english prologo__405a0c53:

    # sr "No es nada, para eso son los amigos"
    sr "เรื่องแค่นี้เอง เพื่อนกันซะเปล่า"

# game/scripts/History/PrincipalStory/Prologo.rpy:1459
translate english prologo__d896f0be:

    # n "Una vez que llegan a Konoha ambos se despiden y toman caminos separados"
    n "หลังจากมาถึงโคโนฮะ ทั้งคู่ก็บอกลาและแยกย้ายกันกลับบ้าน"

# game/scripts/History/PrincipalStory/Prologo.rpy:1460
translate english prologo__36eda554:

    # n "Hasta que finalmente [MN] llega a casa"
    n "จนกระทั่งในที่สุด [MN] ก็กลับมาถึงบ้าน"

# game/scripts/History/PrincipalStory/Prologo.rpy:1467
translate english prologo__c4e64238:

    # mn "Aaah, estoy cansado... Hoy fue un día muy largo"
    mn "อ่า... เหนื่อยเป็นบ้าเลย วันนี้เป็นวันที่ยาวนานจริงๆ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1469
translate english prologo__494cb6a2:

    # mn "Bueno, Sarada me ahorró el ir donde el Hokage"
    mn "แถมซาราดะยังช่วยให้ผมไม่ต้องไปเจอโฮคาเงะอีกต่างหาก"

# game/scripts/History/PrincipalStory/Prologo.rpy:1471
translate english prologo__3d5e3e6a:

    # mn "Ahora tengo algo de tiempo para mí"
    mn "ตอนนี้ผมมีเวลาส่วนตัวเหลือเฟือเลยล่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1473
translate english prologo__32462c4b_4:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1475
translate english prologo__215d675a:

    # mn "Aún sigo pensando pensando en lo de mi clan..."
    mn "ผมยังคิดเรื่องตระกูลของตัวเองอยู่เลย..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1477
translate english prologo__be495b4a:

    # mn "Y pensar que me enteré de todo eso hoy por suerte meramente"
    mn "ไม่นึกเลยว่าวันนี้จะได้รู้เรื่องพวกนั้นโดยบังเอิญแท้ๆ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1479
translate english prologo__56daa2cc:

    # mn "De no haber activado el... Karugan, ¿No?... Me hubiera metido en un problema muy grande hoy"
    mn "ถ้าเมื่อกี้ผมไม่ได้ปลุก... คารูกันขึ้นมาล่ะก็... วันนี้คงแย่แน่ๆ เลย"

# game/scripts/History/PrincipalStory/Prologo.rpy:1481
translate english prologo__32462c4b_5:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1483
translate english prologo__c5f42a3e:

    # mn "Mi clan me salvó"
    mn "ตระกูลของผมช่วยผมไว้สินะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1485
translate english prologo__4f96593f:

    # mn "Joder, ¿Realmente soy la última persona que queda con vida de los Karui?"
    mn "ให้ตายสิ ผมเป็นคนสุดท้ายของตระกูลคารูกันที่ยังมีชีวิตอยู่จริงๆ งั้นเหรอ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1487
translate english prologo__d6689c62:

    # mn "Existe la posibilidad de que no sea el caso..."
    mn "มันก็อาจจะไม่ใช่แบบนั้นก็ได้นะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1491
translate english prologo__120917d7:

    # n "Llega un mensaje al teléfono"
    n "มีข้อความส่งเข้ามาในมือถือ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1492
translate english prologo__9a7b0c62:

    # mn "¿Quién será a esta hora?"
    mn "ใครกันนะส่งมาป่านนี้?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1495
translate english prologo__f8275cc8:

    # mn "Quiere que me reúna con él cuando tenga algo de tiempo..."
    mn "เขาอยากให้ฉันไปพบตอนที่พอมีเวลาว่าง..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1497
translate english prologo__6ae664e6:

    # mn "Bueno... También es verdad que puedo salir un rato..."
    mn "อืม... ออกไปข้างนอกสักพักก็ไม่เลวเหมือนกัน..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1499
translate english prologo__04cac574:

    # mn "Mantener la mente ocupada también me viene bien"
    mn "หาอะไรทำเบี่ยงเบนความสนใจซะบ้างน่าจะดีกับตัวผมเหมือนกัน"

# game/scripts/History/PrincipalStory/Prologo.rpy:1501
translate english prologo__98f808b8:

    # mn "Sobrepensar las cosas no me resulta muy útil en este momento con la poca información que tengo"
    mn "ขืนคิดมากไปตอนนี้ที่มีข้อมูลอยู่น้อยนิดก็คงไม่ได้อะไรขึ้นมาหรอก"

# game/scripts/History/PrincipalStory/Prologo.rpy:1503
translate english prologo__1c69b541:

    # mn "Por ahora creo que iré a dar una vuelta por la aldea, y quizás vaya a ver que quiere el sensei"
    mn "ตอนนี้ออกไปเดินเล่นรอบหมู่บ้านหน่อยดีกว่า เผื่อแวะไปดูซะหน่อยว่าอาจารย์เรียกพบเรื่องอะไร"
# TODO: Translation updated at 2024-02-17 12:30

# game/scripts/History/PrincipalStory/Prologo.rpy:190
translate english Prologo_ef8bd713:

    # d "Y este dijo que se llamaría {color=#f3c271}[MN]{/a}"
    d "แถมเขายังบอกอีกว่าเขาจะชื่อว่า {color=#f3c271}[MN]{/a}"

# game/scripts/History/PrincipalStory/Prologo.rpy:191
translate english Prologo_c93ade31:

    # d "Ese día lo ví muy féliz..."
    d "วันนั้นฉันเห็นเขามีความสุขมากๆ เลยล่ะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:192
translate english Prologo_646e693f:

    # d "Le pregunté porqué ese nombre..."
    d "ฉันเลยลองถามเขาดูว่าทำไมถึงเลือกชื่อนั้น..."

# game/scripts/History/PrincipalStory/Prologo.rpy:193
translate english Prologo_028b34c0:

    # d "Me dijo que era el nombre del protagonista de un libro"
    d "เขาบอกฉันว่านั่นเป็นชื่อตัวเอกในหนังสือเล่มหนึ่งน่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:194
translate english Prologo_a20cefa7_4:

    # "..."
    "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:195
translate english Prologo_3e78d374:

    # d "Recuerdo que también me preguntó sobre mi profesión"
    d "ฉันจำได้ว่าเขาเคยถามฉันเกี่ยวกับอาชีพของฉันด้วย"

# game/scripts/History/PrincipalStory/Prologo.rpy:196
translate english Prologo_a4019395:

    # d "Por lo que le conté sobre la aldea, los ninjas y el Hokage"
    d "นั่นแหละคือสาเหตุที่ฉันเล่าเรื่องหมู่บ้าน เรื่องนินจา และเรื่องท่านโฮคาเงะให้เขาฟัง"

# game/scripts/History/PrincipalStory/Prologo.rpy:197
translate english Prologo_ee96b4c2:

    # d "Mostrando también un gran interés por ser un ninja"
    d "แถมเขายังแสดงความสนใจอย่างมากที่จะเป็นนินจาด้วย"

# game/scripts/History/PrincipalStory/Prologo.rpy:198
translate english Prologo_b0ceada0:

    # d "Le recomendé que se esforzara para que pudiera presentar el examen en la academia ninja"
    d "ฉันเลยแนะนำให้เขาพยายามเข้า จะได้ไปสอบเข้าสถาบันนินจาได้"

# game/scripts/History/PrincipalStory/Prologo.rpy:199
translate english Prologo_d05ac47d:

    # d "Pidiéndome ayuda para entrenar, le terminé enseñando lo necesario para que aprobara el examen"
    d "เขาขอให้ฉันช่วยฝึกฝนให้อย่างจริงจัง สุดท้ายฉันเลยต้องคอยสอนพื้นฐานที่จำเป็นในการสอบผ่านให้กับเขา"

# game/scripts/History/PrincipalStory/Prologo.rpy:208
translate english Prologo_44857b83:

    # d "Mostrando ya no solo interés, sino también potencial para ser un ninja"
    d "เขาไม่ได้แสดงแค่ความสนใจเท่านั้น แต่ยังมีแววและศักยภาพที่จะเป็นนินจาได้ด้วย"

# game/scripts/History/PrincipalStory/Prologo.rpy:209
translate english Prologo_467f2151:

    # d "Al final aprobó el examen y se convirtió en Genin"
    d "และในที่สุดเขาก็สอบผ่านจนได้เป็นเกะนิน"

# game/scripts/History/PrincipalStory/Prologo.rpy:210
translate english Prologo_bce214e2:

    # d "En dónde le fue asignado un equipo"
    d "ซึ่งเขาถูกจัดให้อยู่ในทีมเดียวกัน"

# game/scripts/History/PrincipalStory/Prologo.rpy:221
translate english Prologo_434b3711:

    # d "Su Sensei {color=#f3c271}Zubon{/a}, y sus dos compañeros, {color=#f3c271}Hideo{/a} y {color=#f3c271}Yuna{/a}"
    d "โดยมีอาจารย์ประจำทีมคือ {color=#f3c271}ซูบง{/a} และเพื่อนร่วมทีมอีกสองคนคือ {color=#f3c271}ฮิเดโอะ{/a} กับ {color=#f3c271}ยูนะ{/a}"

# game/scripts/History/PrincipalStory/Prologo.rpy:222
translate english Prologo_b66a3208:

    # d "Poco a poco terminó adaptándose y volviéndose uno más de la aldea"
    d "ทีละเล็กทีละน้อย เขาก็ปรับตัวจนกลายเป็นส่วนหนึ่งของหมู่บ้านเราไปในที่สุด"

# game/scripts/History/PrincipalStory/Prologo.rpy:224
translate english Prologo_a20cefa7_5:

    # "..."
    "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:225
translate english Prologo_7cec982c:

    # d "Hoy en día..."
    d "ในปัจจุบันนี้..."

# game/scripts/History/PrincipalStory/Prologo.rpy:228
translate english Prologo_567169e8:

    # d "Es todo un hombre, no es para nada ese chico tímido que fue alguna vez, o eso parece"
    d "เขาเติบโตเป็นชายหนุ่มเต็มตัวแล้ว ไม่ใช่เด็กผู้ชายขี้อายคนเดิมในอดีตอีกต่อไป... หรืออย่างน้อยก็ดูเหมือนจะเป็นแบบนั้นนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:229
translate english Prologo_1db2c194:

    # d "Iré a visitarlo para charlar con él, como en los viejos tiempos"
    d "ฉันจะไปเยี่ยมเขาสักหน่อย ไปนั่งคุยกันเหมือนวันวานเก่าๆ"

# game/scripts/History/PrincipalStory/Prologo.rpy:230
translate english Prologo_100928e2:

    # d "Espero no esté ocupado"
    d "หวังว่าเขาคงไม่ยุ่งอยู่นะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:233
translate english Prologo_a20cefa7_6:

    # "..."
    "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:236
translate english Prologo_e1eb59fe:

    # n "-EN LA ACTUALIDAD-"
    n "-ปัจจุบัน-"

# game/scripts/History/PrincipalStory/Prologo.rpy:237
translate english Prologo_a20cefa7_7:

    # "..."
    "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:238
translate english Prologo_93cf0365:

    # mn "Oh..."
    mn "อืม..."

# game/scripts/History/PrincipalStory/Prologo.rpy:242
translate english Prologo_ee0ace93:

    # mn "Vaya.."
    mn "โห..."

# game/scripts/History/PrincipalStory/Prologo.rpy:243
translate english Prologo_38a5d262:

    # mn "Con que ella hizo eso..."
    mn "งั้นเธอว์ก็ทำแบบนั้นเหรอเนี่ย..."

# game/scripts/History/PrincipalStory/Prologo.rpy:244
translate english Prologo_81f7ca0b:

    # mn "¿Y apretó su...?"
    mn "แถมยังบีบตรงนั้นของเธอ...?"

# game/scripts/History/PrincipalStory/Prologo.rpy:245
translate english Prologo_79242173:

    # mn "Me pregunto que se habría sentido hacer eso... Lástima que no pude haberlo intentado cuando tenía oportunidad..."
    mn "ชักสงสัยจังแฮะว่าถ้าทำแบบนั้นมันจะรู้สึกยังไง... น่าเสียดายชะมัดที่ตอนมีโอกาสดันไม่ได้ลองดู..."

# game/scripts/History/PrincipalStory/Prologo.rpy:248
translate english Prologo_b919c54d:

    # "{b}Alguien toca la puerta{/b}"
    "{b}มีเสียงเคาะประตู@{/b}"

# game/scripts/History/PrincipalStory/Prologo.rpy:249
translate english Prologo_f023f1d7:

    # mn "¡¿Eh, q-quién es?!"
    mn "หา ใครมาเคาะประตูเอาป่านนี้เนี่ย?!"

# game/scripts/History/PrincipalStory/Prologo.rpy:250
translate english Prologo_a5d7cd39:

    # sr "Soy yo, Sarada"
    sr "ฉันเอง ซาราดะจ้ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:251
translate english Prologo_88e122cb:

    # mn "(Mierda...)"
    mn "(ซวยแล้ว...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:252
translate english Prologo_1ba8a0da:

    # sr "¿Estás ocupado?"
    sr "ยุ่งอยู่หรือเปล่า?"

# game/scripts/History/PrincipalStory/Prologo.rpy:253
translate english Prologo_c147e2c2:

    # mn "Eh... ¡N-No!, voy en un momento..."
    mn "เอ่อ... ม-ไม่ยุ่ง! เดี๋ยวฉันออกไปเปิดให้เดี๋ยวนี้แหละ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:254
translate english Prologo_abfc44c0:

    # n "[MN] se cambió y escondió el libro lo más rápido posible"
    n "[MN] เปลี่ยนเสื้อผ้าและซ่อนหนังสืออย่างรวดเร็วที่สุด"

# game/scripts/History/PrincipalStory/Prologo.rpy:261
translate english Prologo_e1590592:

    # mn "Listo... ¡Ahora abro!"
    mn "เสร็จแล้ว... จะเปิดประตูแล้วนะ!"

# game/scripts/History/PrincipalStory/Prologo.rpy:265
translate english Prologo_94810809:

    # mn "(Joder... Casi me atrapa...)"
    mn "(ให้ตายสิ... เกือบไปแล้วมั้ยล่ะ...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:271
translate english Prologo_4bdce36e:

    # n "[MN] abre la puerta, dejando entrar a Sarada"
    n "[MN] เปิดประตูแล้วปล่อยให้ซาราดะเดินเข้ามา"

# game/scripts/History/PrincipalStory/Prologo.rpy:277
translate english Prologo_807610b5:

    # mn "Hola, ¿Qué tal, Sarada? Disculpa que me haya tardado..."
    mn "อ้าว ซาราดะ เป็นไงมาไงเนี่ย? โทษทีนะที่ให้รอซะนาน..."

# game/scripts/History/PrincipalStory/Prologo.rpy:280
translate english Prologo_eb2870c4:

    # sr "No te preocupes por eso"
    sr "ไม่ต้องคิดมากหรอกจ้ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:283
translate english Prologo_ddc0d9a0:

    # mn "¿A qué debo esta agradable visita?"
    mn "ลมอะไรหอบเธอมาถึงนี่ได้ล่ะเนี่ย?"

# game/scripts/History/PrincipalStory/Prologo.rpy:286
translate english Prologo_b5b878c7:

    # sr "Acabo de llegar de una misión, y quería pasar a saludarte"
    sr "ฉันเพิ่งกลับมาจากทำภารกิจน่ะ เลยอยากแวะมาทักทายสักหน่อย"

# game/scripts/History/PrincipalStory/Prologo.rpy:289
translate english Prologo_177faa85:

    # mn "Genial, ¿Y cómo te fue?, ¿No te ocurrió nada?"
    mn "เยี่ยมเลย แล้วเป็นไงบ้าง? ไม่มีอะไรแย่เกิดขึ้นกับเธอใช่ไหม?"

# game/scripts/History/PrincipalStory/Prologo.rpy:292
translate english Prologo_a251872f:

    # sr "No fue nada que no pudiera manejar"
    sr "ก็ไม่มีอะไรที่ฉันรับมือไม่ไหวหรอกนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:295
translate english Prologo_96a52d7d:

    # mn "Bueno, eso es evidente, tú eres increible"
    mn "แหงอยู่แล้ว ก็เธอน่ะเก่งจะตายนี่นา"

# game/scripts/History/PrincipalStory/Prologo.rpy:298
translate english Prologo_0e850a53:

    # sr "Jeje, no es para tanto"
    sr "คิกคิก เรื่องแค่นี้เองน่า"

# game/scripts/History/PrincipalStory/Prologo.rpy:300
translate english Prologo_0ffb8736:

    # sr "Bueno..."
    sr "ว่าแต่..."

# game/scripts/History/PrincipalStory/Prologo.rpy:302
translate english Prologo_29e42389:

    # sr "¿Qué tal te va a tí?"
    sr "ช่วงนี้เป็นยังไงบ้างล่ะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:304
translate english Prologo_0611a956:

    # sr "¿Sigues haciendo misiones de rango D?"
    sr "นายยังรับทำภารกิจระดับ D อยู่อีกเหรอ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:307
translate english Prologo_fe65b44b:

    # mn "Si... De algo tengo que comer jaja"
    mn "อือ... ก็ต้องหาเงินมากินมาใช้บ้างล่ะนะ ฮ่าๆ"

# game/scripts/History/PrincipalStory/Prologo.rpy:310
translate english Prologo_cd827254:

    # sr "En eso tienes razón... Aunque si solo lo haces por dinero..."
    sr "นั่นก็จริง... ถึงทำแค่วิธีนั้นเพื่อหาเงินก็เถอะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:312
translate english Prologo_9f44fd93:

    # sr "También podrías ayudar a otras personas en la aldea a cambio de algo de dinero"
    sr "เธอน่าจะลองไปช่วยงานคนอื่นในหมู่บ้านเพื่อแลกกับเงินบ้างก็ได้นะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:315
translate english Prologo_8b287ff9:

    # mn "No es mala idea, así puedo matar un poco más el tiempo a la espera de una misión de mayor rango"
    mn "ก็ไม่เลวนะ ถือซะว่าฆ่าเวลาตอนรอภารกิจระดับสูงกว่านี้ไปด้วยในตัว"

# game/scripts/History/PrincipalStory/Prologo.rpy:318
translate english Prologo_d13e4d5e:

    # sr "Me alegra que lo tengas en cuenta"
    sr "ดีใจนะที่เธอคิดแบบนั้นน่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:321
translate english Prologo_5065d38d:

    # mn "Por cierto ¿Como está tu madre?"
    mn "ว่าแต่ แม่ของเธอเป็นยังไงบ้างล่ะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:324
translate english Prologo_ac9f701f:

    # sr "¿Por qué no vas a verla por ti mismo?, seguro le daría gusto verte"
    sr "ทำไมไม่ลองแวะไปหาท่านด้วยตัวเองดูล่ะ? ท่านต้องดีใจแน่เลยที่ได้เจอเธออีกครั้ง"

# game/scripts/History/PrincipalStory/Prologo.rpy:327
translate english Prologo_68b077df:

    # mn "Sí, tienes razón... Tal vez lo haga luego"
    mn "อืม เธอก พูดถูก... ไว้ว่างๆ ค่อยแวะไปก็แล้วกัน"

# game/scripts/History/PrincipalStory/Prologo.rpy:330
translate english Prologo_349f601c:

    # sr "¿Estás bien? Te noto un poco agitado"
    sr "เป็นอะไรหรือเปล่า? ดูลุกลี้ลุกลนพิกลนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:334
translate english Prologo_83a06f2f:

    # mn "(¿Se dió cuenta?)"
    mn "(ยัยนี่สังเกตเห็นเหรอเนี่ย?)"

# game/scripts/History/PrincipalStory/Prologo.rpy:337
translate english Prologo_d3dc9519:

    # mn "Oh, sí, sí.. es que estaba haciendo un poco de ejercicio aquí..."
    mn "อ๋อ ใช่ๆ... พอดีฉันกำลังออกกำลังกายอยู่นิดหน่อยน่ะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:340
translate english Prologo_ccd44fc5:

    # sr "Ya veo... Así que aún te sigues manteniendo en forma"
    sr "งั้นเหรอ... แสดงว่าเธอยยังรักษาร่างกายให้ฟิตอยู่สินะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:343
translate english Prologo_0e9b1d9f:

    # mn "En forma... Sí..."
    mn "ฟิต... ใช่แล้ว..."

# game/scripts/History/PrincipalStory/Prologo.rpy:345
translate english Prologo_cd034fa5:

    # mn "Por ahora, ¿Qué tal si vamos a comer a Ichiraku? Para ponernos al día"
    mn "งั้นตอนนี้ เราไปหาอะไรกินที่อิจิราคุดีไหม? ไปนั่งคุยอัปเดตเรื่องต่างๆ กันหน่อย"

# game/scripts/History/PrincipalStory/Prologo.rpy:348
translate english Prologo_107f3510:

    # sr "Bien, me gusta la idea"
    sr "เอาสิ ฉันชอบไอเดียนี้เหมือนกัน"

# game/scripts/History/PrincipalStory/Prologo.rpy:350
translate english Prologo_f29bae33:

    # sr "Tengo un poco de tiempo libre, así que no hay problema"
    sr "ฉันพอมีเวลาว่างอยู่ ไม่มีปัญหาอยู่แล้วล่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:353
translate english Prologo_6ba3d00d:

    # mn "Bien, entonces lo mejor será irnos ya, solo dame un momento para estar listo"
    mn "งั้นเราไปกันตอนนี้เลยดีกว่า รอแป๊บเดียวนะ ขอฉันเตรียมตัวสักครู่"

# game/scripts/History/PrincipalStory/Prologo.rpy:358
translate english Prologo_1e764614:

    # sr "De acuerdo"
    sr "ได้จ้ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:360
translate english Prologo_a131e229:

    # sr "Te espero afuera miestras"
    sr "งั้นฉันไปรอข้างนอกก่อนนะ ระหว่างนี้"

# game/scripts/History/PrincipalStory/Prologo.rpy:363
translate english Prologo_86ce38fd:

    # n "Sarada sale del departamento"
    n "ซาราดะเดินออกจากห้องพักไป"

# game/scripts/History/PrincipalStory/Prologo.rpy:365
translate english Prologo_34cb155b:

    # mn "Joder... Eso estuvo cerca"
    mn "ให้ตายสิ... เกือบไปแล้วไหมล่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:367
translate english Prologo_ceb8769e:

    # mn "Un poco más y me descubre..."
    mn "อีกนิดเดียวก็เกือบโดนจับได้แล้วเชียว..."

# game/scripts/History/PrincipalStory/Prologo.rpy:369
translate english Prologo_50f37ce0:

    # mn "Bueno, me vestiré rápidamente, no quiero hacerla esperar"
    mn "เอาล่ะ รีบแต่งตัวดีกว่า ไม่อยากปล่อยให้เธอรอนาน"

# game/scripts/History/PrincipalStory/Prologo.rpy:374
translate english Prologo_eebdf2ba:

    # n "[MN] se prepara y sale de casa junto a Sarada, para ambos dirigirse a Ichiraku Ramen"
    n "[MN] เตรียมตัวเสร็จแล้วก็ออกจากบ้านไปกับซาราดะ ทั้งคู่มุ่งหน้าไปยังร้านราเม็งอิจิราคุ"

# game/scripts/History/PrincipalStory/Prologo.rpy:391
translate english Prologo_d2f3f798:

    # sr "Mmm... El ramen de Ichiraku Ramen es el mejor"
    sr "อื้ม... ราเม็งของร้านอิจิราคุเนี่ยอร่อยที่สุดเลย"

# game/scripts/History/PrincipalStory/Prologo.rpy:392
translate english Prologo_7ab85ff6:

    # mn "Ooh si..."
    mn "นั่นสิ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:394
translate english Prologo_f2931cee:

    # mn "Y que lo digas, desde que llegué a la aldea este siempre ha sido mi restaurante favorito"
    mn "จริงด้วย ตั้งแต่ฉันมาที่หมู่บ้านนี้ ที่นี่ก็เป็นร้านโปรดของฉันมาตลอดเลยล่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:398
translate english Prologo_1b558f35:

    # sr "Eso pude notar luego de comerte tantos tazones"
    sr "สังเกตจากที่ซัดไปซะหลายชามนั่นแหละนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:401
translate english Prologo_5ed6db3d:

    # mn "Jajaja, es que es inevitable no comer tantos tazones de Ramen"
    mn "ฮ่าๆๆ ก็มันอดใจไม่ให้กินราเม็งหลายๆ ชามได้ซะที่ไหนล่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:403
translate english Prologo_50f2a33c:

    # mn "Uff.. estoy que reviento..."
    mn "อื๋อ... แน่นท้องจะตายอยู่แล้ว..."

# game/scripts/History/PrincipalStory/Prologo.rpy:405
translate english Prologo_301def01:

    # sr "Jajaja..."
    sr "ฮ่าๆๆ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:407
translate english Prologo_1b9fc9b7:

    # mn "Tengo que salir más seguido contigo, realmente disfruto mucho tu compañía"
    mn "ฉันน่าจะชวนเธอออกมาเที่ยวด้วยกันบ่อยๆ นะเนี่ย อยู่กับเธอแล้วสนุกจริงๆ เลย"

# game/scripts/History/PrincipalStory/Prologo.rpy:410
translate english Prologo_2ec51f55:

    # sr "El sentimiento es mutuo"
    sr "ฉันก็รู้สึกเหมือนกันจ่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:428
translate english Prologo_8b54f21e:

    # sr "Y... Quisiera quedarme un poco más, pero ya tengo que irme"
    sr "งั้น... ฉันอยากจะอยู่ต่ออีกสักหน่อยนะ แต่ต้องไปแล้วล่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:438
translate english Prologo_62868ee4:

    # mn "Está bien, fue un gusto haber pasado el rato contigo"
    mn "อื้ม ดีใจที่ได้มาเที่ยวด้วยกันนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:441
translate english Prologo_136b1983:

    # sr "Igualmente"
    sr "เช่นกันจ่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:445
translate english Prologo_dfdab6e6:

    # sr "Hasta luego"
    sr "ไว้เจอกันนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:448
translate english Prologo_f9857bc1:

    # n "Sarada se despide con una sonrisa"
    n "ซาราดะกล่าวลาพร้อมกับรอยยิ้ม"

# game/scripts/History/PrincipalStory/Prologo.rpy:451
translate english Prologo_201d9475:

    # mn "Es una buena amiga..."
    mn "เป็นเพื่อนที่ดีจริงๆ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:453
translate english Prologo_10365187:

    # ay "Vaya... Así que le tienes el ojo encima..."
    ay "โฮห... เล็งยัยนั่นไว้สินะเนี่ย..."

# game/scripts/History/PrincipalStory/Prologo.rpy:454
translate english Prologo_a5eb1bf5:

    # mn "¿Mmm?"
    mn "หืมน์?"

# game/scripts/History/PrincipalStory/Prologo.rpy:487
translate english Prologo_f6bae0e8:

    # mn "¿Yo?"
    mn "ฉันเนี่ยนะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:490
translate english Prologo_6f602591:

    # ay "Sí, a Sarada"
    ay "ใช่ ก็ซาราดะไงล่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:493
translate english Prologo_93aa89cd:

    # mn "¿Qué? Naaah..."
    mn "หา? เปล่าซะหน่อย..."

# game/scripts/History/PrincipalStory/Prologo.rpy:495
translate english Prologo_34de67b4:

    # mn "Sarada y yo solo somos... Amigos"
    mn "ฉันกับซาราดะเป็นแค่... เพื่อนกัน"

# game/scripts/History/PrincipalStory/Prologo.rpy:498
translate english Prologo_07a76f54:

    # ay "¿Y eso qué tiene? Ese es el punto de partida..."
    ay "แล้วมันเสียหายตรงไหนล่ะ? นั่นมันก็แค่จุดเริ่มต้น..."

# game/scripts/History/PrincipalStory/Prologo.rpy:500
translate english Prologo_6a65ea56:

    # ay "Sé honesto conmigo, ¿Después de tantos años no sientes nada más que amistad por ella?"
    ay "พูดความจริงกับฉันมาซิ รู้จักกันมาตั้งหลายปี ไม่เคยรู้สึกอะไรเกินเพื่อนเลยจริงดิ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:503
translate english Prologo_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:505
translate english Prologo_3e91a61d:

    # mn "T-Tal vez... No lo sé..."
    mn "อ-อาจจะ... ฉันก็ไม่รู้เหมือนกัน..."

# game/scripts/History/PrincipalStory/Prologo.rpy:508
translate english Prologo_d267b7ff:

    # ay "¡Lo sabía!"
    ay "รู้อยู่แล้วเชียว!"

# game/scripts/History/PrincipalStory/Prologo.rpy:511
translate english Prologo_22f21fed:

    # mn "Oye, dije -Tal vez- realmente no estoy seguro..."
    mn "เดี๋ยวสิ ฉันบอกว่า -อาจจะ- ต่างหาก ยังไม่แน่ใจสักหน่อย..."

# game/scripts/History/PrincipalStory/Prologo.rpy:514
translate english Prologo_0cbdcd47:

    # ay "Entiendo, entiendo... Aún indeciso jeje"
    ay "เข้าใจแล้วๆ... ยังลังเลอยู่สินะเนี่ย ฮิฮิ"

# game/scripts/History/PrincipalStory/Prologo.rpy:516
translate english Prologo_5a996065:

    # ay "Ella ha crecido mucho también eh, seguro que ya se fija un poco más en los chicos"
    ay "แถมพักนี้เธอก็โตเป็นสาวขึ้นเยอะเลยด้วยนะ ฉันพนันได้เลยว่าช่วงนี้เธอต้องเริ่มสนใจพวกผู้ชายขึ้นมาบ้างแล้วแหละ"

# game/scripts/History/PrincipalStory/Prologo.rpy:518
translate english Prologo_09f8c195:

    # ay "Yo digo que si te interesa puedes intentar mostrar tu lado seductor con ella"
    ay "ฉันว่านะ ถ้าสนใจล่ะก็ ลองโชว์เสน่ห์มัดใจเธอหน่อยเป็นไง"

# game/scripts/History/PrincipalStory/Prologo.rpy:521
translate english Prologo_ac594416:

    # mn "¿A qué te refieres con -Lado seductor-?"
    mn "ที่พูดว่า -มุมเย้ายวนใจ- เนี่ยหมายความว่ายังไงกัน?"

# game/scripts/History/PrincipalStory/Prologo.rpy:524
translate english Prologo_3c12014c:

    # ay "Conquístala, ya sabes... Coquetearle, darle regalos, incluso podrías invitarla a una cita..."
    ay "พิชิตใจเธอยังไงล่ะ รู้จักไหม... หยอดคำหวานใส่ หาของขวัญให้ หรือจะชวนเธอไปเดทก็ได้นะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:529
translate english Prologo_8b260cb8:

    # mn "(No creo que Sarada sea fácil de conquistar... O si yo sea su tipo...)"
    mn "(ฉันว่าซาราดะไม่ได้จีบติดง่ายๆ ขนาดนั้นหรอกมั้ง... หรือฉันจะไม่ใช่สเปกเธอเลยวะเนี่ย...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:532
translate english Prologo_c485fb29:

    # mn "Ahh, no estoy tan seguro si Sarada sea el tipo de chica que le gustan esas cosas..."
    mn "อ่า ฉันไม่ค่อยแน่ใจเท่าไหร่หรอกนะว่าซาราดะจะเป็นผู้หญิงที่ชอบอะไรแบบนั้นน่ะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:534
translate english Prologo_00152c3f:

    # mn "Y si fuera el caso, yo tampoco es que sepa mucho sobre coquetear y esas cosas"
    mn "แล้วต่อให้ใช่ขึ้นมาจริงๆ ฉันก็ไม่ค่อยรู้เรื่องเกี่ยวกับการจีบสาวอะไรพวกนั้นด้วยสิ"

# game/scripts/History/PrincipalStory/Prologo.rpy:537
translate english Prologo_d3849f9e:

    # ay "Espera, ¿No tenías novia antes?, ¿Cómo la conquistaste a ella?"
    ay "เดี๋ยวนะ นายเคยมีแฟนมาก่อนไม่ใช่เหรอ? ไปจีบเขายังไงล่ะนั่น?"

# game/scripts/History/PrincipalStory/Prologo.rpy:540
translate english Prologo_6e9c342a:

    # mn "Pues, realmente ella me conquistó a mí"
    mn "ก็... พูดตามตรงเลยนะ คือฝ่ายนั้นเป็นคนเข้ามาจีบฉันเองต่างหากล่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:543
translate english Prologo_b6aa6c27:

    # mn "Tú ya sabes como era cuando llegué a la aldea, era bastante callado, y solo hablaba con Sarada"
    mn "ก็น่าจะรู้อยู่แล้วนี่ว่าตอนที่ฉันมาถึงหมู่บ้านใหม่ ๆ มันค่อนข้างเงียบเหงา แล้วฉันก็คุยอยู่กับแค่ซาราดะคนเดียว"

# game/scripts/History/PrincipalStory/Prologo.rpy:545
translate english Prologo_706784ee:

    # mn "Y no sé que vió en mí y empezó a acercarse"
    mn "แล้วก็ไม่รู้เหมือนกันว่าเธอเห็นอะไรในตัวฉัน ถึงได้เริ่มเข้ามาตีสนิทก่อน"

# game/scripts/History/PrincipalStory/Prologo.rpy:547
translate english Prologo_c89d177c:

    # mn "Pero actualmente estoy solo, terminé con ella hace un tiempo"
    mn "แต่ตอนนี้ฉันโสดแล้วล่ะ เพิ่งเลิกกับเธอไปได้สักพักแล้วด้วย"

# game/scripts/History/PrincipalStory/Prologo.rpy:549
translate english Prologo_a9f82d0e:

    # mn "Pero no, no sé como coquetear"
    mn "แต่เอาเถอะ ฉันไม่รู้วิธีจีบใครหรอกนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:552
translate english Prologo_7222e45a:

    # ay "Ya veo..."
    ay "งั้นเหรอ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:554
translate english Prologo_1579c39e:

    # ay "Pero descuida, tal vez yo... "
    ay "แต่ก็ไม่ต้องห่วงไปหรอก บางทีฉัน..."

# game/scripts/History/PrincipalStory/Prologo.rpy:559
translate english Prologo_430a9c1b:

    # ay "Tal vez... Yo pueda ayudarte un poco con eso, siempre y cuando estés de acuerdo..."
    ay "บางที... ฉันอาจจะช่วยนายเรื่องนั้นได้บ้างนะ ถ้าไม่ว่าอะไรล่ะก็นะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:562
translate english Prologo_6a7b1dfa:

    # mn "Mmm..."
    mn "อืม..."

# game/scripts/History/PrincipalStory/Prologo.rpy:565
translate english Prologo_01382cf3:

    # mn "Aún no sé si esté listo para otra relación"
    mn "ฉันไม่รู้เหมือนกันว่าตอนนี้ตัวเองพร้อมจะมีความรักครั้งใหม่หรือยัง"

# game/scripts/History/PrincipalStory/Prologo.rpy:567
translate english Prologo_feba7fa0:

    # mn "La última terminó mal"
    mn "ครั้งล่าสุดนี่จบไม่ค่อยสวยสักเท่าไหร่ด้วยสิ"

# game/scripts/History/PrincipalStory/Prologo.rpy:570
translate english Prologo_f9d3ffb2:

    # ay "[MN], ¿Cuánto tiempo llevas desde que terminaste con tu ex?"
    ay "[MN] เลิกกับแฟนเก่าไปนานแค่ไหนแล้วเนี่ย?"

# game/scripts/History/PrincipalStory/Prologo.rpy:572
translate english Prologo_6a7b1dfa_1:

    # mn "Mmm..."
    mn "อืม..."

# game/scripts/History/PrincipalStory/Prologo.rpy:574
translate english Prologo_babdbb8a:

    # mn "Creo que hace 2 meses"
    mn "น่าจะสักสองเดือนก่อนมั้ง"

# game/scripts/History/PrincipalStory/Prologo.rpy:577
translate english Prologo_838cc566:

    # ay "Entonces... ¿Estás solo hace 2 meses?"
    ay "งั้น... ก็นั่งเหงาคนเดียวมาสองเดือนแล้วเหรอ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:579
translate english Prologo_b8ee5397:

    # ay "¿Ella no te hace falta? Estuvieron juntos por mucho tiempo..."
    ay "ไม่คิดถึงเธอหน่อยเหรอ? คบกันตั้งนานแท้ๆ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:581
translate english Prologo_91bfea64:

    # ay "¿No te sientes solo?"
    ay "ไม่รู้สึกเหงาบ้างเลยรึไง?"

# game/scripts/History/PrincipalStory/Prologo.rpy:586
translate english Prologo_32462c4b_1:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:588
translate english Prologo_85caf454:

    # ay "Oh, lo siento, no quería meterme donde no debía"
    ay "อ๊ะ ขอโทษที ฉันไม่ได้ตั้งใจจะก้าวก่ายเรื่องส่วนตัวเกินไปหรอกนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:590
translate english Prologo_32462c4b_2:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:592
translate english Prologo_ed890103:

    # mn "No te preocupes... Ya no tiene importancia"
    mn "ไม่ต้องห่วง... ช่างมันเถอะ ตอนนี้มันไม่สำคัญอีกต่อไปแล้วล่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:595
translate english Prologo_dda069db:

    # mn "Y... Sobre lo de tu propuesta, lo tendré en mente"
    mn "แล้วก็... เรื่องที่เธอเสนอมา ฉันจะเก็บไปคิดดูแล้วกัน"

# game/scripts/History/PrincipalStory/Prologo.rpy:600
translate english Prologo_56affdda:

    # ay "Bueno, está bien, si cambias de parecer, aquí estaré"
    ay "งั้นก็ไม่เป็นไร ถ้าเกิดเปลี่ยนใจเมื่อไหร่ ฉันอยู่ตรงนี้นะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:606
translate english Prologo_a32aed55:

    # mn "Claro, nos vemos luego"
    mn "อ่าไว้เจอกัน"

# game/scripts/History/PrincipalStory/Prologo.rpy:610
translate english Prologo_845628dc:

    # ay "Hasta pronto"
    ay "แล้วเจอกันนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:613
translate english Prologo_4b5a5cb6:

    # n "[MN] sale de Ichiraku para volver a su casa"
    n "[MN] เดินออกจากร้านอิจิราคุเพื่อกลับบ้าน"

# game/scripts/History/PrincipalStory/Prologo.rpy:620
translate english Prologo_43a24f8c:

    # mn "Aaah... Al fin en casa..."
    mn "ฮ้า... ถึงบ้านสักที..."

# game/scripts/History/PrincipalStory/Prologo.rpy:622
translate english Prologo_32462c4b_3:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:624
translate english Prologo_a6f1f02d:

    # mn "Ayame hizo una pregunta muy rara hoy..."
    mn "วันนี้อายะเมะถามเรื่องแปลกพิลึกแฮะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:626
translate english Prologo_b60f1081:

    # mn "¿Por qué de la nada me preguntó por ella...?"
    mn "อยู่ดีๆ ทำไมถึงถามเรื่องเธอกับฉันขึ้นมาล่ะเนี่ย..."

# game/scripts/History/PrincipalStory/Prologo.rpy:628
translate english Prologo_32462c4b_4:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:635
translate english Prologo_159c52d8:

    # mn "(A decir verdad... Solía ser muy distinto de lo que soy ahora)"
    mn "(อันที่จริง... ฉันเมื่อก่อนกับตอนนี้ต่างกันลิบลับเลยนะ)"

# game/scripts/History/PrincipalStory/Prologo.rpy:636
translate english Prologo_89acbb69:

    # mn "(Era inexpresivo, callado, y muy raro)"
    mn "(ทั้งไร้อารมณ์ เงียบขรึม แล้วก็แปลกคนสุดๆ)"

# game/scripts/History/PrincipalStory/Prologo.rpy:638
translate english Prologo_c76f966b:

    # mn "(No sabía donde estaba, qué me había pasado... Ni quien era...)"
    mn "(ฉันไม่รู้ด้วยซ้ำว่าตัวเองอยู่ที่ไหน เกิดอะไรขึ้นกับตัวเอง... หรือแม้แต่ว่าตัวเองเป็นใคร...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:639
translate english Prologo_2cb14cca:

    # mn "(Incluso ahora no sé muchas cosas, como quién era, o de donde provengo)"
    mn "(จนถึงตอนนี้ก็ยังมีหลายเรื่องที่ไม่รู้ อย่างเช่นตัวตนที่แท้จริงของฉัน หรือว่าฉันมาจากไหนกันแน่)"

# game/scripts/History/PrincipalStory/Prologo.rpy:640
translate english Prologo_2aec188d:

    # mn "(Si tenía padres... O hermanos...)"
    mn "(ถ้าฉันมีพ่อแม่... หรือพี่น้องล่ะก็...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:641
translate english Prologo_85b77973:

    # mn "(...)"
    mn "(...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:642
translate english Prologo_e1f995c7:

    # mn "(Antes habían personas que me veían mal...)"
    mn "(เมื่อก่อนเคยมีคนดูถูกเหงียดหยามฉันอยู่บ่อยๆ...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:643
translate english Prologo_8a67c259:

    # mn "(Los únicos que me trataban bien, eran el Séptimo Hokage, Sarada y su Familia...)"
    mn "(คนกลุ่มเดียวที่ปฏิบัติต่อฉันอย่างดี ก็มีท่านโฮคาเงะรุ่นที่ 7, ซาราดะกับครอบครัวของเธอ...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:644
translate english Prologo_337f5eba:

    # mn "(Y ella...)"
    mn "(แล้วก็ผู้หญิงคนนั้น...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:648
translate english Prologo_c38f2216:

    # mn "Agh, no quiero pensar en ella"
    mn "โธ่เว้ย ไม่อยากจะนึกถึงเธอคนนั้นเลยให้ตายสิ"

# game/scripts/History/PrincipalStory/Prologo.rpy:650
translate english Prologo_85b77973_1:

    # mn "(...)"
    mn "(...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:652
translate english Prologo_00ed7ace:

    # mn "(Ayame me preguntó si me sentía solo)"
    mn "(อายะเมะถามฉันว่า รู้สึกเหงาบ้างไหมสินะ)"

# game/scripts/History/PrincipalStory/Prologo.rpy:653
translate english Prologo_85b77973_2:

    # mn "(...)"
    mn "(...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:655
translate english Prologo_c30643ca:

    # mn "(Y es un poco triste admitirlo... Pero sí...)"
    mn "(แล้วมันก็ค่อนข้างน่าเศร้าที่จะยอมรับ... แต่ก็นั่นแหละ...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:657
translate english Prologo_f3766c69:

    # mn "(Realmente si me siento solo a veces...)"
    mn "(บางครั้งฉันก็รู้สึกเหงาขึ้นมาจริงๆ นั่นแหละ...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:658
translate english Prologo_1d2f7d89:

    # mn "(Debido a eso, empecé a buscar una forma de entretenerme cuando estoy en casa)"
    mn "(เพราะเหตุผลนั้น ฉันเลยเริ่มมองหาวิธีสร้างความบันเทิงให้ตัวเองเวลาอยู่บ้าน)"

# game/scripts/History/PrincipalStory/Prologo.rpy:659
translate english Prologo_f22b047b:

    # mn "(Empecé a leer libros, creo que fue gracias a ellos que empecé a ser alguien de mente abierta y con ganas de experimentar muchas cosas)"
    mn "(ฉันเริ่มหันมาอ่านหนังสือ คิดว่าคงเป็นเพราะพวกมันนั่นแหละที่ทำให้ฉันกลายเป็นคนใจกว้างขึ้น และอยากออกไปสัมผัสประสบการณ์อะไรตั้งหลายอย่าง)"

# game/scripts/History/PrincipalStory/Prologo.rpy:661
translate english Prologo_24853412:

    # mn "(Leí muchos libros con historias, anécdotas y personalidades diferentes)"
    mn "(ฉันอ่านหนังสือมาหลายเล่มที่มีเรื่องราว เกร็ดเล็กเกร็ดน้อย และบุคลิกตัวละครที่แตกต่างกันไป)"

# game/scripts/History/PrincipalStory/Prologo.rpy:662
translate english Prologo_d1d23e02:

    # mn "(Las cuales me dieron muchos modelos a seguir y empecé a moldear mi personalidad para intentar ser diferente)"
    mn "(ซึ่งมันทำให้ฉันมีไอดอลในดวงใจหลายคน และเริ่มหล่อหลอมบุคลิกตัวเองให้พยายามดูแตกต่างออกไป)"

# game/scripts/History/PrincipalStory/Prologo.rpy:663
translate english Prologo_66ec6a1f:

    # mn "(Aunque ahora uno de esos libros está despertando un sentimiento que pocas veces había sentido antes)"
    mn "(ถึงแม้ว่าตอนนี้ หนึ่งในหนังสือพวกนั้นกำลังปลุกเร้าความรู้สึกที่ฉันแทบจะไม่เคยสัมผัสมาก่อนขึ้นมาซะแล้ว)"

# game/scripts/History/PrincipalStory/Prologo.rpy:669
translate english Prologo_af2ca843:

    # mn "¿Dónde fue que dejé ese libro?"
    mn "ฉันเอาหนังสือเล่มนั้นไปไว้ไหนนะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:673
translate english Prologo_e27f66fb:

    # mn "Oh, aquí está"
    mn "อ่า อยู่นี่เอง"

# game/scripts/History/PrincipalStory/Prologo.rpy:676
translate english Prologo_19f85071:

    # mn "Me llamó la atención que fuera para mayores de edad"
    mn "ฉันรู้สึกสะดุดตากับการที่มันเป็นหนังสือสำหรับผู้ใหญ่เนี่ยแหละ"

# game/scripts/History/PrincipalStory/Prologo.rpy:678
translate english Prologo_5c318c9b:

    # mn "Y desde que lo comencé a leer hizo que brotara en mi, una curiosidad por saber más sobre las mujeres y cómo relacionarse con ellas"
    mn "และนับตั้งแต่เริ่มอ่านมัน ความอยากรู้อยากเห็นเกี่ยวกับผู้หญิงและวิธีเข้าหาพวกเธอ... ก็เริ่มผุดขึ้นในใจฉัน"

# game/scripts/History/PrincipalStory/Prologo.rpy:680
translate english Prologo_aae05852:

    # mn "¿A eso se refería Ayame cuando dijo que Sarada probablemente comenzó a fijarse en los chicos?"
    mn "นั่นคือสิ่งที่อายะเมะหมายถึงตอนที่บอกว่าซาราดะเริ่มสนใจพวกผู้ชายแล้วงั้นเหรอ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:682
translate english Prologo_c49239f0:

    # mn "¿Le estará pasando lo mismo que a mí?"
    mn "เรื่องแบบเดียวกันกำลังเกิดขึ้นกับเธอยู่งั้นเหรอ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:686
translate english Prologo_bbfd2dca:

    # mn "¡!"
    mn "!"

# game/scripts/History/PrincipalStory/Prologo.rpy:688
translate english Prologo_8ef9f1fc:

    # mn "Mierda, se me puso dura de nuevo..."
    mn "ให้ตายสิ ของลับตื่นตัวขึ้นมาอีกแล้ว..."

# game/scripts/History/PrincipalStory/Prologo.rpy:690
translate english Prologo_440239a5:

    # mn "Bueno... Solo para que deje de estarlo debo de..."
    mn "ให้ตายสิ... ทางเดียวที่จะทำให้มันสงบลงได้ก็คือ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:692
translate english Prologo_e5f20f72:

    # mn "Sí... Seguiré leyendo un poco más..."
    mn "อืม... อ่านต่ออีกนิดดีกว่า..."

# game/scripts/History/PrincipalStory/Prologo.rpy:695
translate english Prologo_73449b9b:

    # n "Luego de masturbarse por leer un rato más el libro Icha-Icha, [MN] cae dormido"
    n "หลังจากสำเร็จความความใคร่พร้อมกับอ่านหนังสืออิจาะอิจะต่ออีกสักพัก [MN] ก็หลับไป"

# game/scripts/History/PrincipalStory/Prologo.rpy:702
translate english Prologo_befffd7a:

    # mn "Aaaah..."
    mn "อ่าาาห์..."

# game/scripts/History/PrincipalStory/Prologo.rpy:704
translate english Prologo_e962dc9b:

    # mn "Otro nuevo día"
    mn "วันใหม่เริ่มต้นขึ้นอีกแล้ว"

# game/scripts/History/PrincipalStory/Prologo.rpy:706
translate english Prologo_215f8ec4:

    # mn "Mmm, hoy no tengo planes"
    mn "อืม วันนี้ไม่มีแผนจะทำอะไรเลยแฮะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:708
translate english Prologo_10c818f8:

    # mn "Creo que hoy saldré un rato... tal vez visite a la señora Sakura..."
    mn "วันนี้ออกไปข้างนอกสักหน่อยดีกว่า... บางทีอาจจะแวะไปหาคุณซากุระสักหน่อย..."

# game/scripts/History/PrincipalStory/Prologo.rpy:710
translate english Prologo_50674c2f:

    # mn "Sarada dijo que le daría gusto verme, y ya que tengo tiempo libre, puedo pasar a saludar"
    mn "ซาราดะบอกว่าเธอคงดีใจที่จะได้เจอฉัน แล้วในเมื่อฉันมีเวลาว่างพอดี งั้นแวะไปทักทายหน่อยดีกว่า"

# game/scripts/History/PrincipalStory/Prologo.rpy:712
translate english Prologo_e2d21dc4:

    # n "[MN] sale de su casa para ir a la residencia Uchiha"
    n "[MN] ออกจากบ้านเพื่อมุ่งหน้าไปยังบ้านตระกูลอุจิฮะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:719
translate english Prologo_7cb07a87:

    # mn "Ya tenía mucho tiempo sin ver a la señora Sakura"
    mn "ไม่ได้เจอคุณซากุระนานเลยแฮะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:721
translate english Prologo_4d7cad96:

    # mn "Últimamente no he tenido tiempo, me he estado esforzando bastante en los entrenamientos"
    mn "ช่วงนี้ฉันไม่ค่อยมีเวลาเลย มัวแต่ทุ่มเทฝึกซ้อมอย่างหนัก"

# game/scripts/History/PrincipalStory/Prologo.rpy:724
translate english Prologo_8be03bed:

    # mn "Bueno, es por aquí"
    mn "เอาล่ะ ไปทางนี้ดีกว่า"

# game/scripts/History/PrincipalStory/Prologo.rpy:726
translate english Prologo_74f63841:

    # n "[MN] llega a la residencia Uchiha y toca la puerta, pero nadie sale..."
    n "[MN] เดินทางมาถึงบ้านตระกูลอุจิฮะแล้วเคาะประตู แต่ไม่มีใครออกมาเปิด..."

# game/scripts/History/PrincipalStory/Prologo.rpy:728
translate english Prologo_7bc42ffc:

    # n "Pero se escucha un ruido extraño dentro de la casa"
    n "แต่กลับมีเสียงประหลาดดังออกมาจากข้างในบ้าน"

# game/scripts/History/PrincipalStory/Prologo.rpy:729
translate english Prologo_aa62df9a:

    # mn "¿Qué fue eso?"
    mn "เสียงอะไรน่ะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:730
translate english Prologo_82e820b5:

    # n "En vista que nadie abría y de que un ruido extraño se escuchó adentro de la casa, [MN] procede a abrir la puerta"
    n "เนื่องจากไม่มีใครขานรับแถมยังมีเสียงแปลกๆ ดังมาจากในบ้าน [MN] จึงตัดสินใจลองเปิดประตูเข้าไป"

# game/scripts/History/PrincipalStory/Prologo.rpy:733
translate english Prologo_7c5d0405:

    # mn "!!!"
    mn "!!!"

# game/scripts/History/PrincipalStory/Prologo.rpy:734
translate english Prologo_51f83752:

    # mn "¡Señorita Sakura, ¿S-Se encuentra bien?!"
    mn "คุณซากุระระ โ-โร่เป็นอะไรรึเปล่าครับเนี่ย?!"

# game/scripts/History/PrincipalStory/Prologo.rpy:735
translate english Prologo_6d8ea0fb:

    # sk "Zzz.. Sasuke..."
    sk "คร่อก... ซาสึเกะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:736
translate english Prologo_a7311aa0:

    # mn "Oh, solo está dormida..."
    mn "อ่า แค่หลับอยู่หรอกเหรอเนี่ย..."

# game/scripts/History/PrincipalStory/Prologo.rpy:737
translate english Prologo_cdbfe03c:

    # mn "¿Pasó toda la noche tomando sake?"
    mn "เธอซดเหล้าสาเกมาตลอดทั้งคืนเลยรึไงเนี่ย?"

# game/scripts/History/PrincipalStory/Prologo.rpy:738
translate english Prologo_58662278:

    # mn "Espera.. ¿Por qué está ella...?"
    mn "เดี๋ยวก่อน...ทำไมเธอถึง...?"

# game/scripts/History/PrincipalStory/Prologo.rpy:743
translate english Prologo_25b43eec:

    # mn "Casi sin ropa..."
    mn "แทบไม่ได้ใส่อะไรเลย..."

# game/scripts/History/PrincipalStory/Prologo.rpy:744
translate english Prologo_32462c4b_5:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:745
translate english Prologo_6bed7357:

    # mn "¿Así que este es el cuerpo... de una mujer adulta...?"
    mn "นี่น่ะเหรอ...เรือนร่างของหญิงสาวที่โตเป็นผู้ใหญ่แล้ว...?"

# game/scripts/History/PrincipalStory/Prologo.rpy:746
translate english Prologo_d5e62a6b:

    # mn "Es hermoso..."
    mn "งดงามจัง..."

# game/scripts/History/PrincipalStory/Prologo.rpy:747
translate english Prologo_ae014432:

    # mn "¿Qué tal si yo...?"
    mn "จะเป็นไรไหมถ้าฉันจะ...?"

# game/scripts/History/PrincipalStory/Prologo.rpy:751
translate english Prologo_1084f63a:

    # mn "E-Espera.. ¿Qué estoy diciendo...? ¿Qué cosas sucias estaba apunto de pensar?"
    mn "ด-เดี๋ยวก่อน... ฉันพูดอะไรออกไปเนี่ย...? เมื่อกี้ฉันกำลังจะคิดเรื่องลามกอะไรอยู่ฟะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:752
translate english Prologo_4f8efa4a:

    # mn "Ella es la madre de mi amiga... Simplemente debería de llevarla a su cama..."
    mn "เธอเป็นแม่ของเพื่อนฉันนะ... ฉันควรพาเธอนอนบนเตียงดีกว่า..."

# game/scripts/History/PrincipalStory/Prologo.rpy:756
translate english Prologo_e675a14c:

    # n "[MN] recoge a Sakura en sus brazos"
    n "[MN] อุ้มซากุระขึ้นมาไว้ในอ้อมแขน"

# game/scripts/History/PrincipalStory/Prologo.rpy:759
translate english Prologo_83e74f94:

    # n "Pero [MN] se tropieza con unas botellas de sake que habían en el piso..."
    n "แต่ [MN] ดันสะดุดขวดสาเกที่วางเกลื่อนอยู่บนพื้น..."

# game/scripts/History/PrincipalStory/Prologo.rpy:760
translate english Prologo_30ff1503:

    # mn "¡Mierda!"
    mn "เวรเอ๊ย!"

# game/scripts/History/PrincipalStory/Prologo.rpy:762
translate english Prologo_2b74cf8f:

    # n "Cayendo en los pechos de Sakura"
    n "ล้มทับหน้าอกของซากุระเข้าเต็มๆ"

# game/scripts/History/PrincipalStory/Prologo.rpy:763
translate english Prologo_32462c4b_6:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:764
translate english Prologo_3d3b06a9:

    # mn "Estas son..."
    mn "นี่มัน..."

# game/scripts/History/PrincipalStory/Prologo.rpy:766
translate english Prologo_65325467:

    # mn "(Se siente cálido...)"
    mn "(รู้สึกอบอุ่นจัง...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:767
translate english Prologo_ca5b995f:

    # mn "(Es como estar entre dos nubes...)"
    mn "(ราวกับได้ซบอยู่ท่ามกลางก้อนเมฆสองก้อน...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:768
translate english Prologo_7ba17d17:

    # mn "(Ok [MN], basta de tonterías y llevala a la cama)"
    mn "(พอได้แล้ว [MN] เลิกเพ้อเจ้อแล้วพาเธอไปนอนได้แล้ว)"

# game/scripts/History/PrincipalStory/Prologo.rpy:773
translate english Prologo_1348b8f9:

    # n "Te levantas y recoges a Sakura entre tus brazos para llevarla a su habitación.."
    n "คุณลุกขึ้นแล้วอุ้มซากุระขึ้นมาแนบอกเพื่อพาเธอกลับไปส่งที่ห้องนอน"

# game/scripts/History/PrincipalStory/Prologo.rpy:779
translate english Prologo_2090e48a:

    # mn "Ya ahí debería estar bien..."
    mn "แค่นี้ก็เรียบร้อยแล้วสินะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:780
translate english Prologo_0af9f4c4:

    # n "Justo cuando dejas a Sakura en su cama se empiezan a escuchar unas pisadas"
    n "และในจังหวะที่คุณวางซากุระลงบนเตียง เสียงฝีเท้าบางอย่างก็ดังขึ้นมา"

# game/scripts/History/PrincipalStory/Prologo.rpy:781
translate english Prologo_446b0110:

    # mn "Mierda, no me digas qué..."
    mn "เวรเอ๊ย อย่าบอกนะว่า..."

# game/scripts/History/PrincipalStory/Prologo.rpy:782
translate english Prologo_f1a05eab:

    # sr "Mamá... ¿Estás en casa?"
    sr "คุณแม่คะ... อยู่บ้านหรือเปล่าคะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:783
translate english Prologo_c8b0886d:

    # mn "(¡Oh, no, no, no!)"
    mn "(แย่แล้วๆๆ!)"

# game/scripts/History/PrincipalStory/Prologo.rpy:784
translate english Prologo_6b04a524:

    # mn "(Si Sarada me ve aquí con su madre pensará lo peor de mí)"
    mn "(ถ้าซาราดะมาเห็นฉันอยู่กับแม่ของเธอในสภาพนี้ เธอต้องคิดไปในทางที่แย่ที่สุดแน่ๆ)"

# game/scripts/History/PrincipalStory/Prologo.rpy:785
translate english Prologo_ec4ad477:

    # mn "(Debo esconderme)"
    mn "(ฉันต้องซ่อนตัว)"

# game/scripts/History/PrincipalStory/Prologo.rpy:786
translate english Prologo_59cd79ee:

    # mn "(¡Pero no hay sitio dónde esconderse!)"
    mn "(แต่ไม่มีที่ให้ซ่อนเลยนี่หว่า!)"

# game/scripts/History/PrincipalStory/Prologo.rpy:787
translate english Prologo_f940c616:

    # sr "¿Qué son estas botellas?"
    sr "ขวดพวกนี้อะไรเนี่ย?"

# game/scripts/History/PrincipalStory/Prologo.rpy:788
translate english Prologo_8b37ab94:

    # sr "¿Pasaste toda noche tomando sake de nuevo?"
    sr "นี่แอบดื่มเหล้าสาเกทั้งคืนอีกแล้วเหรอเนี่ย?"

# game/scripts/History/PrincipalStory/Prologo.rpy:789
translate english Prologo_09a41f66:

    # mn "(Cada vez está más cerca, ¿Qué mierda hago?)"
    mn "(เสียงฝีเท้าเข้ามาใกล้แล้ว ฉันกำลังทำบ้าอะไรอยู่เนี่ย?)"

# game/scripts/History/PrincipalStory/Prologo.rpy:790
translate english Prologo_7aacb977:

    # sr "Y luego la niña soy yo, ¿No?"
    sr "แล้วเด็กผู้หญิงคนนั้นก็คือหนูเองสินะคะเนี่ย?"

# game/scripts/History/PrincipalStory/Prologo.rpy:791
translate english Prologo_efee21b7:

    # mn "(¡La ventana!)"
    mn "(หน้าต่าง!)"

# game/scripts/History/PrincipalStory/Prologo.rpy:792
translate english Prologo_b01ca5dc:

    # mn "(¡No me queda de otra que salir por la ventana!)"
    mn "(ไม่มีทางเลือกอื่นนอกจากต้องหนีออกทางหน้าต่างแล้ว!)"

# game/scripts/History/PrincipalStory/Prologo.rpy:798
translate english Prologo_853ada90:

    # n "[MN] intentó abrir la ventana"
    n "[MN] พยายามจะเปิดหน้าต่าง"

# game/scripts/History/PrincipalStory/Prologo.rpy:799
translate english Prologo_52ce3c73:

    # n "Pero esta estaba atascada"
    n "แต่ว่ามันดันติดเปิดไม่ออก"

# game/scripts/History/PrincipalStory/Prologo.rpy:805
translate english Prologo_1b56d3fa:

    # n "Lo que provocó que al intentar abrirla con tanta fuerza tropezaras contra el suelo"
    n "ทำให้เขาเสียหลักล้มลงไปกับพื้นตอนที่พยายามออกแรงงัดมันเข้าเต็มแรง"

# game/scripts/History/PrincipalStory/Prologo.rpy:812
translate english Prologo_bbfd2dca_1:

    # mn "¡!"
    mn "!"

# game/scripts/History/PrincipalStory/Prologo.rpy:813
translate english Prologo_b62845f5:

    # sr "¿Qué fue eso?"
    sr "เสียงอะไรน่ะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:820
translate english Prologo_ce47ec7f:

    # mn "(¡Mierda!)"
    mn "(เวรเอ๊ย!)"

# game/scripts/History/PrincipalStory/Prologo.rpy:821
translate english Prologo_4df18da8:

    # mn "(Sarada...)"
    mn "(ซาราดะ...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:822
translate english Prologo_af07b704:

    # mn "(No pienses mal de mí)"
    mn "(อย่าเพิ่งเข้าใจฉันผิดนะ)"

# game/scripts/History/PrincipalStory/Prologo.rpy:823
translate english Prologo_c3699fc9:

    # sr "Mamá, voy a entrar"
    sr "คุณแม่คะ หนูเข้าไปแล้วนะคะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:826
translate english Prologo_fb256a11:

    # mn "(¡A-Ahí viene!)"
    mn "(ม-มาแล้ว!)"

# game/scripts/History/PrincipalStory/Prologo.rpy:843
translate english Prologo_33b203be:

    # sr "Ahí estás..."
    sr "ให้อย่างนี้สิ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:845
translate english Prologo_fca0d22e:

    # sr "Mírate, no tienes vergüenza alguna..."
    sr "ดูสภาพตัวเองสิคะเนี่ย ไม่มีความละอายเลยจริงๆ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:848
translate english Prologo_682a85a6:

    # mn "(S-Sabía que reaccionaria así...)"
    mn "(ฉ-ฉันรู้อยู่แล้วเชียวว่าเธอต้องปฏิกิริยาแบบนี้...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:851
translate english Prologo_72a7ad9e:

    # sr "Ya tienes edad como para dejar botellas tiradas en la casa mamá"
    sr "โตจนป่านนี้แล้วยังปล่อยให้มีขวดวางเกลื่อนบ้านอีกนะคุณแม่"

# game/scripts/History/PrincipalStory/Prologo.rpy:857
translate english Prologo_77be194c:

    # mn "(¿Eh?)"
    mn "(ฮะ?)"

# game/scripts/History/PrincipalStory/Prologo.rpy:859
translate english Prologo_4aca6f6b:

    # sk "Zzz.. Zzz..."
    sk "ครอก... ฟี้..."

# game/scripts/History/PrincipalStory/Prologo.rpy:861
translate english Prologo_8e81c2ce:

    # sr "Me sorprende que por lo menos esta vez hayas llegado a tu cama..."
    sr "แปลกใจจังเลยนะคะที่อย่างน้อยคราวนี้แม่ก็ลากสังขารมานอนบนเตียงได้..."

# game/scripts/History/PrincipalStory/Prologo.rpy:864
translate english Prologo_4d7adc7a:

    # mn "(¡¿Q-Qué está pasando? ¿Por qué está casi desnuda?!)"
    mn "(ก-เกิดอะไรขึ้นเนี่ย? ทำไมเธอถึงเกือบจะแก้ผ้าอยู่แล้วล่ะ?!)"

# game/scripts/History/PrincipalStory/Prologo.rpy:866
translate english Prologo_cc461dc9:

    # mn "(¡¿Y por que está ignorandome?!)"
    mn "(แล้วทำไมเธอถึงเมินฉันล่ะเนี่ย?!)"

# game/scripts/History/PrincipalStory/Prologo.rpy:868
translate english Prologo_7987b58a:

    # mn "(Un segundo.. ¡Mi cuerpo...!)"
    mn "(เดี๋ยวก่อนนะ... ร่างกายฉัน!)"

# game/scripts/History/PrincipalStory/Prologo.rpy:869
translate english Prologo_73e90517:

    # mn "(¡Veo a mi cuerpo trasparente...!)"
    mn "(ทำไมร่างกายฉันมันดูโปร่งใสขึ้นมาฟะ!!)্ন"

# game/scripts/History/PrincipalStory/Prologo.rpy:876
translate english Prologo_980c3be2:

    # sr "En fin, debo cambiarme"
    sr "ช่างเถอะ ยังไงก็ต้องไปเปลี่ยนชุดก่อน"

# game/scripts/History/PrincipalStory/Prologo.rpy:878
translate english Prologo_4bad1a7b:

    # sr "Iré a ver a Chocho antes de ir a la residencia del Hokage"
    sr "เดี๋ยวค่อยแวะไปหาโจโจ้ก่อนไปบ้านท่านโฮคาเงะก็แล้วกัน"

# game/scripts/History/PrincipalStory/Prologo.rpy:880
translate english Prologo_700cf446:

    # sr "Nos vemos hasta entonces..."
    sr "ไว้เจอกันนะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:883
translate english Prologo_513bf35e:

    # n "Sarada sale nuevamente de la habitación y cierra la puerta"
    n "ซาราดะเดินออกจากห้องไปอีกครั้งแล้วปิดประตู"

# game/scripts/History/PrincipalStory/Prologo.rpy:884
translate english Prologo_32462c4b_7:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:888
translate english Prologo_88e0c1ec:

    # mn "(¡¿Qué carajos acaba de pasar?!)"
    mn "(เกิดบ้าอะไรขึ้นเนี่ย?!)"

# game/scripts/History/PrincipalStory/Prologo.rpy:889
translate english Prologo_f12c21fd:

    # mn "(Mierda, ¿Y qué tengo en el ojo? Me arde mucho)"
    mn "(เวรเอ๊ย ตาฉันโดนอะไรเนี่ย? แสบชิบหายเลย)"

# game/scripts/History/PrincipalStory/Prologo.rpy:891
translate english Prologo_ac286ec1:

    # n "[MN] encuentra un espejo en la habitación, y decide verse el ojo"
    n "[MN] พบกระจกในห้องและตัดสินใจมองดูดวงตาของตัวเอง"

# game/scripts/History/PrincipalStory/Prologo.rpy:896
translate english Prologo_4fbcd150:

    # mn "¿Ese es...?"
    mn "นั่นมัน...?"

# game/scripts/History/PrincipalStory/Prologo.rpy:897
translate english Prologo_13206721:

    # mn "¿Mi ojo...?"
    mn "ตาของฉันเหรอ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:898
translate english Prologo_9ad6f6a6:

    # mn "¿Por qué se ve así mi ojo?"
    mn "ทำไมตาฉันถึงกลายเป็นแบบนี้ไปได้ล่ะเนี่ย?"

# game/scripts/History/PrincipalStory/Prologo.rpy:901
translate english Prologo_32462c4b_8:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:902
translate english Prologo_c3e548b4:

    # mn "(No sé qué es lo que acaba de pasar)"
    mn "(ฉันไม่รู้เลยว่าเกิดอะไรขึ้นกับฉันกันแน่)"

# game/scripts/History/PrincipalStory/Prologo.rpy:903
translate english Prologo_04065692:

    # mn "(Pero algo me dice que hice algo para que Sarada no pudiera verme)"
    mn "(แต่สัญชาตญาณมันบอกว่าฉันทำอะไรบางอย่าง ทำให้ซาราดะมองไม่เห็นฉัน)"

# game/scripts/History/PrincipalStory/Prologo.rpy:912
translate english Prologo_171e37cf:

    # mn "(Dijo que iría a cambiarse)"
    mn "(เธอบอกว่าจะไปเปลี่ยนชุดสินะ)"

# game/scripts/History/PrincipalStory/Prologo.rpy:913
translate english Prologo_5a218823:

    # mn "(Debería aprovechar para irme ahora antes de que termine)"
    mn "(ฉันควรใช้โอกาสนี้ชิ่งหนีก่อนที่เธอจะแต่งตัวเสร็จดีกว่า)"

# game/scripts/History/PrincipalStory/Prologo.rpy:914
translate english Prologo_6e219983:

    # mn "(Dudo mucho que un milagro así vuelva a salvarme)"
    mn "(ฉันไม่คิดหรอกนะว่าปาฏิหาริย์แบบนี้จะช่วยฉันได้อีกรอบ)"

# game/scripts/History/PrincipalStory/Prologo.rpy:916
translate english Prologo_bd18d009:

    # n "Siendo lo más sigiloso posible, [MN] sale de la residencia Uchiha sin ser descubierto"
    n "พยายามทำตัวให้กลมกลืนและเงียบเชียบที่สุด [MN] แอบออกจากบ้านอุจิฮะไปได้โดยไม่มีใครรู้ตัว"

# game/scripts/History/PrincipalStory/Prologo.rpy:925
translate english Prologo_b24c350e:

    # mn "(¿Qué debería hacer ahora?)"
    mn "(ตอนนี้ฉันควรทำยังไงดีล่ะเนี่ย?)"

# game/scripts/History/PrincipalStory/Prologo.rpy:927
translate english Prologo_85b77973_3:

    # mn "(...)"
    mn "(...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:929
translate english Prologo_bdeaf003:

    # mn "(Creo que debería reportarselo al Hokage...)"
    mn "(ฉันว่าเธอควรไปรายงานเรื่องนี้ให้ท่านโฮคาเงะฟังนะ...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:931
translate english Prologo_e8a5ca93:

    # mn "(Él es la única persona que conozco que puede que sepa algo acerca de mi ojo)"
    mn "(เขาเป็นคนเดียวที่ฉันรู้จัก ที่อาจจะรู้อะไรเกี่ยวกับตาข้างนี้บ้าง)"

# game/scripts/History/PrincipalStory/Prologo.rpy:936
translate english Prologo_e045eff1:

    # n "[MN] decide poner rumbo a la residencia del Hokage"
    n "[MN] ตัดสินใจมุ่งหน้าไปยังบ้านพักโฮคาเงะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:937
translate english Prologo_c5dffc2e:

    # n "Y por el camino se da cuenta que todo el mundo se le queda viendo"
    n "และระหว่างทางเขาก็สังเกตเห็นว่าทุกคนกำลังจ้องมองมาที่เขา"

# game/scripts/History/PrincipalStory/Prologo.rpy:938
translate english Prologo_0ae9bcd0:

    # ""
    ""

# game/scripts/History/PrincipalStory/Prologo.rpy:939
translate english Prologo_7cb699d6:

    # n "Llegando finalmente a la oficina del Hokage"
    n "ในที่สุดก็มาถึงห้องทำงานของโฮคาเงะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:950
translate english Prologo_725b90ff:

    # nt "¿Dónde estarán esos documentos?"
    nt "เอกสารพวกนั้นมันไปอยู่ไหนซะล่ะเนี่ย?"

# game/scripts/History/PrincipalStory/Prologo.rpy:953
translate english Prologo_4239ff62:

    # mn "Buenos días, señor Hokage..."
    mn "อรุณสวัสดิ์ครับท่านโฮคาเงะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:957
translate english Prologo_07896b62:

    # nt "Oh, buenos días, [MN], ¿Que te trae por...?"
    nt "โอ้ อรุณสวัสดิ์ [MN] มีธุระอะไรถึงมาหาฉันแต่เช้าล่ะเนี่ย...?"

# game/scripts/History/PrincipalStory/Prologo.rpy:963
translate english Prologo_254c214e:

    # nt "¡Aah! ¿Qué te pasó en el ojo?"
    nt "อ๊ะ! ตาของเธอไปโดนอะไรมาน่ะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:966
translate english Prologo_3f47a559:

    # mn "Bueno, justo por eso vine a verlo... Pensé que podría ayudarme"
    mn "นั่นแหละครับคือเหตุผลที่ผมมาหาท่าน... ผมคิดว่าท่านน่าจะช่วยผมได้"

# game/scripts/History/PrincipalStory/Prologo.rpy:969
translate english Prologo_a223d0e6:

    # mn "Yo..."
    mn "ผม..."

# game/scripts/History/PrincipalStory/Prologo.rpy:973
translate english Prologo_517d7ca6:

    # mn "(Un momento... No puedo decirle la verdad...)"
    mn "(เดี๋ยวก่อนนะ... จะบอกความจริงไปไม่ได้ซะด้วยสิ...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:975
translate english Prologo_9021bf50:

    # mn "(Tendré que improvisar una mentira...)"
    mn "(สงสัยต้องกุเรื่องโกหกแก้ขัดไปก่อนแล้ว...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:978
translate english Prologo_0abb5826:

    # mn "Yo... Me desperté y veía mi cuerpo transparente..."
    mn "ผม... ผมตื่นขึ้นมาแล้วก็พบว่าร่างกายของตัวเองโปร่งใสไปหมดเลยครับ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:981
translate english Prologo_5def33c4:

    # nt "¿Trasparente?"
    nt "โปร่งใสอย่างนั้นเหรอ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:984
translate english Prologo_038baef6:

    # mn "Así es... Y fui a verme al espejo pero no podía ver mi reflejo..."
    mn "ใช่ครับ... แล้วพอผมไปส่องกระจกก็มองไม่เห็นเงาตัวเองเลย..."

# game/scripts/History/PrincipalStory/Prologo.rpy:986
translate english Prologo_d0a8b3d0:

    # mn "Era como si fuera invisible..."
    mn "เหมือนกับว่าผมล่องหนได้ยังไงยังงั้นเลยครับ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:988
translate english Prologo_ef3ac838:

    # mn "Y luego... Salí y vi a alguien, pero parecía que esa persona no me podía ver a mí..."
    mn "แล้วจากนั้น... ผมก็ออกไปข้างนอกแล้วเจอคนคนหนึ่ง แต่ดูเหมือนว่าเขาจะมองไม่เห็นผม..."

# game/scripts/History/PrincipalStory/Prologo.rpy:991
translate english Prologo_58b46560:

    # nt "Entiendo... ¿Y como volviste a la normalidad?"
    nt "ฉันเข้าใจละ... แล้วเธอคืนสภาพเดิมได้ยังไงล่ะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:994
translate english Prologo_8957e7a6:

    # mn "Después de un rato me calmé y fue ahí cuando dejé de ser transparente..."
    mn "สักพักพอผมสงบสติอารมณ์ลง อาการโปร่งใสถึงได้หายไปครับ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:996
translate english Prologo_871d8900:

    # mn "Pero cuando volví a verme al espejo, mi ojo ya era amarillo"
    mn "แต่พอผมลองส่องกระจกดูอีกที ตาของผมก็กลายเป็นสีเหลืองไปซะแล้ว"

# game/scripts/History/PrincipalStory/Prologo.rpy:998
translate english Prologo_ade94437:

    # mn "Y decidí venir aquí, pensando en que usted podría ayudarme"
    mn "ผมก็เลยตัดสินใจมาที่นี่ โดยคิดว่าท่านน่าจะช่วยผมได้น่ะครับ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1001
translate english Prologo_9d537539:

    # nt "Así que invisibilidad..."
    nt "งั้นก็เรื่องล่องหนสินะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1003
translate english Prologo_c2d06cfe:

    # nt "Hmm..."
    nt "อืม..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1005
translate english Prologo_32150f5e:

    # nt "¿Nadie más te vió el ojo?"
    nt "ไม่มีใครคนอื่นเห็นตาของเธอเลยเหรอ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1008
translate english Prologo_67dad1f5:

    # mn "Por desgracia, terminé siendo el centro de atención..."
    mn "น่าเสียดายครับ ดันมีคนเห็นเข้าซะได้..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1011
translate english Prologo_524d4a72:

    # nt "Ya veo..."
    nt "งั้นเหรอ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1014
translate english Prologo_90f622bf:

    # nt "Déjame ver tu ojo..."
    nt "ขอดูตาของเธอหน่อยซิ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1016
translate english Prologo_6f7643d8:

    # n "Naruto le hecha un vistazo al ojo de [MN]"
    n "นารูโตะลองมองดูตาของ [MN]"

# game/scripts/History/PrincipalStory/Prologo.rpy:1023
translate english Prologo_ff7aa509:

    # nt "Creo que ya sé que pasa..."
    nt "ฉันว่าฉันพอจะเข้าใจละว่าเกิดอะไรขึ้น..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1025
translate english Prologo_f266031a:

    # nt "Noto un pequeño flujo en tu ojo"
    nt "ฉันสัมผัสได้ถึงกระแสจักระแปลก ๆ ในตาของเธอนิดหน่อยนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1027
translate english Prologo_be9df601:

    # nt "Bastante parecido al flujo de chkra de los Uchiha cuando despiertan el Sharingan"
    nt "ค่อนข้างคล้ายกับกระแสจักระของพวกอุจิฮะตอนที่เบิกเนตรวงแหวนเลยล่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1029
translate english Prologo_77b262ab:

    # nt "Probablemente... Sea un Kekkei Genkai, heredado del clan del que provienes"
    nt "น่าจะนะ... มันน่าจะเป็นขีดจำกัดสายเลือดที่สืบทอดมาจากตระกูลของเธอนั่นแหละ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1032
translate english Prologo_afad8976:

    # mn "¿Mi clan?"
    mn "ตระกูลของผมเหรอครับ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1035
translate english Prologo_50019802:

    # nt "Es la explicación más sencilla"
    nt "มันเป็นคำอธิบายที่ง่ายที่สุดแล้วล่ะนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1037
translate english Prologo_b853befd:

    # nt "Así como el Sharingan de los Uchiha, ese ojo es un Kekkei Genkai"
    nt "ก็เหมือนกับเนตรวงแหวนของพวกอุจิฮะ ดวงตาข้างนั้นก็คือขีดจำกัดสายเลือดเหมือนกัน"

# game/scripts/History/PrincipalStory/Prologo.rpy:1039
translate english Prologo_9420d955:

    # nt "Un Dojutsu para ser más precisos"
    nt "พูดให้ถูกก็คือวิชาเนตรน่ะนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1041
translate english Prologo_4e812cd3:

    # nt "Seguramente la invisibilidad sea algún jutsu"
    nt "เรื่องการล่องหนก็น่าจะเป็นวิชานินจาบางอย่าง"

# game/scripts/History/PrincipalStory/Prologo.rpy:1043
translate english Prologo_5e07f2ad:

    # nt "Pero para estar seguros..."
    nt "แต่เพื่อความชัวร์..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1050
translate english Prologo_4552aede:

    # n "Entra Sarada a la oficina"
    n "ซาราดะเดินเข้ามาในห้องทำงาน"

# game/scripts/History/PrincipalStory/Prologo.rpy:1052
translate english Prologo_e8c56533:

    # sr "Buen día Señor Séptimo"
    sr "สวัสดีค่ะท่านโฮคาเงะรุ่นที่ 7"

# game/scripts/History/PrincipalStory/Prologo.rpy:1054
translate english Prologo_64414f6f:

    # sr "[MN], ¿Qué haces aquí?"
    sr "[MN] มาทำอะไรอยู่ที่นี่เหรอ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1060
translate english Prologo_b41bdbdd:

    # mn "H-Hola Sarada..."
    mn "ส-สวัสดี ซาราดะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1067
translate english Prologo_bda86687:

    # sr "¡¿Q-Qué demonios te pasó en el ojo?!"
    sr "ทะ...ทำไมตาของเธอถึงเป็นแบบนั้นล่ะล่ะเนี่ย?!"

# game/scripts/History/PrincipalStory/Prologo.rpy:1069
translate english Prologo_6db20aeb:

    # sr "¿A-Alguien te hizo eso?"
    sr "ม-มีใครทำอะไรเธอมาเหรอ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1072
translate english Prologo_c9c028e5:

    # nt "Creo que no es el caso..."
    nt "ฉันว่าไม่ใช่แบบนั้นหรอกนะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1075
translate english Prologo_8a90a00f:

    # sr "¿Qué?"
    sr "คะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1078
translate english Prologo_7d01f808:

    # mn "El Hokage cree que es un Kekkei Genkai"
    mn "ท่านโฮคาเงะคิดว่านี่คือขีดจำกัดสายเลือดน่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1082
translate english Prologo_85cd4682:

    # nt "Me alegra que hayas venido, Sarada"
    nt "ดีเลยที่เธอมาพอดี ซาราดะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1084
translate english Prologo_d65a0244:

    # nt "Necesito que acompañes a [MN] al escondite de Orochimaru"
    nt "ฉันอยากให้เธอพา [MN] ไปที่ห้องทดลองของโอโรจิมารุหน่อย"

# game/scripts/History/PrincipalStory/Prologo.rpy:1086
translate english Prologo_ee7284ca:

    # nt "Tú eres de las pocas personas que saben su localización"
    nt "เธอเป็นหนึ่งในไม่กี่คนที่รู้ว่าที่ตั้งมันอยู่ไหน"

# game/scripts/History/PrincipalStory/Prologo.rpy:1088
translate english Prologo_ec793a5b:

    # nt "Él tiene todo tipo de registros y archivos de clanes y las copias sobre los experimentos de Shin Uchiha"
    nt "ที่นั่นมีบันทึกข้อมูลและแฟ้มตระกูลสารพัด รวมถึงสำเนาการทดลองของชิน อุจิฮะด้วย"

# game/scripts/History/PrincipalStory/Prologo.rpy:1090
translate english Prologo_b9fe8d97:

    # nt "Sí alguien puede ayudar a [MN], es él"
    nt "ถ้าจะมีใครช่วย [MN] ได้ล่ะก็ ก็คงเป็นเขานี่แหละ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1093
translate english Prologo_f4c4f2c1:

    # sr "Entendido, señor"
    sr "รับทราบค่ะท่าน"

# game/scripts/History/PrincipalStory/Prologo.rpy:1096
translate english Prologo_ebd4c037:

    # nt "Le avisaré de su visita, vayan ahora y tengan mucho cuidado"
    nt "เดี๋ยวฉันจะติดต่อไปแจ้งเขาเรื่องที่พวกเธอจะไป รีบไปกันเถอะแล้วก็ระวังตัวกันด้วยล่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1101
translate english Prologo_72128c1c:

    # mn "Está bien señor, y... Muchas gracias"
    mn "ครับท่าน แล้วก็... ขอบคุณมากครับ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1103
translate english Prologo_9f6d4869:

    # nt "Jeje, no es nada"
    nt "หึๆ ไม่เป็นไรหรอก"

# game/scripts/History/PrincipalStory/Prologo.rpy:1105
translate english Prologo_86e76ffc:

    # nt "Ahora vayan, es mejor que salgan temprano para que no vuelvan tan tarde"
    nt "ไปกันได้แล้ว ออกเดินทางแต่เนิ่นๆ จะได้ไม่กลับดึกจนเกินไป"

# game/scripts/History/PrincipalStory/Prologo.rpy:1107
translate english Prologo_a8eebdf1:

    # n "Sales junto a Sarada de la oficina del Hokage"
    n "คุณออกจากห้องทำงานของท่านโฮคาเงะพร้อมกับซาราดะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1115
translate english Prologo_825cd505:

    # sr "Debemos irnos ya para que no se nos haga tarde, el escondite se encuentra en las afueras de la aldea, cerca del bosque de la hoja"
    sr "พวกเราต้องรีบไปกันแล้วจะได้ไม่สาย ศูนย์หลบภัยนั่นอยู่แถวชานเมือง ใกล้ๆ กับป่าแห่งโคโหนะนี่แหละ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1118
translate english Prologo_ef92ae41:

    # mn "Está bien, te sigo"
    mn "โอเค งั้นฉันเดินตามเธอไปนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1121
translate english Prologo_f5d687b8:

    # sr "¿Qué te parece si en el camino me cuentas como despertaste ese Jutsu de un día para otro?"
    sr "ระหว่างทางนี้... เธอช่วยเล่าให้ฟังหน่อยได้ไหมว่า อยู่ดีๆ เธอปลุกวิชานินจานั่นขึ้นมาได้ยังไง?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1124
translate english Prologo_478d3e94:

    # mn "C-Claro... No tengo problemas con eso..."
    mn "ก-ก็ได้... ฉันไม่มีปัญหาอยู่แล้ว..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1127
translate english Prologo_2eaec596:

    # n "En camino al escondite de Orochimaru, [MN] le dice a Sarada su mentira sobre como su ojo se volvió amarillo"
    n "ระหว่างทางไปห้องทดลองของโอโรจิมารุ [MN] ได้เล่าเรื่องโกหกให้ซาราดะฟังเกี่ยวกับสาเหตุที่ตาของเขาเปลี่ยนเป็นสีเหลือง"

# game/scripts/History/PrincipalStory/Prologo.rpy:1140
translate english Prologo_17cee95a:

    # mn "Y eso fue lo que pasó..."
    mn "ก็ประมาณนี้แหละ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1141
translate english Prologo_41f10758:

    # sr "Vaya... es algo difícil de creer"
    sr "โห... ฟังดูเหลือเชื่อเป็นบ้าเลยแฮะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1142
translate english Prologo_b0660926:

    # sr "¿Entonces ahora puedes volverte invisible a voluntad?"
    sr "งั้นตอนนี้เธอก็ล่องหนได้ตามใจชอบเลยเหรอ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1143
translate english Prologo_bfabe5b6:

    # mn "A voluntad aún no puedo"
    mn "ตามใจชอบนี่สิยังไม่ได้หรอก"

# game/scripts/History/PrincipalStory/Prologo.rpy:1144
translate english Prologo_9860e560:

    # mn "Ni siquiera sabía que podía hacer algo como esto"
    mn "ฉันเองก็ไม่รู้ด้วยซ้ำว่าทำอะไรแบบนี้ได้"

# game/scripts/History/PrincipalStory/Prologo.rpy:1145
translate english Prologo_c10b7753:

    # mn "Pero, quizás con práctica pueda hacerlo"
    mn "แต่ว่า... ถ้าฝึกฝนดูหน่อยก็น่าจะทำได้แหละนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1146
translate english Prologo_fd1ff3f6:

    # mn "Sería muy útil, tanto para el combate como para misiones de infiltración"
    mn "มันคงจะมีประโยชน์มากๆ เลย ทั้งเรื่องการต่อสู้แล้วก็ภารกิจแทรกซึม"

# game/scripts/History/PrincipalStory/Prologo.rpy:1147
translate english Prologo_e6bd356e:

    # sr "Hacerte invisible..."
    sr "ทำให้ตัวเองล่องหนได้เนี่ยนะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1148
translate english Prologo_821239d6:

    # sr "Suena al sueño de un pervertido"
    sr "ฟังดูเหมือนความฝันของพวกโรคจิตเลยแฮะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1149
translate english Prologo_36de0c90:

    # sr "¿Sí llegas a dominarlo, crees que te convertirás en una especie de voyeur?"
    sr "ถ้าเธอคล่องมือขึ้นมาแล้ว คิดว่าจะกลายเป็นพวกชอบแอบดูชาวบ้านเขาไรงี้ไหมล่ะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1150
translate english Prologo_f96eaede:

    # mn "Sarada..."
    mn "ซาราดะ..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1151
translate english Prologo_358677be:

    # sr "Jajaja.. Solo bromeaba... Ya casi llegamos"
    sr "ฮ่าๆๆ... ล้อเล่นน่า... ถึงกันสักที"

# game/scripts/History/PrincipalStory/Prologo.rpy:1152
translate english Prologo_8581dfe8:

    # mn "Fue más rápido de lo que pensé"
    mn "เร็วกว่าที่คิดแฮะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1153
translate english Prologo_da05f235:

    # sr "Suelo hacer varios encargos aquí, así que conozco los atajos"
    sr "ปกติฉันมารับงานหลายอย่างแถวนี้บ่อยน่ะ ก็เลยรู้ทางลัด"

# game/scripts/History/PrincipalStory/Prologo.rpy:1154
translate english Prologo_e4561f94:

    # sr "Mira, es justo aquí"
    sr "นี่ไง อยู่ตรงนี้แหละ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1157
translate english Prologo_f3e605e1:

    # n "Entras junto a Sarada al escondite de Orochimaru"
    n "คุณเข้ามาในห้องทดลองของโอโรจิมารุพร้อมกับซาราดะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1166
translate english Prologo_32462c4b_9:

    # mn "..."
    mn "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1168
translate english Prologo_d6fca1cf:

    # sr "¿Hmm?"
    sr "หืม?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1172
translate english Prologo_8242c578:

    # sr "Oye, ¿Estás bien?"
    sr "นี่ เธอไหวรึเปล่า?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1175
translate english Prologo_b492f364:

    # mn "Ah, si... Es solo que este lugar, se siente familiar a uno no muy agradable para mí..."
    mn "อ๋อ อืม... แค่รู้สึกว่าที่นี่มันแอบคล้ายกับสถานที่ที่ไม่ค่อยน่าพิศวาสสำหรับฉันเท่าไหร่..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1178
translate english Prologo_16278896:

    # sr "..."
    sr "..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1181
translate english Prologo_17d5d7a0:

    # sr "Tranquilo, solo vinimos por información"
    sr "ใจเย็นน่า พวกเราแค่มาหาข้อมูลเท่านั้นเอง"

# game/scripts/History/PrincipalStory/Prologo.rpy:1183
translate english Prologo_ee996f44:

    # sr "Una vez que Orochimaru nos diga lo que sabe sobre tu ojo volveremos a la aldea"
    sr "พอโอโรจิมารุบอกสิ่งที่เขารู้เกี่ยวกับตาของเธอแล้ว เราก็จะกลับหมู่บ้านกัน"

# game/scripts/History/PrincipalStory/Prologo.rpy:1186
translate english Prologo_de89add6:

    # mn "Está bien..."
    mn "อืม..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1188
translate english Prologo_c352b367:

    # n "Poco a poco se adentran más en el laboratorio"
    n "พวกเขาลึกเข้าไปในห้องทดลองทีละน้อย"

# game/scripts/History/PrincipalStory/Prologo.rpy:1189
translate english Prologo_757960f2:

    # n "Y llega alguien a recibirlos"
    n "แล้วก็มีคนเดินออกมาต้อนรับพวกเขา"

# game/scripts/History/PrincipalStory/Prologo.rpy:1205
translate english Prologo_85a2c6cf:

    # kr "Sarada, ¿Cómo has estado?"
    kr "ซาราดะ สบายดีไหม?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1207
translate english Prologo_dfa71089:

    # kr "Me avisaron de su llegada para que los recibiera"
    kr "ฉันได้รับแจ้งว่าพวกเธอมาถึงแล้ว เลยออกมาต้อนรับน่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1210
translate english Prologo_6fef4457:

    # sr "Karin, muy bien, ¿Tú cómo has estado?"
    sr "คาริน สบายดีจ่ะ พี่เองก็สบายดีใช่ไหม?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1213
translate english Prologo_726a80f9:

    # kr "Pues, bien dentro de lo que cabe jaja"
    kr "ก็เรื่อยๆ นะ ฉันสบายดีอย่างที่เห็นนี่แหละ ฮ่าๆ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1215
translate english Prologo_4c7e3a4e:

    # kr "¿Mmm?"
    kr "อืม?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1218
translate english Prologo_f20f88ee:

    # kr "Oye, ¿Y quién viene contigo?"
    kr "แล้วนี่ใครที่มาด้วยกันล่ะเนี่ย?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1221
translate english Prologo_65f19891:

    # sr "Oh si, te lo presento, su nombre es [MN]"
    sr "อ่อ ใช่สิ ขอแนะนำให้รู้จักนะ เขาชื่อ [MN] จ่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1224
translate english Prologo_23a56baf:

    # sr "[MN], ella es Karin Uzumaki, es una gran amiga mía"
    sr "[MN] นี่คือ อุซูมากิ คาริน เธอเป็นเพื่อนสนิทของฉันเอง"

# game/scripts/History/PrincipalStory/Prologo.rpy:1227
translate english Prologo_0e1e2516:

    # mn "Mucho gusto en conocerla, señorita Karin"
    mn "ยินดีที่ได้รู้จักครับ คุณคาริน"

# game/scripts/History/PrincipalStory/Prologo.rpy:1231
translate english Prologo_09ac6eed:

    # kr "Ya veo, entonces tú eres el chico del ojo extraño"
    kr "งั้นเหรอนี่ นายเองสินะไอ้หนุ่มที่มีตาประหลาดนั่นน่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1233
translate english Prologo_c0d852b4:

    # kr "El gusto es mío"
    kr "ยินดีที่ได้รู้จักเช่นกันนะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1237
translate english Prologo_eafff4f7:

    # mn "(Vaya... Karin es una chica muy linda...)"
    mn "(ว้าว... คุณคารินนี่น่ารักเป็นบ้าเลยแฮะ...)"

# game/scripts/History/PrincipalStory/Prologo.rpy:1239
translate english Prologo_1a097e52:

    # mn "(No esperaba encontrarme a una chica en un sitio como este)"
    mn "(ไม่คิดเลยว่าจะเจอผู้หญิงในสถานที่แบบนี้)"

# game/scripts/History/PrincipalStory/Prologo.rpy:1243
translate english Prologo_4581cf59:

    # sr "¿Orochimaru tardará mucho?"
    sr "โอโรจิมารุจะนานไหมเนี่ย?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1246
translate english Prologo_812464a4:

    # kr "No lo sé, apenas recibió el informe del Hokage se puso a buscar entre unos documentos"
    kr "ไม่รู้สิ ทันทีที่เขาได้รับรายงานจากท่านโฮคาเงะ เขาก็เริ่มไปค้นเอกสารพวกนั้นดูเลยล่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1249
translate english Prologo_6cadef93:

    # d "Documentos que acabo de encontrar"
    d "เอกสารที่ฉันเพิ่งเจอน่ะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1253
translate english Prologo_8bd4a600:

    # n "Orochimaru hace acto de presencia en la sala"
    n "โอโรจิมารุปรากฏตัวขึ้นในห้อง"

# game/scripts/History/PrincipalStory/Prologo.rpy:1255
translate english Prologo_7496367e:

    # oro "Tú eres [MN], ¿No es así?"
    oro "เธอคือ [MN] สินะ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1258
translate english Prologo_cc448a98:

    # mn "S-Sí señor..."
    mn "ค-ครับท่าน..."

# game/scripts/History/PrincipalStory/Prologo.rpy:1261
translate english Prologo_36fc2319:

    # oro "Cuando recibí el mensaje de Naruto, me pareció algo extraño lo que me describía"
    oro "ตอนที่ฉันได้รับข้อความจากนารูโตะ สิ่งที่เขาอธิบายมามันดูแปลกพิกลสำหรับฉัน"

# game/scripts/History/PrincipalStory/Prologo.rpy:1263
translate english Prologo_882c1756:

    # oro "¿Un Kekkei Genkai capaz de volver invisible al usuario?"
    oro "ขีดจำกัดสายเลือดที่ทำให้ผู้ใช้ล่องหนได้งั้นรึ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1265
translate english Prologo_b8565213:

    # oro "Era algo sumamente curioso que tenía que investigar"
    oro "มันเป็นเรื่องที่น่าสนใจสุดๆ จนฉันอดไม่ได้ที่จะต้องตรวจสอบดู"

# game/scripts/History/PrincipalStory/Prologo.rpy:1267
translate english Prologo_56c98952:

    # oro "Y divagando entre unos documentos de Shin Uchiha"
    oro "แล้วระหว่างที่ค้นดูเอกสารเก่าของชิน อุจิฮะ"

# game/scripts/History/PrincipalStory/Prologo.rpy:1269
translate english Prologo_f678bc71:

    # oro "Encontré esto"
    oro "ฉันก็เจอเจ้านี่เข้า"

# TODO: Translation updated at 2024-12-13 21:25

# game/scripts/History/PrincipalStory/Prologo.rpy:27
translate english Prologo_bf908fcd:

    # d "Era un tipo despreciable, usaba a sus {color#f3c271}hijos{/a} como simples herramientas para lograr un fin"
    d "เขาเป็นผู้ชายที่น่ารังเกียจจริงๆ เอา{color=#f3c271}เด็กๆ{/a}ของตัวเองมาเป็นแค่เครื่องมือเพื่อบรรลุเป้าหมาย"

# game/scripts/History/PrincipalStory/Prologo.rpy:28
translate english Prologo_c64abf6c:

    # d "Tenía pensado {color#f3c271}cumplir la voluntad de Itachi Uchiha{/a}, el hermano de mi padre, y mi tío"
    d "เขาตั้งใจที่จะ {color=#f3c271}สานต่อเจตนารมณ์ของ อุจิฮะ อิตาจิ{/a} พี่ชายของพ่อฉัน และเป็นลุงของฉัน"

# game/scripts/History/PrincipalStory/Prologo.rpy:190
translate english Prologo_37d06c7f:

    # d "Y este dijo que se llamaría {color#f3c271}[MN]{/a}"
    d "และเขาบอกว่าเขาจะถูกเรียกว่า {color=#f3c271}[MN]{/a}"

# game/scripts/History/PrincipalStory/Prologo.rpy:221
translate english Prologo_63def8a2:

    # d "Su Sensei {color#f3c271}Zubon{/a}, y sus dos compañeros, {color#f3c271}Hideo{/a} y {color#f3c271}Yuna{/a}"
    d "เซนเซของเขา {color=#f3c271}ซูบง{/a} และเพื่อนร่วมทีมอีกสองคนของเขา {color=#f3c271}ฮิเดโอะ{/a} และ {color=#f3c271}ยูนะ{/a}"

# game/scripts/History/PrincipalStory/Prologo.rpy:261
translate english Prologo_c0bf5068:

    # mn "Listo... ¡Ahora abro!" with dissolve5
    mn "กำลังไป... เดี๋ยวเปิดให้ครับ!" with dissolve5

# game/scripts/History/PrincipalStory/Prologo.rpy:956
translate english Prologo_175463ac:

    # nt "Oh, buenos días, [MN], ¿Que te trae por...?" with dissolve1
    nt "โอ้ อรุณสวัสดิ์ [MN] มีธุระอะไรถึงมาที่นี่ล่ะเนี่ย...?" with dissolve1

# game/scripts/History/PrincipalStory/Prologo.rpy:1013
translate english Prologo_5d2fe439:

    # nt "Déjame ver tu ojo..." with dissolve1
    nt "ขอดูตาของเธอหน่อยซิ..." with dissolve1

# game/scripts/History/PrincipalStory/Prologo.rpy:1059
translate english Prologo_4ced686d:

    # mn "H-Hola Sarada..." with dissolve1
    mn "ส-สวัสดีซาราดะ..." with dissolve1

# game/scripts/History/PrincipalStory/Prologo.rpy:1100
translate english Prologo_f59fd506:

    # mn "Está bien señor, y... Muchas gracias" with dissolve1
    mn "ไม่เป็นไรครับท่าน และ... ขอบคุณมากครับ" with dissolve1

# game/scripts/History/PrincipalStory/Prologo.rpy:1171
translate english Prologo_15f1533e:

    # sr "Oye, ¿Estás bien?" with dissolve1
    sr "นี่ นายไหวไหมเนี่ย?" with dissolve1

# game/scripts/History/PrincipalStory/Prologo.rpy:1217
translate english Prologo_b238b880:

    # kr "Oye, ¿Y quién viene contigo?" with dissolve1
    kr "ว่าแต่ ใครเหรอที่มาด้วยกันน่ะ?" with dissolve1

# game/scripts/History/PrincipalStory/Prologo.rpy:1248
translate english Prologo_9a8e3d09:

    # d "Documentos que acabo de encontrar" with dissolve1
    d "เอกสารที่ฉันเพิ่งเจอน่ะ" with dissolve1

# game/scripts/History/PrincipalStory/Prologo.rpy:1283
translate english prologo__8019fe9b:

    # mn "¿{color#f3c271}Ryuta Karui{/a}?"
    mn "{color=#f3c271}ริวตะ คารุอิ{/a} เหรอ?"

# game/scripts/History/PrincipalStory/Prologo.rpy:1287
translate english prologo__ec7dbb26:

    # oro "Aparentemente ese es tu nombre real, {color#f3c271}Ryuta Karui{/a}"
    oro "ดูเหมือนว่านั่นคือชื่อจริงของเธอสินะ {color=#f3c271}ริวตะ คารุอิ{/a}"

# game/scripts/History/PrincipalStory/Prologo.rpy:1341
translate english prologo__7361e0f1:

    # oro "Un clan con un Dojutsu que los hacía volverse invisible, a este Dojutsu se le hacía llamar {color#f3c271}Karugan{/a}"
    oro "ตระกูลที่มีเนตรวิชาที่ทำให้ล่องหนได้ เนตรวิชานี้ถูกเรียกว่า {color=#f3c271}คารูกัน{/a}"

# game/scripts/History/PrincipalStory/Prologo.rpy:1362
translate english prologo__19676ed3:

    # sr "Bueno... Al menos ya con esto resolvimos el misterio de tu clan. ¿Cierto?" with dissolve1
    sr "งั้นเหรอ... อย่างน้อยเรื่องปริศนาเกี่ยวกับตระกูลของนายก็น่าจะคลี่คลายแล้วล่ะนะ ว่าไหม?" with dissolve1

# game/scripts/History/PrincipalStory/Prologo.rpy:1401
translate english prologo__27ecbd70:

    # oro "Ayudé en lo que pude, si quieres saber algo más tendrás que averiguarlo por tu cuenta" with dissolve1
    oro "ฉันช่วยเท่าที่ทำได้แล้วล่ะ ถ้าอยากรู้มากกว่านี้ก็ต้องไปสืบหาเอาเองแล้วกันนะ" with dissolve1

# game/scripts/History/PrincipalStory/Prologo.rpy:1419
translate english prologo__e4c05cdd:

    # kr "Mientras más tarden en irse, más tarde se hará" with dissolve1
    kr "ยิ่งชักช้าไม่ยอมไป เดี๋ยวก็ยิ่งดึกดื่นกันพอดีหรอก" with dissolve1

# game/scripts/History/PrincipalStory/Prologo.rpy:1424
translate english prologo__ef24d61f:

    # mn "Tienes razón, volvamos a la aldea" with dissolve1
    mn "นั่นสินะ กลับหมู่บ้านกันเถอะ" with dissolve1

# game/scripts/History/PrincipalStory/Prologo.rpy:1429
translate english prologo__cd240e3f:

    # kr "Nos vemos chicos" with dissolve1
    kr "ไว้เจอกันนะทุกคน" with dissolve1
