# TODO: Translation updated at 2024-12-01 21:25

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:6
translate english arc2_hinata_quest1_2_257358b9:

    # n "Un tranquilo Domingo por la mañana"
    n "เช้าวันอาทิตย์อันเงียบสงบ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:7
translate english arc2_hinata_quest1_2_503231b7:

    # n "[MN] caminaba hacia la casa de la {b}Familia Uzumaki{/a}"
    n "[MN] กำลังเดินมุ่งหน้าไปยังบ้านของ {b}ครอบครัวอุซุมากิ{/a}"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:14
translate english arc2_hinata_quest1_2_98ad021e:

    # mn "Aquí estoy, hace mucho tiempo que no vengo de visita"
    mn "ถึงแล้วสินะ ไม่ได้มาเยี่ยมซะนานเลย"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:15
translate english arc2_hinata_quest1_2_59ad4765:

    # mn "Con todo lo que he tenido en la cabeza, no he podido, pero aquí estoy"
    mn "มีเรื่องให้คิดตั้งหลายเรื่อง เลยไม่มีโอกาสได้มา... แต่ตอนนี้ก็มาถึงแล้วล่ะนะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:19
translate english arc2_hinata_quest1_2_d2bb48ee:

    # n "[MN] toca la puerta"
    n "[MN] เคาะประตู"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:21
translate english arc2_hinata_quest1_2_28b0375a:

    # n "Rápidamente se escuchan unos pasos acercarse, y rápidamente alguien abre la puerta"
    n "เสียงฝีเท้าใกล้เข้ามาอย่างรวดเร็ว และมีคนเปิดประตูทันที"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:29
translate english arc2_hinata_quest1_2_2bc79c09:

    # hm "¡[MN]! ¡Bienvenido!" with vpunch
    hm "[MN]! ยินดีต้อนรับค่ะ!" with vpunch

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:31
translate english arc2_hinata_quest1_2_79bf889b:

    # mn "Himawari! Buenos días, espero no haber llegado muy temprano"
    mn "ฮิมาวาริ! อรุณสวัสดิ์ หวังว่าฉันคงไม่ได้มาเช้าเกินไปหรอกนะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:32
translate english arc2_hinata_quest1_2_f1c5b843:

    # hm "Para nada, llegas justo a tiempo"
    hm "ไม่เลยค่ะ มาได้เวลาพอดีเลย"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:33
translate english arc2_hinata_quest1_2_d7883c4a:

    # hm "Vamos, pasa adelante"
    hm "เชิญเข้ามาข้างในก่อนสิคะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:36
translate english arc2_hinata_quest1_2_90a06247:

    # n "Himawari llevó a [MN] al interior de la casa"
    n "ฮิมาวารินำทาง [MN] เข้าไปในบ้าน"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:44
translate english arc2_hinata_quest1_2_e619b5cb:

    # hm "Mamá, [MN] ya está aquí"
    hm "คุณแม่คะ [MN] มาแล้วค่ะ!"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:48
translate english arc2_hinata_quest1_2_07568263:

    # n "Hinata aparece, feliz de ver a [MN] nuevamente" with fade
    n "ฮินาตะปรากฏตัวขึ้นด้วยความดีใจที่ได้พบ [MN] อีกครั้ง" with fade

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:49
translate english arc2_hinata_quest1_2_18492779:

    # hi "[MN] Que gusto verte, me alegra que te hayas decidido venir a visitarnos"
    hi "[MN] ดีใจจังเลยที่ได้พบคุณ! ดีใจนะที่คุณตัดสินใจแวะมาเยี่ยมพวกเรา"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:50
translate english arc2_hinata_quest1_2_4b493ec1:

    # mn "Hola Señorita Hinata, es un placer volver a verla"
    mn "สวัสดีครับคุณฮินาตะ ดีใจที่ได้พบคุณอีกครั้งเช่นกันครับ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:51
translate english arc2_hinata_quest1_2_65e22286:

    # hi "Por favor, solo dime Hinata, no tienes que ser tan formal"
    hi "ตามสบายเถอะจ่ะ เรียกว่าฮินาตะเฉยๆ ก็ได้ ไม่ต้องเป็นทางการขนาดนั้นหรอก"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:53
translate english arc2_hinata_quest1_2_6eab5379:

    # hi "Siéntete como en casa"
    hi "ตามสบายเลยนะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:56
translate english arc2_hinata_quest1_2_d8615ab9:

    # mn "Gracias Hinata"
    mn "ขอบคุณครับ ฮินาตะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:58
translate english arc2_hinata_quest1_2_3535780d:

    # hm "Bueno, ¿Qué tal si vamos a la sala? Tenémos que ponernos al día ¿Cierto?"
    hm "งั้นเราไปที่ห้องนั่งเล่นกันดีไหมคะ? เรามีเรื่องต้องคุยกันอีกเยอะเลยใช่ไหมล่ะคะ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:60
translate english arc2_hinata_quest1_2_1263f2e2:

    # mn "Claro jaja, vamos entonces"
    mn "นั่นสินะ ฮ่าๆ งั้นไปกันเลย"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:63
translate english arc2_hinata_quest1_2_81338fad:

    # n "Ambos caminaron hacia la sala y se acomodaron para conversar"
    n "พวกเขาทั้งสองเดินไปที่ห้องนั่งเล่นแล้วนั่งลงเพื่อพูดคุยกัน"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:72
translate english arc2_hinata_quest1_2_8a953ea7:

    # hm "Hace mucho que no hablamos"
    hm "พวกเราไม่ได้คุยกันนานเลยนะคะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:73
translate english arc2_hinata_quest1_2_2cf042dd:

    # hm "No creí que cambiaras tanto en este tiempo"
    hm "ไม่คิดเลยว่าช่วงนี้คุณจะเปลี่ยนไปเยอะขนาดนี้"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:75
translate english arc2_hinata_quest1_2_16f534eb:

    # mn "Bueno, han pasado muchas cosas últimamente jaja..."
    mn "ก็นะ ช่วงนี้มีเรื่องเกิดขึ้นตั้งหลายอย่างน่ะ ฮ่าๆ..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:77
translate english arc2_hinata_quest1_2_a30faa60:

    # mn "Pero yo también puedo decir lo mismo de tí Himawari, has crecido mucho"
    mn "แต่ฉันก็พูดเรื่องเดียวกันนี้กับเธอได้เหมือนกันนะ ฮิมาวาริ เธอดูโตขึ้นเยอะเลย"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:78
translate english arc2_hinata_quest1_2_ca634915:

    # mn "La última vez que te ví aún estabas en la academia"
    mn "ครั้งล่าสุดที่ฉันเจอเธอ เธอยังเรียนอยู่ที่สถาบันนินจาอยู่เลย"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:80
translate english arc2_hinata_quest1_2_9bdfce93:

    # hm "Si, ahora ya soy toda una adulta"
    hm "ใช่ค่ะ ตอนนี้หนูกลายเป็นผู้ใหญ่เต็มตัวแล้วนะคะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:82
translate english arc2_hinata_quest1_2_29173e85:

    # mn "¿Cómo te va con tus misiones? Me imagino que ya haces con tu Equipo ¿Cierto?"
    mn "แล้วภารกิจช่วงนี้เป็นยังไงบ้างล่ะ? ฉันเดาว่าเธอคงเริ่มทำงานร่วมกับทีมแล้วใช่ไหม?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:83
translate english arc2_hinata_quest1_2_3ba93608:

    # hm "Nos está yendo bien, aunque aún tengo que aprender"
    hm "ก็ไปได้ด้วยดีค่ะ แม้ว่าหนูยังต้องเรียนรู้อีกเยอะเลยก็ตามที"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:84
translate english arc2_hinata_quest1_2_c09bb12b:

    # hm "Por eso me esfuerzo todos los días para sobrepasar mis límites"
    hm "นั่นแหละค่ะคือเหตุผลที่หนูต้องขยันฝึกซ้อมทุกวันเพื่อก้าวข้ามขีดจำกัดของตัวเอง"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:86
translate english arc2_hinata_quest1_2_2333b384:

    # mn "Esa es la actitud Hima, se nota que eres hija del Séptimo Hokage"
    mn "สมกับเป็นฮิมาจิงๆ สมแล้วที่เป็นลูกสาวของท่านโฮคาเงะรุ่นที่ 7"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:88
translate english arc2_hinata_quest1_2_26704f61:

    # mn "No dudo en que llegarás lejos si sigues con esa motivación, de veras"
    mn "ฉันเชื่อเลยว่าถ้าเธอยังรักษาแรงผลักดันนี้ไว้ได้ ไกลเกินเอื้อมแน่ๆ จริงๆ นะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:90
translate english arc2_hinata_quest1_2_4dc697bf:

    # hm "Gracias jaja... ¿De veras?"
    hm "ขอบคุณค่ะ ฮ่าๆ... จริงเหรอคะเนี่ย?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:93
translate english arc2_hinata_quest1_2_17f68a15:

    # mn "Ah, lo siento jaja... Es algo que se me pegó del Séptimo Hokage..."
    mn "อ่า ขอโทษทีนะ ฮ่าๆ... มันติดมาจากท่านโฮคาเงะรุ่นที่ 7 น่ะ..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:95
translate english arc2_hinata_quest1_2_b8743ea7:

    # hm "No importa, ahora, hay algo que me llama mucho la atención"
    hm "ไม่เป็นไรค่ะ งั้น... มีเรื่องหนึ่งที่คาใจหนูมาตลอดเลยล่ะค่ะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:97
translate english arc2_hinata_quest1_2_d860adda:

    # hm "Cuéntame, ¿Porqué te cambió de color el Ojo?"
    hm "บอกหนูหน่อยสิคะ ทำไมตาของคุณถึงเปลี่ยนสีได้ล่ะคะ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:101
translate english arc2_hinata_quest1_2_9846e4e2:

    # mn "Eso jaja, es una larga historia"
    mn "เรื่องนั้นเหรอ ฮ่าๆ มันยาวน่ะสิ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:105
translate english arc2_hinata_quest1_2_f3bce1a8:

    # hm "Eso dijiste el día que nos encontramos, y te lo dejé pasar porque esbas ocupado"
    hm "คุณก็พูดแบบนี้เมื่อวันที่เราเจอกัน แล้วหนูก็ยอมปล่อยผ่านเพราะเห็นว่าคุณกำลังยุ่งอยู่"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:108
translate english arc2_hinata_quest1_2_115c0ed8:

    # hm "Pero ahora no escaparás, tenémos todo el día para que me cuentes jiji"
    hm "แต่ตอนนี้คุณหนีไม่พ้นแล้วล่ะค่ะ เรามีเวลาทั้งวันให้คุณเล่าให้ฟังเลยนะ ฮี่ๆ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:110
translate english arc2_hinata_quest1_2_82cd36b5:

    # mn "*suspiro* Está bien, admito que me atrapaste jaja"
    mn "*ถอนหายใจ* ให้ตายสิ ยอมแพ้เลยนะเนี่ย ฮ่าๆ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:114
translate english arc2_hinata_quest1_2_e6e7811b:

    # n "[MN] le contó a Himawari todo lo que había descubierto en los últimos meses, desde el {b}Karugan{/a} hasta lo poco que sabía sobre su clan"
    n "[MN] เล่าเรื่องทุกอย่างที่เขาค้นพบตลอดช่วงหลายเดือนที่ผ่านมาให้ฮิมาวาริฟัง ตั้งแต่เรื่องเนตร {b}คารูกัน{/a} ไปจนถึงเรื่องตระกูลของเขาที่พอจะรู้มาบ้าง"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:115
translate english arc2_hinata_quest1_2_0e3f50fe:

    # n "Sin entrar en demasiados detalles, evitó mencionar ciertas habilidades específicas, pero fue honesto acerca de su incertidumbre y su deseo de saber más"
    n "โดยเลี่ยงที่จะลงรายละเอียดลึกเกินไป และไม่พูดถึงความสามารถเฉพาะตัวบางอย่าง แต่ก็พูดความจริงเกี่ยวกับความไม่แน่นอนของตัวเองและความต้องการที่จะเรียนรู้ให้มากขึ้น"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:120
translate english arc2_hinata_quest1_2_3475fb04:

    # n "La conversación continuó por un rato, mientras ambos compartían sus experiencias recientes"
    n "บทสนทนาดำเนินต่อไปสักพัก ขณะที่พวกเขาร่วมพูดคุยแบ่งปันเรื่องราวประสบการณ์ช่วงนี้ให้กันฟัง"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:121
translate english arc2_hinata_quest1_2_29344de5:

    # n "En medio de su charla, el sonido de pasos los interrumpió, y de pronto aparecieron Naruto y Hinata en la sala"
    n "ท่ามกลางบทสนทนา เสียงฝีเท้าก็ดังขึ้นขัดจังหวะพวกเขาก่อนที่นารูโตะกับฮินาตะจะปรากฏตัวขึ้นในห้องอย่างกะทันหัน"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:129
translate english arc2_hinata_quest1_2_99f2e08c:

    # nt "Vaya, [MN], que milagro verte por aquí, hace mucho no venías de visita"
    nt "โอ้ [MN] เซอร์ไพรส์จังเลยนะที่ได้เห็นเธอที่นี่ ไม่ได้มาเยี่ยมซะนานเลยนะเนี่ย"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:130
translate english arc2_hinata_quest1_2_f22bfb43:

    # nt "¿A tí también te atraparon hoy?"
    nt "โดนจับตัวมาเหมือนกันเหรอวันนี้?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:134
translate english arc2_hinata_quest1_2_e8edadec:

    # hihm "¿Atraparon?"
    hihm "จับตัวเหรอคะ/เหรอจ๊ะ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:138
translate english arc2_hinata_quest1_2_bbc1185e:

    # nt "Eh, digo, jejeje..."
    nt "เอ่อ หมายถึง แบบว่า แหะๆ..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:143
translate english arc2_hinata_quest1_2_91489d9d:

    # mn "Señor séptimo, Hinata, es un honor estár aquí con ustedes"
    mn "ท่านโฮคาเงะ ฮินาตะ เป็นเกียรติจริงๆ ครับที่ได้มาอยู่ที่นี่กับพวกท่าน"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:145
translate english arc2_hinata_quest1_2_78de2c61:

    # nt "Un momento, no tienes que ser tan formal aquí, siéntete libre"
    nt "เดี๋ยวก่อน ไม่ต้องเป็นทางการขนาดนั้นหรอกน่า อยู่กันตามสบายเถอะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:147
translate english arc2_hinata_quest1_2_7694746b:

    # nt "Aquí no soy el Hokage, solo llámame solo Naruto"
    nt "ที่นี่ฉันไม่ได้เป็นโฮคาเงะหรอก เรียกฉันว่านารูโตะก็พอ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:149
translate english arc2_hinata_quest1_2_f58e1ce4:

    # mn "E-Está bien... Naruto"
    mn "อ-โอเค... นารูโตะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:151
translate english arc2_hinata_quest1_2_c85f6868:

    # mn "Gracias por recibirme, me alegra estar aquí después de tanto tiempo"
    mn "ขอบคุณที่ต้อนรับนะครับ ดีใจจริงๆ ที่ได้มาที่นี่หลังจากไม่ได้มานาน"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:152
translate english arc2_hinata_quest1_2_83d707ce:

    # mn "Con todo lo que ha pasado últimamente, no he tenido nada de tiempo libre"
    mn "ช่วงนี้มีเรื่องเกิดขึ้นตั้งหลายอย่าง ผมเลยแทบไม่มีเวลาว่างเลยครับ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:153
translate english arc2_hinata_quest1_2_616ea0f3:

    # hi "Todos necesitamos un descanso de vez en cuando, es bueno que tomes este tiempo para relajarte antes de los Exámenes"
    hi "คนเราก็ต้องพักผ่อนกันบ้างเป็นธรรมดาแหละจ้ะ ดีแล้วล่ะที่เธอใช้เวลาตอนนี้พักผ่อนก่อนจะถึงการสอบ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:154
translate english arc2_hinata_quest1_2_f1ded560:

    # hm "Eso le estaba diciendo"
    hm "นั่นแหละค่ะที่หนูบอกเขาไป"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:157
translate english arc2_hinata_quest1_2_0c7162f5:

    # hm "Por cierto Papá, tú también necesitas descansar más seguido"
    hm "ว่าแต่ คุณพ่อเองก็ควรพักผ่อนให้บ่อยขึ้นเหมือนกันนะคะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:159
translate english arc2_hinata_quest1_2_dafd26d2:

    # nt "Sí, sí, lo sé... Pero alguien tiene que asegurarse de que todo marche bien en la aldea, ¿No?"
    nt "จ้าๆ พ่อรู้แล้ว... แต่ก็ต้องมีคนคอยดูแลให้ทุกอย่างในหมู่บ้านเรียบร้อยดีนี่นา จริงไหมล่ะ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:162
translate english arc2_hinata_quest1_2_0c07eb5e:

    # hi "Naruto, hoy no hablemos de trabajo, ¿Si?, tú también debes relajarte"
    hi "นารูโตะ วันนี้เราไม่คุยเรื่องงานกันดีกว่านะจ๊ะ? คุณเองก็ต้องพักผ่อนเหมือนกันนะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:166
translate english arc2_hinata_quest1_2_2e935745:

    # nt "E-Está bien..."
    nt "ก-ก็ได้..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:172
translate english arc2_hinata_quest1_2_01d33ef8:

    # hi "Por cierto, ¿Estás listo para los Exámenes Chunin [MN]?"
    hi "ว่าแต่อีก, [MN] พร้อมสำหรับการสอบจูนินแล้วหรือยังจ๊ะ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:174
translate english arc2_hinata_quest1_2_23255c28:

    # hi "Este año no serán como los anteriores, será mucho más peligroso, así que debes estar preparado"
    hi "ปีนี้จะไม่เหมือนกับครั้งก่อนๆ มันจะอันตรายกว่าเดิมมาก เพราะฉะนั้นลูกต้องเตรียมตัวให้พร้อมเสมอนะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:175
translate english arc2_hinata_quest1_2_a1846e76:

    # mn "Estoy haciendo lo mejor que puedo, aún puedo mejorar mucho, pero estoy seguro que puedo hacerlo"
    mn "ผมพยายามเต็มที่เลยครับ ถึงจะยังมีจุดที่ต้องพัฒนาอีกเยอะ แต่ผมมั่นใจว่าทำได้แน่นอนครับ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:176
translate english arc2_hinata_quest1_2_8349c365:

    # nt "Eso es bueno de escuchar, sé que si trabajas duro y trabajan en equipo, lo harán bien"
    nt "ฟังแล้วชื่นใจจริงๆ ฉันรู้ว่าถ้าเธอขยันและทำงานร่วมกับทีมได้ดี เธอจะต้องทำได้ดีแน่ๆ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:179
translate english arc2_hinata_quest1_2_e3ccedbe:

    # n "La conversación continuó de manera relajada, mientras Naruto y Hinata comtartían algunas anécdotas de sus propias experiencias"
    n "บทสนทนาดำเนินต่อไปด้วยบรรยากาศสบายๆ เมื่อนารูโตะและฮินาตะช่วยกันเล่าเกร็ดเล็กเกร็ดน้อยจากประสบการณ์ของตัวเองให้ฟัง"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:180
translate english arc2_hinata_quest1_2_2bfd45c0:

    # n "También le dieron bastantes consejos para mejorar ciertos aspectos"
    n "พวกเขายังให้คำแนะนำมากมายเพื่อช่วยปรับปรุงจุดต่างๆ ให้ดีขึ้นด้วย"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:181
translate english arc2_hinata_quest1_2_cefe6fed:

    # n "Tales como control y manejo de chakra, su postura de combate, estrategias con ciertos jutjus, etc."
    n "อย่างเช่นการควบคุมและการจัดการจักระ ท่าทางการต่อสู้ กลยุทธ์ในการใช้นินจาคาถาบางประเภท และอื่นๆ อีกมากมาย"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:182
translate english arc2_hinata_quest1_2_e635aafb:

    # n "El ambiente se volvió muy cálido, [MN] se sintió como en casa..."
    n "บรรยากาศอบอุ่นเป็นกันเองมาก จน [MN] รู้สึกเหมือนได้อยู่บ้าน..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:184
translate english arc2_hinata_quest1_2_147ccd89:

    # n "Algo que no experimentaba muy a menudo..."
    n "ความรู้สึกแบบนี้... เป็นสิ่งที่เขาไม่ค่อยได้สัมผัสบ่อยนักหรอก..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:197
translate english arc2_hinata_quest1_2_bc3eb633:

    # mn "¿Entonces eso se puede hacer? Vaya, no lo sabía"
    mn "แบบนั้นก็ทำได้ด้วยเหรอครับเนี่ย? โอ้โห ผมเพิ่งรู้เลยนะเนี่ย"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:198
translate english arc2_hinata_quest1_2_97de543f:

    # nt "Si, solo debes de saber manejar bien el flujo de chakra y mantener la concentración"
    nt "ใช่แล้ว แค่ต้องรู้กําวิธีควบคุมการไหลของจักระให้ดีและมีสมาธิอยู่เสมอก็พอ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:199
translate english arc2_hinata_quest1_2_053d10b7:

    # nt "Lo hice varias veces con mi Maestro..."
    nt "ฉันเคยทำมันหลายครั้งแล้วตอนที่อยู่กับอาจารย์ของฉัน..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:201
translate english arc2_hinata_quest1_2_7aad5715:

    # hm "Oigan, ¿De qué jutsu están hablando?"
    hm "เดี๋ยวนะคะ คาถาอะไรกันเหรอที่คุยอยู่?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:204
translate english arc2_hinata_quest1_2_a6ae3d9e:

    # hi "Naruto... No me digas que le enseñaste ese Jutsu"
    hi "นารูโตะ... อย่าบอกนะว่าคุณสอนคาถา*นั้น*ให้เขาเนี่ย"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:207
translate english arc2_hinata_quest1_2_d1ae6633:

    # nt "¡Eeh! ¡N-No, para nada!" with vpunch
    nt "เอ๊ะ! ม-ไม่เลยสักนิด!" with vpunch

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:209
translate english arc2_hinata_quest1_2_e22d2f8a:

    # mn "Este, ehh... Jajaja..."
    mn "เอ่อ เอ๊ะ... ฮ่าๆ..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:211
translate english arc2_hinata_quest1_2_5e181dc1:

    # hi "..."
    hi "..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:212
translate english arc2_hinata_quest1_2_e862c801:

    # hm "¿De qué Jutsu hablan?"
    hm "สรุปว่าคุยเรื่องคาถาอะไรกันอยู่เหรอคะ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:215
translate english arc2_hinata_quest1_2_77a11f8a:

    # hi "Oh, miren la hora que es, ya es demasiado tarde"
    hi "อุ๊ย ตายจริง ดูเวลาสิคะ ดึกขนาดนี้แล้วเหรอเนี่ย"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:219
translate english arc2_hinata_quest1_2_c624729b:

    # hi "Himawari, ¿Pueder venir conmigo a la tienda?"
    hi "ฮิมาวาริ ไปซื้อของที่ร้านกับแม่หน่อยจ่ะ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:220
translate english arc2_hinata_quest1_2_5d3fd3e1:

    # hi "Necesitamos comprar algunas cosas para la cena"
    hi "เราต้องซื้อของทำมื้อเย็นเพิ่มอีกร้อยอย่าง"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:222
translate english arc2_hinata_quest1_2_e78ae909:

    # hm "Claro Mamá"
    hm "ค่ะ คุณแม่"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:226
translate english arc2_hinata_quest1_2_dd840a28:

    # hi "Naruto-kun..."
    hi "นารูโตะคุง..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:230
translate english arc2_hinata_quest1_2_4e47bd57:

    # nt "Ah, ¿S-Si?"
    nt "อ่า ค-ครับ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:234
translate english arc2_hinata_quest1_2_afd5f6ee:

    # hi "Por favor descansa, no te vayas a sobre exigir, ¿Entendido?"
    hi "ช่วยพักผ่อนด้วย อย่าหักโหมงานให้มากนักล่ะ เข้าใจไหมคะ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:236
translate english arc2_hinata_quest1_2_3e80db9a:

    # nt "Si, no te preocupes Hinata, vayan con cuidado"
    nt "จ้า ไม่ต้องห่วงนะฮินาตะ เดินทางปลอดภัยนะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:239
translate english arc2_hinata_quest1_2_2cc7b17b:

    # n "Hinata y Himawari se despidieron momentáneamente, dejando a [MN] a solas con Naruto"
    n "ฮินาตะและฮิมาวาริกล่าวลาชั่วคราว ปล่อยให้ [MN] อยู่ตามลำพังกับนารูโตะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:240
translate english arc2_hinata_quest1_2_87ea7a3e:

    # n "El ambiente se volvió ligeramente más tranquilo cuando Hinata y Himawari salieron, dejando a [MN] y Naruto solos en la sala"
    n "บรรยากาศดูสงบลงเล็กน้อยเมื่อฮินาตะและฮิมาวาริออกไป ปล่อยให้ [MN] และนารูโตะอยู่กันตามลำพังในห้อง"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:249
translate english arc2_hinata_quest1_2_7eef81eb:

    # mn "Naruto, ¿Se encuentra bien? Parece algo cansado"
    mn "นารูโตะ เป็นอะไรหรือเปล่าครับ? ดูเหนื่อยๆ นะครับเนี่ย"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:251
translate english arc2_hinata_quest1_2_87096742:

    # nt "¿Eh? Si, si, no te preocupes, estoy bien jaja..."
    nt "หือ? เปล่าๆ ไม่ต้องห่วง ฉันยังไหว ฮ่าๆ..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:253
translate english arc2_hinata_quest1_2_2ab0d582:

    # mn "Bueno..."
    mn "คือว่า..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:254
translate english arc2_hinata_quest1_2_ad972c35:

    # mn "Hinata y Himawari se preocupan mucho por usted, de verdad no se exija mucho en el trabajo"
    mn "ทั้งฮินาตะและฮิมาวาริเป็นห่วงคุณมากเลยนะครับ ยังไงก็อย่าหักโหมงานให้มันมากนักสิครับ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:255
translate english arc2_hinata_quest1_2_03a1573b:

    # nt "Si jaja... Ambas se preocupan mucho... Pero tienen razón, debo cuidarme más"
    nt "นั่นสินะ ฮ่าๆ... สองแม่ลูกเขาเป็นห่วงกันเก่งจริง ๆ... แต่พวกเขาก็พูดถูก ฉันควรจะดูแลตัวเองให้ดีกว่านี้หน่อย"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:257
translate english arc2_hinata_quest1_2_8e8d8f3b:

    # mn "Hace mucho que no venía a visitarlos, ¿Hace cuánto fue, 6 o 7 años?"
    mn "ก็นี่มันนานมากแล้วนี่ครับที่ผมไม่ได้มาเยี่ยมพวกคุณเลย สัก... 6 หรือ 7 ปีได้แล้วมั้งครับ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:258
translate english arc2_hinata_quest1_2_6b84e8a9:

    # mn "Himawari ha crecido mucho... Y vaya que tiene carácter"
    mn "ฮิมาวาริโตขึ้นเยอะเลยแฮะ... แล้วก็นะ โห มีความเป็นตัวของตัวเองสูงมากเลยทีเดียว"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:259
translate english arc2_hinata_quest1_2_2811a0cc:

    # nt "Si... De verdad ha crecido"
    nt "นั่นสินะ... แกโตขึ้นเยอะเลยล่ะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:260
translate english arc2_hinata_quest1_2_7eabcfc8:

    # nt "Hima siempre ha tenido esa mezcla de ternura y fuerza"
    nt "ฮิมาเนี่ยมีนิสัยที่ผสมผสานระหว่างความอ่อนโยนกับความแข็งแกร่งมาตั้งแต่ไหนแต่ไรแล้วล่ะนะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:261
translate english arc2_hinata_quest1_2_a2167c98:

    # nt "Su carácter fuerte ya venía desde pequeña jaja"
    nt "นิสัยใจคอที่เข้มแข็งน่ะมีมาตั้งแต่ตอนที่ยังเด็ก ๆ แล้วล่ะ ฮ่าๆ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:263
translate english arc2_hinata_quest1_2_657ad3a0:

    # mn "¿De verdad? No la recuerdo así"
    mn "เหรอครับ? ผมจำไม่ได้แฮะว่าแกเคยเป็นแบบนั้น"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:266
translate english arc2_hinata_quest1_2_1bfad3e2:

    # nt "Te contaré una anecdota, fue el día que me iban a nombrar Hokage"
    nt "งั้นฉันจะเล่าอะไรให้ฟัง มันคือวันเดียวกับที่ฉันกำลังจะได้เข้ารับตำแหน่งโฮคาเงะน่ะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:268
translate english arc2_hinata_quest1_2_55ce00d8:

    # nt "Estábamos Boruto, Himawari y yo en casa"
    nt "โบรูโตะ ฮิมาวาริ แล้วก็ฉัน... พวกเราอยู่กันที่บ้าน"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:269
translate english arc2_hinata_quest1_2_a25c3a59:

    # nt "Boruto estaba peleando con Himawari mientras yo me preparaba para irnos"
    nt "โบรูโตะกำลังทะเลาะอยู่กับฮิมาวาริ ตอนที่ฉันกำลังเตรียมตัวจะออกไปพอดี"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:272
translate english arc2_hinata_quest1_2_c5905dd3:

    # nt "Yo les estaba gritando para que se apresuraran, cuando de pronto sentí un chakra elevarse"
    nt "ฉันกำลังตะโกนเร่งพวกแกอยู่ จู่ ๆ ก็สัมผัสได้ถึงจักระที่พุ่งสูงขึ้น"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:274
translate english arc2_hinata_quest1_2_d320cdf3:

    # nt "Poco después Boruto salió aterrado, decía que se volvió fuerte y peligrosa"
    nt "หลังจากนั้นไม่นาน โบรูโตะก็วิ่งเตลิดเปิดเปิงออกมาด้วยความกลัว บอกว่ายัยหนูนั่นทั้งเก่งแถมยังอันตรายสุด ๆ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:276
translate english arc2_hinata_quest1_2_79abbd00:

    # nt "Y ahí salió, ¡Himawari había despertado el Byakugan!" with vpunch
    nt "และนั่นแหละ... ฮิมาวาริเบิกเนตรสีขาวตื่นขึ้นมาแล้ว!" with vpunch

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:278
translate english arc2_hinata_quest1_2_f3766878:

    # nt "Y estaba lista para atacar a Boruto"
    nt "แถมยังเตรียมจะพุ่งเข้าไปเล่นงานโบรูโตะอีกต่างหาก"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:280
translate english arc2_hinata_quest1_2_afd38d92:

    # mn "¡¿D-De verdad?!" with vpunch
    mn "จ-จริงเหรอครับเนี่ย?!" with vpunch

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:282
translate english arc2_hinata_quest1_2_b6755250:

    # nt "¿Puedes creerlo? Era muy pequeña en ese entonces"
    nt "เชื่อไหมล่ะ? ทั้งที่ตอนนั้นตัวยังเล็กนิดเดียวเองแท้ ๆ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:283
translate english arc2_hinata_quest1_2_79cf65a3:

    # nt "Yo al verla me dí prisa, iba a golpear a Boruto, que en ese momento estaba aterrado mientras pedía auxilio"
    nt "พอฉันเห็นเข้าก็รีบพุ่งเข้าไปเลย ตอนนั้นแกกำลังจะซัดโบรูโตะที่กำลังกลัวจนหัวหดแถมยังร้องขอชีวิตอยู่พอดี"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:285
translate english arc2_hinata_quest1_2_75467e0a:

    # nt "Yo me puse frente a él para bloquear el golpe..."
    nt "ฉันเลยก้าวไปขวางข้างหน้าเพื่อรับหมัดนั้นแทน..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:287
translate english arc2_hinata_quest1_2_4af19744:

    # nt "¡Y me Golpeó!" with vpunch
    nt "แล้วฉันก็โดนซัดเข้าเต็มรักเลย!" with vpunch

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:288
translate english arc2_hinata_quest1_2_4219312d:

    # mn "¡¿Qué?!" with hpunch
    mn "หาบะฮ์?!" with hpunch

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:292
translate english arc2_hinata_quest1_2_4e33d6d7:

    # nt "Luego de eso Hinata tuvo que {b}Despertarme para llegar a tiempo{/a} a la ceremonia"
    nt "หลังจากนั้น ฮินาตะเลยต้อง {b}ปลุกฉันให้ตื่นเพื่อให้ไปร่วมพิธีทันเวลา{/b}"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:294
translate english arc2_hinata_quest1_2_87292929:

    # mn "¿Lo dejó inconsciente?"
    mn "ถึงกับสลบเลยเหรอครับนั่น?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:296
translate english arc2_hinata_quest1_2_54649160:

    # nt "Si jajaja, incluso dejó inconsciente al propio Kurama"
    nt "ใช่แล้ว ฮ่าๆๆ เล่นเอาคุรามะสลบเหมือดไปด้วยเลยล่ะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:297
translate english arc2_hinata_quest1_2_0ba8a990:

    # mn "¿Kurama?..."
    mn "คุรามะ?... คร้าบ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:300
translate english arc2_hinata_quest1_2_2f982e1f:

    # nt "Ah... Este..."
    nt "อ่า... เรื่องนี้น่ะนะ..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:301
translate english arc2_hinata_quest1_2_c099cc63:

    # n "El semblante de Naruto cambió ligeramente..."
    n "สีหน้าของนารูโตะเปลี่ยนไปเล็กน้อย..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:303
translate english arc2_hinata_quest1_2_da598802:

    # nt "Sí... Kurama... Ustedes lo conocerán como el Zorro de Nueve colas"
    nt "ใช่แล้ว... คุรามะ... นายคงรู้จักเขาในฐานะจิ้งจอกเก้าหางสินะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:304
translate english arc2_hinata_quest1_2_38e4fe28:

    # nt "Él estuvo conmigo desde el día que nací"
    nt "เขาอยู่เคียงข้างฉันมาตั้งแต่ฉันเกิดเลยล่ะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:305
translate english arc2_hinata_quest1_2_ae4ae32a:

    # mn "¿Y qué pasó con él?"
    mn "แล้วเกิดอะไรขึ้นกับเขากันล่ะครับ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:307
translate english arc2_hinata_quest1_2_f8047cde:

    # nt "Bueno... El murió en la batalla contra Isshiki..."
    nt "ก็... เขาเสียชีวิตในการต่อสู้กับอิชิกิ..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:309
translate english arc2_hinata_quest1_2_4740bc0d:

    # nt "Durante la batalla tuve que usar una técnica llamada {b}Modo Barion{/a}"
    nt "ในระหว่างการต่อสู้ ฉันจำเป็นต้องใช้วิชาที่เรียกว่า {b}โหมดบาริออน{/a}"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:311
translate english arc2_hinata_quest1_2_bc6e4248:

    # nt "Una técnica que combinaba nuestros chakras, pero... Había un costo..."
    nt "มันเป็นวิชาที่หลอมรวมจักระของเราเข้าด้วยกัน แต่ว่า... มันมีราคาที่ต้องจ่าย..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:312
translate english arc2_hinata_quest1_2_5502cecb:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:313
translate english arc2_hinata_quest1_2_e7b7581e:

    # nt "El costo fue su vida..."
    nt "ราคาที่ว่านั่นก็คือชีวิตของเขา..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:315
translate english arc2_hinata_quest1_2_a884a5ac:

    # mn "Yo... De verdad lo siento... No sabía que eso había ocurrido..."
    mn "ผม... ผมเสียใจด้วยนะครับ... ผมไม่รู้มาก่อนเลยว่าเกิดเรื่องแบบนี้ขึ้น..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:317
translate english arc2_hinata_quest1_2_59e9b49f:

    # nt "No te preocupes, no es tu culpa, esa era información que solo un pequeño círculo de personas sabía, es normal que no lo supieras"
    nt "ไม่ต้องห่วงหรอก ไม่ใช่ความผิดของเธอสักหน่อย เรื่องนั้นมีแค่คนวงในไม่กี่คนที่รู้เท่านั้นเอง การที่เธอจะไม่รู้ก็เป็นเรื่องธรรมดาแหละนะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:319
translate english arc2_hinata_quest1_2_1bb34dac:

    # mn "Entiendo..."
    mn "เข้าใจแล้วครับ..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:320
translate english arc2_hinata_quest1_2_d5fe1ebc:

    # mn "Si no quiere hablar sobre él... Puedo entenderlo"
    mn "ถ้าท่านไม่อยากพูดถึงเรื่องของเขา... ผมก็เข้าใจนะครับ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:322
translate english arc2_hinata_quest1_2_409de26b:

    # nt "Está bien, no hay problema, ahora estoy bien"
    nt "ไม่เป็นไร ไม่มีปัญหาเลย ตอนนี้ฉันทำใจได้แล้วล่ะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:324
translate english arc2_hinata_quest1_2_57f4cb23:

    # nt "Verás, cuando una {b}Bestia con Cola{/a} muere, esta renace en algún lugar del mundo"
    nt "You see, when a {b}Tailed Beast{/a} dies, it is reborn somewhere in the world"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:325
translate english arc2_hinata_quest1_2_bc105f69:

    # nt "Esto es debido a que las {b}Bestias con Cola{/a} son chakra puro, no pueden morir permanentemente"
    nt "This is because {b}Tailed Beasts{/a} are pure chakra, they cannot die permanently"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:327
translate english arc2_hinata_quest1_2_d10f4bf9:

    # nt "Si ellos o sus jinchuriki mueren, su chakra se volverá a formar con el tiempo"
    nt "ถ้าหากพวกมันหรือร่างสถิตเสียชีวิต จักระของพวกมันก็จะก่อตัวขึ้นใหม่ตามกาลเวลา"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:328
translate english arc2_hinata_quest1_2_73370c01:

    # nt "Eso fue hace ya unos 7 años ya, así que mi teoría es que renació en algún lugar del mundo"
    nt "เหตุการณ์นั้นเกิดขึ้นเมื่อประมาณ 7 ปีមុន ทฤษฎีของฉันก็เลยคิดว่ามันน่าจะไปเกิดใหม่ที่ไหนสักแห่งบนโลกใบนี้แล้วล่ะนะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:330
translate english arc2_hinata_quest1_2_3784c00b:

    # nt "Hemos estado buscandolo todo este tiempo, envié varios equipos para intentar localizarlo, porque..."
    nt "พวกเราตามหากันมาตลอดเลยล่ะ ฉันส่งหลาย ๆ ทีมออกไปเพื่อพยายามหาเบาะแส เพราะว่า..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:331
translate english arc2_hinata_quest1_2_4e7ff57d:

    # nt "Si está suelto, podría ser peligroso... Tampoco podemos dejar que caiga en manos de otra Aldea"
    nt "ถ้าปล่อยให้มันเตลิดไปทั่ว มันอาจจะอันตรายได้... แถมเรายังปล่อยให้มันตกไปอยู่ในมือของหมู่บ้านอื่นไม่ได้ด้วย"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:332
translate english arc2_hinata_quest1_2_bc7e7ea2:

    # nt "Y no sabemos si es el mismo Kurama que conocí, o si volvió a ser el ser salvaje que era antes"
    nt "แถมเราก็ไม่รู้ด้วยว่ามันจะยังเป็นคุรามะตัวเดิมที่ฉันเคยรู้จัก หรือว่าคืนสภาพกลับไปเป็นสัตว์ป่าดุร้ายเหมือนเมื่อก่อนกันแน่"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:333
translate english arc2_hinata_quest1_2_bf603319:

    # mn "Debe ser difícil para usted, especialmente porque estuvieron vinculados toda su vida..."
    mn "คงจะยากลำบากสำหรับท่านน่าดูเลยนะครับ โดยเฉพาะเมื่อผูกพันกันมาทั้งชีวิตแบบนั้น..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:334
translate english arc2_hinata_quest1_2_c99445df:

    # nt "Si... Kurama y yo no empezamos bien, ¿Sabes?"
    nt "ใช่... ตอนแรกฉันกับคุรามะไม่ได้เริ่มต้นกันด้วยดีเท่าไหร่หรอกนะรู้ไหม?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:336
translate english arc2_hinata_quest1_2_0a6778b1:

    # nt "Fue una relación de odio mutuo al principio, pero con el tiempo... Se convirtió en parte de mi Familia"
    nt "ตอนแรกมันคือความสัมพันธ์แบบเกลียดชังกันและกัน แต่พอผ่านไปนานเข้า... เขาก็กลายเป็นส่วนหนึ่งในครอบครัวของฉันไปซะแล้ว"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:337
translate english arc2_hinata_quest1_2_0f89e650:

    # nt "Su poder ayudó mucho en la {b}Cuarta Gran Guerra Ninja{/a}"
    nt "พลังของเขาช่วยได้มากใน {b}สงครามโลกนินจาครั้งที่ 4{/a}"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:338
translate english arc2_hinata_quest1_2_787818c6:

    # mn "¿Cree que lo volverá a encontrar?"
    mn "ท่านคิดว่าจะตามหาเขาเจออีกครั้งไหมครับ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:340
translate english arc2_hinata_quest1_2_58a36d9f:

    # nt "Eso espero... Pero incluso si lo hacemos, hay decisiones que tendré que tomar... Y no son nada fáciles"
    nt "ฉันก็หวังอย่างนั้น... แต่ต่อให้เจอ ฉันก็ต้องตัดสินใจเรื่องยากๆ... และมันคงไม่ง่ายเลยล่ะนะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:341
translate english arc2_hinata_quest1_2_d3282e85:

    # mn "¿Cómo qué?"
    mn "เรื่องอะไรเหรอครับ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:343
translate english arc2_hinata_quest1_2_672bcffc:

    # nt "..."
    nt "..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:345
translate english arc2_hinata_quest1_2_44630113:

    # nt "¿Puedo confiar en tí para no decir esto a nadie? Hasta ahora muy pocas personas saben esto"
    nt "ฉันจะไว้ใจเธอได้ไหมว่าจะไม่เอาเรื่องนี้ไปบอกใคร? จนถึงตอนนี้ มีคนรู้น้อยมากเลยนะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:347
translate english arc2_hinata_quest1_2_ff8b5f83:

    # mn "Si señor, le juro que no diré nada, por algo soy un Ninja de la Hoja, jamás revelaría información"
    mn "ได้เลยครับท่าน ผมขอสาบานว่าจะไม่ปริปากบอกใครเด็ดขาด อีกอย่าง ผมเป็นนินจาแห่งโคโนฮะ ไม่มีทางเอาความลับไปแพร่งพรายอยู่แล้วครับ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:348
translate english arc2_hinata_quest1_2_1bf18894:

    # nt "Bien... Entonces..."
    nt "งั้น... ถ้าอย่างนั้นล่ะก็..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:349
translate english arc2_hinata_quest1_2_00357d48:

    # nt "Si Kurama regresa, independientemente si es el mismo o no, tendríamos que sellarlo en un Jinchuriki..."
    nt "ถ้าคุรามะกลับมา ไม่ว่าเขาจะยังเป็นคนเดิมหรือไม่ก็ตาม พวกเราก็จำเป็นต้องผนึกเขาไว้ในร่างสถิต..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:351
translate english arc2_hinata_quest1_2_384b3403:

    # mn "Y ese sería usted, ¿No?"
    mn "แล้วคนๆ นั้นก็คือท่านสินะครับ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:353
translate english arc2_hinata_quest1_2_a6d70857:

    # nt "Yo... Ya no puedo hacerlo..."
    nt "ฉัน... ฉันทำแบบนั้นอีกไม่ไหวแล้วล่ะ..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:355
translate english arc2_hinata_quest1_2_22524eda:

    # mn "¿P-Porqué no? Así recuperaría todo el poder que tenía en el pasado, ¿No?"
    mn "ท-ทำไมล่ะครับ? แบบนั้นท่านก็จะเรียกพลังทั้งหมดที่เคยมีในอดีตกลับคืนมาได้ไม่ใช่เหรอครับ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:356
translate english arc2_hinata_quest1_2_52cc5133:

    # nt "No es tan fácil... Como ya te dije, no sabemos si es el mismo Kurama, así que no me recordaría si no es el caso"
    nt "มันไม่ได้ง่ายขนาดนั้นหรอกนะ... อย่างที่บอกไป เราไม่รู้ด้วยซ้ำว่ามันจะเป็นคุรามะตัวเดิมรึเปล่า ถ้าไม่ใช่... เขาก็คงจำฉันไม่ได้หรอก"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:357
translate english arc2_hinata_quest1_2_08381b80:

    # nt "Y no lograría tener todo el poder desde un principio"
    nt "แถมเขาก็คงไม่มีพลังทั้งหมดตั้งแต่แรกด้วย"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:358
translate english arc2_hinata_quest1_2_0ec1fb0b:

    # nt "Y si fuera el mismo Kurama..."
    nt "และถ้าหากว่าเป็นคุรามะตัวเดิมจริง ๆ ล่ะก็..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:361
translate english arc2_hinata_quest1_2_672bcffc_1:

    # nt "..."
    nt "..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:365
translate english arc2_hinata_quest1_2_062d433a:

    # nt "Yo ya no puedo... Ya estoy bastante viejo y mi cuerpo no soportaría... Estoy bastante débil..."
    nt "ฉันไม่ไหวแล้วล่ะ... ตอนนี้ฉันก็แก่ลงไปเยอะแล้ว ร่างกายคงรับไม่ไหวหรอก... ฉันค่อนข้างอ่อนแอลงแล้วล่ะนะ..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:366
translate english arc2_hinata_quest1_2_5502cecb_1:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:367
translate english arc2_hinata_quest1_2_c8740e2e:

    # mn "Entonces si debe ser alguien más, ¿Tiene a alguien en mente?"
    mn "งั้นก็ต้องเป็นคนอื่นสินะครับ ท่านพอจะมีใครอยู่ในใจบ้างรึเปล่าครับ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:369
translate english arc2_hinata_quest1_2_672bcffc_2:

    # nt "..."
    nt "..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:371
translate english arc2_hinata_quest1_2_a4389a57:

    # nt "Si..."
    nt "อืม..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:372
translate english arc2_hinata_quest1_2_4c517f5e:

    # nt "Pero... No quiero..."
    nt "แต่ว่า... ฉันไม่อยากเลย..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:373
translate english arc2_hinata_quest1_2_a65fcc20:

    # mn "Eh, ¿Porqué no, de quién se trata?"
    mn "เอ๊ะ ทำไมล่ะครับ ใครเหรอครับ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:376
translate english arc2_hinata_quest1_2_672bcffc_3:

    # nt "..."
    nt "..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:379
translate english arc2_hinata_quest1_2_9a0956f5:

    # nt "Hasta ahora, la única persona que sería capaz es..."
    nt "จนถึงตอนนี้ คนเดียวที่มีความสามารถพอจะทำได้ก็คือ..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:380
translate english arc2_hinata_quest1_2_197416b4:

    # nt "Himawari..."
    nt "ฮิมาวาริ..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:382
translate english arc2_hinata_quest1_2_5155a272:

    # mn "¡¿Himawari?!" with vpunch
    mn "ฮิมาวาริเหรอครับ?!" with vpunch

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:383
translate english arc2_hinata_quest1_2_dd8789b1:

    # nt "Si... Ella sería la mejor opción, pero no puedo imaginarme ponerle esa carga a mi hija"
    nt "ใช่... ยัยหนูคือตัวเลือกที่ดีที่สุด แต่ฉันก็นึกภาพตามไม่ออกเลยว่าจะเอาภาระแบบนั้นไปโยนใส่ลูกสาวตัวเองได้ยังไง"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:384
translate english arc2_hinata_quest1_2_5502cecb_2:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:386
translate english arc2_hinata_quest1_2_0d4484b5:

    # mn "Entiendo... Es una carga enorme, especialmente para alguien como ella..."
    mn "ผมเข้าใจครับ... มันเป็นภาระที่หนักหนามากจริงๆ โดยเฉพาะกับเด็กอย่างเธอ..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:388
translate english arc2_hinata_quest1_2_8e6b2230:

    # nt "Te juro que no sé que hacer..."
    nt "ฉันสาบานเลยว่าไม่รู้จะทำยังไงดีแล้ว..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:389
translate english arc2_hinata_quest1_2_e5e9470c:

    # nt "Como Hokage, debería tomar la decisión correcta para La Aldea de la Hoja y el Mundo Ninja"
    nt "ในฐานะโฮคาเงะ ฉันควรจะต้องตัดสินใจให้ถูกต้องเพื่อหมู่บ้านโคโนฮะและโลกนินจา"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:391
translate english arc2_hinata_quest1_2_2dd4d6cc:

    # nt "Pero como padre..."
    nt "แต่ในฐานะพ่อคนหนึ่ง...ชา"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:393
translate english arc2_hinata_quest1_2_64bf6815:

    # nt "Simplemente no puedo imaginarlo... He visto lo que significa ser un Jinchuriki, lo he vivido..."
    nt "ฉันแค่นึกภาพตามไม่ออกเลย... ฉันเคยเห็นมาแล้วว่าการเป็นร่างสถิตมันหมายถึงอะไร และฉันก็ผ่านมันมาด้วยตัวเอง..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:394
translate english arc2_hinata_quest1_2_5502cecb_3:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:395
translate english arc2_hinata_quest1_2_73281077:

    # nt "He estado aplazando esta decisión esperando que nunca tenga que llegar ese día"
    nt "ฉันเอาแต่ผลวันประกันพรุ่งเรื่องนี้ไปเรื่อยๆ เพราะหวังว่าวันนั้นจะไม่มีทางมาถึง"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:397
translate english arc2_hinata_quest1_2_4e153b78:

    # nt "Pero por ahora, lo único que podemos hacer es buscar a Kurama y estar preparados para cualquier escenario..."
    nt "แต่สำหรับตอนนี้ สิ่งเดียวที่เราทำได้ก็คือออกตามหาคุรามะและเตรียมพร้อมรับมือกับทุกสถานการณ์..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:398
translate english arc2_hinata_quest1_2_af7ef742:

    # mn "Naruto, si puedo ayudar en algo, por favor dígamelo, puede contar conmigo para lo que sea, sin importar qué"
    mn "ท่านนารูโตะ ถ้ามีอะไรให้ผมช่วย บอกได้เลยนะครับ พึ่งพาผมได้เสมอ ไม่ว่าเรื่องอะไรก็ตาม"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:402
translate english arc2_hinata_quest1_2_ef7cd256:

    # nt "Gracias... Lo aprecio de verdad"
    nt "ขอบใจนะ... ฉันซาบซึ้งใจจริงๆ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:403
translate english arc2_hinata_quest1_2_1e06d1b3:

    # nt "Tú vienes de fuera, pero para mí también eres formas parte de la Aldea de la Hoja"
    nt "เธอมาจากที่อื่นก็จริง แต่สำหรับฉันแล้ว เธอเองก็เป็นส่วนหนึ่งของหมู่บ้านโคโนฮะเหมือนกัน"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:405
translate english arc2_hinata_quest1_2_7a00df25:

    # mn "Gracias, escuchar eso de usted lo vale mucho..."
    mn "ขอบคุณครับ ได้ยินท่านพูดแบบนั้นแล้วผมดีใจมากเลย..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:406
translate english arc2_hinata_quest1_2_913c0219:

    # nt "No es nada jaja"
    nt "เรื่องแค่นี้เอง ฮ่าๆ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:408
translate english arc2_hinata_quest1_2_67260696:

    # nt "*suspiro* Te juro que siento un gran alivio..."
    nt "*ถอนหายใจ* พูดตามตรงว่าฉันรู้สึกโล่งอกขึ้นเยอะเลย..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:410
translate english arc2_hinata_quest1_2_d8b4b48a:

    # nt "Gracias por escucharme [MN], de veras"
    nt "ขอบคุณที่รับฟังเรื่องนี้นะ [MN] ขอบคุณจริงๆ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:413
translate english arc2_hinata_quest1_2_1155335a:

    # hm "¡Ya volvimos!" with vpunch
    hm "พวกเรากลับมาแล้วค่า!" with vpunch

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:417
translate english arc2_hinata_quest1_2_0ca69fec:

    # nt "Ya llegaron, por favor no le vayas a decir nada a Hima, ella aún no lo sabe"
    nt "กลับมาแล้วเหรอ ได้โปรดอย่าเพิ่งพูดอะไรให้ฮิมาฟังนะ แกยังไม่รู้อะไรเลย"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:418
translate english arc2_hinata_quest1_2_e366db60:

    # nt "Cuando llegue el momento... Yo se lo diré"
    nt "ถึงเวลา... เดี๋ยวฉันจะบอกเธอเอง"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:419
translate english arc2_hinata_quest1_2_c20fa8d2:

    # mn "Está bien, soy una tumba señor"
    mn "รับทราบครับ ผมจะเก็บเป็นความลับสุดยอดเลยครับท่าน"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:421
translate english arc2_hinata_quest1_2_68bbaff3:

    # nt "También, no le vayas a mencionar a Hinata ni a Hima que tuvimos aquel duelo, ¿Si?"
    nt "แล้วก็ อย่าเพิ่งบอกฮินาตะกับฮิมาว่าเราดวลกันเมื่อกี้นะ เข้าใจไหม?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:423
translate english arc2_hinata_quest1_2_d46c5485:

    # mnn "Este... Claro señor"
    mnn "เอ่อ... ครับท่าน"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:426
translate english arc2_hinata_quest1_2_dfe75615:

    # n "Hinata y Himawari vuelven de la tienda con las cosas, listas para preparar la cena"
    n "ฮินาตะกับฮิมาวาริกลับมาจากร้านค้าพร้อมของเต็มมือ เตรียมตัวทำมื้อเย็น"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:440
translate english arc2_hinata_quest1_2_e4283652:

    # hm "Ya llegamos, ¿Qué hicieron es nuestra ausencia?"
    hm "พวกเรากลับมาแล้วค่ะ ระหว่างที่พวกเราไม่อยู่คุยอะไรกันอยู่เหรอคะ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:442
translate english arc2_hinata_quest1_2_09769d16:

    # nt "Bienvenidas"
    nt "กลับมาแล้วเหรอ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:444
translate english arc2_hinata_quest1_2_34f4726e:

    # nt "Solo le estaba dando consejos para mejorar sus jutsus, ¿Y ustedes? ¿Compraron todo lo necesario?"
    nt "พ่อก็แค่ให้คำแนะนำเขาเกี่ยวกับการพัฒนาวิชานินจาน่ะ แล้วทางนั้นล่ะ? ซื้อของที่ต้องการครบไหม?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:446
translate english arc2_hinata_quest1_2_6a385d90:

    # hi "Sí, aunque Himawari casi se olvida de las especias que necesitábamos"
    hi "ครบค่ะ แม้ว่าฮิมาวาริจะเกือบลืมเครื่องเทศที่เราต้องใช้ไปซะแล้วก็เถอะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:449
translate english arc2_hinata_quest1_2_b6dd3948:

    # hm "N-No fue mi culpa! Solo me distraje un poco..." with vpunch
    hm "ม-ไม่ใช่ความผิดหนูสักหน่อย! หนูแค่เผลอเหม่อไปนิดเดียวนี่คะ..." with vpunch

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:451
translate english arc2_hinata_quest1_2_d4574e3c:

    # hi "Bueno, ya es casi hora de preparar la cena, ¿Les gustaría ayudarnos un poco en la cocina?"
    hi "งั้นก็ได้เวลาเตรียมมื้อเย็นแล้วล่ะ สนใจจะมาช่วยพวกเราในครัวสักหน่อยไหมจ๊ะ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:453
translate english arc2_hinata_quest1_2_9757a102:

    # mn "¡Por supuesto! Sería un honor"
    mn "แน่นอนครับ! ถือเป็นเกียรติอย่างยิ่งเลยครับ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:456
translate english arc2_hinata_quest1_2_29fb1223:

    # hm "¡Genial! Vamos entonces"
    hm "เยี่ยมเลย! งั้นก็ไปกันเถอะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:459
translate english arc2_hinata_quest1_2_5b03731c:

    # n "Luego de que las chicas llegaran, [MN] y Himawari ayudaron a Hinata con la cena mientras Naruto descansaba"
    n "หลังจากที่สองแม่ลูกกลับมา [MN] และฮิมาวาริก็ช่วยฮินาตะเตรียมอาหารเย็น ขณะที่นารูโตะพักผ่อน"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:460
translate english arc2_hinata_quest1_2_36b9bf17:

    # n "Una vez ya la comida servida, los aromas cálidos llenaban la habitación"
    n "เมื่ออาหารถูกเสิร์ฟ กลิ่นหอมกรุ่นก็อบอวลไปทั่วห้อง"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:461
translate english arc2_hinata_quest1_2_9c76a11f:

    # n "Hinata, Himawari, Naruto y [MN] compartían la mesa, riendo y charlando mientras comían, en {b}Familia{/a}..."
    n "ฮินาตะ ฮิมาวาริ นารูโตะ และ [MN] น้อมร่วมโต๊ะอาหารเดียวกัน หัวเราะและพูดคุยกันขณะทานอาหาร ราวกับ {b}ครอบครัว{/a}..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:475
translate english arc2_hinata_quest1_2_995af90e:

    # hi "Oye [MN]... Hay algo que no he podido dejar de pensar"
    hi "นี่ [MN]... มีเรื่องนึงที่ฉันคิดถึงอยู่ตลอดเลยล่ะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:476
translate english arc2_hinata_quest1_2_be4d154d:

    # hi "¿Qué le ocurrió a tu ojo, si mal no recuerdo, no era así ¿Cierto?"
    hi "เกิดอะไรขึ้นกับตาของคุณเหรอคะ ถ้าจำไม่ผิด เมื่อก่อนมันไม่ได้เป็นแบบนั้นใช่ไหมล่ะ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:477
translate english arc2_hinata_quest1_2_c3fb81da:

    # mn "Oh, bueno... Es una larga his-"
    mn "อ๋อ คือว่า... มันเรื่องยาวน่ะ-"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:480
translate english arc2_hinata_quest1_2_f518dee1:

    # hm "Es una larga historia, ¿De verdad?"
    hm "เรื่องยาวยังงั้นเหรอคะ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:481
translate english arc2_hinata_quest1_2_dc4ea7ba:

    # hm "Solo haz un resúmen"
    hm "งั้นเล่าแบบสรุปสั้นๆ มาเลยก็ได้ค่ะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:483
translate english arc2_hinata_quest1_2_c769efd1:

    # hi "Himawari, no puedes hablarle así a las personas"
    hi "ฮิมาวาริ พูดกับผู้ใหญ่แบบนั้นไม่ได้นะจ๊ะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:485
translate english arc2_hinata_quest1_2_1e59072b:

    # mn "Jaja... No se preocupe, creo que tiene razón"
    mn "ฮ่าๆ... ไม่เป็นไรครับ ผมว่าเธอก็พูดถูกนะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:487
translate english arc2_hinata_quest1_2_1d556c7e:

    # mn "Pues, resulta que..."
    mn "ก็คือว่านะ..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:490
translate english arc2_hinata_quest1_2_1cc1f9e5:

    # n "[MN] le cuenta a Hinata de una forma breve lo que pasó con el {b}Karugan{/a}"
    n "[MN] เล่าให้ฮิมาวาริฟังคร่าวๆ เกี่ยวกับสิ่งที่เกิดขึ้นกับ {b}คารูกัน{/a}"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:491
translate english arc2_hinata_quest1_2_b029ecec:

    # n "Siempre omitiendo el la parde de la {b}Invisibilidad{/a}"
    n "แต่ก็ยังคงละเว้นเรื่องเกี่ยวกับ {b}วิชาล่องหน{/a} เอาไว้เหมือนเดิม"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:496
translate english arc2_hinata_quest1_2_3c8030f3:

    # hi "Karugan... Nunca había escuchado de el ¿Tu sí Naruto?"
    hi "คารูกันงั้นเหรอ... ฉันไม่เคยได้ยินชื่อนี้เลย นารูโตะล่ะเคยได้ยินไหม?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:497
translate english arc2_hinata_quest1_2_2be87e7f:

    # nt "A mí también me tomó por sorpresa jaja... Hasta ahora no sabemos mucho sobre él"
    nt "ฉันเองก็ยังตกใจเลย ฮ่าๆ... ตอนนี้เรายังรู้อะไรเกี่ยวกับมันไม่มากเท่าไหร่หรอก"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:498
translate english arc2_hinata_quest1_2_e8582f35:

    # mn "Sí, también es desconocido para mí, apenas estoy empezando a entenderlo"
    mn "ใช่ครับ ตัวผมเองก็ไม่ค่อยรู้เรื่องเหมือนกัน เพิ่งจะเริ่มทำความเข้าใจกับมันนี่แหละครับ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:499
translate english arc2_hinata_quest1_2_3474c55f:

    # mn "Pero cada día aprendo más sobre lo que puedo hacer con él"
    mn "แต่ว่าทุกๆ วัน ผมก็ได้เรียนรู้เกี่ยวกับสิ่งที่ตัวเองทำได้มากขึ้นเรื่อยๆ ครับ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:501
translate english arc2_hinata_quest1_2_f666ac59:

    # hi "Eso es maravilloso, entre antes lo entiendas será mejor, ojalá te sirva para lograr todas tus metas"
    hi "ยอดเยี่ยมไปเลยนะ ยิ่งเข้าใจมันได้เร็วเท่าไหร่ก็ยิ่งดี หวังว่ามันจะช่วยให้เธอทำตามเป้าหมายทั้งหมดสำเร็จนะจ๊ะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:502
translate english arc2_hinata_quest1_2_38575a26:

    # hi "¿Sabes? No puedo evitar pensar en cuánto han crecido todos"
    hi "รู้ไหมคะ? ฉันอดคิดไม่ได้เลยนะว่าทุกคนเติบโตขึ้นกันไปเยอะมากเลย"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:503
translate english arc2_hinata_quest1_2_38942de4:

    # hi "Tú y Himawari..."
    hi "ทั้งเธอและฮิมาวาริ..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:504
translate english arc2_hinata_quest1_2_3d57d5fb:

    # n "Hinata sonrió con ternura, pero pronto su expresión se tornó más melancólica"
    n "ฮินาตะยิ้มอย่างอ่อนโยน แต่ไม่นานสีหน้าของเธอก็เปลี่ยนเป็นเศร้าสร้อยลง"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:507
translate english arc2_hinata_quest1_2_0e3c854a:

    # hi "Me encantaría saber como está de grande Boruto"
    hi "แม่ก็อยากรู้จังเลยนะว่าตอนนี้โบรูโตะโตขึ้นขนาดไหนแล้ว"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:512
translate english arc2_hinata_quest1_2_9333a9f7:

    # n "El ambiente se tornó un poco más pesado con la mención de Boruto, Naruto y Himawari intercambiaron miradas breves"
    n "บรรยากาศเริ่มอึมครึมขึ้นเล็กน้อยเมื่อมีการเอ่ยถึงโบรูโตะ นารูโตะกับฮิมาวาริสบตากันแวบหนึ่ง"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:514
translate english arc2_hinata_quest1_2_3b532147:

    # hi "Hace ya tanto que no sabemos de él... Siete años... Espero que esté bien"
    hi "นานมากแล้วที่เราไม่ได้ข่าวคราวจากเขาเลย... ตั้งเจ็ดปีแล้ว... แม่หวังว่าเขาจะไม่เป็นไรนะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:516
translate english arc2_hinata_quest1_2_067e30da:

    # hm "Mamá..."
    hm "แม่คะ..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:518
translate english arc2_hinata_quest1_2_64875e6f:

    # hi "Oh, lo siento... No quería hacer pesado el ambiente, de verdad lo siento"
    hi "อ๊ะ ขอโทษด้วยนะจ๊ะ... แม่ไม่ได้ตั้งใจจะทำให้บรรยากาศมันแย่เลย ขอโทษจริงๆ นะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:520
translate english arc2_hinata_quest1_2_e096b100:

    # mn "No se preocupe... Debe de ser difícil no saber nada de su hijo..."
    mn "ไม่ต้องห่วงหรอกครับ... การที่ไม่รู้อะไรเกี่ยวกับลูกชายเลยเนี่ย มันคงเป็นเรื่องที่ยากลำบากสินะครับ..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:522
translate english arc2_hinata_quest1_2_af8b0236:

    # n "Naruto ve a Himawari, queriendole decir que haga algo"
    n "นารูโตะมองหน้าฮิมาวาริ เหมือนอยากจะส่งสัญญาณให้เธอทำอะไรสักอย่าง"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:525
translate english arc2_hinata_quest1_2_b22a8d03:

    # hm "Este... [MN], ¿Cómo te sientes con los exámenes Chunin tan cerca?"
    hm "เอ่อ... [MN] รู้สึกยังไงบ้างคะที่การสอบจูนินใกล้เข้ามาแล้วเนี่ย?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:527
translate english arc2_hinata_quest1_2_7af522a2:

    # mn "Oh, bueno, he estado entrenando mucho para esto, así que creo que estoy listo, aunque siempre hay algo de nervios jaja"
    mn "อ๋อ ก็... ผมฝึกซ้อมมาเยอะมากเลยล่ะครับสำหรับเรื่องนี้ เลยคิดว่าตัวเองพร้อมแล้ว ถึงจะยังแอบตื่นเต้นอยู่บ้างก็เถอะนะ ฮ่าๆ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:532
translate english arc2_hinata_quest1_2_185c8237:

    # hi "Si, recuerdo el miedo que sentía cuando participé en ellos"
    hi "นั่นสิคะ นึกถึงตอนที่แม่เข้าร่วมสอบแล้วก็ยังจำความกลัวตอนนั้นได้แม่นเลยล่ะค่ะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:535
translate english arc2_hinata_quest1_2_ffbef50d:

    # nt "En mi caso, yo estuve super relajado jeje"
    nt "ส่วนฉันเนี่ย ชิลสุดๆ ไปเลยล่ะ ฮิฮิ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:537
translate english arc2_hinata_quest1_2_1f499efc:

    # hm "Jeh, eso no es lo que me contó la Señora Sakura"
    hm "หึ นั่นไม่ใช่สิ่งที่น้าซากุระบอกหนูมาหรอกนะคะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:542
translate english arc2_hinata_quest1_2_29ad3cae:

    # nt "¡¿EEH?!" with vpunch
    nt "หาพะยะค่ะ เอ๊ย หาอะไรนะ?!" with vpunch

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:544
translate english arc2_hinata_quest1_2_1bd95d0b:

    # nt "¿Q-Qué fue lo que te dijo?"
    nt "ผ-ผมนี่นะ... เธอบอกอะไรเธอไปงั้นเหรอ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:546
translate english arc2_hinata_quest1_2_88379e80:

    # hm "No te lo diré"
    hm "ไม่บอกหรอกค่ะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:548
translate english arc2_hinata_quest1_2_445c528b:

    # n "Hinata y [MN] se ríen ligeramente, parece ser que el ambiente mejoró mucho gracias a Himawari y Naruto"
    n "ฮินาตะกับ [MN] หัวเราะเบาๆ ดูเหมือนว่าบรรยากาศจะกลับมาสดใสขึ้นมากเลยทีเดียว ต้องขอบคุณฮิมาวาริกับนารูโตะแท้ๆ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:554
translate english arc2_hinata_quest1_2_74f99ec8:

    # hm "Por cierto [MN]..." with dissolve1
    hm "ว่าแต่ [MN] คะ..." with dissolve1

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:555
translate english arc2_hinata_quest1_2_ae3dd6e8:

    # hm "¿Te puedo pedir un gran favor?"
    hm "หนูมีเรื่องอยากจะขอร้องให้อะไรหน่อย จะได้ไหมคะ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:556
translate english arc2_hinata_quest1_2_41dc4796:

    # mn "¿De qué se trata?"
    mn "เรื่องอะไรเหรอ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:557
translate english arc2_hinata_quest1_2_85c95ac8:

    # hm "Después de los exámenes..."
    hm "หลังการสอบเสร็จแล้ว..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:559
translate english arc2_hinata_quest1_2_741ab7de:

    # hm "¿Podrías entrenarme? Me gustaría poder aprender algo de tí"
    hm "ช่วยฝึกวิชาให้หนูหน่อยได้ไหมคะ? หนูอยากเรียนรู้อะไรบางอย่างจากพี่น่ะค่ะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:562
translate english arc2_hinata_quest1_2_3e221af7:

    # nt "Es una gran idea, tu podrías enseñarle muchas cosas que le serán útiles"
    nt "เป็นความคิดที่ดีเลยนะ ลูกสามารถสอนอะไรหลายๆ อย่างที่เป็นประโยชน์ให้เธอได้แน่ๆ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:564
translate english arc2_hinata_quest1_2_dfc88009:

    # nt "Luego de verte luchar, estoy seguro que harás un gran trabajo"
    nt "หลังจากได้เห็นเธอสู้แล้ว ฉันมั่นใจเลยว่าเธอจะต้องทำได้ดีมากๆ แน่"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:566
translate english arc2_hinata_quest1_2_af49017a:

    # mn "Bueno, si realmente quieres que yo te entrene, ¿Pues como negarme?"
    mn "งั้น... ถ้าอยากให้พี่ช่วยฝึกให้จริงๆ แล้วพี่จะปฏิเสธได้ยังไงล่ะจริงไหม?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:568
translate english arc2_hinata_quest1_2_1a0428ea:

    # mn "Será después de los Exámenes Chunin, ¿Entendido?"
    mn "เอาไว้หลังสอบจูนินเสร็จ ตกลงตามนี้นะ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:570
translate english arc2_hinata_quest1_2_17160455:

    # hm "¿De verdad?, ¡Gracias! Estaré esperando hasta entonces" with vpunch
    hm "จริงเหรอคะ? ขอบคุณนะคะ! หนูจะตั้งตารอจนถึงตอนนั้นเลยค่ะ" with vpunch

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:573
translate english arc2_hinata_quest1_2_95c480eb:

    # n "El ambiente se alivió nuevamente, y la cena continuó con normalidad, llena de risas y anécdotas compartidas"
    n "บรรยากาศผ่อนคลายลงอีกครั้ง และมื้อค่ำก็ดำเนินต่อไปตามปกติ เต็มไปด้วยเสียงหัวเราะและการแบ่งปันเรื่องเล่าต่างๆ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:574
translate english arc2_hinata_quest1_2_a085ec11:

    # n "Pero la noche avanzaba, y ya era hora de despedirse"
    n "แต่ยามค่ำคืนก็ดึกดื่นขึ้นเรื่อยๆ และถึงเวลาที่ต้องบอกลาแล้ว"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:586
translate english arc2_hinata_quest1_2_78890518:

    # n "Ahora [MN] se encontraba en la entrada de la casa, listo para marcharse mientras la Familia Uzumaki lo acompañaba al pasillo" with fade
    n "ตอนนี้ [MN] มาอยู่ที่บริเวณทางเข้าบ้าน พร้อมที่จะเดินทางกลับแล้ว โดยมีครอบครัวอุซึมากิมาส่งที่ตรงโถงทางเดิน" with fade

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:588
translate english arc2_hinata_quest1_2_2b08a343:

    # hi "Espero que hayas disfrutado la cena [MN], fue un placer tenerte aquí nuevamente"
    hi "หวังว่าจะถูกปากมื้อนี้นะจ๊ะ [MN] แม่ดีใจจริงๆ ที่เธอมาทานข้าวด้วยกันอีก"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:591
translate english arc2_hinata_quest1_2_fbff1003:

    # mn "Muchas gracias por la comida, de verdad me encantó"
    mn "ขอบคุณสำหรับอาหารมากๆ เลยนะครับ ผมชอบมากเลยล่ะครับ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:593
translate english arc2_hinata_quest1_2_d07b985f:

    # hm "Tienes que volver pronto ¿Entendiste? Mamá y yo te recibirémos siempre que quieras visitarnos"
    hm "พี่ต้องมาอีกเร็วนะคะ ตกลงไหม? คุณแม่กับหนูจะต้อนรับพี่เสมอเลยเวลาที่มาเยี่ยม"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:594
translate english arc2_hinata_quest1_2_25bb4632:

    # mn "Seguro, vendré más seguido a visitarlos"
    mn "ได้สิ เดี๋ยวฉันจะแวะมาเยี่ยมให้บ่อยขึ้นนะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:595
translate english arc2_hinata_quest1_2_7c16ae26:

    # hm "Muy bien, tomaré tu palabra, así que no te olvides"
    hm "งั้นหนูถือว่าพี่พูดแล้วนะคะ ห้ามลืมเด็ดขาดเลยล่ะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:596
translate english arc2_hinata_quest1_2_8f04a7b8:

    # nt "Tómate tu tiempo para prepararte [MN], los exámenes Chunin de este años no serán cualquier cosa"
    nt "ค่อยๆ เตรียมตัวให้พร้อมล่ะ [MN] การสอบจูนินปีนี้ไม่ง่ายเลยนะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:597
translate english arc2_hinata_quest1_2_975d35e6:

    # nt "Sé que tienes lo necesario para enfrentarlos, pero es mejor estar preparado"
    nt "ฉันรู้ว่าเธอมีดีพอที่จะรับมือไหว แต่เตรียมตัวไว้ก่อนย่อมดีกว่า"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:598
translate english arc2_hinata_quest1_2_900c6fab:

    # mn "Si, haré todo lo posible para no defraudar a la Aldea de la Hoja y... Tampoco a ustedes"
    mn "ครับ ผมจะทำเต็มที่เพื่อไม่ให้หมู่บ้านโคโนฮะต้องผิดหวัง... แล้วก็จะไม่ทำให้ท่านผิดหวังด้วยครับ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:600
translate english arc2_hinata_quest1_2_2fee3ea3:

    # nt "Estaremos ahí viéndote en las finales, sé que llegarás lejos solo sigue siendo tú mismo y confía en tus habilidades"
    nt "พวกเราจะไปคอยเชียร์เธอในรอบชิงชนะเลิศนะ ฉันรู้ว่าเธอไปได้ไกลแน่ แค่เป็นตัวของตัวเองและเชื่อมั่นในความสามารถก็พอ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:603
translate english arc2_hinata_quest1_2_39bb9f95:

    # n "Finalmente, [MN] salió de la casa, y la familia lo despidió desde la entrada, con palabras de aliento que lo acompañarían en su camino"
    n "ในที่สุด [MN] ก็เดินออกจากบ้าน โดยมีครอบครัวอุซึมากิยืนส่งที่หน้าประตู พร้อมกับคำพูดให้กำลังใจที่คอยติดตามตัวเขาระหว่างทางกลับ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:605
translate english arc2_hinata_quest1_2_487baad7:

    # n "Mientras caminaba bajo la luz de la luna, no podía evitar sonreír"
    n "ขณะที่เขาเดินอยู่ใต้แสงจันทร์ ก็อดไม่ได้ที่จะยิ้มออกมา"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:606
translate english arc2_hinata_quest1_2_85c38501:

    # n "El tiempo con los Uzumaki le recordó lo que significaba tener un hogar y el valor de las conexiones que estaba formando en su vida"
    n "ช่วงเวลาที่ได้อยู่กับครอบครัวอุซึมากิทำให้เขานึกถึงความหมายของการมีบ้าน และคุณค่าของสายสัมพันธ์ที่เขากำลังสร้างขึ้นในชีวิต"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:608
translate english arc2_hinata_quest1_2_7fee5cd1:

    # mn "No estoy solo... Tengo personas que creen en mí. Eso es suficiente para seguir adelante"
    mn "ฉันไม่ได้อยู่ตัวคนเดียว... ฉันมีคนที่เชื่อมั่นในตัวฉัน แค่นั้นก็เพียงพอแล้วที่จะก้าวต่อไป"

# TODO: Translation updated at 2024-12-20 07:52

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:105
translate english arc2_hinata_quest1_2_25d2bb56:

    # hm "Eso dijiste el día que nos encontramos, y te lo dejé pasar porque estabas ocupado"
    hm "พี่พูดแบบนั้นในวันที่เราเจอกัน และหนูก็ปล่อยผ่านเพราะเห็นว่าพี่กำลังยุ่งอยู่แท้ๆ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:179
translate english arc2_hinata_quest1_2_9cb01e6c:

    # n "La conversación continuó de manera relajada, mientras Naruto y Hinata compartían algunas anécdotas de sus propias experiencias"
    n "การสนทนาดำเนินต่อไปอย่างผ่อนคลาย เมื่อนารูโตะกับฮินาตะเริ่มเล่าเรื่องราวตลกๆ จากประสบการณ์ของตัวเองให้ฟัง"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:219
translate english arc2_hinata_quest1_2_6d6d70e6:

    # hi "Himawari, ¿Puedes venir conmigo a la tienda?"
    hi "ฮิมาวาริ ไปช่วยแม่ซื้อของที่ร้านหน่อยจ่ะ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1_2.rpy:491
translate english arc2_hinata_quest1_2_1c6a4149:

    # n "Siempre omitiendo la parde de la {b}Invisibilidad{/a}"
    n "แต่ก็ยังคงละเว้นเรื่องเกี่ยวกับ {b}วิชาล่องหน{/a} เอาไว้เหมือนเดิม"
