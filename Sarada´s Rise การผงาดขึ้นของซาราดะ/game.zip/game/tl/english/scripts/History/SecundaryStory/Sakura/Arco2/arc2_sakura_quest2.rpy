# TODO: Translation updated at 2024-11-29 23:49

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:5
translate english arc2_sakura_quest2_4349b23a:

    # n "[MN] sube al tercer piso del Hospital"
    n "[MN] เดินขึ้นไปบนชั้นสามของโรงพยาบาล"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:17
translate english arc2_sakura_quest2_06695897:

    # mn "Buen día, ya estoy aquí"
    mn "อรุณสวัสดิ์ครับ ผมมาถึงแล้วครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:18
translate english arc2_sakura_quest2_cb458a29:

    # sk "[MN], buen día"
    sk "อรุณสวัสดิ์จ่ะ [MN]"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:19
translate english arc2_sakura_quest2_c29b0f42:

    # sr "Hola [MN]"
    sr "สวัสดีค่ะ [MN]"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:20
translate english arc2_sakura_quest2_b821c4c0:

    # mn "Sarada, que alegría verte aquí"
    mn "ซาราดะ ดีใจจังที่ได้เจอเธอที่นี่นะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:21
translate english arc2_sakura_quest2_6102db1c:

    # sr "Me dijeron que necesitaban mi ayuda para probar una teoría del {b}Karugan{/a}"
    sr "มีคนบอกฉันว่าเธอต้องการความช่วยเหลือจากฉันในการทดสอบทฤษฎีเกี่ยวกับ {b}คารูกัน{/a} น่ะจ่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:22
translate english arc2_sakura_quest2_3462be8e:

    # sr "¿Qué es exactamente?"
    sr "มันคืออะไรเหรอคะ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:23
translate english arc2_sakura_quest2_f1617be6:

    # ts "¿Ya estás al tanto del {b}Karugan{/a} cierto?"
    ts "เธอคุ้นเคยกับ {b}คารูกัน{/a} ดีอยู่แล้วใช่ไหมล่ะ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:24
translate english arc2_sakura_quest2_b5f598ac:

    # sr "Si, yo estoy al corriente con toda la información"
    sr "ค่ะ ฉันอัปเดตข้อมูลเกี่ยวกับเรื่องนั้นทั้งหมดแล้วค่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:25
translate english arc2_sakura_quest2_e04b302e:

    # ts "Muy bien, entonces no nos extenderémos con la explicación"
    ts "งั้นเราก็คงไม่ต้องอธิบายอะไรกันให้ยืดยาวล่ะนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:26
translate english arc2_sakura_quest2_210aed3d:

    # ts "Necesitamos que uses tu {b}Sharingan{/a} mientras [MN] está invisible para comprobar si en ese estado se puede detectar su {b}Flujo de Chakra{/a}"
    ts "เราต้องการให้เธอใช้ {b}เนตรวงแหวน{/a} ตอนที่ [MN] ล่องหนอยู่ เพื่อตรวจสอบว่าเราจะตรวจจับ {b}กระแสจักระ{/a} ของเขาในตอนนั้นได้หรือเปล่า"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:27
translate english arc2_sakura_quest2_ad4b1073:

    # ts "Si logramos confirmar esa información y resulta que también se oculta, [MN] podría ser de mucha ayuda a la aldea de la Hoja en misiones de {b}Sigilo{/a}"
    ts "ถ้าเรายืนยันได้และปรากฏว่ากระแสจักระของเขาถูกซ่อนไว้ด้วย [MN] ก็จะเป็นกำลังสำคัญให้หมู่บ้านโคโนฮะในภารกิจ {b}ลอบเร้น{/a} ได้เลยล่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:28
translate english arc2_sakura_quest2_c2fb8fde:

    # sr "Entiendo, no había pensado en esa posibilidad"
    sr "อย่างนี้นี่เอง ฉันนึกไม่ถึงความเป็นไปข้อนั้นเลยค่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:30
translate english arc2_sakura_quest2_277f9242:

    # mnn "(Vaya... La Señora Tsunade es muy inteligente, ni siquiera a Sarada se le había ocurrido algo así)"
    mnn "(โห… ท่านซึนาเดะฉลาดเป็นกรดเลยแฮะ ขนาดซาราดะยังคิดไม่ถึงเรื่องแบบนั้นเลย)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:31
translate english arc2_sakura_quest2_fc8c98bb:

    # mnn "(No me sorprende que haya sido Hokage en el pasado...)"
    mnn "(ไม่แปลกใจเลยที่อดีตเธอเคยเป็นถึงโฮคาเงะ...)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:33
translate english arc2_sakura_quest2_51fc8b1f:

    # ts "Muy bien, entonces comencémos con las pruebas"
    ts "เอาล่ะ งั้นเรามาเริ่มการทดสอบกันเลยดีกว่า"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:36
translate english arc2_sakura_quest2_ba8d0ff8:

    # n "Tsunade le plantea a Sarada su idea sobre si el {b}Karugan{/a} oculta el {b}Flujo de Chakra{/a} de [MN] y llevan a cabo un exámen para comprobar si es así"
    n "ซึนาเดะอธิบายแผนการของเธอให้ซาราดะฟังว่า {b}คารูกัน{/a} สามารถซ่อน {b}กระแสจักระ{/a} ของ [MN] ได้หรือไม่ และพวกเธอก็ทำการทดสอบเพื่อดูว่ามันเป็นจริงตามนั้นหรือเปล่า"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:40
translate english arc2_sakura_quest2_daae2c8e:

    # n "[MN] se vuelve invisible y Sarada usa su {b}Sharingan{/a} para llevar a cabo esta tarea"
    n "[MN] ล่องหน และซาราดะก็ใช้ {b}เนตรวงแหวน{/a} ของเธอเพื่อทำภารกิจนี้ให้สำเร็จ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:41
translate english arc2_sakura_quest2_05634afd:

    # n "Y el resultado es..."
    n "และผลลัพธ์ที่ได้ก็คือ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:47
translate english arc2_sakura_quest2_1da29add:

    # mn "Mmm... Odio este dolor al usar el Jutsu de Invisibilidad"
    mn "อืม... ผมเกลียดความเจ็บปวดเวลาที่ใช้คาถาล่องหนชะมัด"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:48
translate english arc2_sakura_quest2_2725cc33:

    # sk "Estamos trabajando en una solución para ello, solo danos más tiempo"
    sk "พวกเรากำลังหาทางแก้เรื่องนั้นกันอยู่จ่ะ ขอเวลาเพิ่มอีกหน่อยนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:50
translate english arc2_sakura_quest2_23915d0b:

    # mn "No hay problema"
    mn "ไม่มีปัญหาครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:51
translate english arc2_sakura_quest2_daffc3c7:

    # ts "Y bien, Sarada, ¿Pudiste ver su {b}Flujo de Chakra{/a}?"
    ts "แล้วล่ะ ซาราดะ เธอมองเห็น {b}กระแสจักระ{/a} ของเขาไหม?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:55
translate english arc2_sakura_quest2_a20cefa7:

    # "..."
    "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:61
translate english arc2_sakura_quest2_6c4b097e:

    # sr "Lamentablemente si, pude verlo claramente"
    sr "น่าเสียดายค่ะ... เห็นค่ะ มองเห็นได้ชัดเจนเลยล่ะค่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:62
translate english arc2_sakura_quest2_dfe5e7c4:

    # ts "Maldición..."
    ts "แย่จริง..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:63
translate english arc2_sakura_quest2_d332f46b:

    # mn "Eso quiere decir, ¿Que aunque esté invisible pueden haber personas que pueden detectarme?"
    mn "นั่นหมายความว่า ต่อให้ล่องหนอยู่ ก็ยังมีคนที่สามารถตรวจจับตัวผมได้สินะครับ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:67
translate english arc2_sakura_quest2_f5ca6681:

    # sk "Me temo que si, aunque no hay muchas personas con la capacidad de algo así"
    sk "เกรงว่าเป็นแบบนั้นแหละจ่ะ ถึงแม้จะมีคนที่มีความสามารถแบบนั้นอยู่ไม่มากก็เถอะนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:69
translate english arc2_sakura_quest2_139eea5d:

    # ts "Aún así tu {b}Karugan{/a} nos será de mucha utilidad, es bueno saber lo que puedes y lo que no puedes hacer"
    ts "ถึงอย่างนั้น {b}คารูกัน{/a} ของเธอก็ยังมีประโยชน์กับเรามากๆ อยู่ดี การได้รู้ว่าเธอทำอะไรได้หรือไม่ได้บ้างก็เป็นเรื่องที่ดีนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:70
translate english arc2_sakura_quest2_0c534a99:

    # ts "Para eso estamos haciendo estas pruebas"
    ts "นั่นแหละคือเหตุผลที่เราทำการทดสอบพวกนี้กันยังไงล่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:71
translate english arc2_sakura_quest2_5502cecb:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:73
translate english arc2_sakura_quest2_39663449:

    # ts "Ahora que sabemos esto hemos acabado con los examenes a {b}Karugan{/a}"
    ts "ในเมื่อเรารู้เรื่องนี้แล้ว การทดสอบ {b}คารูกัน{/a} ก็เป็นอันเสร็จสิ้น"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:74
translate english arc2_sakura_quest2_42046b7a:

    # sk "Si, ahora nosotras trabajarémos en una solución para los efectos secundarios"
    sk "ใช่จ่ะ ตอนนี้เราจะไปจัดการเรื่องวิธีแก้ผลข้างเคียงกันต่อ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:75
translate english arc2_sakura_quest2_9186004e:

    # sk "Ya pueden irse, yo te llamaré cuando la tengamos lista"
    sk "เธอไปได้แล้วล่ะ เดี๋ยวถ้าเราทำเสร็จเมื่อไหร่จะเรียกนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:76
translate english arc2_sakura_quest2_de89add6:

    # mn "Está bien..."
    mn "ครับ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:78
translate english arc2_sakura_quest2_3aeb751f:

    # mn "Lamento que el Karugan no hayan cumplido con sus espectativas..."
    mn "ผมขอโทษด้วยนะครับที่คารูกันมันไม่ได้ผลอย่างที่หวังไว้..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:82
translate english arc2_sakura_quest2_8b0c56a0:

    # sk "Oye..."
    sk "นี่..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:90
translate english arc2_sakura_quest2_73777630:

    # ts "¿De qué hablas?"
    ts "เธอพูดอะไรน่ะ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:97
translate english arc2_sakura_quest2_c89151cc:

    # ts "Aunque puedas ser detectado, eso no hace tu jutsu malo"
    ts "ต่อให้มีคนตรวจจับได้ ก็ไม่ได้แปลว่าคาถาของเธอไม่ดีสักหน่อย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:98
translate english arc2_sakura_quest2_102e18bc:

    # ts "En todos los años que tengo, no he conocido a nadie con un jutsu así"
    ts "ตั้งแต่เกิดมา ฉันยังไม่เคยเจอใครที่มีคาถาแบบนั้นเลยสักคน"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:101
translate english arc2_sakura_quest2_33bcd416:

    # sk "La señora Tsunade tiene razón, yo tampoco he conocido a nadie que sea capaz de hacer algo así"
    sk "ท่านซึนาเดะพูดถูกแล้วจ่ะ ฉันเองก็ไม่เคยเจอใครที่ทำอะไรแบบนั้นได้เหมือนกัน"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:102
translate english arc2_sakura_quest2_6a345f22:

    # sr "De verdad posees algo increíble [MN]"
    sr "คุณมีพลังที่เหลือเชื่อจริงๆ นะคะ [MN]"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:103
translate english arc2_sakura_quest2_9b3f17df:

    # ts "Sé que ya no soy la Hokage y no tengo poder sobre tí, pero..."
    ts "ฉันรู้ว่าตอนนี้ตัวเองไม่ได้เป็นโฮคาเงะแล้ว และไม่มีอำนาจอะไรเหนือเธอหรอกนะ แต่ว่า..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:104
translate english arc2_sakura_quest2_702bc5ff:

    # ts "Por eso quiero encomendarte una misión"
    ts "เพราะอย่างนั้น ฉันถึงอยากจะมอบหมายภารกิจให้เธอยังไงล่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:106
translate english arc2_sakura_quest2_9250de8f:

    # mn "¿U-Una misión?" with vpunch
    mn "ภ... ภารกิจเหรอครับ?" with vpunch

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:110
translate english arc2_sakura_quest2_58890d97:

    # ts "{b}[MN] Karui{/a}. Te encargo la misión de dominar el {b}Karugan{/a} y lo uses para proteger a todos los habitantes de la aldea de la Hoja"
    ts "{b}[MN] คารุย{/a} ฉันขอฝากภารกิจในการฝึกฝน {b}คารูกัน{/a} ให้เชี่ยวชาญ และใช้มันเพื่อปกป้องชาวบ้านทุกคนในหมู่บ้านโคโนฮะด้วยนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:112
translate english arc2_sakura_quest2_2b67d440:

    # mnn "¡!" with vpunch
    mnn "!" with vpunch

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:114
translate english arc2_sakura_quest2_b09b42b5:

    # ts "Nuestro primer encuentro no fue muy... Agradable"
    ts "การพบกันครั้งแรกของเรามันอาจจะไม่ค่อย... น่าประทับใจเท่าไหร่"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:116
translate english arc2_sakura_quest2_bf814449:

    # ts "Pero por lo que Sakura y Sarada me han contado eres un ninja de fiar y muy talentoso"
    ts "แต่จากที่ซากุระกับซาราดะเล่าให้ฟัง เธอเป็นนินจาที่น่าเชื่อถือและมีความสามารถมากๆ เลยล่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:117
translate english arc2_sakura_quest2_28109909:

    # ts "Así que no creo que haya un mejor usuario para el {b}Karugan{/a}"
    ts "ดังนั้นฉันเลยคิดว่าไม่มีใครเหมาะที่จะใช้ {b}คารูกัน{/a} นี้ไปมากกว่าเธออีกแล้วล่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:118
translate english arc2_sakura_quest2_b1ee145e:

    # mn "Yo... No sé que decir..."
    mn "ผม... ผมไม่รู้จะพูดอะไรเลยครับ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:119
translate english arc2_sakura_quest2_cdf2fbf5:

    # ts "No digas nada, solo quiero que aceptes mi misión"
    ts "ไม่ต้องพูดอะไรหรอก ฉันแค่อยากให้เธอรับภารกิจนี้ก็พอ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:121
translate english arc2_sakura_quest2_5502cecb_1:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:124
translate english arc2_sakura_quest2_289a9308:

    # mn "¡Si, protegeré la aldea de la Hoja con mi vida!" with vpunch
    mn "ครับ! ผมจะปกป้องหมู่บ้านโคโนฮะด้วยชีวิตของผมเอง!" with vpunch

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:125
translate english arc2_sakura_quest2_788abd4f:

    # ts "Muy bien, así me gusta" with vpunch
    ts "ดีมาก นั่นแหละที่ฉันอยากได้ยิน" with vpunch

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:127
translate english arc2_sakura_quest2_cb0dc71d:

    # ts "Ahora si ya pueden retirarse"
    ts "ตอนนี้เธอไปได้แล้วล่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:129
translate english arc2_sakura_quest2_96bdd930:

    # n "Después de las palabras de Tsunade, [MN] y Sarada salen del Hospital"
    n "หลังจากคำพูดของซึนาเดะ [MN] และซาราดะก็ออกจากโรงพยาบาลไป"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:138
translate english arc2_sakura_quest2_573f5473:

    # sk "Gracias por motivar a [MN] Lady Tsunade"
    sk "ขอบคุณที่ช่วยพูดปลุกใจ [MN] นะคะ ท่านซึนาเดะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:139
translate english arc2_sakura_quest2_d616bcde:

    # sk "Sin duda ahora estará más motivado para seguir mejorando sus habilidades"
    sk "จากนี้เขาคงจะมีแรงฮึดในการพัฒนาฝีมือของตัวเองมากขึ้นแน่ๆ เลยจ่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:141
translate english arc2_sakura_quest2_22fed923:

    # ts "¿El muchacho participará en los exámenes chunin de este año?"
    ts "เด็กหนุ่มคนนั้นจะเข้าร่วมการสอบจููนินในปีนี้ด้วยไหมล่ะ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:142
translate english arc2_sakura_quest2_eb6c8485:

    # sk "Si, será su primera vez"
    sk "ค่ะ จะเป็นการสอบครั้งแรกของเขาเลยล่ะค่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:143
translate english arc2_sakura_quest2_6e733651:

    # ts "Tiene potencial, quisiera verlo en acción en los exámenes Chunin"
    ts "เขามีแววนะ ฉันอยากจะเห็นเขาสาดฝีมือในการสอบจูนินจริงๆ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:144
translate english arc2_sakura_quest2_bcb3159c:

    # ts "Y así como yo, pueden haber otros ninjas interesados en su {b}Karugan{/a}"
    ts "แล้วก็... เหมือนอย่างฉัน อาจจะมีนินจาคนอื่นที่สนใจ {b}คารูกัน{/a} ของเธออีกก็ได้นะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:147
translate english arc2_sakura_quest2_639b733f:

    # sk "..."
    sk "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:150
translate english arc2_sakura_quest2_f399fa5c:

    # sk "Entiendo, debemos tenerlo vigilado..."
    sk "เข้าใจแล้วค่ะ เราคงต้องคอยจับตาดูเขาไว้สินะ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:151
translate english arc2_sakura_quest2_a26bb9f8:

    # ts "Si es posible, que evite usar el {b}Karugan{/a} en las finales de los exámenes chunin en medio de cientos de personas"
    ts "ถ้าเป็นไปได้ ก็พยายามอย่าใช้ {b}คารูกัน{/a} ในรอบชิงชนะเลิศสอบจููนินท่ามกลางผู้คนนับร้อยจะดีกว่านะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest2.rpy:152
translate english arc2_sakura_quest2_64ecf42d:

    # sk "Si, me encargaré de ello"
    sk "ค่ะ ฉันจะระวังเรื่องนั้นเองค่ะ"

