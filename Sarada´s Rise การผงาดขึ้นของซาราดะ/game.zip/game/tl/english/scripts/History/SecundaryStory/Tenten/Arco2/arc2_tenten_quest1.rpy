# TODO: Translation updated at 2024-12-01 21:25

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:13
translate english arc2_tenten_quest1_f6b3c334:

    # mn "Hola Tenten"
    mn "ว่าไง เท็นเท็น"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:14
translate english arc2_tenten_quest1_da5f3ec0:

    # mn "Leí tu mensaje, ¿De qué quieres hablar conmigo?"
    mn "ฉันอ่านข้อความที่เธอส่งมาแล้ว มีเรื่องอะไรอยากคุยเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:16
translate english arc2_tenten_quest1_777c110c:

    # tt "[MN], justo te estaba esperando"
    tt "[MN] ฉันก็แค่รอนายอยู่พอดีเลย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:18
translate english arc2_tenten_quest1_b545edd7:

    # tt "Antes que nada, déjame preguntarte algo"
    tt "ก่อนอื่นเลย ขอถามอะไรหน่อยสิ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:19
translate english arc2_tenten_quest1_5373cae5:

    # tt "¿Cómo te fue en el Examen de Zubon?"
    tt "การสอบของซูบงเป็นยังไงบ้างล่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:20
translate english arc2_tenten_quest1_b624ecfc:

    # tt "¿Lograste partirle el trasero como te dije?"
    tt "นายจัดการอัดเขาซะน่วมตามที่ฉันบอกได้รึเปล่า?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:22
translate english arc2_tenten_quest1_79b4d381:

    # mn "Jaja, no pensé que eso sería lo primero que preguntarías"
    mn "ฮ่าๆ ไม่คิดเลยนะเนี่ยว่าเธอจะถามเรื่องนี้เป็นเรื่องแรก"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:24
translate english arc2_tenten_quest1_fd1efb97:

    # mn "Pero sí, logramos ganarle a Zubon, gracias a eso nos recomendará para los {b}Exámenes Chunin{/a}"
    mn "แต่ก็ตามนั้นแหละ พวกเราจัดการซูบงได้ และเพราะงั้นเขาเลยจะเขียนใบแนะนำตัวพวกเราให้ไปสอบ {b}จูนิน{/b} น่ะสิ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:26
translate english arc2_tenten_quest1_863b0673:

    # tt "¡Felicidades!" with vpunch
    tt "ยินดีด้วยนะ!" with vpunch

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:29
translate english arc2_tenten_quest1_7b217ad9:

    # tt "Hace mucho deseé que alguien pusiera en su lugar a ese maldito"
    tt "ฉันอยากให้มีใครสักคนสั่งสอนไอ้เวรนั่นให้หลาบจำมานานแล้วล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:31
translate english arc2_tenten_quest1_8c6d0d09:

    # mn "Jeje... ¿Porqué le guardas tanto rencor?"
    mn "หึๆ... ทำไมเธอถึงแค้นเขาฝังหุ่นขนาดนั้นล่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:32
translate english arc2_tenten_quest1_412f40d7:

    # tt "Pues..."
    tt "ก็... อื้ม"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:40
translate english arc2_tenten_quest1_9dabe6ff:

    # tt "En el pasado se la pasaba acosando"
    tt "เมื่อก่อนน่ะ เขาชอบก่อกวนชาวบ้านอยู่เรื่อย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:41
translate english arc2_tenten_quest1_9f849c3e:

    # tt "Una vez lo encontré espiándome vientra me vestía"
    tt "มีอยู่ครั้งหนึ่ง ฉันจับได้ว่าแอบดูตอนที่ฉันกำลังเปลี่ยนเสื้อผ้าอยู่"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:42
translate english arc2_tenten_quest1_c8eecda3:

    # tt "Ugh, si no fuera por Rock Lee le hubiera partido la cara en ese instante"
    tt "ให้ตายสิ ถ้าไม่ได้ร็อค ลีห้ามไว้ ป่านนี้ฉันซัดหน้าหงายไปตั้งนานแล้ว"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:43
translate english arc2_tenten_quest1_5ab29c8e:

    # mn "Si... Es una historia muy creíble si se trata de él"
    mn "งั้นเหรอ... ฟังดูเป็นเรื่องที่ตาบ้านั่นทำได้สบายมากเลยแฮะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:49
translate english arc2_tenten_quest1_2dceca5c:

    # tt "Bueno, no te hice venir para hablar de ese tipo"
    tt "เอาเถอะ ฉันไม่ได้เรียกนายมาคุยเรื่องหมอนั่นหรอกนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:50
translate english arc2_tenten_quest1_6242ac89:

    # tt "Pero antes quería contarte algo"
    tt "แต่ก่อนอื่น ฉันมีเรื่องอยากจะบอกนายก่อน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:51
translate english arc2_tenten_quest1_87203074:

    # mn "Claro, dime"
    mn "ว่ามาเลยสิ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:52
translate english arc2_tenten_quest1_b36944f8:

    # tt "Verás, yo no soy una herrera como tal..."
    tt "คือว่านะ ฉันไม่ได้เป็นช่างตีเหล็กแบบจริงจังหรอก..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:54
translate english arc2_tenten_quest1_790aa014:

    # mn "¿No lo eres?"
    mn "เหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:56
translate english arc2_tenten_quest1_bb6d12f0:

    # tt "No, me dedico a vender armas"
    tt "เปล่าหรอก ฉันขายอาวุธต่างหาก"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:59
translate english arc2_tenten_quest1_6332cc32:

    # tt "Pero claro, eso es sumamente aburrido"
    tt "แต่แน่นอนว่ามันน่าเบื่อสุดๆ ไปเลยล่ะนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:61
translate english arc2_tenten_quest1_e148eb23:

    # tt "No sé que tenía en la cabeza para abrir una tienda de armas en tiempos de paz"
    tt "ไม่รู้ว่าเขาคิดอะไรอยู่ถึงมาเปิดร้านขายปืนในยุคสมัยที่สงบสุขแบบนี้"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:62
translate english arc2_tenten_quest1_5502cecb:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:65
translate english arc2_tenten_quest1_4d4fed75:

    # tt "Entonces, gracias a eso fue que decidí entrar al mundo de la forja"
    tt "เพราะงั้น ฉันก็เลยตัดสินใจก้าวเข้าสู่โลกแห่งการตีเหล็กซะเลย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:66
translate english arc2_tenten_quest1_a2656163:

    # tt "Emprendí un viaje para aprender sobre herrería, así fue como hice tu espada"
    tt "ฉันออกเดินทางไปเรียนรู้เรื่องการตีเหล็ก และนั่นแหละคือวิธีที่ฉันใช้สร้างดาบให้นายไงล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:67
translate english arc2_tenten_quest1_06069590:

    # mn "Ya veo... ¿Pero a qué quieres llegar?"
    mn "งั้นเหรอ... แต่เธอพยายามจะสื่ออะไรกันแน่เนี่ย?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:69
translate english arc2_tenten_quest1_4d81484d:

    # tt "Que no soy tan buena como crees, aún tengo mucho que aprender sobre la forja"
    tt "ก็คือฉันไม่ได้เก่งกาจอย่างที่นายคิดหรอก ฉันยังต้องเรียนรู้วิธีการตีเหล็กอีกเยอะเลย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:71
translate english arc2_tenten_quest1_aaf2094b:

    # tt "Así que, si tu quieres darle la tarea a alguien más... Puedo recomendarte a la persona que me enseñó a forjar"
    tt "เพราะงั้น ถ้านายอยากจะมอบหมายงานนี้ให้คนอื่น... ฉันแนะนำคนที่สอนฉันตีเหล็กให้ได้นะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:73
translate english arc2_tenten_quest1_d1b1ecf0:

    # tt "Sé que es importante para..."
    tt "ฉันรู้ว่ามันสำคัญสำหรับ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:74
translate english arc2_tenten_quest1_853ce6c9:

    # mn "No quiero"
    mn "ไม่อ่ะ ไม่อยากทำแบบนั้น"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:76
translate english arc2_tenten_quest1_33f84255:

    # tt "¿E-Eh?"
    tt "อ-เหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:77
translate english arc2_tenten_quest1_128a9a58:

    # tt "Pero, te aseguro que-"
    tt "แต่ฉันรับรองเลยนะว่า-"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:78
translate english arc2_tenten_quest1_42182d9a:

    # mn "Confio en tí, Tenten"
    mn "ฉันเชื่อใจเธอนะ เท็นเท็น"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:79
translate english arc2_tenten_quest1_aff3a799:

    # mn "Esta espada que me hiciste ha rendido mucho todos estos años"
    mn "ดาบเล่มนี้ที่เธอทำให้ฉัน มันใช้งานได้ดีมาตลอดหลายปีที่ผ่านมาเลยนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:80
translate english arc2_tenten_quest1_72898576:

    # mn "Ha resistido más que otras armas que he tenido"
    mn "มันทนทานกว่าอาวุธเล่มอื่นๆ ที่ฉันเคยมีซะอีก"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:82
translate english arc2_tenten_quest1_8110b4bd:

    # tt "..."
    tt "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:83
translate english arc2_tenten_quest1_619e9723:

    # mn "Puede que quien te enseñó a forjar sea mejor que tú"
    mn "ต่อให้คนที่สอนเธอตีเหล็กจะเก่งกว่าเธอก็เถอะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:84
translate english arc2_tenten_quest1_7b738b0c:

    # mn "Pero no quiero que mi espada sea forjada por otra persona..."
    mn "แต่ฉันไม่อยากให้ใครหน้าไหนมาตีดาบให้ฉันอีกแล้ว..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:85
translate english arc2_tenten_quest1_4edfd3d0:

    # mn "Solamente tú, Tenten"
    mn "ต้องเป็นเธอเท่านั้น เท็นเท็น"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:87
translate english arc2_tenten_quest1_8df78b5f:

    # mn "Para mí, no hay mejor persona que tú"
    mn "สำหรับฉันแล้ว ไม่มีใครเก่งไปกว่าเธออีกหรอก"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:89
translate english arc2_tenten_quest1_8110b4bd_1:

    # tt "..."
    tt "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:91
translate english arc2_tenten_quest1_97439874:

    # tt "D-De verdad no soy tan buena..."
    tt "จ-จริงจังนะเนี่ย ฉันไม่ได้เก่งขนาดนั้นสักหน่อย..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:92
translate english arc2_tenten_quest1_5502cecb_1:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:94
translate english arc2_tenten_quest1_bd55db0d:

    # mn "¿Y qué tal esto?"
    mn "งั้นเอาแบบนี้ไหมล่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:95
translate english arc2_tenten_quest1_019d2a87:

    # mn "Yo puedo ayudarte, ¿Qué te parece?"
    mn "ฉันช่วยเธอได้นะ ว่าไงล่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:98
translate english arc2_tenten_quest1_5d87536b:

    # tt "¿Ayudarme?"
    tt "ช่วยฉันงั้นเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:100
translate english arc2_tenten_quest1_85de34fc:

    # mn "Si, puedo ser tu asistente"
    mn "อื้ม ฉันมาเป็นลูกมือให้เธอได้นะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:101
translate english arc2_tenten_quest1_d672d87f:

    # mn "No sé nada realmente de la forja de armas, pero puedo ayudarte en lo que necesites"
    mn "ฉันอาจจะไม่รู้อะไรเกี่ยวกับการตีอาวุธเลย แต่ฉันช่วยหยิบจับนู่นนี่ตามที่เธอต้องการได้แน่นอน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:102
translate english arc2_tenten_quest1_622ddf70:

    # mn "Incluso puedo aprender, siempre tuve curiosidad sobre la herrería"
    mn "ฉันเรียนรู้ได้นะ แถมฉันยังสนใจเรื่องการตีเหล็กมาตลอดอยู่แล้วด้วย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:103
translate english arc2_tenten_quest1_e34c0e23:

    # mn "Ya verás que juntos harémos la mejor arma que hayan visto en los exámenes"
    mn "คอยดูเถอะ ถ้าเราช่วยกัน เราจะต้องสร้างอาวุธที่ดีที่สุดเท่าที่เคยมีมาในการสอบครั้งนี้แน่ๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:105
translate english arc2_tenten_quest1_d305f5af:

    # mn "NUESTRA ARMA SERÁ LEGENDARIA!" with vpunch
    mn "อาวุธของเราจะต้องกลายเป็นตำนานแน่!" with vpunch

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:110
translate english arc2_tenten_quest1_6a2694b1:

    # tt "Jajajaja..."
    tt "ฮ่าๆๆ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:111
translate english arc2_tenten_quest1_5de7fd7f:

    # mn "Entonces... ¿Qué dices?"
    mn "ว่าไงล่ะ... ว่าไงดีล่ะเนี่ย?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:114
translate english arc2_tenten_quest1_8110b4bd_2:

    # tt "..."
    tt "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:116
translate english arc2_tenten_quest1_4207cd48:

    # tt "Pues... Con esa oferta, ¿Quién se negaría?"
    tt "งั้นเหรอ... ด้วยข้อเสนอแบบนั้น ใครจะไปปฏิเสธลงล่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:117
translate english arc2_tenten_quest1_6fc00f36:

    # mn "¿Eso quiere decir que aceptas?"
    mn "นั่นหมายความว่าเธอยอมรับแล้วสินะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:119
translate english arc2_tenten_quest1_aa755746:

    # tt "Si... Esta puede ser una oportunidad única para que ambos mejoremos nuestras habilidades..."
    tt "อื้ม... นี่อาจจะเป็นโอกาสพิเศษสุดๆ สำหรับเราทั้งคู่ที่จะได้พัฒนาฝีมือเลยนะ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:120
translate english arc2_tenten_quest1_ffda1a06:

    # tt "Y tengo una idea de como hacerlo..."
    tt "แถมฉันก็มีไอเดียว่าจะทำยังไงดีด้วย..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:122
translate english arc2_tenten_quest1_fcc555e3:

    # mn "¿Una idea?"
    mn "มีไอเดียเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:123
translate english arc2_tenten_quest1_cbf09ba4:

    # tt "Desde hace tiempo he querido hacer un arma con un metal especial"
    tt "ฉันอยากจะลองสร้างอาวุธด้วยโลหะพิเศษมานานแล้วล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:124
translate english arc2_tenten_quest1_070ddb30:

    # mn "¿Un metal especial?"
    mn "โลหะพิเศษงั้นเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:125
translate english arc2_tenten_quest1_b9fc6de6:

    # tt "Si, este no es el metal que se usa normalmente con las armas normales"
    tt "ใช่แล้ว มันไม่ใช่โลหะแบบเดียวกับที่ใช้ทำอาวุธทั่วไปหรอกนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:126
translate english arc2_tenten_quest1_0b7fd51e:

    # mn "¿Cual es la diferencia?"
    mn "มันต่างกันยังไงเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:127
translate english arc2_tenten_quest1_3d8b5c03:

    # tt "Este mineral especial es más resistente, así que te durará años antes de que necesites cambiarla"
    tt "แร่พิเศษชนิดนี้มีความทนทานสูงมาก ทำให้ใช้งานได้หลายปีกว่าจะต้องเปลี่ยนใหม่เลยล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:128
translate english arc2_tenten_quest1_ad48e6dd:

    # tt "Pero la principal diferencia es que las armas creadas con este metal tienen una composición única con el Chakra"
    tt "แต่ความแตกต่างหลักๆ ก็คือ อาวุธที่ทำจากโลหะชนิดนี้จะมีคุณสมบัติพิเศษในการผสานเข้ากับจักระ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:129
translate english arc2_tenten_quest1_b8efcdca:

    # tt "Esto permite que el Chakra se adhiera de mejor manera en la hoja"
    tt "ซึ่งมันจะช่วยให้จักระยึดเกาะกับตัวใบมีดได้ดียิ่งขึ้นด้วย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:130
translate english arc2_tenten_quest1_b86a8130:

    # mn "Mmmm, ¿Y eso es bueno?"
    mn "อืม แล้วมันดีอย่างไรเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:133
translate english arc2_tenten_quest1_a12c91fc:

    # tt "*suspiro*"
    tt "*ถอนหายใจ*"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:135
translate english arc2_tenten_quest1_aeaa5dd1:

    # tt "Veamos... ¿Has visto que hay ninjas capaces de usar elementos en sus armas?"
    tt "งั้นลองนึกดูนะ... เคยเห็นนินจาที่ใช้ธาตุต่างๆ กับอาวุธของตัวเองไหมล่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:136
translate english arc2_tenten_quest1_f25a4b6e:

    # tt "Así como viento como Mirai... O el elemento Rayo de Sasuke"
    tt "อย่างเช่นธาตุลมของมิไร... หรือธาตุสายฟ้าของซาสึเกะยังไงล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:138
translate english arc2_tenten_quest1_5f5e3a86:

    # mn "¡Oh! Si lo he visto, hace unas semanas Sarada tomó mi espada y le imbuyó el elemento Rayo, ¿Es eso?"
    mn "อ๋อ! ใช่ ฉันเคยเห็นอยู่ เมื่อไม่กี่สัปดาห์ก่อนซาราดะเพิ่งเอาดาบของฉันไปเคลือบธาตุสายฟ้ามา แบบนั้นสินะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:140
translate english arc2_tenten_quest1_fe6f399d:

    # tt "¡Si, eso es!"
    tt "ใช่แล้ว แบบนั้นเลย!"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:141
translate english arc2_tenten_quest1_2a59ed4b:

    # tt "Para hacer eso se requiere un {b}Manejo del Chakra{/a} casi perfecto, pero con un arma hecha con este metal es más fácil manipularlo"
    tt "การทำแบบนั้นจำเป็นต้องอาศัย {b}การควบคุมจักระ{/b} ที่แทบจะสมบูรณ์แบบเลยทีเดียว แต่ถ้าใช้อาวุธที่ทำจากโลหะนี้ มันก็จะควบคุมได้ง่ายขึ้นล่ะนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:142
translate english arc2_tenten_quest1_85e74a1f:

    # tt "Eso no quita que sea difícil de dominar, pero no es tanto como hacerlo con un arma común y corriente"
    tt "มันก็ยังยากที่จะฝึกให้เชี่ยวชาญอยู่ดีแหละนะ แต่ก็ไม่ได้ยากเท่ากับการทำกับอาวุธธรรมดาทั่วไปหรอก"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:143
translate english arc2_tenten_quest1_f3397734:

    # mn "Ya veo..."
    mn "อย่างนี้นี่เอง..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:144
translate english arc2_tenten_quest1_7c9a01df:

    # tt "Dime, ¿Cuál es tu {b}Naturaleza de Chakra{/a}?"
    tt "บอกฉันหน่อยสิ ว่า{b}ธาตุประจำตัว{/a}ของนายคืออะไรเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:146
translate english arc2_tenten_quest1_9332d8ee:

    # mn "¿Mi naturaleza de Chakra?"
    mn "ธาตุประจำตัวของฉันงั้นเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:147
translate english arc2_tenten_quest1_50ff65c0:

    # mn "Es Naturaleza de {b}Fuego{/a}"
    mn "น่าจะเป็น{b}ธาตุไฟ{/b}นะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:148
translate english arc2_tenten_quest1_86c5b76d:

    # tt "Fuego..."
    tt "ธาตุไฟ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:149
translate english arc2_tenten_quest1_a252ae92:

    # tt "Con un arma de este tipo, al imbuir tu Chakra en la hoja se envolvería en llamas"
    tt "ถ้ามีอาวุธแบบนี้ ตอนที่นายถ่ายทอดจักระลงไปในใบมีด มันก็จะถูกห่อหุ้มไปด้วยเปลวเพลิงเลยล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:150
translate english arc2_tenten_quest1_f037ed67:

    # tt "Las llamas aumentarían la capacidad de corte de la espada, permitiéndote atravesar materiales que de otra manera serían resistentes"
    tt "เปลวไฟพวกนั้นจะช่วยเพิ่มพลังการตัดของดาบ ทำให้เธอสามารถฟันผ่านวัสดุที่ปกติแล้วทนทานต่อการตัดได้อย่างสบายๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:151
translate english arc2_tenten_quest1_04a462b7:

    # tt "E incluso los enemigos golpeados por la espada no solo sufrirán cortes, sino también quemaduras graves debido al calor extremo de las llamas"
    tt "แถมศัตรูที่โดนฟัน นอกจากจะบาดเจ็บจากคมดาบแล้ว ก็ยังจะโดนแผลไฟไหม้อย่างรุนแรงจากความร้อนสูงของเปลวเพลิงอีกด้วยนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:152
translate english arc2_tenten_quest1_3403fe94:

    # tt "Te aseguro que valdrá la pena, en serio"
    tt "รับรองเลยว่าคุ้มค่าสุดๆ แน่นอน พูดจริงนะเนี่ย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:153
translate english arc2_tenten_quest1_4946c48f:

    # mn "¿Y cómo podría aprender a imbuir mi Chakra en el arma, tú sabes hacerlo?"
    mn "แล้วฉันจะเรียนรู้วิธีถ่ายทอดจักระลงในอาวุธได้ยังไงล่ะ? เธอรู้วิธีไหม?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:154
translate english arc2_tenten_quest1_40c97f5b:

    # tt "No"
    tt "ไม่รู้สิ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:156
translate english arc2_tenten_quest1_5502cecb_2:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:157
translate english arc2_tenten_quest1_bc3a507c:

    # tt "Pero, Sarada sabe hacerlo ¿No?"
    tt "แต่ซาราดะรู้วิธีทำใช่ไหมล่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:159
translate english arc2_tenten_quest1_501cc5a5:

    # tt "Siendo ella no creo que no quiera ayudarte"
    tt "นิสัยอย่างเธอแล้ว ฉันว่าเธอไม่ปฏิเสธที่จะช่วยนายหรอก"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:160
translate english arc2_tenten_quest1_3854d094:

    # mnn "Mmmm..."
    mnn "อืม..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:162
translate english arc2_tenten_quest1_c99eb673:

    # mnn "(Ciertamente... Aprender una habilidad así me será muy útil...)"
    mnn "(นั่นสินะ... การได้เรียนรู้ทักษะแบบนี้คงจะมีประโยชน์มากแน่ๆ...)"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:163
translate english arc2_tenten_quest1_9c82d0c2:

    # mnn "(Pero ya le he pedido ayuda con el Sharingan y el Karugan, ¿Tendrá tiempo esta vez?)"
    mnn "(แต่ฉันเพิ่งจะขอให้เธอช่วยเรื่องเนตรวงแหวนกับคารูกันไปเอง... รอบนี้เธอจะมีเวลาว่างไหมนะ?)"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:164
translate english arc2_tenten_quest1_3a8fa72a:

    # mnn "(...)"
    mnn "(...)"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:165
translate english arc2_tenten_quest1_48446013:

    # mnn "(Bueno, supongo que no pierdo nada con preguntarle)"
    mnn "(ช่างเถอะ ลองไปถามดูก่อนก็ไม่เสียหายอะไรนี่นะ)"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:168
translate english arc2_tenten_quest1_82211808:

    # mn "Está bien, iré a preguntarle a ver si puede ayudarme, ¿Qué dices?"
    mn "งั้นก็ได้ เดี๋ยวฉันจะลองไปถามเธอดูล่ะกัน ว่าจะพอช่วยฉันได้ไหม เธอว่าไงล่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:169
translate english arc2_tenten_quest1_51b727bf:

    # tt "Bien, entonces te espero aquí"
    tt "ได้สิ ฉันจะรออยู่ที่นี่นะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:171
translate english arc2_tenten_quest1_5d042699:

    # mn "Bien, ya regreso"
    mn "โอเค เดี๋ยวฉันรีบกลับมานะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:176
translate english arc2_tenten_quest1_df8d8f19:

    # n "[MN] sale de la tienda de Tenten"
    n "[MN] เดินออกจากร้านของเท็นเท็น"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:201
translate english arc2_tenten_quest1_2_45a68cc7:

    # mn "Sarada, que bueno que te encuentro"
    mn "ซาราดะ ดีใจจังที่เจอเธอ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:202
translate english arc2_tenten_quest1_2_c4a70a12:

    # sr "[MN], cuanto tiempo sin verte"
    sr "[MN] ไม่ได้เจอกันนานเลยนะเนี่ย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:203
translate english arc2_tenten_quest1_2_3a620415:

    # sr "¿Cómo te fue en el exámen de Zubon?"
    sr "การสอบของซูบงเป็นยังไงบ้างล่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:205
translate english arc2_tenten_quest1_2_2798078e:

    # mn "¡Me fue increíble!"
    mn "ยอดเยี่ยมมากเลยล่ะ!"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:208
translate english arc2_tenten_quest1_2_1c63cd3c:

    # mn "Gracias a eso podrémos participar en los próximos exámenes Chunin"
    mn "เพราะแบบนั้น พวกเราเลยได้สิทธิ์เข้าร่วมการสอบจูนินที่จะถึงนี้ด้วย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:210
translate english arc2_tenten_quest1_2_27c0912d:

    # sr "¿En serio? ¡Felicidades!"
    sr "จริงเหรอเนี่ย? ยินดีด้วยนะ!"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:212
translate english arc2_tenten_quest1_2_4c5783c3:

    # mn "Gracias, no hubiera podido hacerlo sin tu ayuda"
    mn "ขอบคุณนะ ถ้าไม่ได้เธอช่วยไว้ ฉันคงไม่ผ่านแน่ๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:213
translate english arc2_tenten_quest1_2_a5d04ab2:

    # sr "No hay de qué jaja"
    sr "เรื่องแค่นี้เอง ฮ่าๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:214
translate english arc2_tenten_quest1_2_39759207:

    # sr "Pero bueno, ¿Necesitas que te ayude en algo?"
    sr "ว่าแต่ เธอมีเรื่องให้ฉันช่วยอะไรรึเปล่า?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:215
translate english arc2_tenten_quest1_2_1a47118b:

    # mn "Quería preguntarte algo"
    mn "คือฉันอยากจะมาขอให้เธอช่วยอะไรหน่อยน่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:216
translate english arc2_tenten_quest1_2_0fecfa61:

    # mn "Verás, estaba hablando con Tenten sobre una espada nueva, porque esta ya está obsoleta, tiene muchos años ya"
    mn "คือฉันคุยกับเท็นเท็นเรื่องอยากจะได้ดาบเล่มใหม่ เพราะเล่มนี้มันเก่ามากแล้ว ใช้มาตั้งหลายปีแล้วน่ะสิ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:217
translate english arc2_tenten_quest1_2_08bbd565:

    # sr "Si, ya era hora que la cambiaras, pude notar que la hoja estaba muy mellada la última vez"
    sr "อ๋อ ก็สมควรเปลี่ยนได้แล้วล่ะ รอบก่อนฉันสังเกตเห็นว่าใบดาบมันบิ่นไปเยอะเลย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:218
translate english arc2_tenten_quest1_2_196319a7:

    # mn "Si, y a Tenten se le ocurrió la idea de hacer una espada con un metal especial"
    mn "ใช่ แล้วเท็นเท็นก็เสนอไอเดียเรื่องการทำดาบด้วยโลหะพิเศษขึ้นมาน่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:219
translate english arc2_tenten_quest1_2_4fbee61b:

    # mn "Y pues, quería saber si puedes ayudarme a entrenar"
    mn "แล้วก็... ฉันเลยอยากจะรู้ว่าเธอพอจะช่วยฝึกให้ฉันหน่อยได้ไหม"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:220
translate english arc2_tenten_quest1_2_1ed7d7fa:

    # mn "Quiero aprender más sobre la {b}Manipulación del Chakra{/a}, quiero hacer lo mismo que tú"
    mn "ฉันอยากเรียนรู้เรื่อง {b}การควบคุมจักระ{/a} ให้มากขึ้น อยากทำได้แบบเธอบ้างน่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:221
translate english arc2_tenten_quest1_2_8c4e7a15:

    # mn "Tomaste mi espada y le imbuiste {b}Chakra de Rayo{/a}"
    mn "ที่เธอเคยเอาดาบของฉันไปแล้วก็ผสาน{b}จักระธาตุสายฟ้า{/a} ลงไปน่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:223
translate english arc2_tenten_quest1_2_b86d9a67:

    # sr "Mmmm... Déjame ver..."
    sr "อืม... ขอคิดดูก่อนนะ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:224
translate english arc2_tenten_quest1_2_623ccbce:

    # mn "Si no puedes no hay problema, de verdad"
    mn "ถ้าเธอไม่ว่างก็ไม่เป็นไรนะ เอาจริง ๆ เลย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:225
translate english arc2_tenten_quest1_2_9860ef1c:

    # sr "Verás, estos días estaré ocupada, tengo que ayudar con las preparaciones para los exámenes Chunin"
    sr "คือช่วงนี้ฉันค่อนข้างยุ่งน่ะ ต้องช่วยเตรียมการสำหรับการสอบจูนินด้วย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:227
translate english arc2_tenten_quest1_2_c557bb0b:

    # mn "¿No es el {b}Hokage{/a} y los ninjas de Nivel {b}Jonin{/a} los que hacen los preparativos?"
    mn "ไม่ใช่ว่าพวก {b}โฮคาเงะ{/a} กับนินจาระดับ {b}โจนิน{/a} เขาเป็นคนเตรียมกันหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:229
translate english arc2_tenten_quest1_2_eafd291d:

    # sr "¿Qué quieres decir con eso...?"
    sr "นายหมายความว่ายังไงน่ะ...?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:230
translate english arc2_tenten_quest1_2_bbf78925:

    # mn "¿Tú eres Chunin no?"
    mn "ก็เธอเป็นจูนินไม่ใช่เหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:232
translate english arc2_tenten_quest1_2_16278896:

    # sr "..."
    sr "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:233
translate english arc2_tenten_quest1_2_5502cecb:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:235
translate english arc2_tenten_quest1_2_769a36a0:

    # sr "No... Desde hace unos 2 años soy de {b}Rango Jonin{/a}..."
    sr "เปล่าสักหน่อย... ฉันเลื่อนขั้นเป็น{b}ระดับโจนิน{/a}มาได้ประมาณ 2 ปีแล้วนะ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:237
translate english arc2_tenten_quest1_2_c6b51398:

    # mn "¡¿E-En serio?!" with vpunch
    mn "จ-จริงเหรอครับเนี่ย?!" with vpunch

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:241
translate english arc2_tenten_quest1_2_16278896_1:

    # sr "..."
    sr "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:244
translate english arc2_tenten_quest1_2_554ac81a:

    # mn "Lo siento, no lo sabía"
    mn "ขอโทษที ฉันไม่รู้น่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:248
translate english arc2_tenten_quest1_2_28c1feb7:

    # sr "Si quiero ser la {b}Octava Hokage{/a}, posteriormente tengo que ser Rango {b}Jonin{/a}"
    sr "ถ้าฉันอยากจะเป็น{b}โฮคาเงะรุ่นที่แปด{/a} ฉันก็ต้องเป็น{b}นินจาระดับโจนิน{/a}ซะก่อนสิ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:250
translate english arc2_tenten_quest1_2_0235eda3:

    # mn "Si jaja..."
    mn "นั่นสินะ ฮ่าๆ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:252
translate english arc2_tenten_quest1_2_6203dbbb:

    # sr "*suspiro*"
    sr "*ถอนหายใจ*"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:255
translate english arc2_tenten_quest1_2_69617572:

    # sr "Bueno, el punto es que tendré algo de tiempo libre días antes, así que puedo ayudarte un poco en lo que necesites"
    sr "เอาเเป็นว่า ประเด็นคือฉันพอจะมีเวลาว่างก่อนวันสอบสักสองสามวันแหละ งั้นเดี๋ยวช่วยติวเรื่องที่นายต้องการให้หน่อยละกัน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:257
translate english arc2_tenten_quest1_2_38f37947:

    # sr "Pero debido al poco tiempo que dinpondré"
    sr "แต่เนื่องจากเวลาที่ฉันมีค่อนข้างจำกัด"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:258
translate english arc2_tenten_quest1_2_3bcf6f5c:

    # sr "Te tendré que someter a un entrenamiento riguroso para perfeccionar todas tus habilidades"
    sr "ฉันคงต้องให้เธอผ่านการฝึกสุดโหด เพื่อขัดเกลาทุกทักษะของเธอให้สมบูรณ์แบบ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:259
translate english arc2_tenten_quest1_2_dfe13314:

    # mn "Claro"
    mn "ได้ครับ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:261
translate english arc2_tenten_quest1_2_b86517cc:

    # sr "Seré mucho más estricta que las veces anteriores, y no te lo pondré fácil"
    sr "ฉันจะเข้มงวดกว่าเดิมมาก และไม่มีทางออมมือให้อย่างแน่นอน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:262
translate english arc2_tenten_quest1_2_98bdf65f:

    # sr "Será un entrenamiento completo para mejorar todas tus capacidades"
    sr "มันจะเป็นการฝึกแบบจัดเต็มเพื่อยกระดับความสามารถทั้งหมดของนาย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:263
translate english arc2_tenten_quest1_2_24575d2b:

    # sr "¿Aún así quieres hacerlo?"
    sr "นายยังอยากจะทำอยู่ไหมล่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:265
translate english arc2_tenten_quest1_2_c857f58f:

    # mn "Soportaré todo lo que me pongas en frente"
    mn "ผมจะทนทุกอย่างที่คุณโยนใส่ให้ได้ครับ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:268
translate english arc2_tenten_quest1_2_ac8007d6:

    # sr "Así me gusta, entonces yo te enviaré un mensaje cuando tenga tiempo entonces"
    sr "ฉันชอบความมุ่งมั่นนี้นะ งั้นเดี๋ยวว่างแล้วฉันจะส่งข้อความหาละกัน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:269
translate english arc2_tenten_quest1_2_6d780dc9:

    # sr "Quizás el {b}Sharingan{/a} pueda ayudar a que domines más rápido esta técnica"
    sr "บางที {b}เนตรวงแหวน{/a} อาจจะช่วยให้นายเรียนรู้วิชานี้ได้เร็วขึ้นก็ได้นะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:271
translate english arc2_tenten_quest1_2_b15c5bd1:

    # sr "El {b}Sharingan{/a} es capaz de ver el {b}Flujo de Chakra{/a} de tu enemigo, así que se te puede hacer más facil entender"
    sr "{b}เนตรวงแหวน{/a} มันมองเห็น {b}การไหลเวียนของจักระ{/a} ของศัตรูได้ ดังนั้นมันน่าจะทำให้นายเข้าใจได้ง่ายขึ้น"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:272
translate english arc2_tenten_quest1_2_7a813eda:

    # sr "Pero aún así no te hará todo el trabajo, esta habilidad depende completamente de tu {b}Manejo de Chakra{/a}, ¿Entendiste?"
    sr "แต่มันไม่ได้ช่วยทำแทนให้หมดทุกอย่างหรอกนะ ความสามารถนี้มันขึ้นอยู่กับ {b}การควบคุมจักระ{/a} ของนายล้วนๆ เลย เข้าใจไหม?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:273
translate english arc2_tenten_quest1_2_a0a56fa5:

    # mn "Si, haré todo lo que esté en mi poder para aprender, te lo juto"
    mn "ครับ ผมจะทำทุกวิถีทางเพื่อเรียนรู้ให้ได้ ขอสัญญาเลย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:276
translate english arc2_tenten_quest1_2_449097fb:

    # sr "[MN] se va del campo de entrenamiento"
    sr "[MN] เดินออกจากสนามฝึกไป"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:295
translate english arc2_tenten_quest1_3_76540997:

    # mn "Tenten, ya he vuelto"
    mn "เท็นเท็น ผมกลับมาแล้ว"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:297
translate english arc2_tenten_quest1_3_fee84992:

    # mn "Sarada aceptó, ¡Así que si podemos hacer esa espada!"
    mn "ซาราดะยอมช่วยแล้ว งั้นเราก็สร้างดาบเล่มนั้นได้สิ!"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:301
translate english arc2_tenten_quest1_3_9a2afd2f:

    # tt "¡Perfecto!"
    tt "เยี่ยมไปเลย!"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:304
translate english arc2_tenten_quest1_3_ea59a1cd:

    # tt "Si Sarada te ayuda entonces no habrá problemas"
    tt "ถ้าซาราดะช่วยล่ะก็ ไม่มีปัญหาแน่นอน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:308
translate english arc2_tenten_quest1_3_af4d0b53:

    # mn "Si, eso me ayudará mucho"
    mn "ใช่ครับ แบบนั้นช่วยผมได้เยอะเลย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:315
translate english arc2_tenten_quest1_3_50027fa0:

    # hd "¡¡[MN]!!"
    hd "[MN]!!"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:320
translate english arc2_tenten_quest1_3_da28e17c:

    # mnn "¡AAAAH!" with vpunch
    mnn "อ๊ากกก!" with vpunch

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:322
translate english arc2_tenten_quest1_3_c88af5b6:

    # hd "¡Oye!, ¿Porqué gritas de la nada?, me asustaste"
    hd "เฮ้! อยู่ๆ จะตะโกนขึ้นมาทำไมเนี่ย? ทำเอาตกใจหมดเลย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:325
translate english arc2_tenten_quest1_3_60f08a7c:

    # mn "¡TU ERES EL QUE VINO GRITANDO IDIOTA!" with hpunch
    mn "นายต่างหากเล่าที่โผล่มาตะโกนใส่ ไอ้งั่งเอ๊ย!" with hpunch

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:330
translate english arc2_tenten_quest1_3_a15e629f:

    # hd "Oh, cierto jeje, lo siento"
    hd "อ่า จริงด้วย ฮ่าๆ โทษที"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:332
translate english arc2_tenten_quest1_3_6a39331a:

    # tt "Hola Hideo, ¿Puedo ayudarte en algo?"
    tt "อ้าว ฮิเดโอะ มีอะไรให้ฉันช่วยหรือเปล่าจ๊ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:333
translate english arc2_tenten_quest1_3_6279b78c:

    # hd "Hola Tenten, ¿Puedes venderme dos docenas de Kunais?"
    hd "หวัดดีเท็นเท็น เธอขายคุไนให้ฉันสักสองโหลหน่อยสิ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:334
translate english arc2_tenten_quest1_3_f9d56de7:

    # tt "Si, cla-"
    tt "ได้สึ—"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:339
translate english arc2_tenten_quest1_3_f836feee:

    # tt_mn "¡¿Dos Docena?!" with vpunch
    tt_mn "สองโหลเลยเหรอ?!" with vpunch

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:344
translate english arc2_tenten_quest1_3_69f483a3:

    # hd "Eh, si jaja, es que estoy entrenando con Zubon-Sensei y me está preparando para los exámenes Chunin"
    hd "เอ่อ ใช่ ฮ่าๆ พอดีฉันกำลังฝึกกับอาจารย์ซูบงอยู่ แล้วเขากำลังเตรียมตัวให้ฉันสำหรับการสอบจูนินน่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:349
translate english arc2_tenten_quest1_3_cf755e82:

    # hd "Aunque hubiera preferido que me entrenara Kakashi-Sensei, pero esta vez no puede ayudarme..."
    hd "ถึงฉันจะอยากให้อาจารย์คาคาชิเป็นคนฝึกให้มากกว่าก็เถอะ แต่รอบนี้เขาช่วยไม่ได้..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:350
translate english arc2_tenten_quest1_3_9dd32f2c:

    # tt "Entiendo... Vuelvo enseguida entonces"
    tt "เข้าใจแล้วล่ะ... งั้นเดี๋ยวฉันมานะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:352
translate english arc2_tenten_quest1_3_5d1e4f58:

    # n "Tenten va a traer el pedido de Hideo"
    n "เท็นเท็นเดินไปหยิบของตามที่ฮิเดโอะสั่ง"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:357
translate english arc2_tenten_quest1_3_4bb55cad:

    # hd "Y tu [MN], ¿Qué haces aquí, también vienes por nuevo equipo?"
    hd "แล้วนายล่ะ [MN] มาทำอะไรที่นี่เนี่ย หรือว่าจะมาหาซื้ออุปกรณ์ใหม่เหมือนกันเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:359
translate english arc2_tenten_quest1_3_21ef551b:

    # mn "Si, Tenten me va a ayudar a cambiar mi espada"
    mn "ใช่ครับ เท็นเท็นกำลังจะช่วยฉันเปลี่ยนดาบเล่มใหม่ให้น่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:360
translate english arc2_tenten_quest1_3_43687638:

    # mn "Ya es demasiado vieja, no me servirá en los exámenes"
    mn "ดาบมันเก่าเกินไปแล้ว เอาไปใช้ในการสอบไม่ได้หรอก"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:362
translate english arc2_tenten_quest1_3_6331cf2a:

    # hd "De tantos golpes que recibía de Yuna en los entrenamientos, me sorprende que aún esté de una pieza"
    hd "เจอการโจมตีของยูนะตอนฝึกซ้อมไปซะขนาดนั้น ฉันยังแปลกใจเลยว่ามันยังไม่หักเป็นสองท่อน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:364
translate english arc2_tenten_quest1_3_f41d8586:

    # mn "Si jaja"
    mn "ใช่ครับ ฮ่าๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:369
translate english arc2_tenten_quest1_3_ab7b2261:

    # mn "Por cierto, ¿Sabes qué hará Yuna antes de los exámenes?"
    mn "ว่าแต่ นายรู้ไหมว่ายูนะจะทำอะไรก่อนถึงวันสอบหรือเปล่า?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:371
translate english arc2_tenten_quest1_3_fa8e0108:

    # hd "También está entrenando con Zubon-Sensei"
    hd "เธอก็ฝึกอยู่กับอาจารย์ซูบงเหมือนกันนั่นแหละ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:372
translate english arc2_tenten_quest1_3_824ea928:

    # hd "Lo mismo de siempre, entrenando para perfeccionar su {b}Estilo de Acero{/a}"
    hd "ก็เหมือนเดิม ฝึกฝน{b}คาถาเหล็กไหล{/a}ของเธอให้สมบูรณ์แบบ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:373
translate english arc2_tenten_quest1_3_300a47b8:

    # hd "También está entrenando para crear un nuevo Jutsu"
    hd "แถมเธอยังฝึกเพื่อสร้างวิชานินจาใหม่อีกด้วยนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:375
translate english arc2_tenten_quest1_3_211c1b3a:

    # hd "¿Pero sabes que es lo peor? Que Zubon-Sensei le ha metido en la cabeza que yo seré su compañero de entrenamiento"
    hd "แต่รู้ไหมว่าอะไรแย่ที่สุด? อาจารย์ซูบงดันกรอกหูเธอว่าฉันต้องเป็นคู่ซ้อมให้เนี่ยสิ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:377
translate english arc2_tenten_quest1_3_e631d0e7:

    # hd "¡Eso es impensable!" with vpunch
    hd "มันเป็นไปไม่ได้เลยสักนิด!" with vpunch

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:381
translate english arc2_tenten_quest1_3_753e089a:

    # hd "Yo no estoy al nivel de Yuna, no estoy ni cerca"
    hd "ฉันไม่ได้เก่งเท่าระดับยูนะหรอก เทียบกันไม่ติดฝุ่นเลยด้วยซ้ำ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:385
translate english arc2_tenten_quest1_3_d1a40685:

    # mn "Te deseo mucha suerte jajaja"
    mn "ขอให้โชคดีนะ ฮ่าๆๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:386
translate english arc2_tenten_quest1_3_cb7bf5ef:

    # hd "Eso no es gracioso ¿Sabes?"
    hd "มันไม่ตลกเลยนะ รู้ไหม?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:391
translate english arc2_tenten_quest1_3_cbfce183:

    # tt "Listo, aquí tienes dos docenas de Kunais"
    tt "นี่จ่ะ คุไนสองโหล"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:395
translate english arc2_tenten_quest1_3_b26d6bf3:

    # tt "Aún creo que son demasiados... Pero el cliente siempre tiene la razón ¿No?"
    tt "ฉันยังคิดว่ามันเยอะไปอยู่ดีนะ... แต่ลูกค้าคือพระเจ้าสินะคะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:396
translate english arc2_tenten_quest1_3_fef115f6:

    # hd "Zubon-Sensei fue quien me dijo que comprara tantas..."
    hd "อาจารย์ซูบงต่างหากล่ะที่บอกให้ฉันซื้อมาเยอะขนาดนี้..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:397
translate english arc2_tenten_quest1_3_a6004e01:

    # mn "De seguro es porque piensa que Yuna los romperá todos"
    mn "เขาคงคิดว่ายูนะจะทำพังหมดทุกอันแน่ๆ เลยมั้ง"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:399
translate english arc2_tenten_quest1_3_be553259:

    # hd "Oh, ¿Por eso me pidió dos docenas?"
    hd "อ๋อ งั้นเหรอ ถึงว่าทำไมเขาถึงสั่งให้ฉันซื้อตั้งสองโหล?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:402
translate english arc2_tenten_quest1_3_5dbc7d5a:

    # hd "..."
    hd "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:405
translate english arc2_tenten_quest1_3_c6217791:

    # hd "Oye, ¿Crees que basten dos docenas?"
    hd "นี่ นายว่าสองโหลมันจะพอไหมเนี่ย?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:407
translate english arc2_tenten_quest1_3_d5b2ac37:

    # mn "¿Tienes para comprar más?"
    mn "นายมีเงินซื้อเพิ่มหรือไงล่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:408
translate english arc2_tenten_quest1_3_19e4501d:

    # hd "No... Espero que con esto baste..."
    hd "เปล่า... หวังว่ามันจะพอหรอกนะ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:409
translate english arc2_tenten_quest1_3_97caaf44:

    # mn "Créeme que no bastará"
    mn "เชื่อฉันเถอะ ว่ามันไม่พอหรอก"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:410
translate english arc2_tenten_quest1_3_1792d78a:

    # mn "Dile a Yuna que no sea tan brusca contigo ¿Quieres?"
    mn "งั้นก็บอกให้ยูนะเบามือหน่อยก็แล้วกัน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:413
translate english arc2_tenten_quest1_3_5dbc7d5a_1:

    # hd "..."
    hd "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:416
translate english arc2_tenten_quest1_3_3e11adf4:

    # hd "[MN], hace años que eres mi {b}Mejor Amigo{/a}"
    hd "[MN] นอกเหนือจากนายที่เป็น {b}เพื่อนสนิท{/a} ของฉันมาหลายปี"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:418
translate english arc2_tenten_quest1_3_a6d5c303:

    # hd "Si me pasa algo, dile a mi abuela que morí heroicamente luchando con una bestia incontrolable"
    hd "ถ้าเกิดอะไรขึ้นกับฉัน ช่วยบอกย่าของฉันทีนะว่าฉันตายอย่างวีรบุรุษตอนที่สู้กับสัตว์ร้ายที่ควบคุมไม่ได้น่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:420
translate english arc2_tenten_quest1_3_a0e4b939:

    # mn "No exageres jajaja"
    mn "อย่าพูดเวอร์น่า ฮ่าๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:422
translate english arc2_tenten_quest1_3_f97b0408:

    # mn "Ya vete, sabes que a Yuna no le gusta que la hagan esperar"
    mn "ไปได้แล้ว ก็น่ารู้ไม่ใช่เหรอว่ายูนะไม่ชอบให้ใครปล่อยให้รอนานน่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:424
translate english arc2_tenten_quest1_3_27ee42c7:

    # hd "Bueno, aquí tienes Tenten"
    hd "งั้นก็นี่ครับ เงินค่าของ เท็นเท็น"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:426
translate english arc2_tenten_quest1_3_8a190330:

    # tt "Gracias por tu compra, vuelve cuando necesites otra docena de kunais"
    tt "ขอบคุณที่อุดหนุนนะคะ ไว้มาซื้อคุไนเพิ่มอีกสักโหลได้เรื่อยๆ เลยนะึคะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:427
translate english arc2_tenten_quest1_3_a52d1d4d:

    # hd "Yuna me dejará pobre e inválido..."
    hd "ยูนะต้องทำให้ฉันทั้งถังแตกแถมพิการแน่ๆ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:431
translate english arc2_tenten_quest1_3_6b54430d:

    # hd "Mejor iré escribiendo mi testamento..."
    hd "ฉันรีบไปเขียนพินัยกรรมไว้ก่อนดีกว่า..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:434
translate english arc2_tenten_quest1_3_39b82d9b:

    # n "Hideo sale de la tienda"
    n "ฮิเดโอะเดินออกจากร้านไป"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:443
translate english arc2_tenten_quest1_3_3d88a8e8:

    # tt "Fue divertido ver como te asustaste jajaja"
    tt "เห็นนายทำหน้ากลัวแบบนั้นแล้วตลกชะมัด ฮ่าๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:444
translate english arc2_tenten_quest1_3_0aaf2ab5:

    # tt "Nunca había visto esa cara en tí antes jajaja"
    tt "ฉันไม่เคยเห็นนายทำหน้าแบบนั้นมาก่อนเลยนะเนี่ย ฮ่าๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:447
translate english arc2_tenten_quest1_3_6d153c0c:

    # mn "O-Oye... Casi me muero del susto"
    mn "ด-เดี๋ยวสิ... ฉันเกือบช็อกตายอยู่แล้วนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:448
translate english arc2_tenten_quest1_3_69acf0a9:

    # tt "Jajaja"
    tt "ฮ่าๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:449
translate english arc2_tenten_quest1_3_5502cecb:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:453
translate english arc2_tenten_quest1_3_32e828a7:

    # tt "Bueno, con ese asunto arreglado, ya podemos seguir con el tema de la espada"
    tt "เอาล่ะ ในเมื่อเรื่องนั้นเคลียร์แล้ว เรามาคุยเรื่องดาบกันต่อเถอะนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:454
translate english arc2_tenten_quest1_3_e9459944:

    # mn "¿Si harás la espada de ese metal especial?"
    mn "เธอจะทำดาบจากแร่พิเศษนั่นจริงๆ เหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:455
translate english arc2_tenten_quest1_3_7606b313:

    # tt "Si, pero antes de empezar a hacerla..."
    tt "ใช่จ่ะ แต่ก่อนที่ฉันจะเริ่มลงมือทำ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:457
translate english arc2_tenten_quest1_3_99b4330e:

    # tt "Verás..."
    tt "คือว่านะ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:458
translate english arc2_tenten_quest1_3_5e57628d:

    # tt "No tengo de ese mineral..."
    tt "ฉันยังไม่มีแร่นั้นน่ะสิ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:460
translate english arc2_tenten_quest1_3_5502cecb_1:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:462
translate english arc2_tenten_quest1_3_38c86c8e:

    # mn "¿Qué?"
    mn "อะไรนะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:463
translate english arc2_tenten_quest1_3_97b97510:

    # tt "Si, no tengo noticias del comerciante que lo vende"
    tt "ใช่แล้วล่ะ ฉันยังติดต่อพ่อค้าที่ขายแร่นั้นไม่ได้เลย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:464
translate english arc2_tenten_quest1_3_56326859:

    # mn "Entonces... ¿Qué opciones tenémos?"
    mn "งั้น... เรามีทางเลือกอะไรบ้างล่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:466
translate english arc2_tenten_quest1_3_4fcfa578:

    # tt "No podemos esperar, los exámenes Chunin comenzarán en unas semanas, así que solo tenémos una opción"
    tt "เราจะรอไม่ได้ การสอบจููนินจะเริ่มในอีกไม่กี่สัปดาห์นี้แล้ว เพราะงั้นเราเลยมีทางเลือกเดียว"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:467
translate english arc2_tenten_quest1_3_83e8f889:

    # tt "Tenemos que salir de la aldea a recoger el mineral directamente de la mina en la que se extrae"
    tt "พวกเราต้องออกจากหมู่บ้านเพื่อไปเก็บแร่โดยตรงจากเหมืองที่ขุดมันขึ้นมาเลยล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:468
translate english arc2_tenten_quest1_3_44c7cd73:

    # mn "¿Y es un viaje largo?"
    mn "แล้วมันต้องเดินทางไกลไหมล่ะนั่น?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:469
translate english arc2_tenten_quest1_3_93ce91e7:

    # tt "Es un viaje de dos días, uno de ida y otro de vuelta"
    tt "เป็นการเดินทางสองวัน ไปหนึ่งวันแล้วก็กลับอีกหนึ่งวันน่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:470
translate english arc2_tenten_quest1_3_a0559f92:

    # tt "Eso sin contar el tiempo que tenemos que descansar por el camino"
    tt "นั่นยังไม่รวมเวลาที่เราต้องหยุดพักระหว่างทางด้วยนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:471
translate english arc2_tenten_quest1_3_71e92b2f:

    # tt "Así que quizás sean 3 días"
    tt "งั้นก็น่าจะสัก 3 วันได้ล่ะมั้ง"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:472
translate english arc2_tenten_quest1_3_1bb34dac:

    # mn "Entiendo..."
    mn "ผมเข้าใจครับ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:474
translate english arc2_tenten_quest1_3_26366070:

    # mn "Bueno, ¿Cuándo salimos?"
    mn "งั้นพวกเราจะออกเดินทางกันเมื่อไหร่ล่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:476
translate english arc2_tenten_quest1_3_b20f8bf6:

    # tt "Que fácil eres"
    tt "นายเนี่ยใจง่ายจังนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:477
translate english arc2_tenten_quest1_3_6ca03a6d:

    # tt "Pensé que tardarías más en aceptar..."
    tt "ฉันนึกว่านายจะใช้เวลากว่านี้ในการยอมตกลงซะอีก..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:478
translate english arc2_tenten_quest1_3_2dace198:

    # mn "Justo ahora mi prioridad es la espada, no puedo quedarme sin ella"
    mn "ตอนนี้สิ่งสำคัญที่สุดของฉันคือดาบเล่มนั้น ขาดมันไปไม่ได้หรอก"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:480
translate english arc2_tenten_quest1_3_d30990f6:

    # tt "Muy bien, entonces salimos el {b}Viernes{/a} por la {b}Mañana{/a}"
    tt "งั้นเราจะออกเดินทางกันตอนเช้า {b}วันศุกร์{/a} นะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:481
translate english arc2_tenten_quest1_3_c18f2a33:

    # tt "Nos encontrarémos en {b}La Puerta de la Hoja{/a}"
    tt "ไปเจอกันที่{b}ประตูหมู่บ้านโคโนฮะ{/a}ก็แล้วกัน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:482
translate english arc2_tenten_quest1_3_99a3cc79:

    # mn "Bien, ahí estaré"
    mn "เข้าใจแล้ว เดี๋ยวผมจะไปที่นั่นครับ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:483
translate english arc2_tenten_quest1_3_6e4fc7a6:

    # tt "Perfecto, yo iré preparando mis cosas para el viaje"
    tt "เยี่ยมเลย งั้นฉันขอตัวไปเตรียมของสำหรับการเดินทางก่อนนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:485
translate english arc2_tenten_quest1_3_342e28fe:

    # mn "Yo igual, nos vemos el {b}Viernes{/a} entonces"
    mn "ผมก็เหมือนกัน เจอกัน{b}วันศุกร์{/a}นี้นะครับ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest1.rpy:40
translate english arc2_tenten_quest1_3e793b39:

    # tt "En el pasado, siempre que podía me acosaba"
    tt "เมื่อก่อนนี้น่ะ เขาคอยตามรังควานฉันตลอดเวลาที่มีโอกาสเลยล่ะ"

