# TODO: Translation updated at 2024-12-01 21:25

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:6
translate english arc2_ino_quest2_7a6231ad:

    # n "[MN] sale de su Apartamento y se dirige al punto de Reunión para encontrarse con Ino"
    n "[MN] เดินออกจากห้องพักแล้วมุ่งหน้าไปยังจุดนัดพบเพื่อเจออิโนะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:20
translate english arc2_ino_quest2_726193f7:

    # mn "Hola Ino, siento la tardanza"
    mn "หวาดีจ้าอิโนะ โทษทีที่มาสายนะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:21
translate english arc2_ino_quest2_1aa18f65:

    # ino "No te preocupes, llegas justo a tiempo"
    ino "ไม่ต้องห่วง นายมาตรงเวลาพอดีเลย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:22
translate english arc2_ino_quest2_c7c94620:

    # mn "¿Cómo está la situación, todos los trabajadores ya se fueron?"
    mn "สถานการณ์เป็นไงบ้าง คนงานกลับกันหมดรึยัง?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:24
translate english arc2_ino_quest2_a7736167:

    # ino "Si, en teoría ya no hay nadie en el edificio"
    ino "อืม ตามหลักแล้วไม่มีใครอยู่ในตึกนั้นแล้วล่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:25
translate english arc2_ino_quest2_2670b120:

    # ino "Ví salir a todos los que trabajan en el Centro de Investigación"
    ino "ฉันเห็นทุกคนที่ทำงานอยู่ในศูนย์วิจัยทยอยออกไปหมดแล้ว"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:26
translate english arc2_ino_quest2_28e96ba0:

    # mn "Bien, eso significa que no hay nadie que abra desde adentro"
    mn "เยี่ยม งั้นก็แปลว่าจะไม่มีใครเปิดประตูจากด้านในสินะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:27
translate english arc2_ino_quest2_a712670b:

    # mn "Tenémos que estar atentos a cualquier cosa que pueda ocurrir"
    mn "เราต้องระแวดระวังเรื่องอะไรก็ตามที่อาจจะเกิดขึ้นด้วย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:30
translate english arc2_ino_quest2_504d32cc:

    # n "Luego de que [MN] se reuniera con Ino, ambos estuvieron vigilando el Centro de Investigación"
    n "หลังจาก [MN] พบกับอิโนะ ทั้งคู่ก็ช่วยกันเฝ้าระวังรอบศูนย์วิจัย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:31
translate english arc2_ino_quest2_c9eea66b:

    # n "[MN] estuvo atento, moviéndose de edificio en edificio sigilosamente"
    n "[MN] คอยระแวดระวังตัว พร้อมกับหลบซ่อนเร้นกายย้ายจากตึกหนึ่งไปยังอีกตึกหนึ่ง"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:32
translate english arc2_ino_quest2_69c9ff56:

    # n "Mientras Ino verificaba los alrededores"
    n "ในขณะที่อิโนะคอยสำรวจบริเวณรอบๆ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:33
translate english arc2_ino_quest2_313d7c61:

    # n "Pero lamentablemente no ocurrió nada"
    n "แต่ก็น่าเสียดายที่ไม่มีอะไรเกิดขึ้นเลย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:37
translate english arc2_ino_quest2_b5f5fe16:

    # ino "Maldición..."
    ino "ให้ตายสิ..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:38
translate english arc2_ino_quest2_7f5f7858:

    # ino "No viene nadie..."
    ino "ไม่มีใครมาเลยแฮะ..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:39
translate english arc2_ino_quest2_d6033e84:

    # mn "Debemos tener paciencia... De ser necesario debemos quedarnos aquí toda la noche"
    mn "เราต้องอดทนไว้... ถ้าจำเป็น เราก็ควรจะอยู่เฝ้าที่นี่ทั้งคืนเลย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:41
translate english arc2_ino_quest2_ccbacd08:

    # ino "Mmmm... El desvelo no es bueno para mi rostro..."
    ino "อืมมม... การนอนดึกเนี่ยไม่ดีต่อผิวหน้าฉันเลยนะ..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:44
translate english arc2_ino_quest2_87c2ad2d:

    # mn "No te preocupes, te verías hermosa aún con ojeras"
    mn "ไม่ต้องห่วงน่า เธอต่อให้มีขอบตาดำคล้ำก็ยังดูสวยอยู่ดีนั่นแหละ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:47
translate english arc2_ino_quest2_b07faf0a:

    # ino "Claro que no, ¿A quién le gusta tener ojeras? Jajaja"
    ino "ไม่เห็นจะจริงเลย ใครจะไปอยากมีขอบตาดำกันเล่า ฮ่าๆๆ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:50
translate english arc2_ino_quest2_6a03cb62:

    # mn "Jajaja"
    mn "ฮ่าๆๆ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:52
translate english arc2_ino_quest2_f62869d6:

    # ino "Por cierto, no pude decírtelo antes"
    ino "ว่าแต่ ฉันยังไม่ได้บอกเรื่องนี้กับนายก่อนหน้านี้เลย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:53
translate english arc2_ino_quest2_4b149ba2:

    # ino "Pero esa nueva vestimenta te queda muy bien"
    ino "แต่ชุดใหม่นั่นดูเข้ากับนายดีจังเลยนะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:54
translate english arc2_ino_quest2_1daa5cff:

    # ino "Te hace ver mucho más serio... Más masculino..."
    ino "ทำให้นายดูจริงจังขึ้นเยอะเลย... ดูเป็นผู้ชายขึ้นด้วย..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:57
translate english arc2_ino_quest2_7d3a4f28:

    # mn "Oh, ¿en serio? No lo había notado jaja"
    mn "อ๋อ, งั้นเหรอ? ฉันไม่ทันสังเกตเลยแฮะ ฮ่าๆ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:60
translate english arc2_ino_quest2_5c486576:

    # ino "Sí, te ves mucho más como un ninja experto ahora"
    ino "ใช่ ตอนนี้นายดูเหมือนนินจามืออาชีพขึ้นเป็นกองเลยล่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:61
translate english arc2_ino_quest2_874167e6:

    # ino "¿Paticiparás en los Exámenes Chunin de este año?"
    ino "นายจะเข้าร่วมสอบจููนินปีนี้ด้วยรึเปล่า?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:62
translate english arc2_ino_quest2_94124871:

    # mn "Así es, de hecho, lo cambié precisamente pensando en los Exámenes Chunin que se acercan"
    mn "ถูกต้องแล้ว จริงๆ ฉันเปลี่ยนชุดนี้ก็เพื่อเตรียมตัวสำหรับการสอบจูนินที่จะถึงนี้โดยเฉพาะเลยนะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:63
translate english arc2_ino_quest2_65c4fc3d:

    # ino "Buena elección, los colores oscuros son perfectos para misiones que requieren ser sigiloso"
    ino "เลือกได้ดีนี่ สีเข้มเหมาะกับภารกิจที่ต้องใช้ความลับสุดยอดจริงๆ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:64
translate english arc2_ino_quest2_0d996a68:

    # ino "Será más fácil para ti moverte sin ser detectado en la oscuridad"
    ino "มันจะช่วยให้นายเคลื่อนไหวในความมืดโดยไม่ให้ใครจับได้ง่ายขึ้นด้วย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:65
translate english arc2_ino_quest2_2ed3db87:

    # ino "También las protecciones que integraste te ayudarán en el combate cuerpo a cuerpo"
    ino "แถมอุปกรณ์ป้องกันที่นายติดเพิ่มเข้ามา ก็น่าจะช่วยประโยชน์ในการต่อสู้ระยะประชิดได้ดีเลย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:67
translate english arc2_ino_quest2_343e50c3:

    # ino "Sinceramente, te da un aire más intimidante"
    ino "พูดตามตรงนะ มันทำให้ดูลึกลับน่าเกรงขามขึ้นเป็นกองเลยล่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:69
translate english arc2_ino_quest2_a6907077:

    # mn "Jeje, lo tomaré como un cumplido"
    mn "เฮะๆ ถือว่าเป็นคำชมก็แล้วกันนะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:72
translate english arc2_ino_quest2_b7cd143c:

    # ino "Deberías, Es un buen cambio"
    ino "ก็ควรจะรับไว้นะ เป็นการเปลี่ยนแปลงที่ดีออก"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:74
translate english arc2_ino_quest2_d5eddf4e:

    # ino "También pude notar tu nueva espada, ahora ya estás perfectamente preparado para los exámenes, ¿Cierto?"
    ino "ฉันสังเกตเห็นดาบเล่มใหม่ของนายด้วยนะ ทีนี้ก็พร้อมเต็มที่สำหรับการสอบแล้วสินะ?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:75
translate english arc2_ino_quest2_bedb52c8:

    # mn "Oh, si, Tenten fue quien la hizo para mí, está hecha con un mineral especial que absorbe de manera más eficaz el Chakra del protador"
    mn "อ่า ใช่แล้ว เท็นเท็นเป็นคนทำให้อ่ะ มันทำมาจากแร่พิเศษที่ช่วยดูดซับจักระของผู้ใช้ได้มีประสิทธิภาพมากขึ้นน่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:76
translate english arc2_ino_quest2_0ddbe401:

    # mn "Aunque, aún no aprendo a hacerlo jaja, luego de esta misión voy a entrenar para eso, espero lograrlo"
    mn "ถึงฉันจะยังใช้ไม่ค่อยเป็นก็เถอะนะ ฮ่าๆ ไว้เสร็จภารกิจนี้แล้วค่อยไปฝึกใช้อย่างจริงจัง หวังว่าจะทำได้นะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:78
translate english arc2_ino_quest2_e821496b:

    # ino "Lo lograrás, estoy segura de ello"
    ino "นายทำได้อยู่แล้ว ฉันมั่นใจเลย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:80
translate english arc2_ino_quest2_1293cf8f:

    # ino "Solo cree en tí, y lograrás todo lo que te propongas"
    ino "แค่มั่นใจในตัวเอง นายก็จะทำทุกอย่างที่ตั้งใจไว้ให้สำเร็จได้แน่นอน"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:81
translate english arc2_ino_quest2_8564ce8d:

    # mn "Gracias... Eso significa mucho, sobre todo viniendo de ti"
    mn "ขอบคุณนะ... คำพูดนี้มีความหมายกับฉันมากเลย โดยเฉพาะเมื่อมาจากเธอเนี่ย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:82
translate english arc2_ino_quest2_d33efe36:

    # ino "No hay de qué"
    ino "ด้วยความยินดีจ่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:83
translate english arc2_ino_quest2_c74bc0b5:

    # ino "Ya quiero ver como logras vencer a todos en los exámenes jaja"
    ino "ชักรอไม่ไหวแล้วสิอยากเห็นนายไปซัดทุกคนให้ร่วงในการสอบจัง ฮ่าๆ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:84
translate english arc2_ino_quest2_d213e6ac:

    # mn "Cuando pase los exámenes salimos a celebrar, ¿Qué te parece?"
    mn "ไว้ถ้าฉันสอบผ่านเมื่อไหร่ เราไปฉลองกันหน่อยไหม ว่าไงล่ะ?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:86
translate english arc2_ino_quest2_00af959a:

    # ino "Me parece bien, me encanta la idea"
    ino "ฟังดูเข้าท่าดีนะ ฉันชอบไอเดียนี้เลยล่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:90
translate english arc2_ino_quest2_19b9b733:

    # n "Mientras [MN] e Ino charlaban, pasaron las horas, hasta que se hizo de madrugada"
    n "ระหว่างที่ [MN] กับอิโนะคุยกัน เวลาผ่านไปหลายชั่วโมงจนกระทั่งเข้าสู่ช่วงเช้ามืด"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:91
translate english arc2_ino_quest2_21217e42:

    # n "Y de pronto, ven algo acercarse al Centro de Investigación"
    n "แล้วจู่ๆ พวกเขาก็เห็นบางอย่างกำลังเคลื่อนตัวเข้ามาใกล้ศูนย์วิจัย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:100
translate english arc2_ino_quest2_7bc2434e:

    # mn "Ino, ¿Ves eso por allá?" with vpunch
    mn "อิโนะ เห็นตรงนั้นรึเปล่า?" with vpunch

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:101
translate english arc2_ino_quest2_6a67a175:

    # ino "Sí, lo veo... pero como imaginábamos, no siento ningún chakra"
    ino "อืม เห็นจ่ะ... แต่ก็อย่างที่เราคิดไว้เลย ฉันไม่สัมผัสได้ถึงจักระเลยสักนิด"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:102
translate english arc2_ino_quest2_3d61c33f:

    # mn "Exacto, tal como dijo Amado"
    mn "นั่นสินะ เหมือนกับที่อามาโดะบอกไว้ไม่มีผิด"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:103
translate english arc2_ino_quest2_f9dda55b:

    # mn "Eso tiene que ser el dron que mencionaron"
    mn "นั่นต้องเป็นโดรนที่พวกเขาพูดถึงแน่ๆ เลย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:104
translate english arc2_ino_quest2_68227707:

    # mn "Pero, veo más de uno, son varios"
    mn "แต่ว่า ฉันไม่ได้เห็นแค่ตัวเดียวนะ มีตั้งหลายลำแน่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:105
translate english arc2_ino_quest2_69afadf7:

    # ino "Si, el ladrón los debe estar utilizando para seguir robando"
    ino "ใช่แล้ว เจ้าขโมยคงจะใช้พวกมันเพื่อลักลอบขโมยของต่อไปเรื่อยๆ แน่เลย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:106
translate english arc2_ino_quest2_0a92a5d5:

    # mn "Entonces el ladrón debe de estar por las cercanías controlando los Drones"
    mn "งั้นแสดงว่าตัวการต้องอยู่แถวนี้เพื่อคอยควบคุมเจ้าพวกนี้อยู่แน่ๆ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:107
translate english arc2_ino_quest2_4e53d852:

    # mn "Separémonos, busquemos al que los está controlando, si para cuando los Drones salgan no lo hemos encontrado, debemos seguirlos para dar con él"
    mn "พวกเราแยกย้ายกันหากันเถอะ ลองหาคนที่ควบคุมพวกมันดู ถ้ายังหาไม่เจอจนกว่าโดรนพวกนั้นจะไป เราค่อยสะกดรอยตามพวกมันไปเพื่อหาตัวเขาแทน"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:108
translate english arc2_ino_quest2_0d7e3f00:

    # ino "Bien, si encuentro algo te lo haré saber con el comunicador"
    ino "เข้าใจแล้ว ถ้าเจออะไรผิดปกติ ฉันจะติดต่อบอกทางเครื่องสื่อสารนะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:109
translate english arc2_ino_quest2_6cf68cc3:

    # mn "Bien, andando pues"
    mn "โอเค ลุยกันเลย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:113
translate english arc2_ino_quest2_27bb7542:

    # n "Ambos ninjas se dispersan y comienzan a buscar al que controla los Drones"
    n "นินจาทั้งสองแยกย้ายกันออกค้นหาผู้ที่ควบคุมโดรนเหล่านั้น"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:114
translate english arc2_ino_quest2_9404662e:

    # n "Pasan los minutos, y ninguno encuentra nada"
    n "เวลาผ่านไปหลายนาที แต่ก็ยังไม่มีใครพบเบาะแสอะไรเลย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:115
translate english arc2_ino_quest2_7ce47837:

    # n "Los Drones salen del Centro de Investigación y ambos se reúnen nuevamente"
    n "เมื่อโดรนบินออกจากศูนย์วิจัย ทั้งคู่ก็กลับมารวมตัวกันอีกครั้ง"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:122
translate english arc2_ino_quest2_f74cf9bc:

    # mn "Maldición..."
    mn "เวรเอ๊ย..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:123
translate english arc2_ino_quest2_5a306e84:

    # mn "Los Drones se están yendo, no debemos perderlos"
    mn "พวกโดรนกำลังจะไปแล้ว ห้ามให้พวกมันคลาดสายตาเด็ดขาด"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:124
translate english arc2_ino_quest2_00abc239:

    # ino "Vamos, démonos prisa"
    ino "เร็วเข้า รีบตามไปกันเถอะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:126
translate english arc2_ino_quest2_123d60c1:

    # n "Ino y [MN] siguen sigilosamente los Drones"
    n "อิโนะกับ [MN] สะกดรอยตามโดรนไปอย่างเงียบเชียบ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:160
translate english arc2_ino_quest2_51bb51f4:

    # n "Pero, mientras ambos los siguen..."
    n "แต่ทว่า ในระหว่างที่ทั้งคู่กำลังตามไปนั้น..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:174
translate english arc2_ino_quest2_ed850257:

    # n "¡Los Drones desaparecen!"
    n "พวกโดรนก็หายตัวไป!"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:181
translate english arc2_ino_quest2_09ea1403:

    # mn "¡¿Q-QUÉ?!" with vpunch
    mn "วะ-ว่าไงนะ?!" with vpunch

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:182
translate english arc2_ino_quest2_431e7e88:

    # ino "¿¿D-Desaparecieron??"
    ino "จ-จู่ๆ ก็หายไปงั้นเหรอ??"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:183
translate english arc2_ino_quest2_ae427621:

    # mn "¿A-Adónde se fueron?"
    mn "พ-พวกมันหายไปไหนกันเนี่ย?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:186
translate english arc2_ino_quest2_6a687082:

    # ino "Maldición, separémonos, tenémos que encontrar esas cosas, ¡Rápido!" with vpunch
    ino "บ้าเอ๊ย แยกย้ายกันเร็ว เราต้องหาเจ้าพวกนั้นให้เจอ รีบหน่อย!" with vpunch

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:190
translate english arc2_ino_quest2_af9c77e6:

    # n "Luego de ver como los Drones desaparecían frente a sus ojos, Ino y [MN] se separan para buscarlos rápidamente"
    n "หลังจากเห็นโดรนหายไปต่อหน้าต่อตา อิโนะและ [MN] ก็แยกย้ายกันออกค้นหาอย่างเร่งรีบ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:191
translate english arc2_ino_quest2_594f9dfe:

    # n "Pero, ya era tarde..."
    n "ทว่า... มันก็สายไปเสียแล้ว..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:200
translate english arc2_ino_quest2_45091c41:

    # ino "Maldición, de verdad desaparecieron, no los encontré por ningún lado..."
    ino "บ้าจริง หายไปอย่างไร้ร่องรอยเลย ฉันหาเท่าไหร่ก็ไม่เจอ..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:201
translate english arc2_ino_quest2_5502cecb:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:203
translate english arc2_ino_quest2_7e645d4f:

    # mnn "(Esas cosas... Desaparecieron...)"
    mnn "(เจ้าพวกนั้น... หายตัวไปงั้นเหรอ...)"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:205
translate english arc2_ino_quest2_6a3edbf8:

    # mnn "(¿O se hicieron invisibles...?)"
    mnn "(หรือว่าพวกมันใช้คาตาล่องหน...กันนะ?)"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:206
translate english arc2_ino_quest2_94a5c921:

    # mnn "(Pero, si eso es así...)"
    mnn "(แต่ถ้าเป็นแบบนั้นล่ะก็...)"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:208
translate english arc2_ino_quest2_3a8fa72a:

    # mnn "(...)"
    mnn "(...)"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:210
translate english arc2_ino_quest2_9446a0f3:

    # mnn "(Eso se parecía demasiado a mi {b}Jutsu de Invisibilidad{/a})"
    mnn "(มันดูคล้ายกับ {b}คาถาล่องหน{/a} ของฉันมากเกินไปหน่อย...)"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:212
translate english arc2_ino_quest2_10f5c581:

    # mnn "(Maldición... Esto es más grave de lo que parece...)"
    mnn "(แย่ล่ะสิ... เรื่องนี้ท่าทางจะบานปลายกว่าที่คิดซะแล้ว...)"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:215
translate english arc2_ino_quest2_aad31d8d:

    # ino "Bueno, sea lo que sea que pasó, ya no tenémos nada que hacer aquí"
    ino "ช่างเถอะ ไม่ว่าจะเกิดอะไรขึ้น พวกเราก็ทำอะไรต่อที่นี่ไม่ได้แล้วล่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:216
translate english arc2_ino_quest2_61e5e05f:

    # ino "Debémos irnos, mañana debémos informar al Hokage lo que vimos"
    ino "เรากลับกันเถอะ พรุ่งนี้ต้องไปรายงานเรื่องที่เราเห็นให้ท่านโฮคาเงะทราบด้วย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:217
translate english arc2_ino_quest2_5502cecb_1:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:218
translate english arc2_ino_quest2_32f01105:

    # ino "Oye, ¿Estás bien?"
    ino "นี่ เป็นอะไรรึเปล่า?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:220
translate english arc2_ino_quest2_1e50bb1a:

    # mn "Oh, si..."
    mn "อ๋อ เปล่า... ไม่มีอะไร..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:221
translate english arc2_ino_quest2_4518b3a6:

    # mn "Y-Ya vámonos..."
    mn "ก-กลับกันเถอะ..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:222
translate english arc2_ino_quest2_a3796ac0:

    # ino "Oye..."
    ino "นี่..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:223
translate english arc2_ino_quest2_f950cbab:

    # mn "Ah, ¿Sí?"
    mn "อ๊ะ ว่าไงนะ?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:224
translate english arc2_ino_quest2_27ac256c:

    # ino "Sea lo que sea que pasó aquí"
    ino "เรื่องที่เกิดขึ้นทั้งหมดนี่"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:225
translate english arc2_ino_quest2_0398fe59:

    # ino "No fue culpa tuya"
    ino "ไม่ใช่ความผิดของนายหรอกนะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:226
translate english arc2_ino_quest2_a245e530:

    # ino "Ninguno de los dos sabía que esa cosa iba a desaparecer frente a nuestros ojos"
    ino "ไม่มีใครรู้หรอกว่าเจ้าสิ่งนั้นจะจู่ๆ ก็หายวับไปต่อหน้าต่อตาเราแบบนั้น"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:228
translate english arc2_ino_quest2_5502cecb_2:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:230
translate english arc2_ino_quest2_a3a2306c:

    # mn "Si, tienes razón"
    mn "อืม เธอกล่าวถูกแล้วล่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:231
translate english arc2_ino_quest2_883a0fa9:

    # ino "Por ahora, debémos irnos, debémos informar esto al Hokage"
    ino "ตอนนี้เราควรกลับกันก่อน แล้วค่อยไปรายงานเรื่องนี้ให้ท่านโฮคาเงะฟัง"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:232
translate english arc2_ino_quest2_2802269f:

    # mn "Si, tienes razón, ¿Nos vemos mañana en la Oficina del Hokage?"
    mn "นั่นสินะ งั้นพรุ่งนี้เจอกันที่สำนักงานโฮคาเงะนะ?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:233
translate english arc2_ino_quest2_89b9de96:

    # ino "Ahí estaré"
    ino "อืม ฉันจะไปที่นั่น"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest2.rpy:236
translate english arc2_ino_quest2_7df4b823:

    # n "Después de lo que pasó, Ino y [MN] decidieron irse e informarle al Hokage lo que vieron el día siguiente"
    n "หลังจากเหตุการณ์นั้น อิโนะและ [MN] ก็ตัดสินใจแยกย้ายกันกลับ และเตรียมนำเรื่องที่เห็นไปรายงานต่อท่านโฮคาเงะในวันรุ่งขึ้น"
