# TODO: Translation updated at 2024-11-29 23:49

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:8
translate english arc2_tenten_quest2_11176df3:

    # mn "Bien, ya estoy aquí"
    mn "เอาล่ะ ฉันมาถึงแล้ว"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:9
translate english arc2_tenten_quest2_8e72183a:

    # mn "Parece ser que aún no llega Tenten"
    mn "ดูเหมือนว่าเท็นเท็นจะยังมาไม่ถึงแฮะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:11
translate english arc2_tenten_quest2_9c3bf6dc:

    # mn "¿Se habrá retrasado?"
    mn "เธออาจจะมาช้าหรือเปล่านะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:13
translate english arc2_tenten_quest2_07fc1352:

    # mn "Voy a escribirle a ver si contesta"
    mn "ส่งข้อความไปหาเธอหน่อยดีกว่า ว่าจะตอบกลับไหม"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:28
translate english arc2_tenten_quest2_9f279b73:

    # mn "Ya viene en camino"
    mn "เธอกำลังมาแล้วแฮะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:31
translate english arc2_tenten_quest2_e7871e58:

    # mn "¿Entonces qué hago mientras espero que venga?"
    mn "งั้นระหว่างรอเธอ ฉันควรทำอะไรดีล่ะเนี่ย?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:32
translate english arc2_tenten_quest2_d1d02aa7:

    # mn "Mmmm, ya sé, voy a ejercitarme un poco para entrar en calor"
    mn "อืม... รู้ละ ออกกำลังกายวอร์มอัพร่างกายรอหน่อยดีกว่า"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:34
translate english arc2_tenten_quest2_fb7e5aeb:

    # n "Mientras llega Tenten, [MN] se pone a hacer un poco de ejercicio"
    n "ระหว่างรอเท็นเท็น [MN] ก็เริ่มออกกำลังกายวอร์มอัพเบาๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:35
translate english arc2_tenten_quest2_40e9e3cb:

    # n "Poco después llega Tenten"
    n "หลังจากนั้นไม่นาน เท็นเท็นก็มาถึง"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:36
translate english arc2_tenten_quest2_64baba32:

    # tt "*suspiro* Ya llegué, ¿Dónde esta..."
    tt "*ถอนหายใจ* ฉันมาถึงแล้วนะ อยู่ไหนเนี่ย..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:39
translate english arc2_tenten_quest2_bc898eb4:

    # tt "¡Ah!" with vpunch
    tt "อ๊ะ!" with vpunch

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:41
translate english arc2_tenten_quest2_ffe6d547:

    # tt "(¿E-Ese es... [MN]?)"
    tt "(น-นั่นมัน... [MN] งั้นเหรอ?)"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:42
translate english arc2_tenten_quest2_fa74e050:

    # tt "(No pensé que sería tan...)"
    tt "(ไม่คิดเลยว่าเขาจะ...)"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:43
translate english arc2_tenten_quest2_1e6cfcd6:

    # tt "(Musculoso...)"
    tt "(ล่ำสันขนาดนี้...)"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:45
translate english arc2_tenten_quest2_9928dea8:

    # mn "Oh, Tenten, ya llegaste"
    mn "อ้าว เท็นเท็น มาแล้วเหรอ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:46
translate english arc2_tenten_quest2_8f7d1dbb:

    # tt "Oh si..."
    tt "อ๋อ ใช่..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:47
translate english arc2_tenten_quest2_2c2aca4f:

    # mn "Emm, ¿Tenten?"
    mn "อืม เท็นเท็น?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:48
translate english arc2_tenten_quest2_c0fdb629:

    # tt "¿Eh?, ¡Ah!"
    tt "ฮะ อ๊ะ!"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:49
translate english arc2_tenten_quest2_83975a51:

    # tt "H-Hola... Jaja"
    tt "ส-สวัสดี... ฮ่าๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:60
translate english arc2_tenten_quest2_f683ec44:

    # mn "¿Ocurre algo?"
    mn "มีอะไรหรือเปล่า?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:61
translate english arc2_tenten_quest2_3936ea72:

    # mn "Estás un poco roja, ¿Tienes fiebre?"
    mn "หน้าเธอแดงนิดหน่อยนะ เป็นไข้หรือเปล่า?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:62
translate english arc2_tenten_quest2_fd7a1c9d:

    # mn "Si es así no podemos ir de viaje"
    mn "ถ้าอย่างนั้นพวกเราคงไปเที่ยวกันไม่ได้หรอกนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:63
translate english arc2_tenten_quest2_593debf3:

    # tt "¿Qué? ¡N-No!"
    tt "หา? ป-เปล่าซะหน่อย!"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:64
translate english arc2_tenten_quest2_3e3a35b1:

    # tt "Estoy bien, es solo que me agité un poco..."
    tt "ฉันไม่เป็นไร แค่เมื่อกี้รีบเดินทางมาหน่อยน่ะ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:68
translate english arc2_tenten_quest2_bc1200a1:

    # tt "(Sin duda me agité mucho...)"
    tt "(เมื่อกี้เราตื่นเต้นสุดๆ ไปเลยต่างหาก...)"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:69
translate english arc2_tenten_quest2_ca9ab341:

    # tt "(¿Porqué por simplemente verlo sin camisa?)"
    tt "(ทำไมแค่เห็นเขาถอดเสื้อ ถึงได้...)"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:70
translate english arc2_tenten_quest2_f92132eb:

    # tt "(¿De verdad estoy tan mal?)"
    tt "(อาการเราหนักขนาดนี้เลยเหรอเนี่ย?)"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:72
translate english arc2_tenten_quest2_27792737:

    # mn "Bueno, descansa un poco antes de que nos vayamos"
    mn "งั้นพักสักหน่อยก่อนค่อยออกเดินทางกันเถอะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:76
translate english arc2_tenten_quest2_ca9a9141:

    # n "-{b}Minutos después{/a}-"
    n "-{b}ไม่กี่นาทีต่อมา{/b}-"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:84
translate english arc2_tenten_quest2_2bdf44d2:

    # mn "¿Ya estás mejor?"
    mn "รู้สึกดีขึ้นบ้างหรือยัง?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:85
translate english arc2_tenten_quest2_065aa382:

    # tt "Si, gracias por tu consideración"
    tt "อื้ม ขอบคุณที่เป็นห่วงนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:86
translate english arc2_tenten_quest2_a1ee8907:

    # tt "No estoy tan en forma como antes..."
    tt "ช่วงนี้สภาพร่างกายฉันไม่ค่อยฟิตเหมือนเมื่อก่อนแล้วล่ะ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:87
translate english arc2_tenten_quest2_384a9a8e:

    # mn "Si... Me imagino que es por la tienda"
    mn "งั้นเหรอ... คงเป็นเพราะมัวแต่ยุ่งกับร้านสินะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:89
translate english arc2_tenten_quest2_3776c758:

    # mn "Si quieres hacer ejercicio, puedes hablarme para entrenar juntos"
    mn "ถ้าเธออยากออกกำลังกายล่ะก็ มาคุยกับฉันได้นะ จะได้ฝึกซ้อมไปด้วยกัน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:90
translate english arc2_tenten_quest2_a38d4c07:

    # mn "Hago entrenamiento físico todos los días, tengo que mantenerme en forma"
    mn "ฉันฝึกร่างกายทุกวันเลยล่ะ ต้องรักษารูปร่างให้ฟิตอยู่เสมอ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:91
translate english arc2_tenten_quest2_bde878d0:

    # tt "S-Sí... Ya me he dado cuenta..."
    tt "จ-จ่ะ... ฉันสังเกตเห็นอยู่หรอก..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:92
translate english arc2_tenten_quest2_350b3518:

    # mn "Bueno, ¿Estas lista?"
    mn "งั้น พร้อมหรือยังล่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:94
translate english arc2_tenten_quest2_e05474ca:

    # tt "Si, ya podemos partir"
    tt "อื้อ ออกเดินทางกันได้เลย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:95
translate english arc2_tenten_quest2_451cf1c9:

    # mn "Bien, entonces andando"
    mn "งั้นก็ไปกันเลย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:98
translate english arc2_tenten_quest2_a20cefa7:

    # "..."
    "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:99
translate english arc2_tenten_quest2_0397bcb0:

    # "-{b}Unas horas más tarde{/a}-"
    "-{b}ไม่กี่ชั่วโมงต่อมา{/b}-"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:110
translate english arc2_tenten_quest2_1f3fa4f8:

    # tt "*jadeo* Un... Momento... Espera..."
    tt "*หอบ* ก... เกษียณ... เอ้ย พักก่อน... เดี๋ยวก่อน..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:111
translate english arc2_tenten_quest2_0562b4b9:

    # mn "¿Qué pasa?"
    mn "เป็นอะไรไปเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:112
translate english arc2_tenten_quest2_51f1c837:

    # tt "Descansemos aquí un poco... Ya llevamos un buen rato corriendo..."
    tt "พักตรงนี้กันก่อนสักหน่อยเถอะ... พวกเราวิ่งกันมาสักพักแล้วนะ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:113
translate english arc2_tenten_quest2_662a68b8:

    # mn "¿Ya estás cansada?, Pero si no hemos avanzado nada..."
    mn "เหนื่อยแล้วเหรอ? ทั้งที่เราเพิ่งจะเดินทางมาได้ไม่เท่าไหร่เองนะ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:115
translate english arc2_tenten_quest2_951f02af:

    # tt "Ejem... ¿Tengo que recordarte que no estoy en mi mejor condición física?"
    tt "แฮื่อม... ฉันต้องเตือนนายด้วยไหมเนี่ยว่าสภาพร่างกายฉันไม่ได้ฟิตที่สุดน่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:116
translate english arc2_tenten_quest2_7c3f46e5:

    # tt "De verdad que los hombres no tienen nada de tacto"
    tt "ผู้ชายนี่ไม่รู้เรื่องเอาซะเลยนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:117
translate english arc2_tenten_quest2_f1dcf2b9:

    # mn "Está bien, tomémos un descanso..."
    mn "ก็ได้ พักกันก่อนก็ได้..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:119
translate english arc2_tenten_quest2_4fdb1143:

    # tt "*suspiro* No creí estar tan mal, de verdad tengo que ejercitarme más de ahora en adelante"
    tt "*ถอนหายใจ* ไม่คิดเลยว่าตัวเองจะแย่ขนาดนี้ ต่อไปนี้คงต้องออกกำลังกายให้มากกว่านี้ซะแล้วสิ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:121
translate english arc2_tenten_quest2_52c41f8d:

    # tt "Aveces me gustaría salir de la aldea de vez en cuando, justo como ahora"
    tt "บางทีฉันก็อยากจะออกไปนอกหมู่บ้านซะบ้างเป็นครั้งคราว แบบตอนนี้เนี่ยแหละ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:122
translate english arc2_tenten_quest2_3d197d82:

    # mn "¿Porqué?"
    mn "ทำไมล่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:123
translate english arc2_tenten_quest2_0d333d3b:

    # tt "Paso todo el día encerrada en la tienda trabajando"
    tt "ฉันเอาแต่อุดอู้อยู่แต่ในร้านทำงานทั้งวันเลยน่ะสิ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:124
translate english arc2_tenten_quest2_eb5bc81d:

    # tt "Pero lo más molesto es que es un trabajo muy aburrido..."
    tt "แต่ที่น่าเบื่อที่สุดก็คือมันเป็นงานที่น่าเบื่อมากๆ เลยนี่แหละ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:125
translate english arc2_tenten_quest2_1d34cf26:

    # tt "Estar sentada en una silla esperando que alguien quiera comprar algo, hay días en los que no vendo nada"
    tt "นั่งอยู่บนเก้าอี้คอยให้คนมาซื้อของ มีบางวันที่ฉันขายของไม่ได้เลยสักชิ้นเดียวด้วยซ้ำ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:127
translate english arc2_tenten_quest2_3f280282:

    # tt "No sé que pensaba en abrir una tienda de armas en tiempos de paz..."
    tt "ไม่รู้ว่าตอนนั้นฉันคิดอะไรอยู่ถึงไปเปิดร้านขายอาวุธในยุคสมัยที่สงบสุขแบบนี้..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:128
translate english arc2_tenten_quest2_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:130
translate english arc2_tenten_quest2_c3a330bd:

    # tt "Eh, pero no me confundas, no quiero decir que pefiero la guerra..."
    tt "เฮ้ แต่ก็อย่าเข้าใจฉันผิดล่ะ ฉันไม่ได้หมายความว่าอยากให้มีสงครามนะ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:133
translate english arc2_tenten_quest2_16609a1a:

    # mn "No, no pensé eso jaja"
    mn "เปล่าสักหน่อย ฉันไม่ได้คิดแบบนั้นหรอก ฮ่าๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:135
translate english arc2_tenten_quest2_9110f49f:

    # mn "Pero... Es gracias a tí que los ninjas nuevos tienen equipamiento ninja"
    mn "แต่อย่างน้อย... ก็เพราะเธอไม่ใช่เหรอที่ทำให้เหล่านินจารุ่นใหม่มีอุปกรณ์นินจาใช้กัน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:139
translate english arc2_tenten_quest2_85ece14e:

    # tt "Aunque yo no estuviera siempre hay una manera de conseguir equipamiento, más ahora con la nueva tecnología"
    tt "ต่อให้ไม่มีฉัน มันก็ยังมีวิธีหาอุปกรณ์อยู่วันยังค่ำแหละน่า โดยเฉพาะตอนนี้ที่มีเทคโนโลยีใหม่ๆ ด้วยแล้วเนี่ย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:141
translate english arc2_tenten_quest2_19176924:

    # tt "*suspiro* Creo que voy a cambiar de trabajo..."
    tt "*ถอนหายใจ* ฉันชักอยากจะเปลี่ยนงานซะแล้วสิ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:143
translate english arc2_tenten_quest2_6e2f45db:

    # mn "Bueno, puede que la nueva tecnología sea mejor"
    mn "งั้นเหรอ บางทีเทคโนโลยีใหม่อาจจะดีกว่าก็ได้นะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:145
translate english arc2_tenten_quest2_c592cd12:

    # tt "¿Esa es tu manera de darme ánimos? Si es así mejor déjame estar..."
    tt "นั่นกําลังปลอบใจฉันอยู่หรือไงยะ? ถ้าอย่างงั้นก็เงียบไปเลยดีกว่า..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:147
translate english arc2_tenten_quest2_f2eaef5a:

    # mn "Pero... Yo aún así prefiero las herramientas de siempre"
    mn "แต่... ฉันยังชอบเครื่องมือแบบดั้งเดิมมากกว่านะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:149
translate english arc2_tenten_quest2_19a92104:

    # mn "Antes de que me hicieras esta espada había comprado muchas herramientas con la nueva tecnología"
    mn "ก่อนที่เธอจะทำดาบเล่มนี้ให้ฉัน ฉันเคยซื้อเครื่องมือเทคโนโลยีใหม่ๆ มาตั้งเยอะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:151
translate english arc2_tenten_quest2_73ae35cb:

    # mn "Pero ninguna soportó más de tres golpes de Yuna, ni una"
    mn "แต่ไม่มีอันไหนรับมือการโจมตีสามครั้งจากยูนะได้เลยสักอันเดียว ไม่มีเลยสักอัน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:154
translate english arc2_tenten_quest2_e62b771c:

    # mn "No fue hasta que tú me hiciste esta espada que le pude dar pelea"
    mn "จนกระทั่งเธอทำดาบเล่มนี้ให้ ฉันถึงได้เริ่มสู้กลับได้บ้าง"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:155
translate english arc2_tenten_quest2_8cc1b188:

    # mn "Así que, al menos la espada que TÚ me hiciste es mejor que todas esas armas con la supuesta mejor tecnología"
    mn "งั้นก็หมายความว่า... อย่างน้อยดาบที่เธอทำให้ฉัน ก็ดีกว่าอาวุธพวกนั้นที่อวดอ้างว่าใช้เทคโนโลยีที่ดีกว่าเยอะเลย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:157
translate english arc2_tenten_quest2_8110b4bd:

    # tt "..."
    tt "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:159
translate english arc2_tenten_quest2_bed3b4b2:

    # tt "Bueno... Supongo que no está tan mal..."
    tt "งั้นเหรอ... ฉันเดาว่ามันก็คงไม่ได้แย่ขนาดนั้นสินะ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:160
translate english arc2_tenten_quest2_f0e12755:

    # mn "De verdad te agradezco que me hicieras esta espada, ha estado conmigo desde que comencé con esto de ser Ninja"
    mn "ฉันซาบซึ้งใจจริงๆ ที่เธอทำดาบเล่มนี้ให้ มันอยู่กับฉันมาตั้งแต่เริ่มเป็นนินจาแล้วล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:162
translate english arc2_tenten_quest2_35698ea0:

    # mn "Incluso me siento mal por dejarla a un lado..."
    mn "บางทีฉันก็รู้สึกผิดเหมือนกันนะที่จะทิ้งมันไว้เฉยๆ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:165
translate english arc2_tenten_quest2_8110b4bd_1:

    # tt "..."
    tt "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:168
translate english arc2_tenten_quest2_c0861478:

    # tt "Aún puedes tenerla de recuerdo"
    tt "นายจะเก็บมันไว้เป็นที่ระลึกก็ได้นะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:169
translate english arc2_tenten_quest2_17a5c455:

    # tt "Puedes colgarla en tu habitación para para recordar que soy la mejor herrera de la aldea de la hoja"
    tt "นายจะเอาไปแขวนไว้ในห้อง เพื่อเตือนใจว่าฉันคือช่างตีเหล็กที่เก่งที่สุดในหมู่บ้านโคโนฮะก็ได้นะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:170
translate english arc2_tenten_quest2_ebf6b108:

    # mn "Oh, es una gran idea jaja"
    mn "โอ้ นั่นเป็นความคิดที่ดีเลยนะ ฮ่าๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:173
translate english arc2_tenten_quest2_d701fb3a:

    # d "Vaya vaya... Pero qué tenemos aquí"
    d "แหมๆ... เรามีอะไรน่าสนใจตรงนี้กันนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:183
translate english arc2_tenten_quest2_0a74cb89:

    # mn "¡¿Quién anda ahí?!" with vpunch
    mn "ใครน่ะ?!" with vpunch

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:191
translate english arc2_tenten_quest2_3dee3dd7:

    # d "Basta, basta, no se exalten..."
    d "เดี๋ยวๆ ใจเย็นน่า อย่าเพิ่งตื่นตูมสิ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:192
translate english arc2_tenten_quest2_06ed1696:

    # d "¿Acaso no ven que vengo a saludar?"
    d "ไม่เห็นเหรอว่าฉันมาทักทายเฉยๆ เนี่ย?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:193
translate english arc2_tenten_quest2_cd79b345:

    # d "Es raro ver personas nuevas cerca de... Nuestro territorio"
    d "นานๆ ทีจะมีคนหน้าใหม่มาแถว... อาณาเขตของเรา"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:194
translate english arc2_tenten_quest2_b7a2b0e7:

    # d "Conozco muy bien la zona, ¿Necesitan ayuda con su equipaje?"
    d "ฉันรู้จักแถวนี้ดีเชียวล่ะ ให้ช่วยถือสัมภาระไหม?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:195
translate english arc2_tenten_quest2_1642c19a:

    # mn "No gracias... Podémos solos"
    mn "ไม่ล่ะ ขอบใจ... พวกเราจัดการเองได้"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:196
translate english arc2_tenten_quest2_4de56d1c:

    # d "¿En serio?, la señorita parece cansada, ¿Y tú dejas que lleve el equipaje pesado?"
    d "จริงเหรอ? แม่นางดูท่าทางเหนื่อยนะ แล้วนายปล่อยให้เธอแบกสัมภาระหนักๆ แบบนั้นเนี่ยนะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:197
translate english arc2_tenten_quest2_0f4b89de:

    # d "¿Porqué no eres un poco más hombre y la ayudas a llevarla?"
    d "ทำตัวให้สมเป็นลูกผู้ชายหน่อย แล้วช่วยเธอถือหน่อยสิ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:198
translate english arc2_tenten_quest2_6d12c6ab:

    # d "Vamos señorita... Déjeme ayudarle con el equi..."
    d "มานี่เถอะแม่นาง... เดี๋ยวฉันช่วยเธอบกสัมภาระ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:200
translate english arc2_tenten_quest2_8798322f:

    # tt "Yo no soy ninguna inútil, puedo con esto yo sola"
    tt "ฉันไม่ได้ไร้นะ ฉันจัดการเองได้"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:201
translate english arc2_tenten_quest2_a0442333:

    # tt "Además, esas no son tus intenciones, tú lo que quieres es robarnos, ya he esuchado de unos bandido que le roban a las personas por esta zona"
    tt "อีกอย่าง แกไม่ได้มีเจตนาดีหรอก แกจะปล้นพวกเราต่างหาก ฉันเคยได้ยินเรื่องพวกโจรที่คอยดักปล้นคนแถวนี้มาบ้างแล้วนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:202
translate english arc2_tenten_quest2_1523fe20:

    # d "..."
    d "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:203
translate english arc2_tenten_quest2_4f1e8574:

    # d "Entonces ya nos conoces..."
    d "งั้นก็รู้จักพวกเราแล้วสินะ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:204
translate english arc2_tenten_quest2_e6ba338d:

    # d "¿Saben? No me gusta la violencia"
    d "รู้ไหม? ฉันไม่ค่อยชอบความรุนแรงหรอกนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:205
translate english arc2_tenten_quest2_33207fa2:

    # d "Si no quieren salir heridos les aconsejo que me dén su equipaje y los dejaré tranquilos"
    d "ถ้าไม่อยากเจ็บตัว ฉันแนะนำให้ส่งสัมภาระมาซะแล้วฉันจะปล่อยพวกแกไป"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:207
translate english arc2_tenten_quest2_c9ff8836:

    # mn "Vaya, qué considerado"
    mn "โอ้โห ช่างมีน้ำใจจริงๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:208
translate english arc2_tenten_quest2_ceaa94df:

    # mn "¿Sabes?, A veces la violencia nunca está de más"
    mn "รู้ไหม? บางทีความรุนแรงเนี่ยมันก็ไม่ได้แย่เสมอไปหรอกนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:209
translate english arc2_tenten_quest2_104d9374:

    # mn "Si quieres nuestro equipo tendrás que matarme primero"
    mn "ถ้าแกอยากได้อุปกรณ์ของพวกเรานัก ก็ต้องข้ามศพฉันไปก่อนล่ะวะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:210
translate english arc2_tenten_quest2_c5014359:

    # tt "O-Oye [MN], ¿No crees que es mejor huir?"
    tt "เ-เดี๋ยวสิ [MN] เธอว่าเราหนีไปก่อนดีกว่าไหม?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:211
translate english arc2_tenten_quest2_008cdd69:

    # tt "Parece alguien bastante fuerte..."
    tt "หมอนั่นดูท่าทางเก่งไม่ใช่เล่นเลยนะ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:212
translate english arc2_tenten_quest2_b84ef07d:

    # mn "No te preocupes, este tipo no es nada contra mí"
    mn "ไม่ต้องห่วง หมอนั่นสู้ฉันไม่ได้หรอก"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:213
translate english arc2_tenten_quest2_9172831d:

    # mn "Yo te protegeré Tenten, así que no te preocupes por mí"
    mn "เดี๋ยวฉันปกป้องเธอเอง เท็นเท็น เพราะงั้นไม่ต้องห่วงฉันหรอก"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:215
translate english arc2_tenten_quest2_385dbc00:

    # mn "No soy un simple Ninja, este no es nadie comparado con Zubon-Sensei"
    mn "ฉันไม่ใช่แค่นินจาไก่กาหรอกนะ หมอนั่นเทียบกับอาจารย์ซูบงไม่ติดหรอก"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:217
translate english arc2_tenten_quest2_e26c1f7e:

    # d "Muy bien, entonces que así sea"
    d "ดี งั้นก็ตามใจแก"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:227
translate english arc2_tenten_quest2_before_battle_6eb3df4c:

    # "[MN] se prepara para la batalla"
    "[MN] เตรียมพร้อมเข้าต่อสู้"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:243
translate english arc2_tenten_quest2_after_battle_1912702e:

    # d "Tch..."
    d "ชิ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:253
translate english arc2_tenten_quest2_after_battle_12f67f21:

    # d "Maldita sea..."
    d "เว้ยเอ๊ย..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:254
translate english arc2_tenten_quest2_after_battle_d57d519c:

    # d "Muy bien, por esta vez ganas, pero no los quiero volver a ver por aquí"
    d "เออ แกชนะไปรอบนี้ แต่ไม่อยากเห็นหน้าพวกแกแถวนี้อีกนะเว้ย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:255
translate english arc2_tenten_quest2_after_battle_b8ea12d3:

    # d "Si no, no seré el único con el que debas luchar"
    d "ไม่งั้นล่ะก็ แกไม่ได้สู้กับแค่ฉันคนเดียวแน่"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:256
translate english arc2_tenten_quest2_after_battle_f5c4e99d:

    # mn "Si claro, mejor vete ahora antes que te patee el trasero de nuevo"
    mn "พูดมากน่า รีบไสหัวไปก่อนที่ฉันจะอัดแกอีกรอบดีกว่า"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:257
translate english arc2_tenten_quest2_after_battle_8213d122:

    # d "Hijo de..."
    d "ไอ้เวรเอ๊ย..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:262
translate english arc2_tenten_quest2_after_battle_ab86a236:

    # n "El bandido se va, dejando en paz a [MN] y Tenten"
    n "โจรหนีไปแล้ว ปล่อยให้ [MN] และเท็นเท็นอยู่กันอย่างสงบ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:268
translate english arc2_tenten_quest2_after_battle_6676c755:

    # tt "¡[MN]! ¿Estás herido?, Déjame revisarte"
    tt "[MN]! เจ็บตรงไหนไหม? ขอฉันตรวจดูหน่อยสิ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:269
translate english arc2_tenten_quest2_after_battle_65234f6a:

    # mn "Oh, estoy bien Tenten, no te preocupes"
    mn "โธ่ ฉันไม่เป็นไรหรอก เท็นเท็น ไม่ต้องห่วง"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:270
translate english arc2_tenten_quest2_after_battle_97886b93:

    # mn "Ese tipo no fue nada, de verdad"
    mn "หมอนั่นกระจอกจะตาย จริงๆ นะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:271
translate english arc2_tenten_quest2_after_battle_0319b6f6:

    # tt "¿S-Seguro? En mi equipaje traigo medicamento por si..."
    tt "จ-จิงเหรอ? เผื่อฉุกเฉินฉันมียาอยู่ในกระเป๋านะ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:274
translate english arc2_tenten_quest2_after_battle_bd2c1762:

    # mn "Tenten, ¿De verdad me creías un debilucho?"
    mn "เท็นเท็น เธอนึกว่าฉันอ่อนแอขนาดนั้นเลยเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:276
translate english arc2_tenten_quest2_after_battle_d0525d4d:

    # mn "De verdad no me hizo nada, estoy perfectamente bien"
    mn "หมอนั่นทำอะไรฉันไม่ได้หรอก ฉันสบายดีร้อยเปอร์เซ็นต์"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:277
translate english arc2_tenten_quest2_after_battle_c09f06df:

    # tt "¿E-En serio?"
    tt "จ-จริงเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:278
translate english arc2_tenten_quest2_after_battle_1c3634b1:

    # tt "Bueno, entonces está bien..."
    tt "งั้นก็ไม่เป็นไรแล้วสินะ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:279
translate english arc2_tenten_quest2_after_battle_5bcac875:

    # mn "Descansemos un poco más y sigamos con nuestro viaje"
    mn "พักอีกสักหน่อยแล้วค่อยเดินทางกันต่อเถอะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:280
translate english arc2_tenten_quest2_after_battle_2c0b7243:

    # mn "¿Qué tal si vamos caminando? Para disfrutar el paisaje"
    mn "เราเดินเท้ากันดีไหม? จะได้ชมวิวทิวทัศน์ไปด้วย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:282
translate english arc2_tenten_quest2_after_battle_bb0406b0:

    # tt "Si, me parece bien..."
    tt "อื้ม ฟังดูเข้าท่านะ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:284
translate english arc2_tenten_quest2_after_battle_8110b4bd:

    # tt "..."
    tt "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:286
translate english arc2_tenten_quest2_after_battle_c40bdfd5:

    # tt "Oye, ¿De verdad eres de rango Genin?"
    tt "นี่ เธอเป็นเกะนินจริงๆ เหรอเนี่ย?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:287
translate english arc2_tenten_quest2_after_battle_6572e08c:

    # mn "Si, ¿Porqué lo preguntas?"
    mn "ใช่สิ ทำไมถึงถามอย่างนั้นล่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:288
translate english arc2_tenten_quest2_after_battle_04eedcce:

    # tt "Es que, no luchas como un ninja de rango Genin"
    tt "ก็แค่... สไตล์การต่อสู้ของเธอไม่เหมือนนินจาระดับเกะนินเลยนี่นา"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:289
translate english arc2_tenten_quest2_after_battle_c8512f43:

    # tt "¿Porqué Zubon no los había registrado antes a los exámenes Chunin?"
    tt "ทำไมอาจารย์ซูบงถึงไม่เคยส่งชื่อเธอสอบจูนินมาก่อนเลยล่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:291
translate english arc2_tenten_quest2_after_battle_14a35fda:

    # mn "Ah... Es una buena historia jaja"
    mn "อ่า... เรื่องมันยาวน่ะ ฮ่าๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:293
translate english arc2_tenten_quest2_after_battle_4883960d:

    # mn "Pues, hasta ahora ninguno era capaz de trabajar en equipo"
    mn "ก็คือ... จนถึงตอนนี้พวกเราไม่มีใครทำงานเป็นทีมได้เลยน่ะสิ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:294
translate english arc2_tenten_quest2_after_battle_9b9f9131:

    # mn "Yuna es... Bastante ruda y le gusta luchar sola"
    mn "ยูนะน่ะ... ค่อนข้างดื้อรั้นแล้วก็ชอบลุยเดี่ยวด้วย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:295
translate english arc2_tenten_quest2_after_battle_9670d757:

    # mn "Hideo hasta ahora no podía hacer mucho, solamente hacía de soporte"
    mn "ส่วนฮิเดโอะก็ยังทำอะไรมากไม่ได้จนถึงตอนนี้ ทำได้แค่คอยสนับสนุนน่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:296
translate english arc2_tenten_quest2_after_battle_1f5eb7a6:

    # mn "Y yo pues... Peleaba con Yuna cuando teníamos que luchar juntos"
    mn "แล้วก็ฉัน... ฉันมักจะสู้ร่วมกับยูนะเวลาที่จำเป็นต้องสู้ด้วยกัน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:297
translate english arc2_tenten_quest2_after_battle_2ba826c8:

    # mn "No había trabajo en equipo"
    mn "มันเลยไม่มีความเป็นทีมเอาซะเลย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:300
translate english arc2_tenten_quest2_after_battle_8110b4bd_1:

    # tt "..."
    tt "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:302
translate english arc2_tenten_quest2_after_battle_e7ee4b1b:

    # tt "Ya entiendo todo... ¿Y hasta ahora son capaces de luchar en equipo?"
    tt "งั้นเหรอนี่... แล้วตอนนี้พวกเธอทำงานเป็นทีมกันได้แล้วเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:304
translate english arc2_tenten_quest2_after_battle_0235eda3:

    # mn "Si jaja..."
    mn "อื้ม ฮ่าๆ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:306
translate english arc2_tenten_quest2_after_battle_c693fc0c:

    # mn "Por eso Zubon-Sensei nos aprobó este año"
    mn "นั่นแหละเหตุผลที่อาจารย์ซูบงถึงยอมอนุมัติให้พวกเราในปีนี้ไงล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:309
translate english arc2_tenten_quest2_after_battle_42ace11b:

    # tt "Entiendo"
    tt "เข้าใจแล้วล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:310
translate english arc2_tenten_quest2_after_battle_ec70104e:

    # mn "Bueno, ¿Nos vamos ya? Es mejor que nos vayamos antes de que ese tipo vuelva"
    mn "งั้นไปกันเถอะ? รีบไปก่อนที่หมอนั่นจะกลับมาน่าจะดีกว่านะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:312
translate english arc2_tenten_quest2_after_battle_15b2cd8e:

    # tt "Si, ya vámonos"
    tt "อื้ม ไปกันเถอะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:315
translate english arc2_tenten_quest2_after_battle_e6329860:

    # tt "¡Vámonos pues!" with vpunch
    tt "งั้นก็ไปกันเลย!" with vpunch

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:316
translate english arc2_tenten_quest2_after_battle_20d6dbcc:

    # mn "Eh, ¿Qué haces?"
    mn "นี่ เธอทำอะไรน่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:317
translate english arc2_tenten_quest2_after_battle_80e54e73:

    # tt "¿No nos irémos caminando?"
    tt "ไหนว่าจะเดินเท้ากันไม่ใช่เหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:318
translate english arc2_tenten_quest2_after_battle_a3974470:

    # tt "Solo tomo tu brazo para ir protegida"
    tt "ฉันก็แค่เกาะแขนเธอไว้ จะได้รู้สึกอุ่นใจขึ้นไงล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:319
translate english arc2_tenten_quest2_after_battle_45ef6f58:

    # tt "¿Te molesta?"
    tt "รำคาญเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:320
translate english arc2_tenten_quest2_after_battle_c0016856:

    # mn "No, no realmente... Pero si es un poco repentino"
    mn "เปล่า, ไม่เชิงหรอก... แค่มันกะทันหันไปหน่อยน่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:321
translate english arc2_tenten_quest2_after_battle_a6462580:

    # tt "¿Entonces no quieres que una linda chica te tome del brazo?"
    tt "งั้นเหรอ หรือว่าไม่อยากให้สาวน่ารักมาเกาะแขนกันแน่ล่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:322
translate english arc2_tenten_quest2_after_battle_7ed6af99:

    # mn "N-No quise decir eso..."
    mn "ป-เปล่า ฉันไม่ได้หมายความว่าอย่างนั้นซะหน่อย..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:323
translate english arc2_tenten_quest2_after_battle_386183fd:

    # tt "Pues sigamos nuestro camino jeje"
    tt "งั้นก็เดินทางกันต่อเถอะ แหะๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:324
translate english arc2_tenten_quest2_after_battle_8709c993:

    # tt "Tú mismo lo dijiste"
    tt "เธอก็เป็นคนพูดเองแท้ๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:325
translate english arc2_tenten_quest2_after_battle_df187995:

    # tt "{b}Yo te protegeré Tenten, así que no te preocupes por mí{/a}"
    tt "{b}ฉันจะปกป้องเธอเอง เท็นเท็น เพราะงั้นไม่ต้องห่วงฉันหรอก{/b}"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:326
translate english arc2_tenten_quest2_after_battle_b032b80a:

    # tt "Palabras textuales tuyas jajaja"
    tt "คำพูดเป๊ะๆ ของเธอเลย ฮ่าๆๆๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:329
translate english arc2_tenten_quest2_after_battle_c86346e5:

    # n "Luego de luchar contra el bandido, [MN] y Tenten continúan su viaje"
    n "หลังจากจัดการกับโจรแล้ว [MN] และเท็นเท็นก็เดินทางกันต่อ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:330
translate english arc2_tenten_quest2_after_battle_45fee516:

    # n "Hasta que llega la noche..."
    n "จนกระทั่งตกดึก..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:343
translate english arc2_tenten_quest2_after_battle_885a5f68:

    # mn "Rayos... Estoy hambriento..."
    mn "เวรเอ๊ย... หิวชะมัด..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:345
translate english arc2_tenten_quest2_after_battle_30292b4d:

    # mn "¿Qué tal si nos tomamos un descanso para comer?"
    mn "เราแวะพักกินอะไรกันหน่อยดีไหม?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:347
translate english arc2_tenten_quest2_after_battle_14ea6a50:

    # tt "Si, yo también tengo hambre"
    tt "อื้ม ฉันก็หิวเหมือนกัน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:348
translate english arc2_tenten_quest2_after_battle_30201c65:

    # mn "Bien, entonces haré una hoguera para que descansemos"
    mn "งั้นเดี๋ยวฉันก่อกองไฟไว้ เราจะได้พักผ่อนกัน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:351
translate english arc2_tenten_quest2_after_battle_cc463d2d:

    # n "[MN] se adentra un poco en el bosque y consigue una ramas para hacer una hoguera, para luego regresa con Tenten"
    n "[MN]เดินเข้าป่าไปสักพักเพื่อเก็บกิ่งไม้มาทำกองไฟ แล้วก็กลับมาหาเท็นเท็น"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:352
translate english arc2_tenten_quest2_after_battle_9aecf3c9:

    # n "Con la hoguera lista ambos ya están listos para descansar"
    n "เมื่อกองไฟพร้อมแล้ว ทั้งคู่ก็พร้อมสำหรับการพักผ่อน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:357
translate english arc2_tenten_quest2_after_battle_802a0031:

    # tt "¿Sabes? Desde hace rato te he querido pedir perdón"
    tt "รู้ไหม? ฉันอยากจะขอโทษเธอมาสักพักแล้วล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:358
translate english arc2_tenten_quest2_after_battle_5ccf2889:

    # mn "¿Porqué? No has hecho nada malo"
    mn "เรื่องอะไรเหรอ? เธอก็ไม่ได้ทำอะไรผิดนี่"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:359
translate english arc2_tenten_quest2_after_battle_d531d2d2:

    # tt "Es por lo que pasó con el Bandido de antes, yo realmente te subestimé solo por ser rango Genin"
    tt "ก็เรื่องที่เกิดขึ้นกับโจรเมื่อกี้ไง ฉันดันไปดูถูกเธอซะสนิทเลยเพราะเห็นว่าเป็นแค่เกะนิน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:360
translate english arc2_tenten_quest2_after_battle_27885748:

    # tt "Realmente no creí que fueras tan fuerte, de verdad lo siento"
    tt "ไม่คิดเลยว่าเธอจะเก่งขนาดนั้น ฉันขอโทษจริงๆ นะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:361
translate english arc2_tenten_quest2_after_battle_d0f53c9d:

    # mn "Aah, no te preocupes, no es la primera vez que me pasa algo así"
    mn "อ๋อ ไม่ต้องคิดมากหรอก นี่ไม่ใช่ครั้งแรกหรอกที่มีเรื่องแบบนี้เกิดขึ้นกับฉัน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:362
translate english arc2_tenten_quest2_after_battle_4797b4ec:

    # mn "Las personas se dejan llevar por mi rango, pero eso no quiere decir que sea débil"
    mn "คนอื่นมักจะตัดสินฉันจากขั้นของนินจา แต่ไม่ได้หมายความว่าฉันอ่อนแอสักหน่อย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:363
translate english arc2_tenten_quest2_after_battle_7276a113:

    # mn "He estado entrenando con Zubon-Sensei durante años, así que mi fuerza individual no es un problema"
    mn "ฉันฝึกฝนกับอาจารย์ซูบงมาหลายปีแล้ว เรื่องความแข็งแกร่งส่วนตัวเลยไม่ใช่ปัญหาเลย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:364
translate english arc2_tenten_quest2_after_battle_092e11d1:

    # mn "Todo lo que sé se lo debo a él, es un buen maestro"
    mn "ทุกสิ่งที่ฉันรู้ฉันก็ได้มาจากเขานั่นแหละ เขาเป็นครูที่ดีคนหนึ่งเลยล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:365
translate english arc2_tenten_quest2_after_battle_43542c5b:

    # mn "Aunque eso no justifica su comportamiento..."
    mn "แม้ว่าเรื่องนั้นจะไม่ใช่ข้อแก้ตัวสำหรับนิสัยของเขาก็เถอะ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:366
translate english arc2_tenten_quest2_after_battle_fb2eb100:

    # tt "Si... De verdad es un patán..."
    tt "นั่นส... ตาบ้านั่นโคตรแย่เลย..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:367
translate english arc2_tenten_quest2_after_battle_1a41fc7c:

    # tt "Pero es un alivio que pueda enseñar bien"
    tt "แต่อย่างน้อยเขาก็สอนเก่งล่ะนะ โล่งอกไปที"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:368
translate english arc2_tenten_quest2_after_battle_d95d3cb0:

    # tt "Viendo lo fuerte que eres, seguro pasarás los exámenes Chunin"
    tt "ดูจากความแข็งแกร่งของเธอแล้ว รอบนี้สอบจูนินผ่านฉลุยแน่ๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:369
translate english arc2_tenten_quest2_after_battle_7ffd6a65:

    # mn "¿Tu crees? Jaja"
    mn "คิดงั้นเหรอ? ฮ่าๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:370
translate english arc2_tenten_quest2_after_battle_af4da245:

    # tt "¿Si lo creo? Es que ya verás que así será"
    tt "ถามว่าคิดงั้นเหรอ? คอยดูเถอะ มันต้องเป็นแบบนั้นแน่"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:371
translate english arc2_tenten_quest2_after_battle_fcd57ebf:

    # tt "Más ahora que tendrás un mejor equipo ninja"
    tt "โดยเฉพาะตอนนี้ที่เธอจะได้อยู่ทีมินจาที่ดีขึ้นด้วยแล้ว"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:372
translate english arc2_tenten_quest2_after_battle_13420087:

    # tt "Ya verás que esta espada será mucho mejor, usaré todo lo que he aprendido en estos años y superaré mis límites"
    tt "คอยดูเถอะ ฉันจะใช้ดาบเล่มนี้ให้ดีขึ้นกว่าเดิม จะงัดทุกสิ่งที่เรียนมาตลอดหลายปีออกใช้ แล้วก้าวข้ามขีดจำกัดของตัวเองให้ดู"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:373
translate english arc2_tenten_quest2_after_battle_757776f2:

    # mn "De verdad te lo agradezco Tenten, gracias a tí tendré más oportunidad de superar los exámenes"
    mn "ขอบคุณจริงๆ นะเท็นเท็น เพราะเธอเลยทำให้ฉันมีโอกาสสอบผ่านมากขึ้นแท้ๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:374
translate english arc2_tenten_quest2_after_battle_91ada698:

    # mn "Te juro que en nombre de esta espada que los pasaré"
    mn "ฉันขอเอาเกียรติของดาบเล่มนี้เป็นเดิมพันเลยว่า จะสอบให้ผ่านให้ได้"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:375
translate english arc2_tenten_quest2_after_battle_e70c7502:

    # tt "¡Así se habla!"
    tt "งั้นสิ ถึงจะสมเป็นเธอ!"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:379
translate english arc2_tenten_quest2_after_battle_3c963e27:

    # n "Mientras Tenten y [MN] charlaban, de pronto comenzó a llover"
    n "ในระหว่างที่เท็นเท็นและ [MN] กำลังคุยกันอยู่ จู่ๆ ฝนก็ตกลงมา"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:380
translate english arc2_tenten_quest2_after_battle_93efb358:

    # mn "¿E-Está lloviendo?"
    mn "ฝ-ฝนตกเหรอเนี่ย?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:381
translate english arc2_tenten_quest2_after_battle_3efc6f70:

    # mn "Maldición, ¡La hoguera!"
    mn "เวรละ กองไฟ!"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:382
translate english arc2_tenten_quest2_after_battle_8fbedc42:

    # tt "Rápido, toma tus cosas, hay una cueva por aquí cerca donde podemos refugiarnos"
    tt "เร็วเข้า เก็บของสะ แถวนี้มีถ้ำอยู่ เดี๋ยวเราไปหลบฝนกันก่อน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:384
translate english arc2_tenten_quest2_after_battle_8d0bbf1e:

    # n "Rápidamente, [MN] y Tenten salieron corriendo debido a la lluvia"
    n "[MN] และเท็นเท็นรีบวิ่งหนีฝนกันอย่างรวดเร็ว"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:385
translate english arc2_tenten_quest2_after_battle_87b636fa:

    # n "Y gracias a que Tenten ya conocía la zona, ella sabía de una cueva cercana"
    n "และด้วยความที่เท็นเท็นคุ้นเคยกับแถบนี้ดี เธอจึงรู้ว่ามีถ้ำอยู่ไม่ไกล"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:386
translate english arc2_tenten_quest2_after_battle_50620891:

    # n "Así que ambos se dirigieron hacia ahí para resguardarse de la lluvia"
    n "ทั้งคู่จึงมุ่งหน้าไปที่นั่นเพื่อหลบฝน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:398
translate english arc2_tenten_quest2_after_battle_d324ac10:

    # tt "Maldición, tenía que llover ahora"
    tt "ให้ตายสิ ทำไมต้องมาตกตอนนี้ด้วยนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:399
translate english arc2_tenten_quest2_after_battle_390f773f:

    # tt "¿Porqué de repente comenzó a llover?"
    tt "จู่ๆ ฝนก็ตกลงมาได้ยังไงเนี่ย?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:400
translate english arc2_tenten_quest2_after_battle_94a64c7e:

    # mn "No lo sé, el cielo estaba completamente despejado, no parecía que iba a llover"
    mn "ไม่รู้เหมือนกัน ท้องฟ้าโปร่งโล่งออกจะตาย ไม่เห็นมีทีท่าว่าฝนจะตกเลย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:401
translate english arc2_tenten_quest2_after_battle_ca93bcf0:

    # tt "Maldición, y está haciendo frío..."
    tt "ให้ตายสิ แถมเริ่มหนาวแล้วด้วย..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:402
translate english arc2_tenten_quest2_after_battle_8bbcb526:

    # tt "Iré a explorar la cueva para asegurarme de que es segura"
    tt "งั้นเดี๋ยวฉันไปสำรวจข้างในถ้ำดูก่อนนะ ว่าปลอดภัยไหม"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:403
translate english arc2_tenten_quest2_after_battle_ce8f4682:

    # mn "Claro, yo pondré una hoguera aquí"
    mn "ได้เลย เดี๋ยวฉันก่อกองไฟตรงนี้เอง"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:404
translate english arc2_tenten_quest2_after_battle_c7c279db:

    # mn "Veré que podémos hacer para entrar en calor"
    mn "เดี๋ยวมาดูกันว่าเราจะทำให้อุ่นขึ้นยังไงได้บ้าง"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:407
translate english arc2_tenten_quest2_after_battle_f3dfc802:

    # n "[MN] busca ramas por la zona y monta una hoguera"
    n "[MN] เดินหาเศษกิ่งไม้แถวนั้นแล้วก่อกองไฟขึ้นมา"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:408
translate english arc2_tenten_quest2_after_battle_686347ba:

    # n "Luego Tenten regresa de revisar la cueva"
    n "จากนั้นเท็นเท็นก็กลับมาจากการสำรวจถ้ำ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:421
translate english arc2_tenten_quest2_after_battle_aacdf4d5:

    # tt "Ya volví, la cueva es..."
    tt "ฉันกลับมาแล้ว ในถ้ำนี่..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:428
translate english arc2_tenten_quest2_after_battle_b2a0ffea:

    # tt "¡Aaah!" with vpunch
    tt "กรี๊ด!" with vpunch

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:436
translate english arc2_tenten_quest2_after_battle_4508ec1d:

    # mn "¡AAH!" with hpunch
    mn "เหวอ!" with hpunch

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:439
translate english arc2_tenten_quest2_after_battle_0ba31ef3:

    # mn "N-No grites tan de repente..."
    mn "จ-จะตกใจอะไรเล่า อยู่ดีๆ ก็ร้องซะเสียงหลง..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:441
translate english arc2_tenten_quest2_after_battle_f306cf90:

    # tt "¿P-Porqué estas en ropa interior?"
    tt "ท-ทำไมถึงมาแก้ผ้าเหลือแต่ชุดชั้นในล่ะเนี่ย?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:443
translate english arc2_tenten_quest2_after_battle_97b11652:

    # mn "Aah, esto..."
    mn "อ่า คือว่า..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:446
translate english arc2_tenten_quest2_after_battle_296a6e58:

    # mn "Mi ropa está mojada, no puedo usarla así porque es malo para la salud, me puedo enfermar"
    mn "เสื้อผ้าฉันมันเปียกน่ะ ขืนใส่แบบนี้ต่อไปไม่ดีต่อสุขภาพ เดี๋ยวจะไม่สบายเอา"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:447
translate english arc2_tenten_quest2_after_battle_54b1e638:

    # mn "Sakura me lo dijo una vez"
    mn "ซากุระเคยบอกฉันไว้น่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:448
translate english arc2_tenten_quest2_after_battle_ef47914d:

    # tt "Y-Ya veo..."
    tt "อ-อย่างงั้นเองเหรอ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:450
translate english arc2_tenten_quest2_after_battle_46ac559a:

    # mn "Creo que también deberías quitártela, también estás mojada"
    mn "ฉันว่าเธอเองก็ควรอดเสื้อผ้าออกเหมือนกันนะ เธอก็เปียกฝนเหมือนกันนี่"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:451
translate english arc2_tenten_quest2_after_battle_525e80c1:

    # mn "Puedes ponerla cerca de la hoguera para que se seque, ya mañana nos la volvemos a poner seca"
    mn "เอาไปตากไว้ใกล้กองไฟสิ พรุ่งนี้ค่อยใส่ตอนที่มันแห้งแล้ว"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:453
translate english arc2_tenten_quest2_after_battle_8110b4bd_2:

    # tt "..."
    tt "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:455
translate english arc2_tenten_quest2_after_battle_62e8fb65:

    # tt "¿D-De verdad tengo que hacerlo?"
    tt "จ-ต้องทำขนาดนั้นเลยเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:456
translate english arc2_tenten_quest2_after_battle_20c41271:

    # mn "¿Quieres enfermarte? El viaje es largo y sería peligroso si te enfermas"
    mn "อยากไม่สบายรึไง? การเดินทางยังอีกยาวไกลนะ ถ้าป่วยไปมันจะอันตรายเอา"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:458
translate english arc2_tenten_quest2_after_battle_9af44c77:

    # mn "En mi mochila traigo una toalla, puedo prestártela para que te cubras"
    mn "ในเป้ฉันมีผ้าเช็ดตัวอยู่ เดี๋ยวให้ยืมเอาไปคลุมตัวก่อนได้นะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:460
translate english arc2_tenten_quest2_after_battle_8110b4bd_3:

    # tt "..."
    tt "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:462
translate english arc2_tenten_quest2_after_battle_6e210bb5:

    # tt "E-Está bien"
    tt "อ-โอเค"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:463
translate english arc2_tenten_quest2_after_battle_b8c164ed:

    # tt "Pero déjame desvestirme sola, ¿Quieres? Sería embarazoso si me ves"
    tt "แต่ขอฉันถอดเสื้อผ้าคนเดียวนะ? ถ้าเธอมาเห็นมันจะน่าอายแย่สิ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:464
translate english arc2_tenten_quest2_after_battle_90801a9a:

    # mn "Claro, iré a ver la cueva, me hablas cuando termines"
    mn "ได้เลย งั้นฉันไปสำรวจถ้ำแป๊บนะ เสร็จแล้วเรียกด้วยล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:468
translate english arc2_tenten_quest2_after_battle_c2119a2b:

    # n "[MN] dejó a Tenten sola en la entrada de la cueva, entrando en la cueva oscura"
    n "[MN]ปล่อยให้เท็นเท็นอยู่คนเดียวตรงปากถ้ำ แล้วเดินเข้าสู่ความมืดภายในถ้ำ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:469
translate english arc2_tenten_quest2_after_battle_87b4850f:

    # n "Mientras caminaba pensó en usar el {b}Jutsu de Invisibilidad{/a} para espiar a Tenten"
    n "ขณะที่เดิน เขาก็คิดขึ้นมาได้ว่าจะลองใช้{b}คาถาล่องหน{/a}แอบดูเท็นเท็นดีไหม"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:471
translate english arc2_tenten_quest2_after_battle_8760b8d6:

    # n "Pero esto le traería molestias en su ojo..."
    n "แต่การทำแบบนั้นจะทำให้ตาของเขาแสบเอาได้..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:473
translate english arc2_tenten_quest2_after_battle_aa279649:

    # n "¿Debería [MN] espiar a Tenten?" nointeract
    n "[MN]ควรจะแอบดูเท็นเท็นดีไหมนะ?" nointeract

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:477
translate english arc2_tenten_quest2_after_battle_83de4518:

    # n "[MN] pensó que no debería hacerlo"
    n "[MN]คิดว่าไม่ทำดีกว่า"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:478
translate english arc2_tenten_quest2_after_battle_0762fb49:

    # n "Así que volvió hasta que Tenten le habló"
    n "เขาจึงเดินกลับมาจนกระทั่งเท็นเท็นเอ่ยปากเรียก"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:485
translate english arc2_tenten_quest2_spy_5c381ae4:

    # mn "¡Karugan!"
    mn "คารูกัน!"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:486
translate english arc2_tenten_quest2_spy_bcfab59d:

    # n "Usando el Karugan, [MN] volvió a donde estaba Tenten solo para espiarla"
    n "ด้วยพลังของคารูกัน [MN] จึงแอบย้อนกลับมายังจุดที่เท็นเท็นอยู่เพื่อแอบดูเธอโดยเฉพาะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:494
translate english arc2_tenten_quest2_spy_4c7b8ac4:

    # n "Y ahí estaba..."
    n "และแล้วเธอก็อยู่ที่นั่น..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:495
translate english arc2_tenten_quest2_spy_a4f25f41:

    # n "Mientras el sonido del fuego consumiendo las ramas resonaba en las paredes de esa cueva húmeda"
    n "ท่ามกลางเสียงของเปลวไฟที่กำลังเผาไหม้กิ่งไม้สะท้อนก้องไปทั่วผนังของถ้ำอันอับชื้น"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:496
translate english arc2_tenten_quest2_spy_7adb6a20:

    # n "La lluvia que le había caído tornaba su piel nacarada a la luz parpadeante de la hoguera"
    n "หยาดฝนที่เกาะพราวบนผิวเนียนของเธอสะท้อนกับแสงไฟอันริบหรี่จากกองไฟ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:497
translate english arc2_tenten_quest2_spy_bd4a9824:

    # n "[MN] estaba impacientado, esperando ver como Tenten se desnudaba ante él"
    n "[MN] รู้สึกใจจดใจจ่อ เฝ้ารอที่จะได้เห็นเท็นเท็นถอดเสื้อผ้าต่อหน้าต่อตา"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:499
translate english arc2_tenten_quest2_spy_0b77bd4f:

    # n "Ahora, Tenten de dispone a despojarse de su ropa mojada"
    n "บัดนี้ เท็นเท็นกำลังจะถอดเสื้อผ้าที่เปียกชุ่มออก"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:501
translate english arc2_tenten_quest2_spy_26c47331:

    # n "Primero, sus manos se detienen en su blusa empapada"
    n "อันดับแรก มือของเธอหยุดอยู่ที่เสื้อเชิ้ตที่เปียกโชก"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:502
translate english arc2_tenten_quest2_spy_0b1a54e9:

    # n "Tenten retiraba cada broche lentamente"
    n "เท็นเท็นค่อยๆ แกะกระดุมทีละเม็ดอย่างช้าๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:504
translate english arc2_tenten_quest2_spy_42e0f838:

    # n "Y al soltarlos todos..."
    n "และเมื่อปลดมันออกจนหมด..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:507
translate english arc2_tenten_quest2_spy_c9ae9691:

    # n "Dejó que la camisa de deslizara por sus brazos, hasta caer completamente"
    n "เธอปล่อยให้เสื้อเชิ้ตหลุดร่วงจากแขนลงมา จนกระทั่งมันหลุดออกไปจนหมด"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:508
translate english arc2_tenten_quest2_spy_337caefd:

    # n "Bajo la tenue iluminación, su piel parecía casi iridiscente, con un brillo que hablaba de la lluvia que habían atravesado recientemente"
    n "ภายใต้แสงไฟสลัว ผิวของเปล่งประกายราวกับมีประกายรุ้ง เปล่งแสงเรืองรองที่สะท้อนถึงหยาดฝนที่เพิ่งเผชิญมา"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:509
translate english arc2_tenten_quest2_spy_d47393d5:

    # n "Mientras esto ocurría, el corazón de [MN] comenzó a latir rápidamente"
    n "ในขณะนั้นเอง หัวใจของ [MN] ก็เริ่มเต้นระรัว"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:511
translate english arc2_tenten_quest2_spy_61d89832:

    # n "Posteriormente, Tenten dirigió su atención hacia su cintura..."
    n "จากนั้น เท็นเท็นก็เบนความสนใจไปที่เอวของเธอ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:512
translate english arc2_tenten_quest2_spy_e8a490fc:

    # n "Ella aflojó su pantalón..."
    n "เธอคลายกางเกงออก..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:515
translate english arc2_tenten_quest2_spy_4875cd59:

    # n "Para que su propio peso lo hiciera caer..."
    n "ปล่อยให้น้ำหนักของมันทำให้ร่วงหล่นลงไปเอง..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:516
translate english arc2_tenten_quest2_spy_be0d242a:

    # n "Revelando las suaves curvas de su cadera y muslos..."
    n "เผยให้เห็นส่วนโค้งเว้าอันอ่อนนุ่มของสะโพกและเรียวขา..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:517
translate english arc2_tenten_quest2_spy_26462361:

    # n "[MN] no podía evitar maravillarse al contemplarla, con cada curva y cada contorno marcados nítidamente en la oscuridad."
    n "[MN]อดไม่ได้ที่จะทึ่งในตัวเธอ ทุกส่วนโค้งและสัดส่วนปรากฏชัดเจนตัดกับความมืดมิด"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:519
translate english arc2_tenten_quest2_spy_3236c6e8:

    # n "Con un gesto lento y deliberado, sus manos se deslizaron por la suavidad de su propia piel"
    n "ด้วยท่าทางที่เชื่องช้าและตั้งใจ มือของเธอลูบไล้ไปบนผิวอันเนียนนุ่มของตัวเอง"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:520
translate english arc2_tenten_quest2_spy_afbbc482:

    # n "Recorriendo cada curva hasta llegar a su espalda"
    n "ไล่ตามส่วนโค้งเว้าจนกระทั่งถึงแผ่นหลัง"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:521
translate english arc2_tenten_quest2_spy_c4a0eda2:

    # n "Sus dedos temblaban ligeramente, pero con firmeza encontró el cierre de su sostén y, con un movimiento casi imperceptible"
    n "เรียวนิ้วของเธอสั่นเล็กน้อย แต่เธอก็คว้าตะขอเสื้อชั้นในไว้อย่างมั่นคง และด้วยการเคลื่อนไหวแทบจะไม่เป็นที่สังเกต"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:522
translate english arc2_tenten_quest2_spy_12374e38:

    # n "Comenzó a desabrocharlo"
    n "เธอเริ่มปลดตะขอของมัน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:525
translate english arc2_tenten_quest2_spy_590ee2cf:

    # n "El sostén cayó al suelo, liberando finalmente sus pechos a la fría caricia del aire"
    n "เสื้อชั้นในร่วงหล่นลงสู่พื้น เผยให้เห็นทรวงอกของเธอรับสัมผัสอันเยือกเย็นจากสายลม"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:526
translate english arc2_tenten_quest2_spy_48ffb506:

    # n "[MN] no pudo evitar que su respiración se acelerara, sus ojos cautivados por la imagen frente a él"
    n "[MN]อดไม่ได้ที่จะหายใจถี่กระชั้น สายตาจับจ้องไปที่ภาพตรงหน้า"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:527
translate english arc2_tenten_quest2_spy_bb0854d4:

    # n "Era como si todo a su alrededor se desvaneciera, quedando sólo ella, tan vulnerable y hermosa"
    n "ราวกับว่าทุกสิ่งรอบตัวเลือนหายไป เหลือไว้เพียงแต่เธอผู้ดูเปราะบางและงดงามยิ่งนัก"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:528
translate english arc2_tenten_quest2_spy_46092b35:

    # n "Se deleitó con la visión, sus pupilas dilatadas mientras absorbía cada detalle"
    n "เขาดื่มด่ำกับภาพที่เห็น รูม่านตาขยายกว้างขณะที่ซึมซับทุกรายละเอียด"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:529
translate english arc2_tenten_quest2_spy_a2131147:

    # n "La suavidad, la curva perfecta y la piel tersa que estaba ante él"
    n "ความนุ่มนวล ส่วนโค้งเว้าอันสมบูรณ์แบบ และผิวเนียนละเอียดที่อยู่ตรงหน้า"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:531
translate english arc2_tenten_quest2_spy_f86477fa:

    # n "Finalmente, con una mezcla de decisión y suavidad, Tenten enganchó sus pulgares en el borde de sus bragas"
    n "ในที่สุด ด้วยความมุ่งมั่นและความอ่อนโยนผสมผสานกัน เท็นเท็นก็เกี่ยว นิ้วโป้งเข้ากับขอบกางเกงในของเธอ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:532
translate english arc2_tenten_quest2_spy_53e06d13:

    # n "El roce de sus dedos contra su piel enviaba pequeñas oleadas de placer a través de su cuerpo"
    n "สัมผัสของปลายนิ้วที่ลูบไล้บนผิวของเธอส่งคลื่นความเสียวซ่านแผ่ซ่านไปทั่วร่าง"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:533
translate english arc2_tenten_quest2_spy_caaddb36:

    # n "Y con un suspiro apenas audible"
    n "และพร้อมกับเสียงถอนหายใจแผ่วเบาแทบไม่ได้ยิน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:535
translate english arc2_tenten_quest2_spy_6b36b972:

    # n "Comenzó a deslizar la prenda hasta abajo... Mientras la tela fina descendía"
    n "เธอเริ่มเลื่อนชุดชั้นในลง... ขณะที่เนื้อผ้าอันบางเบาเคลื่อนต่ำลง"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:536
translate english arc2_tenten_quest2_spy_c36fc2ee:

    # n "Rozando con una suavidad exquisita sus muslos húmedos"
    n "ลูบไล้เรียวขาอันเปียกชุ่มของเธออย่างนุ่มนวลและอ่อนโยน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:537
translate english arc2_tenten_quest2_spy_a6d1a613:

    # n "El aire frío besó su piel desnuda, intensificando la sensación de vulnerabilidad y deseo que llenaba el ambiente"
    n "สายลมเย็นเยียบสัมผัสกับผิวเปลือยเปล่าของเธอ เพิ่มพูนความรู้สึกเปราะบางและปรารถนาที่อบอวลอยู่ในบรรยากาศ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:539
translate english arc2_tenten_quest2_spy_1aff23a3:

    # n "Las paredes de esa cueva jamás habían contemplado una visión tan arrebatadoramente hermosa"
    n "ผนังของถ้ำแห่งนั้นไม่เคยได้เห็นภาพที่งดงามเย้ายวนใจเช่นนี้มาก่อนเลย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:540
translate english arc2_tenten_quest2_spy_a596d655:

    # n "[MN] se deleitó en el simple, casi sagrado, acto de observarla mientras se despojaba de cada prenda"
    n "[MN] ดื่มด่ำกับการได้เฝ้ามองเธอเปลื้องผ้าทีละชิ้นด้วยความเรียบง่าย ราวกับพิธีกรรมอันศักดิ์สิทธิ์"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:541
translate english arc2_tenten_quest2_spy_a6428ced:

    # n "Aquí no habría consumación ni un clímax"
    n "จะไม่มีการสมสู่หรือจุดไคลแม็กซ์ใดๆ เกิดขึ้นที่นี่"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:542
translate english arc2_tenten_quest2_spy_b802a2a4:

    # n "En lugar de eso, una pausa envolvía el momento, un paréntesis de deseo contenido y expectativa silenciosa"
    n "ทว่าความเงียบงันกลับเข้าปกคลุมช่วงเวลานี้ ดั่งวงเล็บแห่งความปรารถนาที่ถูกเก็บกดและเสียงกระซิบแห่งความคาดหวังอันเงียบงัน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:543
translate english arc2_tenten_quest2_spy_60bf76cd:

    # n "Cada movimiento era un regalo, cada segundo se prolongaba como una eternidad"
    n "ทุกการเคลื่อนไหวคือของขวัญ ทุกวินาทีทอดยาวราวกับชั่วนิรันดร์"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:544
translate english arc2_tenten_quest2_spy_9835ed3f:

    # n "Sin embargo, sabemos que nada dura para siempre. Incluso el momento más perfecto y hermoso... se desvanece"
    n "กระนั้น เราต่างรู้ดีว่าไม่มีสิ่งใดคงอยู่ตลอดไป แม้กระทั่งช่วงเวลาที่สมบูรณ์แบบและงดงามที่สุด... ก็เลือนหายไป"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:545
translate english arc2_tenten_quest2_spy_84b13dea:

    # n "Con una última exhalación profunda, como liberando la tensión que había acumulado en su interior"
    n "พร้อมกับเสียงถอนหายใจเฮือกสุดท้าย ราวกับปลดปล่อยความตึงเครียดที่สะสมอยู่ภายในร่าง"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:551
translate english arc2_tenten_quest2_spy_cfda8298:

    # n "Con un gesto lento y decidido, alcanzó una toalla cercana y la envolvió alrededor de su cuerpo"
    n "ด้วยท่าทางที่เชื่องช้าและแน่วแน่ เธืเอื้อมมือคว้าผ้าขนหนูที่วางอยู่ใกล้ๆ มาพันรอบกาย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:552
translate english arc2_tenten_quest2_spy_84d4e20a:

    # n "Ocultando la belleza de su figura bajo la suave tela, dejando solo el rastro del deseo en el aire"
    n "ซ่อนความงามของเรือนร่างไว้ใต้เนื้อผ้าอันนุ่มนวล ทิ้งไว้เพียงร่องรอยแห่งความปรารถนาที่อบอวลในอากาศ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:553
translate english arc2_tenten_quest2_spy_8115a9dd:

    # n "Una punzada de decepción atravesó los pensamientos de [MN]. 'Es una lástima', pensó..."
    n "ความรู้สึกผิดหวังวาบขึ้นมาในความคิดของ [MN] 'น่าเสียดายจริงๆ' เขาคิด..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:554
translate english arc2_tenten_quest2_spy_f1bdce52:

    # n "Mientras observaba cómo la tela cubría lo que hace apenas unos instantes era un espectáculo cautivador"
    n "ขณะที่เขามองดูผ้าผืนนั้นปิดบังภาพอันเย้ายวนใจที่เพิ่งปรากฏอยู่ตรงหน้าเมื่อครู่"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:556
translate english arc2_tenten_quest2_spy_f49e7640:

    # n "Y así Ryuta volvió con Tenten, pero con un ardor insoportable en sus ojos..."
    n "และแล้วริวตะก็กลับมาหาเท็นเท็น แต่ด้วยอาการแสบตาอย่างรุนแรงจนทนไม่ไหว..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:558
translate english arc2_tenten_quest2_spy_2384d7ac:

    # n "Y así Ryuta volvió con Tenten"
    n "และแล้วริวตะก็กลับมาหาเท็นเท็น"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:575
translate english arc2_tenten_quest2_after_undress_7c5670fe:

    # mn "Bien, ahora ya no hay peligro de que puedas resfriarte"
    mn "เอาล่ะ ทีนี้ก็ไม่ต้องกลัวว่าจะไม่สบายเป็นหวัดแล้วนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:579
translate english arc2_tenten_quest2_after_undress_d539ca7d:

    # mnn "(Maldición, veo borroso y me duele la vista)"
    mnn "(แย่ล่ะ ตาพร่ามัวไปหมดแถมยังแสบตาชะมัด)"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:581
translate english arc2_tenten_quest2_after_undress_d7377e2d:

    # mnn "(Sé que Sakura me dijo que no usara el Karugan por ahora)"
    mnn "(รู้นะว่าซากุระบอกไม่ให้ใช้คารูกันในช่วงนี้ก็เถอะ)"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:583
translate english arc2_tenten_quest2_after_undress_337cce89:

    # mnn "(Pero esa era una oportunidad única en la vida, no podía desaprovecharla)"
    mnn "(แต่นั่นมันโอกาสครั้งหนึ่งในชีวิตเลยนะ จะให้ปล่อยผ่านไปได้ยังไง)"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:585
translate english arc2_tenten_quest2_after_undress_6dc3f6eb:

    # mnn "(Ver eso fue... Increíble)"
    mnn "(ได้เห็นภาพนั้น... มันยอดเยี่ยมจริงๆ)"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:589
translate english arc2_tenten_quest2_after_undress_59f3a27d:

    # mn "(Esa fue una experiencia inolvidable...)"
    mn "(นั่นมันประสบการณ์ที่ไม่มีวันลืมเลยแฮะ...)"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:590
translate english arc2_tenten_quest2_after_undress_13def9d6:

    # mn "(Y gracias a las gotas que me dio Sakura no siento molestia en el ojo)"
    mn "(แถมเพราะยาหยอดตาที่ซากุระให้มาด้วย ฉันเลยไม่รู้สึกระคายเคืองตาเลยสักนิด)"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:592
translate english arc2_tenten_quest2_after_undress_358978f8:

    # tt "Si, te agradezco que me prestaras esta toalla, ¿Pero tú no tienes con qué abrigarte?"
    tt "อื้ม ขอบใจนะที่ให้ฉันยืมผ้าขนหนูนี่ แต่เธอไม่มีชุดอะไรใส่ให้อุ่นกว่านี้หน่อยเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:593
translate english arc2_tenten_quest2_after_undress_0edb2b93:

    # mn "No te preocupes por eso, no puedo dejar que antes completamente desnuda, ¿No?"
    mn "น่า ไม่เป็นไรหรอก จะปล่อยให้เธอแก้ผ้าโทงๆ ต่อไปได้ยังไงจริงไหม?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:594
translate english arc2_tenten_quest2_after_undress_730e440b:

    # mn "Ven, mejor vamos a comer"
    mn "ป่ะ ไปหาอะไรกินกันเถอะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:595
translate english arc2_tenten_quest2_after_undress_02d27806:

    # mn "Tengo mucha hambre"
    mn "ฉันหิวจะแย่แล้วเนี่ย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:598
translate english arc2_tenten_quest2_after_undress_c10c7064:

    # tt "Si jaja, yo igual"
    tt "นั่นสินะ ฮ่าๆ ฉันก็เหมือนกัน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:601
translate english arc2_tenten_quest2_after_undress_55dd003c:

    # n "Nuevamente, ambos se sientan cerca de la hoguera, para posteriormente comerse su cena"
    n "ทั้งสองคนกลับมานั่งใกล้กองไฟอีกครั้งเพื่อจัดการมื้อค่ำ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:602
translate english arc2_tenten_quest2_after_undress_e2cfab20:

    # n "Luego de comer..."
    n "หลังจากทานอาหารเสร็จ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:610
translate english arc2_tenten_quest2_after_undress_57e21267:

    # mn "Oye Tenten, ¿Cómo sabías que estaba esta cueva aquí?"
    mn "นี่ เท็นเท็น เธอรู้ได้ยังไงเหรอว่ามีถ้ำนี้อยู่แถวนี้?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:611
translate english arc2_tenten_quest2_after_undress_f0c53a19:

    # mn "¿Ya habías venido por esta zona antes?"
    mn "เธอเคยมาแถวนี้มาก่อนเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:612
translate english arc2_tenten_quest2_after_undress_56b5185a:

    # tt "Si, conozco esta zona"
    tt "อื้ม ฉันรู้จักแถวนี้ดีแหละ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:613
translate english arc2_tenten_quest2_after_undress_b3532cf5:

    # tt "He ido unas cuantas veces a esa mina a recoger minerales, y la ví un día que iba de paso"
    tt "ฉันเคยไปเหมืองตรงนั้นอยู่สองสามครั้งเพื่อเก็บแร่ แล้วก็บังเอิญเห็นเข้าตอนที่เดินผ่านน่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:614
translate english arc2_tenten_quest2_after_undress_b5e0db63:

    # mn "¿Y es segura? Digo, ¿No hay osos por esta zona?"
    mn "แล้วมันปลอดภัยไหม? หมายถึงว่าแถวนี้ไม่มีพวกหมีอะไรพวกนั้นใช่ไหม?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:615
translate english arc2_tenten_quest2_after_undress_da1612e8:

    # tt "Ya la revisé y no hay nada fuera de lo común"
    tt "ฉันสำรวจดูแล้วล่ะ ไม่มีอะไรผิดปกตินะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:617
translate english arc2_tenten_quest2_after_undress_91fadbbc:

    # mn "Que bien, no querría pelear contra un oso justo ahora"
    mn "ดีแล้ว ฉันไม่อยากมีเรื่องต่อยตีกับหมีตอนนี้หรอกนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:619
translate english arc2_tenten_quest2_after_undress_36b29ab6:

    # tt "¿Serías capaz de luchar contra un Oso?"
    tt "นายสู้กับหมีไหวด้วยเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:620
translate english arc2_tenten_quest2_after_undress_727eb355:

    # mn "¿Porqué no?"
    mn "ทำไมจะไม่ไหวล่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:621
translate english arc2_tenten_quest2_after_undress_f078cc2a:

    # mn "Claramente le ganaría en una lucha"
    mn "แน่นอนอยู่แล้ว ฉันชนะเห็นๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:623
translate english arc2_tenten_quest2_after_undress_b946cba1:

    # tt "Si claro jaja"
    tt "จ้าๆ ฮ่าๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:625
translate english arc2_tenten_quest2_after_undress_caf21ef7:

    # tt "¿Porqué parece que es el sueño de los hombres luchar contra un Oso?"
    tt "ทำไมผู้ชายทุกคนถึงดูฝันอยากจะสู้กับหมีกันนักนะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:626
translate english arc2_tenten_quest2_after_undress_9184bbb5:

    # mn "¿Porqué no lo sería? Jajaja"
    mn "ทำไมจะไม่ล่ะจริงไหม ฮ่าๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:627
translate english arc2_tenten_quest2_after_undress_2211c059:

    # tt "Bueno, creo que ya es demasiado tarde"
    tt "ว่าแต่ ฉันว่ามันดึกมากแล้วนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:628
translate english arc2_tenten_quest2_after_undress_7fe4551f:

    # tt "Tenemos que estar listos desde temprano para no hacer el viaje demasiado largo"
    tt "เราต้องเตรียมตัวออกเดินทางแต่เช้า จะได้ไม่ต้องเสียเวลาเดินทางนานเกินไป"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:629
translate english arc2_tenten_quest2_after_undress_20874787:

    # mn "Si, tienes razón, no podemos perder mucho tiempo"
    mn "อื้ม เธอพูดถูก เราจะเสียเวลามากไม่ได้"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:630
translate english arc2_tenten_quest2_after_undress_4bb943e3:

    # tt "Bueno, voy a ir preparando mi futón, deberías hacer lo mismo"
    tt "งั้นฉันขอตัวไปปูที่นอนก่อนนะ เธอก็ควรทำเหมือนกันล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:631
translate english arc2_tenten_quest2_after_undress_304c7947:

    # mn "Si, ahora lo hago"
    mn "ได้สิ เดี๋ยวฉันจัดการเดี๋ยวนี้แหละ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:634
translate english arc2_tenten_quest2_after_undress_e004dac5:

    # n "Tenten saca y extiende su Futón"
    n "เท็นเท็นหยิบฟูกที่นอนของเธอออกมาแล้วปูลงกับพื้น"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:635
translate english arc2_tenten_quest2_after_undress_f9e69331:

    # n "Pero algo va mal"
    n "แต่ทว่า มีบางอย่างผิดปกติ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:643
translate english arc2_tenten_quest2_after_undress_e4274a9f:

    # mn "Oye, Tenten..."
    mn "นี่ เท็นเท็น..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:644
translate english arc2_tenten_quest2_after_undress_7078c880:

    # tt "¿Qué pasa?"
    tt "มีอะไรเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:645
translate english arc2_tenten_quest2_after_undress_0e2c753a:

    # mn "¿Cómo te digo esto? Eh..."
    mn "จะพูดไปยังไงดีนะ เอิ่ม..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:647
translate english arc2_tenten_quest2_after_undress_b1b08e30:

    # mn "Se me olvidó mi Futón..."
    mn "ฉันลืมฟูกนอน..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:649
translate english arc2_tenten_quest2_after_undress_8110b4bd:

    # tt "..."
    tt "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:651
translate english arc2_tenten_quest2_after_undress_de668aab:

    # tt "¿Qué?"
    tt "หา?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:652
translate english arc2_tenten_quest2_after_undress_c1ea761e:

    # mn "S-Se me olvidó mi Futón... Creo que se me olvidó meterlo en mi mochila..."
    mn "ฉ-ฉันลืมฟูกนอน... เหมือนฉันจะลืมหยใส่กระเป๋ามาว่ะ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:654
translate english arc2_tenten_quest2_after_undress_8110b4bd_1:

    # tt "..."
    tt "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:657
translate english arc2_tenten_quest2_after_undress_704d6b08:

    # tt "¡¿Cómo se te olvidó algo tan importante?!" with vpunch
    tt "นายลืมของสำคัญขนาดนี้ได้ยังไงเนี่ย?!" with vpunch

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:659
translate english arc2_tenten_quest2_after_undress_99b5308c:

    # mnn "¡N-NO LO SÉ!" with vpunch
    mnn "ฉ-ฉันจะไปรู้เหรอ!" with vpunch

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:661
translate english arc2_tenten_quest2_after_undress_e551225b:

    # mn "De verdad, pensé que lo había metido"
    mn "ฉันนึกว่าฉันหยิบใส่มาแล้วซะอีกจริง ๆ นะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:663
translate english arc2_tenten_quest2_after_undress_b80b6f08:

    # mn "Maldición, ahora me toca dormir en el suelo"
    mn "ให้ตายสิ ฉันต้องมานอนบนพื้นแข็ง ๆ เนี่ยนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:666
translate english arc2_tenten_quest2_after_undress_8110b4bd_2:

    # tt "..."
    tt "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:668
translate english arc2_tenten_quest2_after_undress_9708b5ef:

    # tt "N-No te dejaré dormir en el suelo, ¿Acaso te quieres resfriar?"
    tt "ฉ-ฉันไม่ให้นายนอนบนพื้นหรอกนะ อยากไม่สบายรึไงกัน?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:669
translate english arc2_tenten_quest2_after_undress_370c29dc:

    # mn "¿Entonces dónde duermo? No veo otro lugar donde pueda dormir aparte del suelo"
    mn "งั้นจะให้ฉันไปนอนที่ไหนล่ะ? นอกจากพื้นแล้วก็ไม่เห็นมีที่อื่นเลยนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:671
translate english arc2_tenten_quest2_after_undress_87189988:

    # tt "Tch, de verdad los hombres no entienden nada..."
    tt "ให้ตายสิ ผู้ชายเนี่ยไม่เคยรู้อะไรเลยจริงๆ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:672
translate english arc2_tenten_quest2_after_undress_5ad48a1a:

    # tt "Yo si traje mi Futón, no te dejaré dormir en el suelo, peor si estás desnudo"
    tt "ฉันเอาฟูกมาด้วย และฉันไม่ให้นายนอนบนพื้นแน่ๆ โดยเฉพาะในสภาพเปลือยแบบนี้ด้วย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:673
translate english arc2_tenten_quest2_after_undress_6f4b9a1a:

    # tt "D-Dormirás conmigo..."
    tt "น-นายนอนกับฉันนี่แหละ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:674
translate english arc2_tenten_quest2_after_undress_ab77b50f:

    # mn "¿C-Contigo? Pero... Ambos estamos así..."
    mn "ก-กับเธอเนี่ยนะ? แต่... เราสองคนอยู่ในสภาพนี้กันอยู่นะ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:677
translate english arc2_tenten_quest2_after_undress_8110b4bd_3:

    # tt "..."
    tt "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:679
translate english arc2_tenten_quest2_after_undress_b1a59609:

    # tt "No hagas más incómoda la situación, ¿Quieres?"
    tt "อย่าทำใหสถานการณ์มันน่าอึดอัดไปมากกว่านี้เลยน่า จะได้ไหม?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:680
translate english arc2_tenten_quest2_after_undress_cbf6c5cf:

    # tt "¿No dijiste que no me tenía que enfermar? Lo mismo te digo también"
    tt "ไหนเก๊กบอกว่าไม่อยากให้ฉันไม่สบายไงล่ะ? เรื่องนั้นก็ใช้กับฉันเหมือนกันนั่นแหละ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:681
translate english arc2_tenten_quest2_after_undress_6fe55466:

    # tt "S-Solo entra rápido y duérmete..."
    tt "ร-รีบๆ เข้ามาแล้วนอนได้แล้ว..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:682
translate english arc2_tenten_quest2_after_undress_5502cecb:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:683
translate english arc2_tenten_quest2_after_undress_31caa32c:

    # mn "Bueno... Es verdad que yo dije eso... Pero es una situación completamente diferente..."
    mn "เอ่อ... ก็จริงอยู่ที่ฉันพูดแบบนั้น... แต่นี่มันคนละสถานการณ์กันเลยนะ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:684
translate english arc2_tenten_quest2_after_undress_ef1566f9:

    # tt "Solo entra, ¿Quieres? Antes de que cambie de parecer..."
    tt "รีบเข้ามาได้แล้วน่า! ก่อนที่ฉันจะเปลี่ยนใจ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:685
translate english arc2_tenten_quest2_after_undress_1df159ee:

    # mn "E-Está bien, aquí voy entonces..."
    mn "ก-งั้นก็ได้ เข้าไปแล้วนะ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:687
translate english arc2_tenten_quest2_after_undress_f08c7241:

    # n "[MN] se acostó con Tenten en el único Futón que habían traído"
    n "[MN]ล้มตัวลงนอนกับเท็นเท็นบนฟูกผืนเดียวที่มีอยู่"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:688
translate english arc2_tenten_quest2_after_undress_43f6e893:

    # n "Tenten estaba un poco incómoda con la situación, pero logró dormirse tranquila"
    n "เท็นเท็นรู้สึกอึดอัดกับสถานการณ์นี้เล็กน้อย แต่เธอก็สามารถข่มตาหลับลงได้ด้วยดี"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:689
translate english arc2_tenten_quest2_after_undress_e7d2c883:

    # n "En cambio [MN]..."
    n "ในทางกลับกัน [MN]..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:690
translate english arc2_tenten_quest2_after_undress_87034242:

    # n "Es un hombre, y su cuerpo simplemente no puede ignorar el contacto que había entre él y Tenten"
    n "เขาเป็นผู้ชาย และร่างกายของเขาก็ไม่สามารถละเลยการแนบชิดกันระหว่างเขากับเท็นเท็นได้เลย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:691
translate english arc2_tenten_quest2_after_undress_42b09985:

    # n "Pero él sabía que no podía hacer más, así que solamente cerró sus ojos..."
    n "แต่เขารู้ดีว่าทำอะไรมากกว่านี้ไม่ได้แล้ว เขาจึงหลับตาลง..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:692
translate english arc2_tenten_quest2_after_undress_ffb0388d:

    # n "Y se durmió..."
    n "แล้วผลอยหลับไป..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:696
translate english arc2_tenten_quest2_after_undress_a20cefa7:

    # "..."
    "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:697
translate english arc2_tenten_quest2_after_undress_956f3191:

    # "-{b}Por la mañana{/a}-"
    "-{b}เช้าวันต่อมา{/a}-"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:701
translate english arc2_tenten_quest2_after_undress_45c76f65:

    # tt "Hmmm..."
    tt "อื้ม..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:703
translate english arc2_tenten_quest2_after_undress_ef559230:

    # tt "*Bostezo* ¿Ya amaneció?"
    tt "*หาว* เช้าแล้วเหรอเนี่ย?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:704
translate english arc2_tenten_quest2_after_undress_6ef52e70:

    # tt "¿Q-Qué es esto?"
    tt "อ-อะไรเนี่ย?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:706
translate english arc2_tenten_quest2_after_undress_c52cd863:

    # tt "¿E-El brazo de... [MN]?"
    tt "น-นี่แขนของ [MN] เหรอเนี่ย?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:707
translate english arc2_tenten_quest2_after_undress_1f62676e:

    # tt "Me está abrazando..."
    tt "เขากำลังกอดฉันอยู่..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:709
translate english arc2_tenten_quest2_after_undress_db1d6ffc:

    # tt "Aún sigue durmiendo..."
    tt "เขายังไม่ตื่นเลย..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:711
translate english arc2_tenten_quest2_after_undress_7a039904:

    # tt "¿Qué se le va a hacer? Supongo que no está tan mal..."
    tt "จะทำยังไงได้ล่ะเนี่ย? แต่ก็... ไม่ได้แย่เท่าไหร่หรอกมั้ง..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:713
translate english arc2_tenten_quest2_after_undress_a478761c:

    # tt "*Bostezo* Aún tengo sueño, voy a dormir un poco más..."
    tt "*หาว* ฉันยังง่วงอยู่เลย ขอต่องีบอีกหน่อยละกัน..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:715
translate english arc2_tenten_quest2_after_undress_fd682bcb:

    # n "Tenten cierra los ojos nuevamente"
    n "เท็นเท็นหลับตาลงอีกครั้ง"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:716
translate english arc2_tenten_quest2_after_undress_e8b1d538:

    # n "Hasta que..."
    n "จนกระทั่ง..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:717
translate english arc2_tenten_quest2_after_undress_99ff3bbd:

    # tt "Mmmm, ¿Qué hay aquí atrás?, Algo me está puyando"
    tt "อื้ม... อะไรอยู่ข้างหลังฉันเนี่ย? มีอะไรมาทิ่มอยู่ด้วย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:719
translate english arc2_tenten_quest2_after_undress_6b9baab5:

    # tt "¿Se habrá metido una rama al Futón?"
    tt "มีกิ่งไม้หลุดเข้ามาในฟูกเหรอเนี่ย?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:721
translate english arc2_tenten_quest2_after_undress_4de7ee22:

    # tt "Mmm, hay que sacar esto, así no podré dormir..."
    tt "อื้ม ฉันต้องเอาออกไปซะหน่อย ไม่งั้นนอนต่อไม่ได้แน่..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:722
translate english arc2_tenten_quest2_after_undress_890be0bf:

    # tt "¿Hmm?"
    tt "หืม?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:723
translate english arc2_tenten_quest2_after_undress_49272cf1:

    # tt "Esto no parece una rama..."
    tt "นี่มันไม่น่าจะใช่กิ่งไม้นะ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:724
translate english arc2_tenten_quest2_after_undress_08c995ff:

    # tt "Es muy grueso... Y duro... Parece más un..."
    tt "มันหนามากแถมยังแข็งด้วย... รู้สึกเหมือนกับ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:726
translate english arc2_tenten_quest2_after_undress_3fd369c2:

    # tt "¡Ah!" with hpunch
    tt "อ๊ะ!" with hpunch

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:727
translate english arc2_tenten_quest2_after_undress_337f1291:

    # tt "E-Esto... Es..."
    tt "น-นี่มัน..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:728
translate english arc2_tenten_quest2_after_undress_f2c34429:

    # tt "¡¿Es el pene de [MN]?!" with vpunch
    tt "นี่มันควยของ [MN] เหรอเนี่ย?!" with vpunch

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:729
translate english arc2_tenten_quest2_after_undress_4c57ad61:

    # tt "T-Tiene una erección...?"
    tt "น-นายตื่นตัวอยู่เหรอเนี่ย...?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:730
translate english arc2_tenten_quest2_after_undress_cab63c3a:

    # tt "¿C-Conmigo?"
    tt "ก-กับฉันเนี่ยนะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:731
translate english arc2_tenten_quest2_after_undress_8110b4bd_4:

    # tt "..."
    tt "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:733
translate english arc2_tenten_quest2_after_undress_0e30c24d:

    # n "Tenten se levanta, para ver de cerca lo que la está {b}puyando{/a}"
    n "เท็นเท็นขยับตัวออก เพื่อดูให้ชัดเจนว่ามีอะไร {b}กำลังทิ่มเธออยู่{/a}"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:735
translate english arc2_tenten_quest2_after_undress_ac2a644f:

    # tt "Vaya..."
    tt "เอ่อ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:736
translate english arc2_tenten_quest2_after_undress_0627f26e:

    # tt "Nunca había visto uno tan grande..."
    tt "ฉันไม่เคยเห็นอันใหญ่ขนาดนี้มาก่อนเลย..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:737
translate english arc2_tenten_quest2_after_undress_ffd7fe8b:

    # tt "Es más... Jamás pensé que habría uno de este tamaño..."
    tt "แถม... ไม่คิดเลยว่าจะจะมีคนที่มีขนาดใหญ่ขนาดนี้..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:738
translate english arc2_tenten_quest2_after_undress_a680dc31:

    # tt "El de Lee es la mitad de esto..."
    tt "ของเจ้าลีมีแค่ครึ่งเดียวของอันนี้เอง..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:739
translate english arc2_tenten_quest2_after_undress_8110b4bd_5:

    # tt "..."
    tt "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:740
translate english arc2_tenten_quest2_after_undress_49b15d95:

    # tt "Eh, pero..."
    tt "เอ๊ะ แต่ว่า..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:744
translate english arc2_tenten_quest2_after_undress_72518783:

    # tt "¡¿Q-Qué estoy haciendo?!"
    tt "ด-นี่ฉันกำลังทำอะไรอยู่เนี่ย?!"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:745
translate english arc2_tenten_quest2_after_undress_86e60416:

    # tt "Maldición, mejor dejo de tocarlo antes de que se despierte..."
    tt "แย่ล่ะ เลิกสัมผัสเขาดีกว่าก่อนที่เขาจะตื่น..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:746
translate english arc2_tenten_quest2_after_undress_5a14e73c:

    # tt "Mejor... Voy a preparar el desayuno..."
    tt "ทางที่ดี... ฉันไปทำมื้อเช้าดีกว่า..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:747
translate english arc2_tenten_quest2_after_undress_a20cefa7_1:

    # "..."
    "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:748
translate english arc2_tenten_quest2_after_undress_bd6e7df1:

    # n "-{b}Momentos después{/a}-"
    n "-{b}ไม่นานหลังจากนั้น{/a}-"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:758
translate english arc2_tenten_quest2_after_undress_3854d094:

    # mnn "Mmmm..."
    mnn "อื้ม..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:759
translate english arc2_tenten_quest2_after_undress_8cde1641:

    # tt "Oh, ¿Ya despertaste?"
    tt "อ้าว ตื่นแล้วเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:760
translate english arc2_tenten_quest2_after_undress_d6bdf2c5:

    # tt "Justo a tiempo, ya está listo el desayuno"
    tt "พอดีเลย อาหารเช้าเสร็จพอดี"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:761
translate english arc2_tenten_quest2_after_undress_c3bb226b:

    # mn "Tenten..."
    mn "เท็นเท็น..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:762
translate english arc2_tenten_quest2_after_undress_63db2396:

    # mn "B-Buenos días"
    mn "อ-อรุณสวัสดิ์"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:763
translate english arc2_tenten_quest2_after_undress_bf1588f4:

    # tt "Buenos días, ¿Quieres un poco de café?"
    tt "อรุณสวัสดิ์ รับกาแฟสักหน่อยไหม?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:766
translate english arc2_tenten_quest2_after_undress_b30f272c:

    # n "Momentos después, Ryuta despertó y con su ropa seca, comió con Tenten"
    n "ไม่นานหลังจากนั้น เรียวตะก็ตื่นขึ้นมา และเมื่อเสื้อผ้าแห้งแล้ว เขาก็ร่วมทานอาหารกับเท็นเท็น"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:767
translate english arc2_tenten_quest2_after_undress_caf982ff:

    # n "Después se prepararon para marchar hacia su destino"
    n "หลังจากนั้น ทั้งคู่ก็เตรียมตัวออกเดินทางไปยังจุดหมาย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:779
translate english arc2_tenten_quest2_after_undress_10ddc185:

    # tt "Bueno, ya estamos listos, debemos partir de inmediato"
    tt "เอาล่ะ เราพร้อมแล้ว ออกเดินทางกันเลยดีกว่า"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:780
translate english arc2_tenten_quest2_after_undress_93c42167:

    # mn "¿Ya falta poco para llegar a la mina?"
    mn "ตอนนี้เราใกล้ถึงเหมืองรึยัง?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:781
translate english arc2_tenten_quest2_after_undress_de89ca65:

    # tt "Si, está a unas horas de aquí"
    tt "อืม อีกไม่กี่ชั่วโมงก็ถึงจากตรงนี้"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:782
translate english arc2_tenten_quest2_after_undress_aa96aa62:

    # tt "Aunque estoy preocupada, si nos tardamos ya será tarde"
    tt "ถึงจะกังวลอยู่บ้าง แต่ถ้าชักช้ากว่านี้ เดี๋ยวจะไม่ทันเอา"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:783
translate english arc2_tenten_quest2_after_undress_b044f2b0:

    # tt "Si nos damos prisa, estarémos aquí cuando caiga la noche"
    tt "ถ้าพวกเราเร่งมือหน่อย น่าจะกลับมาถึงที่นี่ได้ทันก่อนค่ำนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:784
translate english arc2_tenten_quest2_after_undress_20e9bd13:

    # tt "Este lugar es seguro, y parece que puede llover en cualquier momento"
    tt "ที่นี่ปลอดภัยดี แถมดูท่าทางฝนน่าจะตกกลงมาได้ตลอดเวลาด้วย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:785
translate english arc2_tenten_quest2_after_undress_edb39710:

    # tt "Nos quedamos mucho tiempo dormidos..."
    tt "พวกเราเผลอนอนเพลินกันไปนานเลย..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:787
translate english arc2_tenten_quest2_after_undress_f048aa79:

    # mn "Por mí no hay problema pero..."
    mn "ฉันไม่มีปัญหาเรื่องนั้นหรอก แต่ว่า..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:788
translate english arc2_tenten_quest2_after_undress_0df24ace:

    # mn "¿Crees poder seguirme el ritmo?"
    mn "เธอคิดว่าจะตามฉันทันแน่เหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:791
translate english arc2_tenten_quest2_after_undress_8110b4bd_6:

    # tt "..."
    tt "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:793
translate english arc2_tenten_quest2_after_undress_eaf692b0:

    # tt "Creo que sí, no falta mucho"
    tt "คิดว่าทันนะ อีกไม่ไกลเท่าไหร่แล้วล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:795
translate english arc2_tenten_quest2_after_undress_642b944d:

    # mn "Bueno, si te cansas me avisas"
    mn "งั้นบอกฉันได้นะถ้าเริ่มเหนื่อย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:796
translate english arc2_tenten_quest2_after_undress_df5f60c5:

    # mn "No te sobre esfuerces"
    mn "อย่าฝืนตัวเองจนเกินไปล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:798
translate english arc2_tenten_quest2_after_undress_482a7366:

    # tt "No te preocupes por eso, yo puedo"
    tt "ไม่ต้องห่วงเรื่องนั้นหรอก ฉันไหวอยู่แล้ว"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:799
translate english arc2_tenten_quest2_after_undress_3ad47171:

    # mn "Bueno, entonces en marcha"
    mn "งั้นก็ไปกันเถอะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:804
translate english arc2_tenten_quest2_after_undress_6db01335:

    # n "[MN] y Tenten retoman su camino"
    n "[MN]และเท็นเท็นออกเดินทางต่อ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:805
translate english arc2_tenten_quest2_after_undress_d195a7a2:

    # n "-{b}Horas después{/a}-"
    n "-{b}ผ่านไปหลายชั่วโมง{/b}-"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:816
translate english arc2_tenten_quest2_after_undress_f27699ed:

    # n "Ambos llegan a su destino"
    n "ทั้งคู่เดินทางมาถึงจุดหมายแล้ว"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:817
translate english arc2_tenten_quest2_after_undress_f60d8057:

    # tt "Por fin... Ya llegamos..."
    tt "ในที่สุด... ก็ถึงสักที..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:818
translate english arc2_tenten_quest2_after_undress_f615c57e:

    # tt "*suspiro* Maldición, ya me estaba cansando..."
    tt "*ถอนหายใจ* ให้ตายสิ ฉันเริ่มเหนื่อยแล้วนะเนี่ย..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:819
translate english arc2_tenten_quest2_after_undress_b3242b29:

    # mn "De verdad debes mejorar tu condición física jajaja"
    mn "เธอเนี่ยต้องไปฝึกความอึดเพิ่มซะแล้วนะ ฮ่าๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:820
translate english arc2_tenten_quest2_after_undress_d606467c:

    # tt "No es gracioso, mejor apresúrate"
    tt "นี่ไม่ใช่เรื่องตลกนะ รีบ ๆ เข้าเถอะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:821
translate english arc2_tenten_quest2_after_undress_6c82e2aa:

    # tt "Debemos darnos prisa"
    tt "เราต้องรีบกันหน่อยแล้ว"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:822
translate english arc2_tenten_quest2_after_undress_6b59a3b4:

    # mn "Si, ahora voy jaja"
    mn "รู้แล้วน่า กำลังทำอยู่ ฮ่าๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:824
translate english arc2_tenten_quest2_after_undress_86ea599c:

    # n "[MN] y Tenten entran en la mina"
    n "[MN]และเท็นเท็นเข้าไปในเหมือง"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:825
translate english arc2_tenten_quest2_after_undress_3fb113c3:

    # n "No se adentraron mucho para encontrar {b}Una veta del mineral especial{/a}"
    n "พวกเขาไม่ต้องเดินหาลึกเท่าไหร่ก็พบกับ{b}สายแร่แร่พิเศษ{/b}"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:826
translate english arc2_tenten_quest2_after_undress_b1596d2e:

    # n "Con la ayuda de {b}[MN] lograron extraer un mineral{/a} de buen tamaño para la espada"
    n "ด้วยความช่วยเหลือจาก{b}[MN] พวกเขาสามารถขุดแร่{/b}ขนาดพอเหมาะสำหรับทำดาบได้สำเร็จ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:827
translate english arc2_tenten_quest2_after_undress_2937208f:

    # n "Ahora con el mineral en sus manos, tienen que seguir por donde vinieron"
    n "ตอนนี้เมื่อได้แร่มาอยู่ในมือแล้ว พวกเขาต้องเดินทางกลับทางเดิม"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:837
translate english arc2_tenten_quest2_after_undress_33d2ffde:

    # mn "Muy bien, con esto será más que suficiente"
    mn "เอาล่ะ แค่นี้ก็เหลือเฟือแล้วล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:838
translate english arc2_tenten_quest2_after_undress_e49d2117:

    # mn "Ya podémos irnos"
    mn "พวกเรากลับกันได้แล้ว"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:839
translate english arc2_tenten_quest2_after_undress_e46f9d18:

    # tt "¿Tan rápido? Ya estoy cansada"
    tt "เร็วขนาดนี้เลยเหรอ? ฉันเหนื่อยแล้วนะเนี่ย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:840
translate english arc2_tenten_quest2_after_undress_60fd02f2:

    # tt "¿No podémos quedarnos a descansar un poco?"
    tt "พวกเราอยู่พักผ่อนสักหน่อยก่อนไม่ได้เหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:842
translate english arc2_tenten_quest2_after_undress_48b3d51b:

    # mn "Creo que lo mejor sería irnos rápidamente"
    mn "ฉันว่ารีบกลับกันน่าจะดีที่สุดนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:843
translate english arc2_tenten_quest2_after_undress_41615c46:

    # mn "Parece que va a volver a llover"
    mn "ดูท่าฝนทำท่าจะตกอีกแล้ว"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:844
translate english arc2_tenten_quest2_after_undress_6cb3f998:

    # mn "Quizás si nos damos prisa lleguemos a la cueva de antes antes de que llueva"
    mn "ถ้าพวกเรารีบหน่อย น่าจะไปถึงถ้ำเมื่อกี้ก่อนฝนจะตกได้นะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:846
translate english arc2_tenten_quest2_after_undress_198eb587:

    # tt "Maldición..."
    tt "ให้ตายสิ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:847
translate english arc2_tenten_quest2_after_undress_18324cb7:

    # tt "Bien, vámonos..."
    tt "ก็ได้ ไปกันเถอะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:850
translate english arc2_tenten_quest2_after_undress_2da95818:

    # n "Así, [MN] y Tenten toman el camino por el que vinieron"
    n "[MN]และเท็นเท็นจึงเดินย้อนกลับไปทางเดิม"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:851
translate english arc2_tenten_quest2_after_undress_4180170a:

    # n "Pero desafortunadamente volvió a llover, mojándolos nuevamente"
    n "แต่โชคร้ายที่ฝนตกลงมาอีกจนเปียกโชกกันไปหมด"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:852
translate english arc2_tenten_quest2_after_undress_e8b0f300:

    # n "No fue hasta unos minutos después que llegaron a la cueva donde pasaron la noche anterior"
    n "ผ่านไปแค่ไม่กี่นาทีพวกเขาก็มาถึงถ้ำที่เคยใช้พักแรมเมื่อคืนก่อน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:853
translate english arc2_tenten_quest2_after_undress_42dc97e3:

    # n "Ambos tuvieron que desvestirse nuevamente, para que su ropa se secara"
    n "ทั้งคู่ต้องถอดเสื้อผ้าออกอีกครั้งเพื่อให้เสื้อผ้าแห้ง"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:868
translate english arc2_tenten_quest2_after_undress_f6ed1034:

    # tt "Maldición, de nuevo nos agarró la lluvia..."
    tt "ให้ตายสี โดนฝนเล่นงานจนได้"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:869
translate english arc2_tenten_quest2_after_undress_bfca1511:

    # tt "Todos estos días esttuvieron soleados, hasta que tuvimos que salir de viaje"
    tt "ช่วงนี้แดดออกดีมาตลอด จนกระทั่งพวกเราต้องออกเดินทางเนี่ยแหละ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:870
translate english arc2_tenten_quest2_after_undress_42f8dbaa:

    # mn "Es como si el clima nos odiara"
    mn "เหมือนสภาพอากาศจะเกลียดพวกเรายังไงยังงั้นเลยนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:873
translate english arc2_tenten_quest2_after_undress_8110b4bd_7:

    # tt "..."
    tt "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:875
translate english arc2_tenten_quest2_after_undress_38c8352b:

    # tt "Oye..."
    tt "นี่..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:876
translate english arc2_tenten_quest2_after_undress_2dd37164:

    # tt "¿Te puedo preguntar algo?"
    tt "ฉันถามอะไรหน่อยได้ไหม?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:877
translate english arc2_tenten_quest2_after_undress_0562b4b9:

    # mn "¿Qué pasa?"
    mn "ว่าไงล่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:878
translate english arc2_tenten_quest2_after_undress_58547eaa:

    # tt "¿Porqué nunca te quitas ese parche?"
    tt "ทำไมเธอถึงไม่เคยถอดที่ปิดตาอันนั้นเลยล่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:879
translate english arc2_tenten_quest2_after_undress_76e300d4:

    # tt "Sé que tienes el Sharingan en ese ojo pero, ¿No está mojado también?"
    tt "ฉันรู้ว่าเธอมีเนตรวงแหวนอยู่นะ แต่มันไม่เปียกน้ำบ้างเลยเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:881
translate english arc2_tenten_quest2_after_undress_2d09d6e8:

    # mn "Oh, eso..."
    mn "อ๋อ เรื่องนั้น..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:882
translate english arc2_tenten_quest2_after_undress_e14ea7f1:

    # mn "No me gusta mostrar esa parte de mi rostro"
    mn "ฉันไม่ค่อยชอบให้ใครเห็นใบหน้าส่วนนั้นเท่าไหร่หรอก"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:883
translate english arc2_tenten_quest2_after_undress_6338b6ac:

    # tt "¿Por el Sharingan?"
    tt "เพราะเรื่องเนตรวงแหวนงั้นเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:884
translate english arc2_tenten_quest2_after_undress_7244b66e:

    # mn "N-No es eso..."
    mn "มะ-ไม่หรอก ไม่ใช่แบบนั้น..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:885
translate english arc2_tenten_quest2_after_undress_3bd5cd87:

    # mn "Es por... Otra cosa..."
    mn "มันเป็นเพราะ... เรื่องอื่นต่างหาก..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:887
translate english arc2_tenten_quest2_after_undress_cef93ba8:

    # tt "E-Entiendo..."
    tt "อ-อ๋อ... งั้นเหรอ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:888
translate english arc2_tenten_quest2_after_undress_ab3912ee:

    # tt "Lo siento, no quería tocar un tema sensible para tí"
    tt "ขอโทษทีนะ ฉันไม่ได้ตั้งใจจะไปสะกิดแผลใจเธอหรอก"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:891
translate english arc2_tenten_quest2_after_undress_60002a91:

    # mn "No te preocupes, no hay problema..."
    mn "ไม่ต้องห่วง ฉันไม่เป็นไรหรอก..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:893
translate english arc2_tenten_quest2_after_undress_8110b4bd_8:

    # tt "..."
    tt "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:896
translate english arc2_tenten_quest2_after_undress_11ca800a:

    # mn "Bueno, ¿Qué tal si ya nos vamos a dormir?"
    mn "ว่าแต่ เรามานอนกันเลยดีไหม?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:897
translate english arc2_tenten_quest2_after_undress_a7aab55a:

    # mn "Ya hemos cenado"
    mn "พวกเราก็กินข้าวกันเรียบร้อยแล้วด้วย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:898
translate english arc2_tenten_quest2_after_undress_7a432ea9:

    # mn "Será mejor dormirnos temprano, no vaya a ser que nos levantemos tarde nuevamente"
    mn "นอนเร็วกหน่อยน่าจะดีกว่า พรุ่งนี้จะได้ไม่ตื่นสายกันอีก"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:901
translate english arc2_tenten_quest2_after_undress_846e167a:

    # tt "Si, tienes razón"
    tt "อื้ม พูดถูกนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:902
translate english arc2_tenten_quest2_after_undress_525fbf6b:

    # tt "Ya solo tenémos que llegar a la aldea y comenzar con la forja de la espada"
    tt "เราแค่ต้องไปให้ถึงหมู่บ้านแล้วเริ่มตีดาบก็พอ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:906
translate english arc2_tenten_quest2_after_undress_74b4d6e1:

    # n "[MN] y Tenten se preparan para dormir"
    n "[MN] และเท็นเท็นเตรียมตัวเข้านอน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:907
translate english arc2_tenten_quest2_after_undress_047132d1:

    # n "Ambos se acuestan en el Futón"
    n "ทั้งคู่ล้มตัวลงนอนบนฟูก"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:908
translate english arc2_tenten_quest2_after_undress_26cb2f4a:

    # n "Tenten estaba un poco preocupada"
    n "เท็นเท็นรู้สึกกังวลใจอยู่นิดหน่อย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:909
translate english arc2_tenten_quest2_after_undress_fecc4b55:

    # n "Pensó en lo que pasó en la mañana, pero el sueño le ganó y se durmió rápidamente"
    n "เธอนึกถึงเรื่องที่เกิดขึ้นเมื่อตอนเช้า แต่ความง่วงก็เข้าครอบงำ จนทำให้เธอผลอยหลับไปอย่างรวดเร็ว"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:910
translate english arc2_tenten_quest2_after_undress_3531dc6e:

    # n "Para [MN] no pasó tan igual que la noche pasada, ya que nuevamente volvió a sentir esa excitación irresistible"
    n "สำหรับ [MN] แล้ว มันไม่ค่อยเหมือนกับคืนก่อนหน้านี้เท่าไหร่ เพราะเขากลับมารู้สึกตื่นเต้นเร้าใจจนห้ามใจไม่ไหวอีกครั้ง"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:911
translate english arc2_tenten_quest2_after_undress_ba267074:

    # n "Pero, ¿Quién lo juzga por eso? Tenten es una mujer hermosa, de pies a cabeza"
    n "แต่ใครจะไปว่าเขาได้ล่ะ? เท็นเท็นเป็นผู้หญิงที่งดงามตั้งแต่หัวจรดเท้าเลยนี่นา"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:912
translate english arc2_tenten_quest2_after_undress_2a3d62c7:

    # n "¿Qué hombre no se sentiría exitado con una mujer así a su lado?"
    n "ผู้ชายที่ไหนจะไม่รู้สึกตื่นเต้นที่มีผู้หญิงแบบนี้อยู่ข้างกายกันล่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:913
translate english arc2_tenten_quest2_after_undress_bb3ab6a8:

    # n "Pero nuevamente, como todo un caballero, decidió no dejarse llevar, y entrar al maravilloso mundo de los sueños"
    n "แต่ทว่า ในฐานะสุภาพบุรุษตัวจริง เขาตัดสินใจที่จะไม่ปล่อยใจไปตามอารมณ์ และเคลิบเคลิ้มเข้าสู่โลกแห่งความฝันอันแสนวิเศษ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:914
translate english arc2_tenten_quest2_after_undress_a20cefa7_2:

    # "..."
    "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:915
translate english arc2_tenten_quest2_after_undress_956f3191_1:

    # "-{b}Por la mañana{/a}-"
    "-{b}รุ่งเช้าวันต่อมา{/b}-"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:918
translate english arc2_tenten_quest2_after_undress_ecdfba4f:

    # mn "Mmmm..."
    mn "อืมม..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:919
translate english arc2_tenten_quest2_after_undress_30209aad:

    # n "Cuando los primeros rayos del sol entran a esta oscura cueva por la mañana, [MN] abre los ojos"
    n "เมื่อแสงแรกของวันสาดส่องเข้ามาในถ้ำอันมืดมิดยามเช้า [MN] ก็ลืมตาขึ้น"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:920
translate english arc2_tenten_quest2_after_undress_3d5cbac1:

    # n "Y de pronto..."
    n "และทันใดนั้นเอง..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:921
translate english arc2_tenten_quest2_after_undress_c9ecb255:

    # n "Siente un gran peso en su pecho, como si algo lo asfixiara"
    n "เขารู้สึกถึงน้ำหนักอันหนักอึ้งบนหน้าอก ราวกับมีบางสิ่งกำลังทำให้เขาหายใจไม่ออก"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:922
translate english arc2_tenten_quest2_after_undress_681bdd76:

    # mn "Mmm... ¿Qué tengo en el pecho? Siento algo pesado..."
    mn "อืม... มีอะไรอยู่บนอกฉันเนี่ย? รู้สึกหนักอึ้งจัง..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:923
translate english arc2_tenten_quest2_after_undress_d27e6393:

    # n "Así que decide abrir sus ojos para ver lo que le generaba tal presión... Y era"
    n "เขาจึงตัดสินใจลืมตาขึ้นเพื่อดูว่าอะไรคือสาเหตุของแรงกดทับนี้... และสิ่งที่เห็นก็คือ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:924
translate english arc2_tenten_quest2_after_undress_753bfe2f:

    # mn "Mmm, ¿Qué tengo en..."
    mn "อืม ฉันกำลังจับอะไรอยู่เนี่ย...?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:927
translate english arc2_tenten_quest2_after_undress_1e890981:

    # n "¡UN TRASERO!" with vpunch
    n "ก้นนี่หว่า!" with vpunch

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:928
translate english arc2_tenten_quest2_after_undress_c27eb3b3:

    # mn "¡¿Q-QUÉ?!" with hpunch
    mn "ห-หา?!" with hpunch

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:929
translate english arc2_tenten_quest2_after_undress_826907e6:

    # mn "¿Qué es esto?"
    mn "นี่มันอะไรเนี่ย?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:930
translate english arc2_tenten_quest2_after_undress_8a55a4f2:

    # mn "¿Esta es... Tenten?"
    mn "นี่คือ... เท็นเท็นงั้นเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:931
translate english arc2_tenten_quest2_after_undress_93521e67:

    # n "[MN] no pudo evitar ver como las nalgas de Tenten descansaban delicadamente tan cerca de su cara"
    n "[MN]อดไม่ได้ที่จะมองดูบั้นท้ายของเท็นเท็นที่แนบชิดอยู่ใกล้ใบหน้าของเขาอย่างอ่อนโยน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:932
translate english arc2_tenten_quest2_after_undress_f8284dae:

    # n "Estaba desconcertado, y se preguntaba cómo llegaron a tan hermosa posición"
    n "เขารู้สึกฉงนและสงสัยว่าพวกเขามาอยู่ในท่าทางสุดสยิวแบบนี้ได้อย่างไร"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:934
translate english arc2_tenten_quest2_after_undress_26f10885:

    # n "Mientras su palpitante erección se acurrucaba entre sus regordetas mejillas, tentadoramente cerca del calor de su boca"
    n "ในขณะที่แก่นกายที่กำลังเต้นตุบๆ ของเขาซุกซอกอยู่ระหว่างแก้มก้นอวบอิ่ม อยู่ใกล้กับความอบอุ่นริมฝีปากของเธออย่างยั่วเย้า"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:935
translate english arc2_tenten_quest2_after_undress_cbd1856d:

    # n "[MN] intentó moverla suavemente para ver si podría librarse"
    n "[MN] พยายามขยับตัวเธอเบาๆ เพื่อดูว่าจะสามารถหลุดพ้นออกมาได้ไหม"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:936
translate english arc2_tenten_quest2_after_undress_9730bce5:

    # n "Pero ella estaba tan aferrada a él que no se podía mover"
    n "แต่เธอกลับกอดรัดเขาไว้แน่นเสียจนเขาขยับไปไหนไม่ได้เลย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:937
translate english arc2_tenten_quest2_after_undress_57a07fc6:

    # n "Ante esa situación, no sabía que hacer, si Tenten despertaba sería un gran problema para él"
    n "ในสถานการณ์แบบนี้ เขาไม่รู้เลยว่าจะทำอย่างไรดี ถ้าเท็นเท็นตื่นขึ้นมา งานนี้คงเป็นเรื่องใหญ่สำหรับเขาแน่ๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:939
translate english arc2_tenten_quest2_after_undress_15ce000c:

    # mn "M-Maldición... Si ella se llegase a despertar... Justo así"
    mn "พ-เวรเอ๊ย... ถ้าเกิดเธอตื่นขึ้นมา... ในสภาพนี้ล่ะก็"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:940
translate english arc2_tenten_quest2_after_undress_93f63a44:

    # mn "Debo de... Librarme de esta situación"
    mn "ฉันต้อง... หลุดพ้นจากสถานการณ์นี้ให้ได้"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:942
translate english arc2_tenten_quest2_after_undress_a231037b:

    # n "Momentos después, [MN] pudo liberarse sin despertar a Tenten"
    n "ครู่ต่อมา [MN] ก็สามารถปลดปล่อยตัวเองออกมาได้โดยที่เท็นเท็นไม่ตื่นขึ้นมา"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:943
translate english arc2_tenten_quest2_after_undress_c284fafb:

    # n "Y luego Tenten se despertó también, sin sospechar nada..."
    n "และหลังจากนั้น เท็นเท็นก็ตื่นขึ้นมาโดยที่ไม่ได้เอะใจอะไรเลย..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:944
translate english arc2_tenten_quest2_after_undress_8eb0e17a:

    # n "Poco después de desayunar ambos están listos para volver a la aldea"
    n "หลังจากทานมื้อเช้าเสร็จไม่นาน ทั้งสองก็พร้อมที่จะเดินทางกลับหมู่บ้านแล้ว"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:957
translate english arc2_tenten_quest2_after_undress_b7c47a72:

    # mn "Bueno, ¿Estás lista?"
    mn "ว่าไง พร้อมหรือยังล่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:958
translate english arc2_tenten_quest2_after_undress_ddc0a3c8:

    # mn "Hoy parece que el día estará soleado"
    mn "ดูท่าวันนี้แดดจะออกสินะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:959
translate english arc2_tenten_quest2_after_undress_e738f0ae:

    # mn "Ya no tendrémos problemas con la lluvia"
    mn "พวกเราคงไม่ต้องเจอกับปัญหาเรื่องฝนตกอีกแล้วล่ะนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:960
translate english arc2_tenten_quest2_after_undress_61f6ca4f:

    # tt "Gracias a Dios, ya no quería seguir mojándome"
    tt "โชคดีจริงๆ ฉันไม่อยากตัวเปียกฝนซ้ำแล้วซ้ำเล่าอีกแล้วล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:961
translate english arc2_tenten_quest2_after_undress_734aa0ee:

    # mn "Si, si nos damos prisa puede que lleguemos a la hora de la cena"
    mn "นั่นสิ ถ้าพวกเรารีบเดินทางหน่อย อาจจะกลับไปทันมื้อเย็นพอดิบพอดีเลยก็ได้"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:962
translate english arc2_tenten_quest2_after_undress_e9ffba2e:

    # mn "Que ganas de comer un tazón de Ramen de Ichiraku"
    mn "ฉันชักจะอดใจรอซดราเมนอิจิราคุร้อนๆ สักชามไม่ไหวแล้วสิ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:963
translate english arc2_tenten_quest2_after_undress_f1db5707:

    # tt "Bueno, pues démonos prisa entonces"
    tt "งั้นก็รีบออกเดินทางกันเถอะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:967
translate english arc2_tenten_quest2_after_undress_a20cefa7_3:

    # "..."
    "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:968
translate english arc2_tenten_quest2_after_undress_d6f84394:

    # n "Y así, esta pareja de ninjas retomó su viaje nuevamente"
    n "และแล้ว นินจาทั้งสองก็เริ่มออกเดินทางกันต่ออีกครั้ง"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:969
translate english arc2_tenten_quest2_after_undress_d195a7a2_1:

    # n "-{b}Horas después{/a}-"
    n "-{b}หลายชั่วโมงต่อมา{/a}-"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:979
translate english arc2_tenten_quest2_after_undress_4b7360e4:

    # n "Ambos por fin llegan a la aldea de la hoja"
    n "ในที่สุดพวกเขาก็เดินทางมาถึงหมู่บ้านโคโนฮะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:981
translate english arc2_tenten_quest2_after_undress_f59fcb22:

    # tt "¡Llegamos!"
    tt "พวกเรากลับมาถึงแล้ว!"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:983
translate english arc2_tenten_quest2_after_undress_6b83e4ef:

    # tt "Al fin, no quería volver a dormir en una cueva"
    tt "ในที่สุด ฉันไม่อยากต้องไปนอนในถ้ำแบบนั้นอีกแล้วนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:985
translate english arc2_tenten_quest2_after_undress_efb48063:

    # mn "No estuvo tan mal jaja"
    mn "มันก็ไม่ได้แย่ขนาดนั้นสักหน่อย ฮ่าๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:987
translate english arc2_tenten_quest2_after_undress_c34ebef2:

    # tt "Si claro"
    tt "จ้า แน่นอนอยู่แล้ว"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:988
translate english arc2_tenten_quest2_after_undress_e19aa162:

    # tt "Yo ya me voy a mi casa, ya estoy muy cansada"
    tt "งั้นฉันกลับบ้านก่อนนะ เหนื่อยมากเลยล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:989
translate english arc2_tenten_quest2_after_undress_dee542be:

    # tt "Mañana comenzaré a trabajar en la espada, yo te avisaré cuando esté lista"
    tt "พรุ่งนี้ฉันจะเริ่มจัดการเรื่องดาบต่อแล้ว เดี๋ยวเสร็จแล้วจะบอกเธอนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:991
translate english arc2_tenten_quest2_after_undress_6fca5fbb:

    # mn "¿No se suponía que yo te iba a ayudar?"
    mn "ไม่ใช่ว่าฉันต้องช่วยเธอด้วยเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:992
translate english arc2_tenten_quest2_after_undress_2f2cf4c3:

    # tt "Estuve pensándolo... Y será mejor que me dejes el trabajo a mí"
    tt "ฉันมาคิดดูแล้ว... ให้ฉันจัดการเรื่องนี้คนเดียวเองน่าจะดีกว่า"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:993
translate english arc2_tenten_quest2_after_undress_9783a48e:

    # tt "No puedo quitarte tiempo que podrías estar utilizando para mejorar tus habilidades"
    tt "ฉันไม่อยากเอาเวลาที่เธอควรจะได้ใช้ฝึกฝนพัฒนาฝีมือมาหรอกนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:994
translate english arc2_tenten_quest2_after_undress_77958a6c:

    # mn "Bueno... Pero..."
    mn "งั้นเหรอ... แต่ว่านะ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:995
translate english arc2_tenten_quest2_after_undress_42ae41a6:

    # tt "¿Qué tal esto? Mejor"
    tt "เอาแบบนี้ดีไหม แบบนี้น่าจะดีกว่านะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:996
translate english arc2_tenten_quest2_after_undress_da6fe931:

    # tt "¿Qué tal si buscas cambiar tu traje?"
    tt "เธอสนใจลองเปลี่ยนชุดดูหน่อยไหมล่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:997
translate english arc2_tenten_quest2_after_undress_02b16e42:

    # mn "¿Mi traje?"
    mn "ชุดฉันเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:998
translate english arc2_tenten_quest2_after_undress_a6d29b6a:

    # tt "Si, viéndolo bien creo que ya es hora de cambiarlo también"
    tt "ใช่แล้ว พอมาลองมองดูดีๆ ฉันว่าถึงเวลาที่เธอควรเปลี่ยนชุดได้แล้วล่ะนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:999
translate english arc2_tenten_quest2_after_undress_8e065714:

    # mn "¿En serio? Pero ha servido muy bien hasta ahora"
    mn "งั้นเหรอ? แต่ชุดนี้ก็ใช้งานได้ดีมาตลอดเลยนี่นา"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:1000
translate english arc2_tenten_quest2_after_undress_bc50ddf7:

    # tt "Si, pero si quieres subir de Rango también tienes que cambia tu traje también"
    tt "ใช่ แต่ถ้าเธออยากเลื่อนขั้นล่ะก็ เธอจำเป็นต้องเปลี่ยนชุดแต่งกายด้วยเหมือนกันนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:1001
translate english arc2_tenten_quest2_after_undress_e8773079:

    # tt "Esa ropa está bien para ser un Genin, pero no servirá para las misiones Chunin"
    tt "ชุดแบบนั้นน่ะใส่สำหรับเกะนินก็พอไหวอยู่หรอก แต่ถ้าเอาไปทำภารกิจระดับจูนินไม่รอดแน่ๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:1002
translate english arc2_tenten_quest2_after_undress_3e0dd5d0:

    # tt "De verdad te recomiendo hacerte otro traje"
    tt "ฉันแนะนำว่าเธอควรหาชุดอื่นมาใส่จริงๆ นะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:1003
translate english arc2_tenten_quest2_after_undress_efbd1606:

    # mn "Mmm, ¿Tú puedes ayudarme?"
    mn "อืม งั้นเธอช่วยฉันหน่อยสิ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:1004
translate english arc2_tenten_quest2_after_undress_5edfbd01:

    # tt "No, de verdad me gustaría pero no puedo jaja"
    tt "ไม่เอาหละ ฉันก็อยากช่วยอยู่หรอกนะแต่ช่วยไม่ได้แฮะ ฮ่าๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:1005
translate english arc2_tenten_quest2_after_undress_33821c1c:

    # tt "Solo te lo decía como una observación"
    tt "ฉันแคท้วงติงตามที่สังเกตเห็นเฉยๆ หรอกน่า"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:1006
translate english arc2_tenten_quest2_after_undress_66a3f26c:

    # tt "Depende de tí buscar ese nuevo traje"
    tt "เรื่องชุดใหม่เนี่ย เธอต้องไปหาเอาเองแล้วล่ะนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:1007
translate english arc2_tenten_quest2_after_undress_1bb34dac:

    # mn "Entiendo..."
    mn "เข้าใจแล้ว..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:1008
translate english arc2_tenten_quest2_after_undress_176cd526:

    # mn "Pero, ¿Tienes a alguien en mente?"
    mn "แล้วพอจะมีใครที่เธอแนะนำไหมล่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:1010
translate english arc2_tenten_quest2_after_undress_81d2f1f5:

    # tt "Mmm, te diría el comerciante que me vende las armas, pero no sé cuando volverá"
    tt "อืม ฉันก็อยากจะแนะนำพ่อค้าที่ขายอาวุธให้ฉันอยู่หรอกนะ แต่ไม่รู้ว่าเขาจะกลับมาเมื่อไหร่น่ะสิ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:1011
translate english arc2_tenten_quest2_after_undress_2a5ce2ae:

    # tt "Y ya que estamos en tiempos de paz las tiendas dejaron de vender buen equipo ninja, solo venden equipo básico"
    tt "แล้วพออยู่ในช่วงเวลาสันติภาพแบบนี้ ร้านค้าต่างๆ ก็เลิกขายอุปกรณ์นินจาดีๆ กันหมดแล้ว มีแต่ขายของพื้นๆ ทั่วไปเท่านั้นเอง"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:1013
translate english arc2_tenten_quest2_after_undress_47eced4a:

    # tt "Mmmm..."
    tt "อืม..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:1015
translate english arc2_tenten_quest2_after_undress_cf52edea:

    # tt "Oh, ¿Qué tal en la nueva tienda de ropa que hay en la aldea?"
    tt "อ้อ แล้วร้านขายเสื้อผ้าแห่งใหม่ในหมู่บ้านล่ะเป็นยังไง?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:1016
translate english arc2_tenten_quest2_after_undress_5e46942d:

    # tt "Creo recordar que la dueña es {b}La Madre de Yuna{/a}"
    tt "ฉันรู้สึกว่าเจ้าของร้านจะเป็น {b}แม่ของยูนะ{/a} นะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:1017
translate english arc2_tenten_quest2_after_undress_b7aa293f:

    # mn "No creo la verdad, ya fui una vez y solo vende ropa para mujer"
    mn "ไม่น่าใช่มั้ง ฉันเคยไปครั้งหนึ่ง ที่นั่นขายแต่เสื้อผ้าผู้หญิงน่ะสิ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:1018
translate english arc2_tenten_quest2_after_undress_03ca6827:

    # mn "Pero puedo preguntarle si sabe de alguien o puede ayudarme"
    mn "แต่ฉันลองไปถามเธอหน่อยก็ได้ เผื่อเธอจะรู้จักใครหรือช่วยอะไรได้บ้าง"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:1020
translate english arc2_tenten_quest2_after_undress_8386185d:

    # tt "Si, siento no poder ayudarte en eso"
    tt "นั่นสินะ ขอโทษทีที่ช่วยเรื่องนี้ไม่ได้นะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:1023
translate english arc2_tenten_quest2_after_undress_28a52ae1:

    # mn "No hay problema, ya haces mucho con la espada nueva"
    mn "ไม่เป็นไรหแค่เรื่องดาบเล่มใหม่เธอก็ช่วยฉันไว้เยอะแล้วล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:1024
translate english arc2_tenten_quest2_after_undress_17148ca6:

    # tt "Bueno, ¿Ya es tarde no?"
    tt "งั้นก็ดึกมากแล้วสินะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:1025
translate english arc2_tenten_quest2_after_undress_ece1f8a5:

    # tt "Ya no te quito más tiempo"
    tt "ฉันไม่กวนเวลาเธอต่อแล้วล่ะกัน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:1030
translate english arc2_tenten_quest2_after_undress_c133f91d:

    # n "Tenten se va"
    n "เท็นเท็นเดินจากไป"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:1032
translate english arc2_tenten_quest2_after_undress_f754e2c7:

    # mn "Bueno, ¿Ahora qué hago yo?"
    mn "เอาล่ะ ทีนี้จะทำอะไรต่อดีล่ะเนี่ย?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:1034
translate english arc2_tenten_quest2_after_undress_44e0a5bb:

    # mnn "Mmm..."
    mnn "อืม..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:1035
translate english arc2_tenten_quest2_after_undress_a5c857b9:

    # mn "Estoy hambriento"
    mn "หิวข้าวแล้วแฮะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:1038
translate english arc2_tenten_quest2_after_undress_39efee83:

    # n "Y así [MN] vuelve a la aldea luego de 2 largos días"
    n "และแล้ว [MN] ก็กลับมาถึงหมู่บ้านหลังจากผ่านไปสองวันที่แสนยาวนาน"

translate english strings:

    # game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:472
    old "No espíarla"
    new "อย่าแอบดูเธอ"

# TODO: Translation updated at 2024-12-01 21:25

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:500
translate english arc2_tenten_quest2_spy_de6def92:

    # n "Ahora, Tenten comienza a despojarse de su ropa mojada"
    n "จากนั้น เท็นเท็นก็เริ่มถอดชุดเปียกชุ่มออก"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:558
translate english arc2_tenten_quest2_spy_6e2fb685:

    # n "Y así [MN] volvió con Tenten, pero con un ardor insoportable en sus ojos..."
    n "แล้ว [MN] ก็กลับมาหาเท็นเท็นอีกครั้ง แต่ดวงตาของเขากลับแสบร้อนจนแทบทนไม่ไหว..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:560
translate english arc2_tenten_quest2_spy_b64b560b:

    # n "Y así [MN] volvió con Tenten"
    n "แล้ว [MN] ก็กลับมาหาเท็นเท็น"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest2.rpy:770
translate english arc2_tenten_quest2_after_undress_3e03bf1b:

    # n "Momentos después, [MN] despertó y con su ropa seca, comió con Tenten"
    n "ครู่ต่อมา [MN] ก็ตื่นขึ้นมาพร้อมกับเสื้อผ้าที่แห้งสนิท และได้กินอาหารร่วมกับเท็นเท็น"

