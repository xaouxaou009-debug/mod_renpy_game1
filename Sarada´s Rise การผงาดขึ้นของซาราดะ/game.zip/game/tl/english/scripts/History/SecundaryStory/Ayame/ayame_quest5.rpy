

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:24
translate english ayame_quest5_e6365516:

    # mn "Hola, ¿Qué tal Ayame?"
    mn "สวัสดี อายาเมะ เป็นไงบ้าง?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:27
translate english ayame_quest5_9bfdab77:

    # ay "[MN], me alegra que hayas venido"
    ay "[MN] ดีใจจังที่คุณมา"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:31
translate english ayame_quest5_0d9bfc48:

    # ay "Escucha, ahora mismo no tengo mucho tiempo para hablar"
    ay "ฟังนะ ฉันมีเวลาคุยไม่มากนักหรอกตอนนี้"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:33
translate english ayame_quest5_d1516f3c:

    # ay "Pero necesito que vayas a esta dirección"
    ay "แต่ฉันอยากให้คุณไปตามที่อยู่นี้"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:35
translate english ayame_quest5_71b3426f:

    # n "Ayame le da a [MN] una llave y una nota con una dirección escrita"
    n "อายาเมะยื่นกุญแจและกระดาษโน้ตที่เขียนที่อยู่ให้กับ [MN]"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:37
translate english ayame_quest5_9c738f0d:

    # mn "Habitacion 12, segundo piso..."
    mn "ห้อง 12 ชั้นสอง..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:39
translate english ayame_quest5_826907e6:

    # mn "¿Qué es esto?"
    mn "นี่มันอะไรกัน?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:42
translate english ayame_quest5_986cbe82:

    # ay "Lo entenderás todo cuando llegues"
    ay "เดี๋ยวคุณก็เข้าใจทุกอย่างเองเมื่อไปถึง"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:44
translate english ayame_quest5_15e5d6ef:

    # ay "Por ahora ve adelantandote, yo iré un poco más tarde para no levantar sospechas"
    ay "ตอนนี้รีบไปก่อนเถอะ ฉันจะตามไปทีหลังเพื่อไม่ให้เป็นที่น่าสงสัย"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:46
translate english ayame_quest5_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:48
translate english ayame_quest5_3ea43e50:

    # mn "¿Está bien?"
    mn "ตกลงไหม?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:52
translate english ayame_quest5_8ec38014:

    # n "[MN] sigue las indicaciones de la nota de Ayame"
    n "[MN] ทำตามคำแนะนำในกระดาษโน้ตของอายาเมะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:53
translate english ayame_quest5_b54ced62:

    # n "Llevándolo a una habitación de un hotel que aparentemente ella había pagado"
    n "พาเขาไปยังห้องพักโรงแรมที่เธอน่าจะเป็นคนจ่ายเงินไว้"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:62
translate english ayame_quest5_c5938a9a:

    # mn "Vaya... Qué lugar tan bonito"
    mn "ว้าว... ที่นี่สวยเป็นบ้าเลย"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:64
translate english ayame_quest5_57ea4ae4:

    # mn "¿Ayame pagó esta habitación?"
    mn "อายาเมะเป็นคนจ่ายค่าห้องนี้เหรอเนี่ย? Q1"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:66
translate english ayame_quest5_33fd17e6:

    # mn "Es impresionante, espero no le haya salido tan caro"
    mn "น่าประทับใจแฮะ หวังว่าคงไม่แพงจนเกินไปนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:68
translate english ayame_quest5_5cf04ee6:

    # mn "Dijo que me adelantara, así que seguramente ya esté viniendo"
    mn "เธอบอกให้ล่วงหน้ามาก่อน งั้นก็น่าจะกำลังมาแล้วสินะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:70
translate english ayame_quest5_b4722f0f:

    # mn "Mientras tanto creo que puedo ir poniéndome cómodo..."
    mn "ระหว่างรอก็ทำตัวตามสบายหน่อยดีกว่า..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:74
translate english ayame_quest5_83873f1f:

    # mn "Aah, cuanta comodidad..."
    mn "อ่า สบายตัวชะมัด..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:75
translate english ayame_quest5_c95a2e07:

    # mn "Creo que en lo llega Ayame tomaré una pequeña siesta..."
    mn "สงสัยพออายาเมะมาถึง ฉันคงต้องงีบสักหน่อยแล้ว..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:76
translate english ayame_quest5_45c5e2b1:

    # mn "Esta cama es tan cómoda que no puedo resistir la tentación de caer rendido ante ella"
    mn "เตียงนี้น่านอนชะมัดจนอดใจไม่ไหวที่จะหลงรักมันซะแล้วสิ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:78
translate english ayame_quest5_32462c4b_1:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:80
translate english ayame_quest5_3df4d424:

    # n "Alguien empieza a tocar la puerta"
    n "มีเสียงคนเริ่มเคาะประตู"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:82
translate english ayame_quest5_7701e01a:

    # mn "(¡Joder!)"
    mn "(เวรเอ๊ย!)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:83
translate english ayame_quest5_582b3cc8:

    # mn "¡V-Voy en un segundo...!"
    mn "ช-เดี๋ยวฉันไปเปิดให้เดี๋ยวนี้แหละ...!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:85
translate english ayame_quest5_3fa70e1d:

    # n "[MN] abre la puerta"
    n "[MN] เปิดประตู"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:95
translate english ayame_quest5_b0d277c2:

    # ay "Buenas noches [MN]"
    ay "ราตรีสวัสดิ์นะ [MN]"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:98
translate english ayame_quest5_e655fda1:

    # mn "Ayame, ya llegaste"
    mn "อายาเมะ มาแล้วเหรอ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:101
translate english ayame_quest5_fe0e042a:

    # ay "Si, siento mucho la tardanza"
    ay "อืม ขอโทษด้วยนะที่มาช้า"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:103
translate english ayame_quest5_8e11d705:

    # ay "¿Te gusta en dónde pasaremos la noche para tu última lección?"
    ay "ชอบสถานที่ที่เราจะใช้คืนนี้ สำหรับบทเรียนสุดท้ายของคุณไหมล่ะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:105
translate english ayame_quest5_17683b5f:

    # ay "Por ser nuestra última clase, creí que sería un buen detalle ir a un lugar más agradable"
    ay "ในเมื่อมันเป็นคลาสสุดท้ายของเราแล้ว ฉันเลยคิดว่ามาที่บรรยากาศดีๆ หน่อยน่าจะดีกว่า"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:108
translate english ayame_quest5_d1886621:

    # mn "Sí, es bastante agradable"
    mn "อืม ก็บรรยากาศดีใช้ได้เลยล่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:110
translate english ayame_quest5_36a186d5:

    # mn "¿No te salió muy costoso?"
    mn "มันไม่แพงเกินไปเหรอ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:113
translate english ayame_quest5_9526f7d5:

    # ay "No te preocupes por eso"
    ay "ไม่ต้องกังวลเรื่องนั้นหรอกน่า"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:116
translate english ayame_quest5_84edf872:

    # mn "Bueno... ¿Y qué harémos hoy entonces?"
    mn "งั้นเหรอ... แล้ววันนี้เราจะทำอะไรกันล่ะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:119
translate english ayame_quest5_b886eca5:

    # ay "Antes que nada, quiero ir al baño primero, tengo que darme una ducha"
    ay "ก่อนอื่นเลย ฉันขอตัวไปเข้าห้องน้ำก่อนนะ พอดีต้องอาบน้ำน่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:122
translate english ayame_quest5_82055b13:

    # mn "Oh, claro"
    mn "อ่า ได้เลย"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:125
translate english ayame_quest5_f9dbea33:

    # n "Ayame entra en el baño de la habitación"
    n "อายาเมะเดินเข้าห้องน้ำภายในห้องพัก"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:126
translate english ayame_quest5_2a66a5aa:

    # n "[MN] vuelve a recostarse en la cama, y se deja llevar por sus pensamientos"
    n "[MN] เอนตัวลงนอนบนเตียง แล้วปล่อยให้ความคิดล่องลอยไป"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:130
translate english ayame_quest5_7665c780:

    # mn "(Me pregunto porqué Ayame hace esto)"
    mn "(สงสัยจังว่าทำไมอายาเมะถึงทำแบบนี้)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:131
translate english ayame_quest5_d86717ce:

    # mn "(Antes de esto éramos amigos, pero nunca llegamos a este punto)"
    mn "(ก่อนหน้านี้เราเป็นเพื่อนกัน แต่ก็ไม่เคยมาถึงจุดนี้เลย)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:132
translate english ayame_quest5_bce94928:

    # mn "(Nunca mostró interés en mí hasta ahora)"
    mn "(เธอไม่เคยแสดงความสนใจในตัวฉันเลยจนกระทั่งตอนนี้)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:133
translate english ayame_quest5_17ccbec9:

    # mn "(Siempre fue amable conmigo, incluso aveces me regalaba los tazones de Ramen cuando no tenía dinero)"
    mn "(เธอใจดีกับฉันมาตลอด แถมบางครั้งยังมีราเม็งมาให้กินตอนที่ฉันไม่มีเงินอีกต่างหาก)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:134
translate english ayame_quest5_e00564b3:

    # mn "(Pero nunca creí que le interesase de esta manera...)"
    mn "(แต่ฉันไม่เคยคิดเลยว่าเธอจะสนใจกันในแง่นี้...)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:135
translate english ayame_quest5_95b03c03:

    # ay "[MN]..."
    ay "[MN]..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:136
translate english ayame_quest5_515d1ad6:

    # mn "¿H-Hola?"
    mn "จ-จ๊ะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:137
translate english ayame_quest5_43859d5d:

    # mn "¿Necesitas algo?"
    mn "มีอะไรหรือเปล่า?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:138
translate english ayame_quest5_ecb881ef:

    # ay "No, solo quería verificar que no me hayas abandonado"
    ay "เปล่าหรอก แค่อยากเช็คดูให้แน่ใจว่าเธอไม่ได้ทิ้งฉันหนีไปไหนแล้ว"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:139
translate english ayame_quest5_b49f3e44:

    # mn "Yo no haría eso"
    mn "ไม่ทำแบบนั้นหรอกน่า"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:140
translate english ayame_quest5_5ad37670:

    # ay "Bien, ya estoy lista"
    ay "โอเค ฉันพร้อมแล้วล่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:143
translate english ayame_quest5_087120de:

    # n "Ayame sale del baño de la habitación"
    n "อายาเมะเดินออกมาจากห้องน้ำในห้องพัก"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:153
translate english ayame_quest5_702834f7:

    # mn "¡¿A-Ayame?!"
    mn "อ-อายาเมะ?!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:155
translate english ayame_quest5_925a4afb:

    # ay "¿Qué tal? ¿Te gusta mi nuevo traje?"
    ay "เป็นไงบ้าง? ชอบชุดใหม่ของฉันไหมล่ะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:158
translate english ayame_quest5_532c6cd1:

    # mn "S-Sí..."
    mn "อ-อื้ม..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:160
translate english ayame_quest5_f248b0c1:

    # mn "¿P-Pero porqué te pusiste ese traje?"
    mn "ต-แต่ทำไมเธอถึงใส่ชุดนั้นล่ะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:163
translate english ayame_quest5_4ee675d1:

    # ay "Has hecho muy bien tu trabajo estos días, esta es tu recompensan jeje"
    ay "ช่วงนี้เธอทำหน้าที่ได้ดีมากเลยนะ นี่ถือเป็นรางวัลสำหรับเธอด้วยล่ะ ฮิฮิ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:165
translate english ayame_quest5_30c0dc3d:

    # ay "Así que espero que hoy también hagas tu mayor esfuerzo"
    ay "เพราะงั้นฉันก็หวังว่าวันนี้เธอจะเต็มที่เหมือนกันนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:168
translate english ayame_quest5_5325f85f:

    # mn "Mi mayor esfuerzo..."
    mn "เต็มที่อย่างงั้นเหรอ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:172
translate english ayame_quest5_c6e92f85:

    # mn "(No me esperaba esto en lo absoluto)"
    mn "(ไม่คิดเลยจริงๆ ว่าจะมีอะไรแบบนี้ด้วย)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:173
translate english ayame_quest5_85b77973:

    # mn "(...)"
    mn "(...)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:175
translate english ayame_quest5_e9103c27:

    # mn "(No entiendo muy bien el porqué pero siento que esto significa más para ella que lo que significa para mí)"
    mn "(ก็ไม่ค่อยเข้าใจเหตุผลเท่าไหร่หรอกนะ แต่รู้สึกว่าเรื่องนี้มันมีความหมายกับเธอมากกว่าที่คิดแฮะ)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:177
translate english ayame_quest5_57909229:

    # mn "(Más me vale hacerlo bien)"
    mn "(ฉันต้องทำออกมาให้ดีที่สุดก็แล้วกัน)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:180
translate english ayame_quest5_bd6daf7a:

    # mn "Muy bien, el día de hoy también haré mi mayor esfuerzo"
    mn "เข้าใจแล้ว วันนี้ฉันก็จะทำให้เต็มที่เหมือนกัน"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:183
translate english ayame_quest5_a0a637c4:

    # ay "Así me gusta"
    ay "พูดได้ดีนี่นา"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:185
translate english ayame_quest5_82a38d68:

    # ay "Ahora, acuéstate en la cama y permiteme adiestrarte"
    ay "ทีนี้ นอนลงบนเตียงแล้วให้ฉันฝึกเธอซะดีๆ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:187
translate english ayame_quest5_e9c3f00e:

    # ay "Aún eres un novato"
    ay "เธอยังเป็นแค่มือใหม่อยู่สินะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:190
translate english ayame_quest5_a6bae7d5:

    # mn "C-Claro"
    mn "อ-อื้ม"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:194
translate english ayame_quest5_df8c0c5a:

    # n "[MN] se acuesta sobre la cama"
    n "[MN] นอนลงบนเตียง"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:195
translate english ayame_quest5_e63a0f01:

    # mn "Listo, ¿Para qué quieres que..."
    mn "พร้อมแล้วล่ะ ทำไมถึงอยากให้ฉัน..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:201
translate english ayame_quest5_bbfd2dca:

    # mn "¡!"
    mn "!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:202
translate english ayame_quest5_939fa88d:

    # mn "Oh... Dios..."
    mn "อ๊าย... พระเอกเจ้าข้า..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:203
translate english ayame_quest5_c20b430a:

    # ay "Hola amiguito, tenía muchas ganas de volver a verte"
    ay "สวัสดีเจ้าตัวเล็ก ฉันอยากเจอเธอมานานแล้วนะเนี่ย"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:204
translate english ayame_quest5_847d129d:

    # mn "¿Q-Qué...?"
    mn "อ-อะไรนะ...?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:205
translate english ayame_quest5_7fb239c7:

    # ay "A esta posición se le conoce como {b}69{/a}"
    ay "ท่านี้เขาเรียกกันว่า {b}69{/a} ยังไงล่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:206
translate english ayame_quest5_32de5763:

    # mn "Si, creo que he leído sobre esto..."
    mn "อืม รู้สึกว่าฉันเคยอ่านเจอเรื่องนี้อยู่นะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:207
translate english ayame_quest5_6e550b10:

    # ay "En ese caso ya sabes lo que debes hacer... ¿Cierto?"
    ay "ถ้าอย่างนั้นเธอก็คงรู้ใช่ไหมล่ะว่าควรทำยังไง...?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:208
translate english ayame_quest5_096dbb9d:

    # mn "Es momento de ponerlo en práctica"
    mn "ถึงเวลาเอาไปใช้จริงแล้วสินะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:209
translate english ayame_quest5_a6d7771f:

    # ay "Déjame jugar un poco antes de ir por el plato principal..."
    ay "ขอฉันเล่นสนุกสักหน่อยก่อนจะไปจานหลักก็แล้วกัน..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:210
translate english ayame_quest5_892f9ab1:

    # mn "¿Plato principal...?"
    mn "จานหลัก...?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:211
translate english ayame_quest5_c6987890:

    # ay "Céntrate en tu trabajo ahí abajo"
    ay "มีสมาธิกับงานข้างล่างนั่นหน่อยสิ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:212
translate english ayame_quest5_a6bae7d5_1:

    # mn "C-Claro"
    mn "อ-อื้ม"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:218
translate english ayame_quest5_7b5b2259:

    # ay "Mmm..."
    ay "อืม..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:219
translate english ayame_quest5_a6bacdab:

    # ay "Mmmm..."
    ay "อื้มหืม..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:220
translate english ayame_quest5_88e122cb:

    # mn "(Mierda...)"
    mn "(เวรเอ๊ย...)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:221
translate english ayame_quest5_cd6d85d4:

    # ay "(Extrañaba mucho... Este sabor...)"
    ay "(ไม่ได้ลิ้มรสนานเลย... รสชาตินี้แหละ...)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:222
translate english ayame_quest5_32462c4b_2:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:223
translate english ayame_quest5_ddc7f5fb:

    # mn "(Realmente me encanta cuando hace eso)"
    mn "(ฉันชอบเวลาที่เขาทำแบบนั้นจริงๆ นะ)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:224
translate english ayame_quest5_ec2e576a:

    # ay "(Es algo complicado meterlo todo en mi boca...)"
    ay "(มันค่อนข้างยากที่จะอมเข้าไปให้หมดทีเดียวนี่สิ...)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:225
translate english ayame_quest5_37f3f970:

    # ay "..."
    ay "..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:226
translate english ayame_quest5_a66a8daf:

    # ay "(Pero realmente me encanta)"
    ay "(แต่ฉันโคตรชอบเลยล่ะ)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:227
translate english ayame_quest5_7b7cbe18:

    # ay "(Mmm... ciertamente sabe cómo usar la lengua)"
    ay "(อืม... เธอรู้วิธีใช้ลิ้นจริงๆ สินะ)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:228
translate english ayame_quest5_6ec85f21:

    # mn "Aagh... Ayame, estoy muy cerca de..."
    mn "อ๊า... อายาเมะ ฉันใกล้จะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:229
translate english ayame_quest5_4c459014:

    # ay "¿Eh? No, aún no..."
    ay "หือ? เปล่า ยังไม่ใช่ตอนนี้..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:234
translate english ayame_quest5_02cdfe5b:

    # mn "Eh..."
    mn "ฮึ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:235
translate english ayame_quest5_64de7e96:

    # mn "¿Por qué te detuviste?"
    mn "ทำไมถึงหยุดล่ะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:236
translate english ayame_quest5_0d51ae74:

    # ay "Quiero que te vengas en un lugar especial esta vez..."
    ay "ฉันอยากให้เธอไปทำตรงที่พิเศษกว่านี้หน่อย..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:238
translate english ayame_quest5_2cd0a222:

    # mn "¿Estás pensando en...?"
    mn "หรือว่าเธอจะหมายถึง...?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:239
translate english ayame_quest5_5d8c7c02:

    # ay "Sí, ahora podrás venirte todo lo que quieras..."
    ay "ใช่แล้ว ตอนนี้เธอจะแตกออกมาเท่าไหร่ก็ได้ตามใจชอบเลย..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:243
translate english ayame_quest5_d512df19:

    # mn "¡Aaagh!"
    mn "อ๊าาาห์!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:244
translate english ayame_quest5_2f48b358:

    # ay "¡Ahhh... Tu duro, pene...!"
    ay "อ่าาาห์... ควยแข็งๆ ของเธอนี่...!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:245
translate english ayame_quest5_5f4dd8fb:

    # mn "(Aaah, ¿Así se siente la Vagina de Ayame?)"
    mn "(อ่าาห์ ช่องคลอดของอายาเมะเนี่ย ความรู้สึกเป็นแบบนี้นี่เองสินะ?)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:246
translate english ayame_quest5_5282dbcb:

    # mn "(Aaah, se siente muy bien...)"
    mn "(อ่าาห์ ข้างในตัวเธอนี่โคตรฟินเลย...)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:251
translate english ayame_quest5_e768c0db:

    # n "Ayame comienza a mover su trasero, de arrba hacia abajo"
    n "อายาเมะเริ่มขยับสะโพกขึ้นลง"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:252
translate english ayame_quest5_9587ba68:

    # ay "Puedo sentirlo dentro..."
    ay "ฉันรู้สึกได้ถึงมันข้างในเลย..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:253
translate english ayame_quest5_f59e327a:

    # ay "Frotándose dentro de mí... *jadeo*"
    ay "ถูไถอยู่ข้างในตัวฉัน... *ฮ่าห์*"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:254
translate english ayame_quest5_a904af52:

    # mn "¡Tu interior se siente muy bien, Ayame!"
    mn "ข้างในตัวเธอโคตรจะรู้สึกดีเลย อายาเมะ!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:255
translate english ayame_quest5_ccd54bc7:

    # ay "¡Más... Quiero más...!"
    ay "อีก... ฉันต้องการอีก...!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:256
translate english ayame_quest5_a8cdbcdb:

    # ay "¡Lo quiero, lo quiero...!"
    ay "ฉันต้องการมัน ฉันต้องการมัน...!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:259
translate english ayame_quest5_62b1e801:

    # n "Ayame comienza a moverse más rápidamente"
    n "อายาเมะเริ่มขยับเร็วขึ้น"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:260
translate english ayame_quest5_674067a5:

    # ay "Siento como la punta golpea lo más profundo de mí!"
    ay "ฉันรู้สึกได้ว่าส่วนหัวมันชนเข้ากับส่วนที่ลึกที่สุดข้างในตัวฉันเลย!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:261
translate english ayame_quest5_d6c82c3a:

    # ay "Si, se siente tan bien..."
    ay "ใช่แล้ว มันรู้สึกดีมากๆ เลย..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:262
translate english ayame_quest5_41991e7f:

    # mn "Ayame... se siente tan cálido dentro de ti..."
    mn "อายาเมะ... ข้างในตัวเธออุ่นมากเลย..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:263
translate english ayame_quest5_3498317e:

    # ay "Es... ¡Asombroso!"
    ay "มัน... สุดยอดไปเลย!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:264
translate english ayame_quest5_7c2d72ec:

    # ay "¿Hiciste esto antes con tu ex...?"
    ay "เธอกับแฟนเก่า... เคยทำแบบนี้มาก่อนหรือเปล่า?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:265
translate english ayame_quest5_5610f26f:

    # mn "Sí, perdí mi virginidad con ella..."
    mn "ใช่ ฉันเสียความซิงกับเธอน่ะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:266
translate english ayame_quest5_67a33450:

    # mn "(Qué pregunta tan extraña...)"
    mn "(เป็นคำถามที่แปลกชะมัด...)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:267
translate english ayame_quest5_37f3f970_1:

    # ay "..."
    ay "..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:268
translate english ayame_quest5_d09e3b52:

    # ay "Y entre ella y yo..."
    ay "แล้วระหว่างเธอกับฉันเนี่ย..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:269
translate english ayame_quest5_51eb124a:

    # ay "¿Cuál se siente mejor?"
    ay "ระหว่างฉันกับเธอ... ใครรู้สึกดีกว่ากันล่ะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:270
translate english ayame_quest5_fa77d287:

    # mn "Tú, definitivamente tú"
    mn "เธอสิ แน่นอนว่าต้องเป็นเธออยู่แล้ว"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:274
translate english ayame_quest5_d10a497b:

    # n "Ayame comienza a moverse mucho más rápidamente"
    n "อายาเมะเริ่มขยับเร็วยิ่งขึ้นกว่าเดิม"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:275
translate english ayame_quest5_9573ca50:

    # mn "¡Agh!"
    mn "อึก!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:276
translate english ayame_quest5_4895acdf:

    # mn "Se siente tan bien cuando te mueves así"
    mn "เวลาเธอขยับแบบนั้นแล้วมันฟินสุดๆ เลยล่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:277
translate english ayame_quest5_a05cf58e:

    # ay "Aah... Si, ¡Se siente increíble!"
    ay "อ่า... ใช่แล้ว มันรู้สึกสุดยอดมากๆ เลย!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:278
translate english ayame_quest5_e481cbf0:

    # mn "Ah, si sigues así..."
    mn "อ่า ถ้าเธอยังขยับแบบนี้ต่อไปล่ะก็..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:279
translate english ayame_quest5_625699f3:

    # mn "Y-Yo, ya no podré aguantarme..."
    mn "ผ-ผม... ฉันจะไม่ไหวแล้วนะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:280
translate english ayame_quest5_9b00c4df:

    # mn "¡Me voy a venir dentro de ti!"
    mn "ฉันจะแตกใส่ข้างในตัวเธอแล้วนะ!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:281
translate english ayame_quest5_de72194a:

    # ay "¡Sí, vente mucho adentro de mí...!"
    ay "ใช่เลย แตกใส่ข้างในตัวฉันเยอะๆ เลยนะ...!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:282
translate english ayame_quest5_f6c23e83:

    # ay "¡Llename con tu semen!"
    ay "เติมน้ำรักของคุณให้เต็มตัวฉันเลย!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:283
translate english ayame_quest5_6ae63658:

    # mn "¡Agh!, me vengooo!"
    mn "อึก! ฉันจะไม่ไหวแล้ว!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:289
translate english ayame_quest5_515d7ea4:

    # ay "*suspiro*..."
    ay "*ถอนหายใจ*..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:290
translate english ayame_quest5_be6b1789:

    # ay "*suspiro* Eso fue, increíble..."
    ay "*ถอนหายใจ* เมื่อกี้มัน... เหลือเชื่อจริงๆ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:291
translate english ayame_quest5_ede4af17:

    # ay "*suspiro* Dame un segundo, necesito recuperar el aliento..."
    ay "*ถอนหายใจ* ขอเวลาแป๊บนะ ฉันขอตั้งสติก่อน..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:296
translate english ayame_quest5_f35cbec8:

    # "{b}Minutos después{/a}"
    "{b}หลายนาทีต่อมา{/a}"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:306
translate english ayame_quest5_11089680:

    # ay "Muy bien, esta fue tu última lección..."
    ay "เอาล่ะ นี่ก็คือบทเรียนสุดท้ายแล้วนะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:308
translate english ayame_quest5_dc1a7085:

    # ay "Ya no tengo nada más por enseñarte"
    ay "ฉันไม่มีอะไรจะสอนเธออีกแล้วล่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:310
translate english ayame_quest5_b1656de4:

    # ay "A partir de ahora todo dependerá de ti y de cómo te desenvuelvas con las chicas"
    ay "จากนี้ไปทุกอย่างจะขึ้นอยู่กับตัวเธอเองแล้ว ว่าจะเข้ากับพวกผู้หญิงได้ดีแค่ไหน"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:312
translate english ayame_quest5_940604e9:

    # ay "Ya eres todo un hombre"
    ay "ตอนนี้เธอเติบโตเป็นลูกผู้ชายเต็มตัวแล้วนะเนี่ย"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:315
translate english ayame_quest5_2eb66866:

    # mn "Ayame... realmente disfruté pasar todo este tiempo contigo"
    mn "อายาเมะ... ผมมีความสุขมากๆ เลยนะที่ได้ใช้เวลาทั้งหมดนี้ร่วมกับคุณ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:317
translate english ayame_quest5_b8f00c9d:

    # mn "Pero hay algo que no dejo de pensar"
    mn "แต่ว่ามันมีเรื่องนึงที่ผมคาใจจนหยุดคิดไม่ได้เลยล่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:320
translate english ayame_quest5_98984bab:

    # ay "¿Qué cosa?"
    ay "อะไรล่ะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:323
translate english ayame_quest5_5c4ebcf5:

    # mn "¿Por qué te ofreciste para ayudarme con esto?"
    mn "ทำไมคุณถึงเสนอตัวมาช่วยผมเรื่องนี้กันล่ะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:325
translate english ayame_quest5_2c90a99f:

    # mn "No veo a ninguna chica ofreciéndose para algo así y en su momento me pareció extraño que me lo dijeras..."
    mn "ผมไม่เห็นเคยได้ยินว่ามีผู้หญิงที่ไหนเสนอตัวมาทำอะไรแบบนี้เลยแถมตอนนั้นผมก็ยังรู้สึกแปลกๆ ที่คุณมาบอกผมด้วย..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:327
translate english ayame_quest5_37f3f970_2:

    # ay "..."
    ay "..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:329
translate english ayame_quest5_4f0394b4:

    # ay "Suelo aburrirme mucho cuando no trabajo en el local de mi padre"
    ay "ฉันน่ะมักจะเบื่อสุดๆ เวลาที่ไม่ได้ไปทำงานที่ร้านของพ่อน่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:332
translate english ayame_quest5_34843a02:

    # ay "Disfruto trabajar ahí ya que puedo hablar y observar a cientos de clientes"
    ay "ฉันสนุกกับการทำงานที่นั่นนะ เพราะได้พูดคุยและสังเกตลูกค้าร้อยแปดพันเก้าเลยล่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:334
translate english ayame_quest5_aeaedd21:

    # ay "Cada uno tiene una historia o algo por contar..."
    ay "ทุกคนต่างก็มีเรื่องราวหรืออะไรให้เล่าให้ฟังทั้งนั้น..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:336
translate english ayame_quest5_f9cbedad:

    # ay "A ti comencé a observarte desde que llegaste a la aldea..."
    ay "ฉันเริ่มสังเกตเห็นเธอตั้งแต่ที่เธอเพิ่งมาถึงหมู่บ้านแล้วล่ะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:338
translate english ayame_quest5_a965026d:

    # ay "Antes eras un chico un poco más tímido y reservado"
    ay "แต่ก่อนเธอเป็นเด็กผู้ชายที่ค่อนข้างขี้อายแล้วก็เก็บตัวมากกว่านี้น่ะนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:340
translate english ayame_quest5_959d423b:

    # ay "Pero a medida que crecias te terminate convirtiendo en un hombre bastante atractivo..."
    ay "แต่พอเธอโตขึ้น เธอกลับกลายเป็นผู้ชายที่ดูมีเสน่ห์เอามากๆ เลยล่ะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:342
translate english ayame_quest5_be38fe90:

    # ay "Y la verdad es que en un principio pensé en ayudarte como una forma de pasar el rato con alguien fuera del trabajo"
    ay "แล้วความจริงก็คือ ตอนแรกฉันคิดจะช่วยเธอเพื่อฆ่าเวลาและหาเพื่อนคุยแก้เบื่อเวลานอกงานน่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:344
translate english ayame_quest5_f8850556:

    # ay "Ya que aunque hable con cientos de personas todos los días la verdad es que son solo clientes..."
    ay "เพราะถึงแม้ฉันจะได้คุยกับผู้คนนับร้อยทุกวัน แต่พวกเขาก็เป็นแค่ลูกค้า..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:346
translate english ayame_quest5_b4152ecb:

    # ay "No tengo muchas amistades..."
    ay "ฉันเองก็ไม่ได้มีเพื่อนเยอะหรอค...ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:348
translate english ayame_quest5_c362c836:

    # ay "Es por eso que disfruté tanto el estar contigo"
    ay "นั่นแหละคือเหตุผลว่าทำไมฉันถึงมีความสุขที่ได้อยู่กับเธอขนาดนี้"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:351
translate english ayame_quest5_db2ca81c:

    # mn "Vaya, no sabía que te sentías así"
    mn "โห ผมไม่รู้เลยนะเนี่ยว่าคุณรู้สึกแบบนั้น"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:353
translate english ayame_quest5_cf3908f2:

    # mn "Ahora todo tiene sentido"
    mn "งั้นก็เข้าใจทุกอย่างแจ่มแจ้งเลย"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:356
translate english ayame_quest5_0edd069e:

    # ay "Sí, es por eso que quiero decirte que no dejes de visitarme"
    ay "ใช่แล้ว เพราะงั้นฉันถึงอยากจะบอกเธอว่าอย่าหยุดมาเยี่ยมฉันนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:358
translate english ayame_quest5_f6e36801:

    # ay "Podemos seguir poniendo en práctica todo lo que aprendiste en nuestras sesiones"
    ay "เราจะได้เอาสิ่งที่เธอเรียนรู้จากบทเรียนของเราไปใช้จริงกันต่อได้ยังไงล่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:361
translate english ayame_quest5_218bab87:

    # mn "Ten por seguro que lo haré"
    mn "วางใจได้เลยครับ ผมไปหาแน่"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:363
translate english ayame_quest5_16b17e9c:

    # mn "Después de esto acabas de convertirte en alguien muy especial para mí"
    mn "หลังจากนี้ไป เธอได้กลายเป็นคนสำคัญมากๆ สำหรับผมไปซะแล้วล่ะครับ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:366
translate english ayame_quest5_41712564:

    # ay "El sentimiento es mutuo"
    ay "ฉันก็รู้สึกเหมือนกันจ่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:368
translate english ayame_quest5_2fbac73f:

    # ay "Quisiera quedarme por más tiempo pero debo volver a casa"
    ay "ฉันก็อยากจะอยู่ต่ออีกหน่อยหรอกนะ แต่ต้องกลับบ้านแล้วล่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:370
translate english ayame_quest5_01996b64:

    # ay "Sí quieres puedes dormir aquí, la noche está paga"
    ay "ถ้าเธออยากจะนอนค้างที่นี่ก็ได้นะ ฉันจ่ายค่าห้องไว้เรียบร้อยแล้วล่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:373
translate english ayame_quest5_f9b4da99:

    # mn "Mmm... Creo que voy a tomarte la palabra..."
    mn "อืม... งั้นผมขอรับคำชวนนั้นก็แล้วกันนะครับ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:375
translate english ayame_quest5_23fa817f:

    # mn "Tengo un asunto que resolver con la cama..."
    mn "พอดีผมมีเรื่องที่ต้องสะสางกับเตียงนอนหน่อยน่ะครับ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:378
translate english ayame_quest5_67f5eb65:

    # ay "Ehh.. okay..."
    ay "เอ๊ะ... ได้สิ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:383
translate english ayame_quest5_3a2734cb:

    # n "Ayame vuelve a vestirse con su ropa casual"
    n "อายาเมะสวมชุดลำลองของเธอกลับเข้าไปใหม่อีกครั้ง"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:386
translate english ayame_quest5_c0d0bfb1:

    # ay "Nos vemos, [MN]"
    ay "แล้วเจอกันนะ [MN]"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:389
translate english ayame_quest5_487a8ab1:

    # mn "Adiós, Ayame, nos vemos"
    mn "ไว้เจอกันครับ อายาเมะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:393
translate english ayame_quest5_6a15e67e:

    # n "Ayame sale de la habitación"
    n "อายาเมะเดินออกจากห้องไป"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:398
translate english ayame_quest5_d4548143:

    # mn "Mmm, sí vamos a volver aquí creo que debería de pagar la habitación la próxima vez..."
    mn "อืม ถ้าพวกเราจะกลับมาที่นี่อีกครั้งล่ะก็ ผมว่าคราวหน้าเธอควรจะเป็นคนจ่ายค่าห้องนะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:400
translate english ayame_quest5_51e5787a:

    # mn "No es justo que ella pague y ni siquiera se quede a dormir"
    mn "ไม่ยุติธรรมเลยที่เธอเป็นคนจ่ายแต่กลับไม่ได้นอนค้างด้วยซ้ำ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:402
translate english ayame_quest5_b43ed847:

    # mn "Dejando eso de lado, estoy algo cansado"
    mn "แต่ช่างเรื่องนั้นก่อนเถอะ ผมเริ่มจะง่วงแล้วสิ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:405
translate english ayame_quest5_dfd55641:

    # mn "Y esa cama no para de seducirme..."
    mn "แถมเตียงนั่นก็เอาแต่เย้ายวนผมอยู่เรื่อยเลย..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:410
translate english ayame_quest5_f9d9785a:

    # n "[MN] pasó toda noche durmiendo en la habitación de hotel"
    n "[MN] ใช้เวลาตลอดทั้งคืนนอนหลับอยู่ในห้องพักของโรงแรม"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest5.rpy:411
translate english ayame_quest5_a8109037:

    # n "Cuando se hizo de mañana, salió del Hotel"
    n "พอล่วงเข้ายามเช้า เขาก็ออกจากโรงแรมไป"
