# TODO: Translation updated at 2024-12-01 21:25

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:6
translate english arc2_hinata_quest1_fc4a01fa:

    # n "Unos días antes de que comiencen los Exámenes Chunin, [MN] se encontraba de paseo en en las afueras de la Aldea de la Hoja"
    n "ไม่กี่วันก่อนการสอบจูนินจะเริ่มขึ้น [MN] กำลังเดินเล่นอยู่แถบชานหมู่บ้านโคโนฮะงากูเร"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:7
translate english arc2_hinata_quest1_93b937aa:

    # n "Al llegar al Río que estaba cerca de la Aldea, [MN] hechó de ver una figura muy familiar a lo lejos"
    n "เมื่อเดินมาถึงแม่น้ำใกล้หมู่บ้าน [MN] ก็สังเกตเห็นร่างที่คุ้นตามากๆ อยู่ไกลๆ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:8
translate english arc2_hinata_quest1_4ef47ecd:

    # mn "Un momento... Esa es..."
    mn "เดี๋ยวก่อนนะ... นั่นมัน..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:9
translate english arc2_hinata_quest1_5aa6ea83:

    # d "¿[MN]?"
    d "[MN]?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:10
translate english arc2_hinata_quest1_ac935fd4:

    # mn "¡Si, es ella!"
    mn "ใช่แล้ว เธอจริงๆ ด้วย!"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:17
translate english arc2_hinata_quest1_4f74085a:

    # hm "¡[MN]! Hace mucho tiempo que no te veía"
    hm "[MN]! ไม่ได้เจอกันนานเลยนะเนี่ย"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:18
translate english arc2_hinata_quest1_e0d61ccc:

    # n "La figura que veía a lo lejos era Himawari"
    n "ร่างที่อยู่ไกลออกไปนั้นคือฮิมาวาริ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:19
translate english arc2_hinata_quest1_9c4c5f96:

    # n "La hija de Naruto, el Séptimo Hokage"
    n "ลูกสาวของนารูโตะ โฮคาเงะรุ่นที่เจ็ด"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:20
translate english arc2_hinata_quest1_2f7ce3bf:

    # hm "Has cambiado mucho, ¿De verdad eres tú?"
    hm "เธอเปลี่ยนไปเยอะมากเลยนะ นี่คุณจริงๆ เหรอเนี่ย?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:31
translate english arc2_hinata_quest1_da3c23ad:

    # mn "Himawari, ¿Cómo has estado?"
    mn "ฮิมาวาริ สบายดีไหม?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:32
translate english arc2_hinata_quest1_e2382f36:

    # mn "Hace mucho no te veía, has crecido mucho"
    mn "ไม่ได้เจอกันซะนานเลยนะ โตขึ้นเยอะเลยนี่"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:34
translate english arc2_hinata_quest1_a18a866e:

    # hm "Jeje, tú también has cambiado mucho [MN]"
    hm "ฮ่าๆ พี่เองก็เปลี่ยนไปเยอะเหมือนกันนะ [MN]"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:39
translate english arc2_hinata_quest1_13b794e9:

    # hm "¿Eh? Un momento"
    hm "เอ๊ะ? เดี๋ยวก่อนนะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:40
translate english arc2_hinata_quest1_2860ada7:

    # hm "¿Tu ojo siempre ha sido de ese color?"
    hm "ตาสของพี่เป็นสีนั้นมาตั้งแต่เมื่อก่อนแล้วเหรอ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:42
translate english arc2_hinata_quest1_1cc62e9a:

    # mn "Oh, esto jaja... Es una larga historia"
    mn "อ๋อ อันนี้เหรอ ฮ่าๆ... มันเรื่องยาวน่ะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:44
translate english arc2_hinata_quest1_49c06911:

    # mn "Quizás te cuente otro día"
    mn "ไว้ค่อยเล่าวันหลังแล้วกันนะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:48
translate english arc2_hinata_quest1_b24c8325:

    # hm "Cuéntame ahora, vamos"
    hm "เล่าตอนนี้เลยสิคะ น่า นะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:50
translate english arc2_hinata_quest1_e322a217:

    # hm "Hoy tengo tiempo libre"
    hm "วันนี้หนูว่างพอดีเลย"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:51
translate english arc2_hinata_quest1_86d04026:

    # mn "Jaja... Quizás otro día,, de veras, hoy tengo otros asuntos que atender..."
    mn "ฮ่าๆ... ไว้โอกาสหน้าจริงๆ เถอะ วันนี้พี่มีธุระต้องไปทำต่อน่ะ..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:52
translate english arc2_hinata_quest1_fd4cdad2:

    # mn "Me estoy preparando para los Exámenes Chunin"
    mn "พี่กำลังเตรียมตัวสำหรับการสอบจูนินอยู่น่ะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:55
translate english arc2_hinata_quest1_c40d5b86:

    # hm "¿Participarás en ellos?"
    hm "พี่จะเข้าร่วมสอบด้วยเหรอคะ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:57
translate english arc2_hinata_quest1_f8d3d8ac:

    # hm "Finalmente! ¿Porqué no lo hacías los años anteriores?" with vpunch
    hm "ในที่สุด! แล้วทำไมปีก่อนๆ ถึงไม่ยอมสอบล่ะคะ?" with vpunch

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:59
translate english arc2_hinata_quest1_eb9299e3:

    # mn "Bueno... También es una larga historia jaja..."
    mn "เอ่อ... นั่นก็เรื่องยาวเหมือนกันแหละน่า ฮ่าๆ..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:62
translate english arc2_hinata_quest1_0487c566:

    # hm "Hmm... Está bien..."
    hm "อืม... ก็ได้ค่ะ..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:64
translate english arc2_hinata_quest1_00ffeee3:

    # mn "Jaja... Esa parte de tí no ha cambiado mucho, ¿No?"
    mn "ฮ่าๆ... นิสัยมุมนั้นของเธอนี่ไม่เปลี่ยนไปเลยนะเนี่ย?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:66
translate english arc2_hinata_quest1_cd896075:

    # mn "Aún pareces una niña..."
    mn "ยังดูเหมือนเด็กอยู่เลยแท้ๆ..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:69
translate english arc2_hinata_quest1_6d6085a6:

    # hm "¿Qué? Para nada"
    hm "หา? ไม่จริงซะหน่อย"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:71
translate english arc2_hinata_quest1_c7eb231f:

    # hm "Ya soy una adulta hecha y derecha"
    hm "ตอนนี้หนูโตเป็นผู้ใหญ่เต็มตัวแล้วนะคะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:74
translate english arc2_hinata_quest1_7302b549:

    # hm "Mejor dime, ¿Porqué no viniste a la fiesta de mis 18 años?"
    hm "ว่าแต่ ทำไมพี่ถึงไม่ไปงานวันเกิดอายุครบ 18 ปีของหนู ล่ะคะ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:75
translate english arc2_hinata_quest1_48bced93:

    # hm "Te enviamos una invitación pero no llegaste"
    hm "พวกเราส่งบัตรเชิญไปให้แล้วนะ แต่พี่ไม่เห็นมาเลย"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:78
translate english arc2_hinata_quest1_7ea14aaa:

    # mn "¿De verdad? No recibí ninguna carta, de veras"
    mn "เหรอ? พี่ไม่ได้รับจดหมายอะไรเลยนะ เอาจริงดิ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:81
translate english arc2_hinata_quest1_487bc9d6:

    # hm "..."
    hm "..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:83
translate english arc2_hinata_quest1_cd9455aa:

    # hm "¿En serio?"
    hm "จริงเหรอเนี่ย?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:87
translate english arc2_hinata_quest1_0b50d37e:

    # mn "Si jaja, ¿Porqué te mentiría?"
    mn "จริงสิ ฮ่าๆ พี่จะโกหกเธอไปทำไมล่ะ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:88
translate english arc2_hinata_quest1_487bc9d6_1:

    # hm "..."
    hm "..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:91
translate english arc2_hinata_quest1_16f98e07:

    # hm "Bueno, está bien..."
    hm "งะ... งั้นก็ได้ค่ะ..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:93
translate english arc2_hinata_quest1_e0355d06:

    # hm "Pero aún así, necesito una compensación"
    hm "แต่ยังไงซะ หนูต้องขอค่าทำขวัญหน่อยนะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:97
translate english arc2_hinata_quest1_4c1f357b:

    # mn "¿U-Una compensación?"
    mn "ค-ค่าทำขวัญเหรอ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:100
translate english arc2_hinata_quest1_2e2d7b7a:

    # mn "Bueno, ¿Qué deseas?"
    mn "ว่าแต่... เธออยากได้อะไรล่ะ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:103
translate english arc2_hinata_quest1_72797253:

    # hm "Tendrás que hacernos una visita a nuestra casa"
    hm "พี่ต้องมาเยี่ยมพวกเราที่บ้านนะคะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:105
translate english arc2_hinata_quest1_60dd7325:

    # hm "¿Qué te parece el próximo {b}Domingo{/a}?"
    hm "วัน{b}อาทิตย์{/a}หน้าเป็นไงคะ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:106
translate english arc2_hinata_quest1_5fda18d8:

    # hm "A Mamá y a Papá le gustaría que los visitaras"
    hm "คุณแม่กับคุณพ่ออยากให้พี่แวะไปเยี่ยมมากๆ เลยล่ะค่ะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:108
translate english arc2_hinata_quest1_d6bfad2b:

    # hm "Así como en los viejos tiempos"
    hm "เหมือนสมัยก่อนเลย"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:111
translate english arc2_hinata_quest1_0c32ecec:

    # mn "¿A tu papá, el séptimo estará en casa?"
    mn "พ่อของเธอ ท่านโฮคาเงะรุ่นที่ 7 จะอยู่บ้านด้วยเหรอ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:112
translate english arc2_hinata_quest1_d7004708:

    # hm "Si, Mamá lo obligó a que no trabajara este Domingo por su-"
    hm "ค่ะ คุณแม่บังคับให้ท่านหยุดงานวันอาทิตย์นี้น่ะค่ะ เพราะว่า..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:114
translate english arc2_hinata_quest1_2390ce65:

    # hm "Ah, este... Porque no ha parado de trabajar jaja..." with vpunch
    hm "อ่า คือว่า... เพราะว่าท่านเอาแต่ทำงานไม่ยอมหยุดเลยน่ะสิคะ ฮ่าๆ..." with vpunch

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:116
translate english arc2_hinata_quest1_5502cecb:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:118
translate english arc2_hinata_quest1_415fd9a0:

    # mnn "(La casa del Séptimo Hokage...)"
    mnn "(บ้านของท่านโฮคาเงะ...)"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:119
translate english arc2_hinata_quest1_2400f78d:

    # mnn "(Hace unos meses que no voy de visita)"
    mnn "(ก็หลายเดือนแล้วสินะที่ฉันไม่ได้มาเหยียบที่นี่)"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:120
translate english arc2_hinata_quest1_07821919:

    # mnn "(También recuerdo que le prometí a Hinata que los visitaría...)"
    mnn "(แถมฉันยังจำได้ด้วยว่าเคยสัญญาไว้ว่าจะแวะไปเยี่ยมฮินาตะ...)"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:121
translate english arc2_hinata_quest1_f36c94b1:

    # mnn "(Y si está el Hokage tendría una oportunidad de hablar con él...)"
    mnn "(แล้วถ้าโฮคาเงะอยู่ที่นั่นด้วย ฉันก็จะมีโอกาสได้คุยกับเขาพอดี...)"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:124
translate english arc2_hinata_quest1_08e494ff:

    # mn "Muy bien, me convenciste, acepto la invitación"
    mn "ก็ได้ เธอกล่อมฉันสำเร็จแล้ว ฉันตอบรับคำชวนก็แล้วกัน"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:126
translate english arc2_hinata_quest1_208b4d0e:

    # hm "¡¿De verdad?!" with vpunch
    hm "จริงเหรอคะ?!" with vpunch

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:128
translate english arc2_hinata_quest1_03694856:

    # hm "Muy bien, entonces te estarémos esperando"
    hm "งั้นพวกเราจะรอนะคะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:130
translate english arc2_hinata_quest1_c1d2a317:

    # hm "No puedes faltar, ¿Entendido?"
    hm "ห้ามเบี้ยวเด็ดขาดเลยนะ เข้าใจไหมคะ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:132
translate english arc2_hinata_quest1_9c57cdc1:

    # hm "¿Me lo prometes?"
    hm "สัญญานะคะ?"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:134
translate english arc2_hinata_quest1_d07562b7:

    # mn "Si, claro jaja... Te lo prometo"
    mn "จ้า แน่นอนอยู่แล้ว ฮ่าๆ... พี่สัญญา"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:137
translate english arc2_hinata_quest1_dc2b6c5b:

    # hm "Muy bien, entonces ya te dejo tranquilo"
    hm "งั้นแค่นี้ก่อนนะคะ ปล่อยให้พี่อยู่คนเดียวดีกว่า"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:139
translate english arc2_hinata_quest1_78c3cbd4:

    # hm "Estaré esperando que me cuentes tus historias"
    hm "หนูรอฟังเรื่องเล่าจากพี่อยู่นะคะ"

# game/scripts/History/SecundaryStory/Hinata/Arco2/arc2_hinata_quest1.rpy:142
translate english arc2_hinata_quest1_66b5ef59:

    # n "Himawari se aleja caminando, dejando a [MN] en el Río"
    n "ฮิมาวาริเดินจากไป ปล่อยให้ [MN] อยู่ริมแม่น้ำเพียงลำพัง"

