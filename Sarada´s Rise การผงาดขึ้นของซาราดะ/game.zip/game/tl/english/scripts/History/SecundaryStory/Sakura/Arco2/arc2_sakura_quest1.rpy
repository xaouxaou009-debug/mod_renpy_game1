# TODO: Translation updated at 2024-11-29 23:49

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:8
translate english arc2_sakura_quest1_77941222:

    # n "[MN] se dirige al Hospital"
    n "[MN] มุ่งหน้าไปยังโรงพยาบาล"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:9
translate english arc2_sakura_quest1_3195ca2e:

    # n "Pero justo antes de entrar..."
    n "แต่ทว่า ก่อนที่จะทันได้ก้าวเข้าไป..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:13
translate english arc2_sakura_quest1_bbfd2dca:

    # mn "¡!"
    mn "!"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:17
translate english arc2_sakura_quest1_499cb090:

    # d "¿De nuevo? Ya estoy harta de que pasen estas cosas..."
    d "อีกแล้วเหรอ? ฉันละเหนื่อยใจกับเรื่องแบบนี้จริง ๆ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:18
translate english arc2_sakura_quest1_4ba69756:

    # mn "(Maldición, ¿De nuevo choqué con alguien?)"
    mn "(ให้ตายสิ นี่ฉันเดินชนใครเข้าอีกแล้วเหรอเนี่ย?)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:19
translate english arc2_sakura_quest1_7669e254:

    # mn "(¿Quién es esta vez? Debo disculparme lo antes posible)"
    mn "(คราวนี้ใครอีกล่ะ? ต้องรีบขอโทษทันทีแล้ว)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:20
translate english arc2_sakura_quest1_85b77973:

    # mn "(...)"
    mn "(...)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:24
translate english arc2_sakura_quest1_0008107b:

    # mn "(Aunque... Esto es demasido suave, ¿Quien será?)"
    mn "(แต่ว่า... นุ่มขนาดนี้ จะเป็นใครกันนะ?)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:25
translate english arc2_sakura_quest1_1523fe20:

    # d "..."
    d "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:26
translate english arc2_sakura_quest1_5397f912:

    # d "¿Lo estás disfrutando?"
    d "กำลังเพลิดเพลินเลยสิ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:27
translate english arc2_sakura_quest1_88690cc3:

    # mn "(¡Ah! Mierda, debo quitarme antes de que...)"
    mn "(อ๊ะ! ให้ตายสิ ต้องรีบขยับออกมาก่อนที่...)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:34
translate english arc2_sakura_quest1_bb42e426:

    # "¡!" with vpunch
    "!" with vpunch

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:35
translate english arc2_sakura_quest1_a20cefa7:

    # "..."
    "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:36
translate english arc2_sakura_quest1_8161e44d:

    # n "-{b}Más tarde, en una habitación del hospital{/a}-"
    n "-{b}ต่อมา ในห้องพักห้องหนึ่งของโรงพยาบาล{/a}-"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:37
translate english arc2_sakura_quest1_ecdfba4f:

    # mn "Mmmm..."
    mn "อืมมม..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:38
translate english arc2_sakura_quest1_37529391:

    # mn "¿Q-Qué?"
    mn "อั... อะไรกัน?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:40
translate english arc2_sakura_quest1_f6865c9f:

    # d "Oh, ¿Ya estás despertando? Que alegría"
    d "อ้าว ฟื้นแล้วเหรอจ๊ะ? ดีจังเลย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:44
translate english arc2_sakura_quest1_b8cc60d5:

    # mn "Mmmm... ¿Sakura?"
    mn "อืมมม... ซากุระเหรอ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:45
translate english arc2_sakura_quest1_f2f88464:

    # sk "Buenos días, ¿Cómo te encuentras?"
    sk "อรุณสวัสดิ์จ้ะ รู้สึกยังไงบ้าง?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:46
translate english arc2_sakura_quest1_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:47
translate english arc2_sakura_quest1_35e4ae4a:

    # mn "... Me duele la cabeza..."
    mn "... ปวดหัวจัง..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:48
translate english arc2_sakura_quest1_47b462a7:

    # sk "¿Quieres que traiga una pastilla para el dolor de cabeza?"
    sk "อยากให้ฉันไปเอายาแก้ปวดให้ไหม?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:49
translate english arc2_sakura_quest1_ede4a95c:

    # sk "¿O te traigo algo más?"
    sk "หรืออยากได้อะไรอย่างอื่นแทน?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:50
translate english arc2_sakura_quest1_32462c4b_1:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:51
translate english arc2_sakura_quest1_7d39dc93:

    # mn "No, así está bien... Gracias..."
    mn "ไม่เป็นไรหรอก... ขอบใจนะ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:52
translate english arc2_sakura_quest1_78ea7472:

    # mn "¿Qué ocurrió?"
    mn "เกิดอะไรขึ้นน่ะ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:53
translate english arc2_sakura_quest1_4d1f2105:

    # sk "Eso te quería preguntar"
    sk "ฉันก็กำลังจะถามเธอเรื่องนั้นอยู่พอดี"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:54
translate english arc2_sakura_quest1_8b201ca6:

    # sk "Hanna me dijo que estabas desmayado en la entrada, y te tuvimos que traer aquí"
    sk "ฮันนะบอกฉันว่าเธอหมดสติอยู่ตรงทางเข้า พวกเราก็เลยต้องพาเธอมาที่นี่"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:55
translate english arc2_sakura_quest1_8a85f35e:

    # sk "¿Recuerdas algo de lo que pasó?"
    sk "จำอะไรที่เกิดขึ้นได้บ้างไหมล่ะ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:56
translate english arc2_sakura_quest1_32462c4b_2:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:58
translate english arc2_sakura_quest1_b0828738:

    # mn "(Recuerdo... Chocar con alguien en la entrada...)"
    mn "(จำได้ว่า... เดินชนใครเข้าสักคนตรงทางเข้า...)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:59
translate english arc2_sakura_quest1_8b788cef:

    # mn "(¿Me habrá golpeado?)"
    mn "(เขาเล่นงานฉันเหรอเนี่ย?)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:60
translate english arc2_sakura_quest1_357af327:

    # mn "(¿Y quién era? No lo recuerdo...)"
    mn "(แล้วมันเป็นใครกันล่ะ? จำไม่ได้เลยแฮะ...)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:61
translate english arc2_sakura_quest1_6eaaa5d4:

    # mn "(Aún así, no puedo decirle lo que pasó...)"
    mn "(ถึงอย่างนั้น ก็บอกเธอเรื่องที่เกิดขึ้นไม่ได้หรอก...)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:63
translate english arc2_sakura_quest1_eef80194:

    # mn "N-No lo sé... "
    mn "มะ-ไม่รู้สิ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:64
translate english arc2_sakura_quest1_85ba4ef3:

    # mn "No lo recuerdo..."
    mn "ฉันจำอะไรไม่ได้เลย..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:65
translate english arc2_sakura_quest1_cb40e7c1:

    # sk "Bueno, no pasa nada"
    sk "งั้นก็ไม่เป็นไรจ้ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:66
translate english arc2_sakura_quest1_1b457de6:

    # sk "Solo, espero que no te estés sobre esforzando, ¿Estás comiendo bien?"
    sk "แค่หวังว่าเธอจะไม่ได้หักโหมจนเกินไปนะ ช่วงนี้กินข้าวครบทุกมื้อหรือเปล่าเนี่ย?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:67
translate english arc2_sakura_quest1_32462c4b_3:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:68
translate english arc2_sakura_quest1_6ef4fb81:

    # mn "Creo que... No realmente"
    mn "คิดว่า... น่าจะอย่างนั้นมั้ง"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:69
translate english arc2_sakura_quest1_c323d466:

    # sk "Lo suponía, así era cuando eras un niño también"
    sk "ฉันว่าแล้วเชียว สมัยเด็กๆ เธอก็เป็นแบบนี้เหมือนกัน"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:70
translate english arc2_sakura_quest1_a46d243b:

    # sk "No comas solamente ramen, ¿Quieres?"
    sk "อย่ากินแต่ราเม็งอย่างเดียวล่ะ รู้ไหม?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:71
translate english arc2_sakura_quest1_e2fef0ac:

    # mn "Si, está bien, no te preocupes, trataré de comer mejor..."
    mn "ครับ รู้แล้วครับ ไม่ต้องห่วง เดี๋ยวผมจะพยายามกินให้อิ่มท้องกว่านี้แล้วกัน..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:72
translate english arc2_sakura_quest1_8749345c:

    # sk "Eso espero, si no, ya sabes que puedes contar conmigo"
    sk "หวังว่าจะอย่างนั้นนะ ถ้าไม่ไหวล่ะก็ รู้ใช่ไหมว่าพึ่งพาฉันได้เสมอ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:73
translate english arc2_sakura_quest1_803c5154:

    # sk "Puedes venir a mi casa, siempre has sido bienvenido"
    sk "แวะมาที่บ้านฉันสิ บ้านเราต้อนรับเธอเสมออยู่แล้ว"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:74
translate english arc2_sakura_quest1_f93ca0bb:

    # sk "Podemos cenar en familia con Sarada, como en los viejos tiempos"
    sk "เราจะได้กินมื้อเย็นด้วยกันกับซาราดะ เหมือนสมัยก่อนด้วยไง"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:75
translate english arc2_sakura_quest1_32462c4b_4:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:76
translate english arc2_sakura_quest1_0ed11c36:

    # mn "Me gusta la idea"
    mn "ฟังดูเข้าท่าดีนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:77
translate english arc2_sakura_quest1_b57d3d12:

    # sk "Bien, es una promesa, ¿Si?"
    sk "ดีล่ะ งั้นสัญญาแล้วนะ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:78
translate english arc2_sakura_quest1_cae9aa1e:

    # mn "Claro jaja"
    mn "แน่นอนครับ ฮ่าๆ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:79
translate english arc2_sakura_quest1_954d9ab1:

    # sk "Ahora, ¿Ya te sientes mejor?"
    sk "แล้วตอนนี้รู้สึกดีขึ้นหรือยังล่ะจ๊ะ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:80
translate english arc2_sakura_quest1_d28eebe9:

    # mn "Si, ya me puedo levantar"
    mn "ครับ ตอนนี้ลุกไหวแล้วล่ะครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:83
translate english arc2_sakura_quest1_6b7fe792:

    # n "[MN] se levanta de la cama"
    n "[MN] ลุกขึ้นจากเตียง"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:91
translate english arc2_sakura_quest1_9fa64dbf:

    # mn "Muchas gracias por cuidarme, y lo siento por las molestias que causé"
    mn "ขอบคุณมากนะครับที่ช่วยดูแล แล้วก็ขอโทษด้วยที่ทำให้ลำบากครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:92
translate english arc2_sakura_quest1_86de0830:

    # sk "No hay problema, ese es mi trabajo después de todo"
    sk "ไม่เป็นไรจ้ะ มันเป็นหน้าที่ของฉันอยู่แล้ว"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:93
translate english arc2_sakura_quest1_32849dc7:

    # mn "Aún así gracias"
    mn "ถึงอย่างนั้นก็ขอบคุณมากนะครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:94
translate english arc2_sakura_quest1_5874c065:

    # mn "Entonces, ¿Seguimos con los exámenes del Karugan?"
    mn "งั้นเรามาตรวจเรื่องเนตรคารูกันต่อเลยดีไหมครับ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:95
translate english arc2_sakura_quest1_55000bc2:

    # sk "Si claro, solo dame unos momentos, hoy vendrá alguien a ayudarnos"
    sk "ได้สจ๊ะ รอแป๊บนะ พอดีวันนี้จะมีคนมาช่วยเราด้วยล่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:96
translate english arc2_sakura_quest1_7233a41e:

    # mn "¿Ah si, de quién se trata?"
    mn "อ่าวเหรอครับ ใครเหรอครับ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:97
translate english arc2_sakura_quest1_3e0f97cb:

    # sk "Se trata de mi maestra, le comenté sobre el {b}Karugan{/a} y dijo que quería verlo con sus propios ojos"
    sk "อาจารย์ของฉันเอง พอฉันเล่าเรื่อง {b}คารูกัน{/a} ให้ฟัง ท่านก็บอกว่าอยากจะมาเห็นด้วยตาตัวเองน่ะจ้ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:98
translate english arc2_sakura_quest1_1f892d76:

    # sk "Con sus conocimientos quizás hagamos más avances en los exámenes"
    sk "ด้วยความรู้ของท่าน บางทีเราอาจจะมีความคืบหน้าในการตรวจมากขึ้นก็ได้นะจ๊ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:99
translate english arc2_sakura_quest1_880ffac0:

    # mn "Bien, supongo que dos cabezas piensan mejor que una"
    mn "ครับ ยังไงสองหัวก็ดีกว่าหัวเดียวอยู่แล้วล่ะครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:100
translate english arc2_sakura_quest1_c35e1c5d:

    # sk "Así es"
    sk "นั่นสินะจ๊ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:102
translate english arc2_sakura_quest1_678007f6:

    # "{b}Alguien toca la puerta{/a}"
    "{b}มีเสียงเคาะประตูที่ด้านนอก{/a}"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:103
translate english arc2_sakura_quest1_c78dab05:

    # sk "Oh, seguramente es ella"
    sk "อ๊ะ สงสัยจะเป็นท่านอาจารย์แน่เลย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:104
translate english arc2_sakura_quest1_57fec694:

    # sk "Dame un momento, iré a abrirle"
    sk "รอแป๊บทเรวนะ เดี๋ยวฉันไปเปิดประตูเองจ้ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:106
translate english arc2_sakura_quest1_a5d96515:

    # n "Sakura se dirige a la puerta"
    n "ซากุระเดินไปที่ประตู"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:107
translate english arc2_sakura_quest1_b49799e2:

    # n "Cuando la abre..."
    n "เมื่อเธอเปิดประตูออก..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:119
translate english arc2_sakura_quest1_248dc2c2:

    # d "¡TÚ!" with vpunch
    d "แกนี่เอง!" with vpunch

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:122
translate english arc2_sakura_quest1_b7393c54:

    # mn "¡¿E-Eh?!"
    mn "อ-อะไรเนี่ย?!"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:126
translate english arc2_sakura_quest1_504f2621:

    # d "Tú fuiste quien chocó conmigo esta tarde, ¡¿Tú eres [MN]?!"
    d "แกนี่เองคนที่ชนฉันเมื่อตอนบ่าย แกใช่ [MN] สินะ?!"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:130
translate english arc2_sakura_quest1_faeb0a9b:

    # mn "(¡E-Es la quinta Hokage, ¡¿Era ella?!)"
    mn "(ฮ-ท่านโฮคาเงะรุ่นที่ 5 คนนั้นเหรอเนี่ย?!)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:131
translate english arc2_sakura_quest1_929886cf:

    # mn "(¿De verdad mi cara estuvo entre sus pechos?)"
    mn "(หน้าฉันเข้าไปซุกอยู่ระหว่างหน้าอกของเธอจริงๆ เหรอเนี่ย?)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:132
translate english arc2_sakura_quest1_99aa8307:

    # mn "(Maldición, ahora qué hago?)"
    mn "(ซวยแล้ว เอาไงดีวะเนี่ย?)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:135
translate english arc2_sakura_quest1_530231ec:

    # sk "¿Ya se conocían?"
    sk "เอ๊ะ รู้จักกันมาก่อนแล้วเหรอจ๊ะ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:137
translate english arc2_sakura_quest1_2dfe64bf:

    # n "Tsunade le cuenta a Sakura y a [MN] lo que pasó antes"
    n "ซึนาเดะเล่าเรื่องที่เกิดขึ้นก่อนหน้านี้ให้ซากุระกับ [MN] ฟัง"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:140
translate english arc2_sakura_quest1_14480b96:

    # mn "¡D-DE VERDAD LO SIENTO MUCHO!" with vpunch
    mn "ผ-ผมขอโทษจริงๆ ครับ!" with vpunch

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:141
translate english arc2_sakura_quest1_94acab77:

    # mn "¡No recuerdo lo que pasó, pero le aseguro que fue un accidente!" with vpunch
    mn "ผมจำไม่ได้ว่าเกิดอะไรขึ้น แต่ผมยืนยันได้เลยว่ามันเป็นอุบัติเหตุครับ!" with vpunch

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:142
translate english arc2_sakura_quest1_f998c632:

    # ts "¿Estás seguro de eso? Parecías disfrutar tener tu horrenda cara en mis tetas"
    ts "แน่ใจเหรอ? ดูท่าทางนายจะเคลิ้มตอนที่เอาหน้าทุเรศๆ นั่นซุกอกฉันอยู่ไม่น้อยเลยนี่"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:143
translate english arc2_sakura_quest1_5502cecb:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:145
translate english arc2_sakura_quest1_da124d95:

    # sk "L-Lady Tsunade, ya fue suficiente"
    sk "ท-ท่านซึนาเดะ พอแค่นั้นเถอะค่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:146
translate english arc2_sakura_quest1_f9469b5f:

    # sk "Yo lo conozco desde hace años, él no haría algo así"
    sk "ฉันรู้จักเขามาหลายปีแล้ว เขาไม่มีทางทำเรื่องแบบนั้นหรอกค่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:147
translate english arc2_sakura_quest1_9fcdb26b:

    # sk "Le doy mi palabra"
    sk "ฉันรับประกันเลย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:149
translate english arc2_sakura_quest1_370575ff:

    # sk "Sea más consciente, lo dejó tirado en la entrada, con su fuerza pudo haberlo matado"
    sk "ระวังหน่อยสิคะ เขาโดนทิ้งให้นอนกองอยู่ตรงทางเข้าเลยนะ ด้วยพละกำลังของท่านเนี่ย เผลอๆ อาจจะฆ่าเขาตายได้เลยนะคะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:150
translate english arc2_sakura_quest1_5bd1fb6e:

    # sk "Además, esta no es la primera vez que pasa algo así, y nuevamente no dudó en acudir a la violencia"
    sk "อีกอย่าง นี่ก็ไม่ใช่ครั้งแรกที่เกิดเรื่องแบบนี้ขึ้น และแถมครั้งนี้เธอก็ยังใช้ความรุนแรงโดยไม่ลังเลอีกต่างหาก"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:152
translate english arc2_sakura_quest1_7be568cb:

    # ts "Jum, es lo que se ganan por pervertidos"
    ts "หึ สมน้ำหน้า ทำตัวทะลึ่งตึงตังเองนี่นา"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:154
translate english arc2_sakura_quest1_0535144c:

    # sk "*suspiro*"
    sk "*ถอนหายใจ*"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:156
translate english arc2_sakura_quest1_05d89eee:

    # sk "Muy bien, ¿Ya podemos seguir con los exámenes?"
    sk "เอาล่ะ งั้นเรามาตรวจต่อกันเลยได้ไหมคะ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:158
translate english arc2_sakura_quest1_58d44d49:

    # ts "Ah, eso"
    ts "อ่า เรื่องนั้นสินะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:161
translate english arc2_sakura_quest1_3cc5513a:

    # ts "Sakura me dijo que tienes un {b}Dojutsu{/a} que posee la habilidad de volverte invisible, ¿Es eso cierto?"
    ts "ซากุระบอกฉันว่านายมี {b}เนตรสังสาระ{/a} ที่ทำให้ล่องหนได้ จริงรึเปล่าล่ะ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:162
translate english arc2_sakura_quest1_1af91fd5:

    # mn "Así es, Lady Tsunade"
    mn "ถูกต้องครับ ท่านซึนาเดะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:163
translate english arc2_sakura_quest1_7969f285:

    # ts "Bah, deja de ser tan formal, dime Tsunade a secas"
    ts "โธ่ เลิกเกร็งเป็นทางการนักเลย เรียกฉันว่าซึนาเดะก็พอ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:164
translate english arc2_sakura_quest1_687cdfd5:

    # mn "E-Está bien"
    mn "อ-โอเคครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:165
translate english arc2_sakura_quest1_cfc3c15e:

    # sk "Oigan, procuren llevarse bien al menos"
    sk "นี่ ช่วยๆ กันปรองดองกันหน่อยสิคะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:167
translate english arc2_sakura_quest1_d6fa9b57:

    # ts "Lo intentaré, solo espero que no intentes algo nuevamente, pervertido"
    ts "ฉันจะลองพยายามดูแล้วกัน หวังว่านายจะไม่หาเรื่องอะไรอีกนะ เจ้าคนลามก"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:169
translate english arc2_sakura_quest1_6570e7be:

    # mn "No lo haré, pero le juro que fue un accidente"
    mn "ไม่ทำหรอกครับ แต่ผมสาบานเลยนะว่ามันเป็นอุบัติเหตุจริงๆ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:172
translate english arc2_sakura_quest1_d91e19a3:

    # ts "Muy bien, elegiré creerte por ahora"
    ts "เอาล่ะ ฉันจะยอมเชื่อคำพูดนายไปก่อนก็แล้วกัน"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:173
translate english arc2_sakura_quest1_b7023b7c:

    # ts "Ahora, comencémos con los exámenes, quiero ver de lo que es capaz el {b}Karugan{/a}"
    ts "เอาล่ะ มาเริ่มการทดสอบกันเถอะ ฉันอยากจะเห็นว่า {b}คารูกัน{/a} ของนายเนี่ยมันทำอะไรได้บ้าง"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:175
translate english arc2_sakura_quest1_f702caaf:

    # mn "¿Porqué siento que me metí donde no debía?"
    mn "(ทำไมฉันถึงรู้สึกเหมือนเอาตัวเข้าไปพัวพันกับเรื่องที่ไม่น่าหาเรื่องใส่ตัวเลยวะเนี่ย?)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:177
translate english arc2_sakura_quest1_993293bd:

    # sk "No te preocupes, estás en buenas manos"
    sk "ไม่ต้องห่วงหรอกน่า นายอยู่ในการดูแลของฉันเอง ไว้ใจได้เลย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:179
translate english arc2_sakura_quest1_d7448d17:

    # ts "Muy bien, comencemos entonces con las pruebas"
    ts "เอาล่ะ งั้นเรามาเริ่มทดสอบกันเลยดีกว่า"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:180
translate english arc2_sakura_quest1_cd6d73a4:

    # ts "Vamos a tener que analizar tus habilidades actuales, tu resistencia, agilidad y reflejos"
    ts "เราจำเป็นต้องวิเคราะห์ความสามารถ ความอดทน ความคล่องแคล่ว และปฏิกิริยาตอบสนองในปัจจุบันของนาย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:181
translate english arc2_sakura_quest1_93ad169e:

    # ts "Vamos al campo de entrenamiento para hacer estas pruebas"
    ts "งั้นเราไปที่สนามฝึกซ้อมเพื่อทำการทดสอบเหล่านี้กันเถอะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:183
translate english arc2_sakura_quest1_3a2597bd:

    # mn "Si, está bien"
    mn "ครับ ไม่มีปัญหาครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:186
translate english arc2_sakura_quest1_a370ab5c:

    # n "Sakura, Tsunade y [MN] se dirigen al campo de entrenamiento"
    n "ซากุระ ซึนาเดะ และ [MN] มุ่งหน้าไปยังสนามฝึกซ้อม"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:196
translate english arc2_sakura_quest1_e236fc00:

    # sk "Llegamos"
    sk "ถึงแล้วล่ะค่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:197
translate english arc2_sakura_quest1_cea6682b:

    # mn "¿Qué tengo que hacer aquí exactamente?"
    mn "แล้วผมต้องทำอะไรบ้างเหรอครับเนี่ย?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:198
translate english arc2_sakura_quest1_89234a28:

    # ts "Quiero que hagas unas pruebas de resistencia, agilidad y reflejos sin activar el Karugan"
    ts "ฉันอยากให้นายทดสอบความอึด ความคล่องแคล่ว และปฏิกิริยาตอบสนองโดยที่ยังไม่ต้องเปิดใช้งานคารูกันก่อน"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:199
translate english arc2_sakura_quest1_3be4a247:

    # ts "Luego las volverás a hacer, pero con el Karugan activo para ver si el Karugan mejora una de estas características"
    ts "จากนั้นค่อยทดสอบซ้ำอีกรอบโดยเปิดใช้งานคารูกัน เพื่อดูว่ามันช่วยพัฒนาความสามารถพวกนี้ขึ้นแค่ไหน"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:200
translate english arc2_sakura_quest1_ba8262d8:

    # mn "Entiendo"
    mn "เข้าใจแล้วครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:201
translate english arc2_sakura_quest1_5d932984:

    # mn "No sé como no lo había pensado antes"
    mn "ทำไมก่อนหน้านี้ฉันถึงคิดเรื่องนี้ไม่ออกนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:202
translate english arc2_sakura_quest1_194829c3:

    # ts "Bueno, entonces comencemos"
    ts "งั้นก็มาเริ่มกันเลยดีกว่า"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:206
translate english arc2_sakura_quest1_8f4eb328:

    # n "Para analizar el Karugan, Tsunade primero somete a [MN] a una prueba de reflejos, donde debe de esquivar todos sus ataques"
    n "เพื่อวิเคราะห์คารูกัน ซึนาเดะจึงให้ [MN] เข้ารับการทดสอบปฏิกิริยาตอบสนองก่อน โดยที่เขาจะต้องหลบการโจมตีทั้งหมดของเธอให้ได้"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:218
translate english arc2_sakura_quest1_ebfb4b33:

    # mn "(¡M-Maldición)!"
    mn "(ช-ชักแย่แล้วสิ!)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:219
translate english arc2_sakura_quest1_bd6c800a:

    # mn "(Si me descuido por un segundo me hará pedazos)"
    mn "(ถ้าเผลอประมาทแม้แต่วินาทีเดียว มีหวังโดนเธออัดเละเป็นโจ๊กแน่)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:220
translate english arc2_sakura_quest1_cae119d3:

    # mn "(Tengo que tomarme esto en serio)"
    mn "(ฉันต้องจริงจังกว่านี้แล้ว)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:226
translate english arc2_sakura_quest1_bb4e2078:

    # n "-{b}Después de unos minutos{/a}-"
    n "-{b}ผ่านไปไม่กี่นาที{/a}-"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:230
translate english arc2_sakura_quest1_7d146464:

    # ts "Interesante... Con el {b}Karugan{/a} activo has esquivado mejor mis ataques"
    ts "น่าสนใจแฮะ... พอเปิดใช้งาน {b}คารูกัน{/a} นายก็หลบการโจมตีของฉันได้ดีขึ้นด้วย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:231
translate english arc2_sakura_quest1_5ca3921f:

    # ts "Tu tiempo de reacción mejoró muchísimo"
    ts "เวลาตอบสนองของนายพัฒนาขึ้นเยอะเลย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:232
translate english arc2_sakura_quest1_7cbe2544:

    # sk "Parece ser que el {b}Karugan{/a} mejora tu {b}Percepción{/a} al igual que el {b}Sharingan{/a}"
    sk "ดูเหมือนว่า {b}คารูกัน{/a} จะช่วยเพิ่มความสามารถด้าน {b}การรับรู้{/a} เหมือนกับ {b}เนตรวงแหวน{/a} เลยสินะคะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:233
translate english arc2_sakura_quest1_bcd6ed14:

    # mn "¿De verdad? No lo había usado sin la invisibilidad hasta ahora"
    mn "จริงเหรอครับ? ก่อนหน้านี้ผมไม่เคยใช้มันแบบไม่เปิดคาถาล่องหนเลยแฮะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:234
translate english arc2_sakura_quest1_b2e0b00e:

    # ts "Mmm, tengo entendido que en tu otro ojo posees un {b}Sharingan{/a}, ¿Cierto?"
    ts "อืม ฉันเข้าใจว่าดวงตาอีกข้างของนายมี {b}เนตรวงแหวน{/a} อยู่สินะ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:235
translate english arc2_sakura_quest1_5522fab1:

    # mn "Así es"
    mn "ถูกต้องครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:236
translate english arc2_sakura_quest1_3620fae3:

    # ts "Quiero que esquives mis ataques con tu Sharingan activo, tenemos que probar si la Percepción del {b}Karugan{/a} es mejor o no"
    ts "งั้นฉันอยากให้นายลองหลบการโจมตีของฉันโดยใช้เนตรวงแหวนดู เราต้องทดสอบว่าความสามารถด้านการรับรู้ของ {b}คารูกัน{/a} มันเหนือกว่าหรือด้อยกว่ากันแน่"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:237
translate english arc2_sakura_quest1_7cdd7e48:

    # mn "Muy bien"
    mn "รับทราบครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:241
translate english arc2_sakura_quest1_8664df1f:

    # n "Tsunade vuelve a atacar a [MN], pero esta vez debe esquivar utilizando el Sharingan"
    n "ซึนาเดะโจมตี [MN] อีกครั้ง แต่คราวนี้เขาต้องใช้เนตรวงแหวนในการหลบหลีก"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:248
translate english arc2_sakura_quest1_8cd30b17:

    # n "Igual que hace unos momentos, [MN] esquiva cada uno de los ataques inhumanos de Tsunade"
    n "เช่นเดียวกับเมื่อครู่ [MN] สามารถหลบการโจมตีอันไร้มนุษยธรรมของซึนาเดะได้ทุกครั้ง"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:254
translate english arc2_sakura_quest1_258ce80d:

    # mn "*jadeo*" with fade
    mn "*หอบ*" with fade

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:255
translate english arc2_sakura_quest1_5e65aa8a:

    # mn "¿Ya está? Ya estoy cansado"
    mn "จบหรือยังครับ? ผมเหนื่อยแล้วนะเนี่ย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:256
translate english arc2_sakura_quest1_8258f1b0:

    # ts "Muy bien, ya hemos acabado por hoy"
    ts "เอาล่ะ วันนี้พอแค่นี้ก่อนก็แล้วกัน"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:257
translate english arc2_sakura_quest1_ff806532:

    # ts "Dime, ¿Cómo se te hizo más difícil esquivar mis ataques?"
    ts "บอกฉันทีสิ ว่าการหลบการโจมตีของฉันมันยากขึ้นกว่าเดิมไหม?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:258
translate english arc2_sakura_quest1_b25e0b08:

    # mn "S-Sin duda se me hizo más difícil con el {b}Karugan{/a}, si mejora mi persepción visual a tal punto de esquivar sus ataques"
    mn "ม-มันยากกว่าตอนใช้ {b}คารูกัน{/a} แน่นอนครับ มันช่วยเพิ่มการมองเห็นของผมจนทำให้หลบการโจมตีของเธอได้"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:260
translate english arc2_sakura_quest1_797d3280:

    # mn "Pero es verdad que el {b}Sharingan{/a} es superior en ese aspecto"
    mn "แต่ก็ปฏิเสธไม่ได้เลยว่า {b}เนตรวงแหวน{/a} เหนือกว่าในเรื่องนั้นจริงๆ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:261
translate english arc2_sakura_quest1_e1782080:

    # ts "Ya veo... Entonces posee una percepción inferior a la del Sharingan"
    ts "งั้นเหรอ... แปลว่าความสามารถในการรับรู้ของมันด้อยกว่าเนตรวงแหวนสินะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:262
translate english arc2_sakura_quest1_291e43eb:

    # sk "[MN], ¿Cómo te sientes, no te molesta el ojo?"
    sk "[MN] เป็นยังไงบ้างคะ? รู้สึกระคายเคืองตาตรงไหนรึเปล่า?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:264
translate english arc2_sakura_quest1_4cef9890:

    # mn "Tenía dudas sobre eso, pero parece ser que no me fastidia cuando no uso la invisibilidad"
    mn "ตอนแรกผมก็ไม่แน่ใจเรื่องนั้นเท่าไหร่ แต่ดูเหมือนว่ามันจะไม่ค่อยระคายเคืองเท่าตอนที่ไม่ได้ใช้คาถาล่องหนแฮะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:266
translate english arc2_sakura_quest1_1c89ee73:

    # sk "Maravilloso, entonces estamos haciendo avances"
    sk "ยอดเยี่ยมเลยค่ะ งั้นพวกเราก็มีความคืบหน้าแล้วสินะคะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:267
translate english arc2_sakura_quest1_e2a45a7e:

    # ts "Yo aún no he tenido la dicha de ver ese jutsu de invisibilidad"
    ts "ฉันยังไม่มีโอกาสได้เห็นคาถาล่องหนนั้นกับตาตัวเองเลยสักครั้งแฮะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:268
translate english arc2_sakura_quest1_b46c3f52:

    # ts "¿Te importaría hacerla? Así confirmamos la teoría sobre el ardor en los ojos"
    ts "ช่วยลองใช้หน่อยได้ไหม? เผื่อเราจะได้ยืนยันสมมติฐานเรื่องอาการระคายเคืองตาได้ด้วย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:269
translate english arc2_sakura_quest1_a6bae7d5:

    # mn "C-Claro"
    mn "ก-ก็ได้ครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:270
translate english arc2_sakura_quest1_a576602a:

    # mn "Bien... Aquí voy"
    mn "งั้น... ไปล่ะนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:273
translate english arc2_sakura_quest1_32462c4b_5:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:295
translate english arc2_sakura_quest1_b726b251:

    # sk "Vaya, es la primera vez que lo presencio en persona"
    sk "ว้าว นี่เป็นครั้งแรกเลยนะคะที่ฉันได้เห็นกับตาตัวเองเนี่ย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:296
translate english arc2_sakura_quest1_1d456553:

    # ts "Vaya... Ciertamente se volvió invisible"
    ts "โฮ... มันล่องหนไปจริงๆ ด้วยแฮะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:298
translate english arc2_sakura_quest1_27173266:

    # sk "Dime [MN], ¿Sientes molestia en la vista?"
    sk "บอกฉันทีสิ [MN] รู้สึกผิดปกติอะไรเกี่ยวกับการมองเห็นไหมคะ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:300
translate english arc2_sakura_quest1_e0402285:

    # mn "Esto... Es extraño..."
    mn "นี่มัน... แปลกจังเลยครับ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:302
translate english arc2_sakura_quest1_4e51d94e:

    # ts "¿Qué ocurre?"
    ts "เกิดอะไรขึ้นเหรอ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:303
translate english arc2_sakura_quest1_76d69961:

    # mn "Esto es nuevo... Hasta ahora solo había utilizado el {b}Jutsu de Invisibilidad{/a} de día"
    mn "นี่มันเรื่องใหม่แฮะ... ปกติแล้วผมจะใช้{b}คาถาล่องหน{/a}เฉพาะในตอนกลางวันเท่านั้น"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:304
translate english arc2_sakura_quest1_65c5a71e:

    # mn "Pero justo ahora que es de noche... Veo todo más claro"
    mn "แต่ตอนนี้... เพราะว่าเป็นเวลากลางคืน... ผมเลยมองเห็นทุกอย่างได้ชัดเจนกว่าเดิมซะอีก"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:305
translate english arc2_sakura_quest1_1e7afdba:

    # mn "Puedo ver perfectamente"
    mn "ผมมองเห็นได้อย่างชัดเจนเลยครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:308
translate english arc2_sakura_quest1_ee9c859d:

    # sk "¡¿D-De verdad?!"
    sk "จ-จริงเหรอคะ?!"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:312
translate english arc2_sakura_quest1_e17379db:

    # mn "Si, veo todo perfectamente"
    mn "ครับ ผมมองเห็นทุกอย่างได้อย่างชัดเจนเลยล่ะครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:313
translate english arc2_sakura_quest1_9a77c256:

    # ts "¿Algo así como una visión nocturna?"
    ts "ประมาณว่าการมองเห็นในที่มืดงั้นเหรอ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:314
translate english arc2_sakura_quest1_2f17c7da:

    # mn "Si, creo que algo así"
    mn "ครับ ผมคิดว่าน่าจะประมาณนั้นแหละครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:315
translate english arc2_sakura_quest1_97151feb:

    # sk "Eso es increíble..."
    sk "สุดยอดไปเลยนะคะ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:318
translate english arc2_sakura_quest1_84753a23:

    # sk "Parece ser que los de tu Clan eran unos expertos en el {b}Sigilo{/a}"
    sk "ดูเหมือนว่าตระกูลของนายจะเต็มไปด้วยผู้เชี่ยวชาญด้าน {b}การพลางตัว{/a} สินะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:320
translate english arc2_sakura_quest1_c0cc9b45:

    # mn "Así parece..."
    mn "ดูเหมือนจะเป็นอย่างนั้นครับ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:321
translate english arc2_sakura_quest1_2e56f4f0:

    # ts "Dime, ¿Cuando estás invisible no sientes cosas fuera de lo normal?"
    ts "บอกฉันทีสิ ตอนที่ล่องหนอยู่ รู้สึกผิดปกติอะไรบ้างไหม?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:323
translate english arc2_sakura_quest1_2be98cd7:

    # mn "Mmm, ahora que lo dice sí, las veces que lo he usado en combate he sentido mi cuerpo más {b}Ligero{/a}, como si me librara de una gran carga de encima"
    mn "อืม พอพูดถึงแล้วก็... ตอนที่ผมใช้มันในการต่อสู้ ผมรู้สึกว่าร่างกายเบาขึ้น เหมือนมันช่วยปลดภาระหนักอึ้งออกไปเลยครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:325
translate english arc2_sakura_quest1_c0be6867:

    # sk "¿Más ligero?"
    sk "เบาลงเหรอคะ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:326
translate english arc2_sakura_quest1_e4e1e862:

    # mn "Si, pero solo cuando permanezco invisible, luego siento que vuelvo a la normalidad, y es cuando mi ojo me comienza a arder"
    mn "ครับ แต่เฉพาะตอนที่ผมยังล่องหนอยู่เท่านั้นนะ พอกลับสู่ร่างเดิมเมื่อไหร่ ตาของผมถึงเริ่มแสบขึ้นมาน่ะครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:327
translate english arc2_sakura_quest1_566b289c:

    # ts "Entiendo... Entonces mientras eres invisible no te arde, ¿Es así?"
    ts "งั้นเหรอ... สรุปคือตอนที่ล่องหนอยู่จะไม่แสบตา สินะคะ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:328
translate english arc2_sakura_quest1_5522fab1_1:

    # mn "Así es"
    mn "ถูกต้องครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:329
translate english arc2_sakura_quest1_0f28af63:

    # ts "Entonces, para confirmar esto quiero que vuelvas a la normalidad"
    ts "งั้นเพื่อยืนยันเรื่องนี้ ฉันอยากให้นายคืนสภาพเดิมซะหน่อย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:330
translate english arc2_sakura_quest1_a11c65db:

    # mn "Bien..."
    mn "ครับ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:343
translate english arc2_sakura_quest1_68c46679:

    # n "[MN] desactiva el {b}Jutsu de Invisibilidad{/a}"
    n "[MN] ยกเลิก{b}คาถาล่องหน{/a}"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:346
translate english arc2_sakura_quest1_f4c8bba5:

    # mn "¡Agh!..." with vpunch
    mn "อึก!...ร." with vpunch

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:348
translate english arc2_sakura_quest1_4cf3e766:

    # sk "[MN], ¿Te encuentras bien?"
    sk "[MN] เป็นอะไรหรือเปล่า?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:351
translate english arc2_sakura_quest1_0ada9e3e:

    # mn "Si... Es el ardor en el ojo..."
    mn "ครับ... มันแสบตาแปลกๆ... ครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:352
translate english arc2_sakura_quest1_980725ca:

    # ts "Parece ser que si es así... Los efectos secundarios aparecen cuando desactivas el {b}Jutsu de Invisibilidad{/a}"
    ts "ดูเหมือนจะเป็นแบบนั้นสินะ... ผลข้างเคียงจะแสดงออกมาตอนที่นายยกเลิก {b}คาถาล่องหน{/a} สินะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:354
translate english arc2_sakura_quest1_578f616f:

    # ts "Pero no cuando usas el Karugan sin hacerte invisible"
    ts "แต่กลับไม่เป็นไรตอนที่ใช้คารูกันโดยไม่ทำให้ตัวเองล่องหนสินะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:355
translate english arc2_sakura_quest1_41a6b33a:

    # sk "Así parece..."
    sk "ดูเหมือนจะเป็นอย่างนั้นจริงๆ ด้วยค่ะ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:356
translate english arc2_sakura_quest1_e4d75387:

    # sk "Es como si tu ojo no es capaz de soportar el {b}Jutsu de Invisibilidad{/a}"
    sk "เหมือนว่าตาของนายจะรับไม่ไหวกับ {b}คาถาล่องหน{/a} สินะคะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:358
translate english arc2_sakura_quest1_958013d0:

    # mn "Genial... Es bueno saberlo supongo"
    mn "นั่นสินะครับ... อย่างน้อยก็ได้รู้อะไรเพิ่มล่ะนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:361
translate english arc2_sakura_quest1_5dd1c361:

    # ts "Estamos haciendo avances"
    ts "เรามีความคืบหน้าไปอีกขั้นแล้วล่ะนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:362
translate english arc2_sakura_quest1_8e9df00c:

    # ts "La visión nocturna, ¿No la puedes activar sin la Invisibilidad?"
    ts "แล้วการมองเห็นในที่มืดเนี่ย นายเปิดใช้มันโดยไม่ต้องล่องหนไม่ได้เหรอ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:363
translate english arc2_sakura_quest1_109de49e:

    # mn "No lo sé, hasta ahora no sabía que podía hacer eso..."
    mn "ผมก็ไม่แน่ใจครับ จนถึงตอนนี้ผมเองก็เพิ่งรู้เหมือนกัน..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:365
translate english arc2_sakura_quest1_0774d882:

    # ts "¿Porqué no pruebas? Sería de mucha utilidad que pudieras activarla aún sin ser invisible"
    ts "ทำไมไม่ลองดูล่ะ? มันจะมีประโยชน์มากเลยนะถ้านายเปิดใช้มันได้โดยไม่ต้องล่องหนน่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:366
translate english arc2_sakura_quest1_728d9d8f:

    # ts "También tenemos que comprobar que no tenga efectos secundarios"
    ts "เรายังต้องตรวจสอบด้วยว่ามันไม่มีผลข้างเคียงตามมาน่ะนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:367
translate english arc2_sakura_quest1_fdb564a9:

    # mn "Lo intentaré..."
    mn "ผมจะลองดูครับ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:369
translate english arc2_sakura_quest1_5502cecb_1:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:371
translate english arc2_sakura_quest1_a91722d7:

    # mnn "(Vamos [MN]...)"
    mnn "(เอาสิ [MN]...)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:372
translate english arc2_sakura_quest1_85d7b7c1:

    # mnn "(Debes de poder hacerlo...)"
    mnn "(ฉันต้องทำได้น่า...)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:374
translate english arc2_sakura_quest1_5502cecb_2:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:389
translate english arc2_sakura_quest1_5502cecb_3:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:391
translate english arc2_sakura_quest1_ff842e23:

    # ts "¿Y bien, logras ver mejor?"
    ts "งั้นมองเห็นได้ชัดขึ้นแล้วใช่ไหม?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:395
translate english arc2_sakura_quest1_9aac5303:

    # mn "Si... Parece que funciona jajaja"
    mn "ครับ... ดูเหมือนจะสำเร็จด้วยล่ะครับ ฮ่าๆๆ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:397
translate english arc2_sakura_quest1_65060af1:

    # ts "Bien, ahora desactívalo y dinos si te causa molestias"
    ts "ดีล่ะ งั้นลองปิดมันแล้วบอกทีว่ามีอาการผิดปกติอะไรไหม"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:398
translate english arc2_sakura_quest1_d129f12a:

    # mn "Entendido"
    mn "รับทราบครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:408
translate english arc2_sakura_quest1_887f0222:

    # n "[MN] desactiva el Karugan"
    n "[MN] ปิดการใช้งานคารูกัน"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:409
translate english arc2_sakura_quest1_2b5e48b2:

    # mn "No... No siento molestia alguna"
    mn "ไม่... ไม่รู้สึกผิดปกติอะไรเลยครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:410
translate english arc2_sakura_quest1_696e1b30:

    # sk "Tal como lo suponía, lo que provoca molestias en tu ojo es el {b}Jutsu de Invisibilidad{/a}"
    sk "ก็อย่างที่ฉันคิดไว้เลย สิ่งที่ทำให้ตาของนายระคายเคืองก็คือ {b}คาถาล่องหน{/a} ต่างหากล่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:411
translate english arc2_sakura_quest1_9ce6642d:

    # ts "Si, parece que eso es"
    ts "นั่นสินะคะ ดูเหมือนจะเป็นแบบนั้นจริงๆ ด้วย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:412
translate english arc2_sakura_quest1_c2b99397:

    # mn "Vaya, es un alivio el saber la causa de esa molestia"
    mn "เฮ้อ โล่งอกไปทีที่รู้สาเหตุของอาการนั้นสักทีครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:413
translate english arc2_sakura_quest1_c578a433:

    # mn "Entonces, ¿Ya acabamos con las pruebas?"
    mn "งั้น... การทดสอบวันนี้ถือว่าเสร็จเรียบร้อยแล้วใช่ไหมครับ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:414
translate english arc2_sakura_quest1_52520ba6:

    # ts "Me gustaría hacer más pruebas mientras estás invisible, pero sería imposible"
    ts "ฉันก็อยากจะทดสอบอะไรเพิ่มตอนที่นายล่องหนอยู่นะ แต่คงเป็นไปไม่ได้ล่ะนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:416
translate english arc2_sakura_quest1_b09c0275:

    # ts "No sabría en donde estás"
    ts "เพราะฉันคงมองไม่เห็นเลยว่านายอยู่ที่ไหน"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:417
translate english arc2_sakura_quest1_d08eca9a:

    # ts "Y eso es una ventaja sin igual"
    ts "แถมมันยังเป็นข้อได้เปรียบที่หาตัวจับยากอีกด้วย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:418
translate english arc2_sakura_quest1_c3157005:

    # ts "En manos equivocadas el {b}Karugan{/a} sería un arma muy peligrosa"
    ts "ถ้าตกไปอยู่ในมือคนผิด {b}คารูกัน{/a} คงจะกลายเป็นอาวุธที่อันตรายสุดๆ ไปเลยล่ะนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:420
translate english arc2_sakura_quest1_60a33cbb:

    # mn "Ya lo creo... Paso completamente desapercibido de los ojos de las personas"
    mn "ก็พอจะจินตนาการได้อยู่ครับ... สายตาคนธรรมดาไม่มีทางมองเห็นผมเลยสักนิด"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:422
translate english arc2_sakura_quest1_d4d4f213:

    # sk "Hmm, ¿Qué tal si no pasas completamente desapercibido?"
    sk "อืม แล้วถ้าไม่ใช่สายตาคนธรรมดาล่ะ จะยังมองไม่เห็นอยู่จริงๆ เหรอ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:423
translate english arc2_sakura_quest1_e1ff12af:

    # mn "¿Qué quieres decir?"
    mn "หมายความว่ายังไงเหรอครับ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:424
translate english arc2_sakura_quest1_d77610f8:

    # sk "Hay Dojutsus como el {b}Byakugan{/a} o el {b}Sharingan{/a} que pueden ver el Flujo de Chakra"
    sk "มันก็ยังมีเนตรอย่าง {b}เนตรสีขาว{/a} หรือ {b}เนตรวงแหวน{/a} ที่มองเห็นการไหลเวียนของจักระได้อยู่นะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:425
translate english arc2_sakura_quest1_a3818180:

    # sk "También hay {b}Jutsus Sensoriales{/a} y se sabe de {b}Herramientas Científicas Ninja{/a} que también pueden detectarlo"
    sk "ไหนจะพวก {b}คาถาตรวจจับ{/a} อีก แถมเราก็รู้กันว่ามี {b}เครื่องมือแพทย์นินจา{/a} ที่ตรวจจับได้เหมือนกัน"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:426
translate english arc2_sakura_quest1_e59d3bef:

    # sk "Eres invisible para los ojos de las personas, pero no sabemos si también se oculta tu Fujo de Chakra"
    sk "ตัวนายอาจจะล่องหนจากสายตาคนทั่วไป แต่เราก็ยังไม่รู้ว่าการไหลเวียนจักระของนายถูกซ่อนไปด้วยหรือเปล่าน่ะสิ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:427
translate english arc2_sakura_quest1_ccd8dbb6:

    # mn "Si... Tiene sentido"
    mn "นั่นสินะครับ... พูดแบบนั้นก็มีเหตุผลเหมือนกัน"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:428
translate english arc2_sakura_quest1_1649660c:

    # sk "Podríamos confirmar eso con la ayuda de Sarada, le pediré su ayuda máñana"
    sk "เรื่องนั้นเราน่าจะลองเช็คดูให้แน่ใจด้วยความช่วยเหลือของซาราดะได้นะ เดี๋ยวพรุ่งนี้ฉันจะลองถามเธอให้เอง"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:430
translate english arc2_sakura_quest1_23007ac7:

    # sk "Creo que hoy ya es demasiado tarde"
    sk "ฉันว่าวันนี้น่าจะดึกเกินไปแล้วล่ะนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:432
translate english arc2_sakura_quest1_572912cc:

    # ts "Si, mejor seguimos mañana"
    ts "นั่นสินะ เอาไว้มาต่อกันพรุ่งนี้จะดีกว่า"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:434
translate english arc2_sakura_quest1_d1ff7d68:

    # ts "Con estos datos investigarémos una forma de apaciguar los efectos secundarios, Sakura me dijo que planeas usar el {b}Jutsu de Invisibilidad{/a} en los próximos exámenes chunin, ¿Cierto?"
    ts "จากข้อมูลพวกนี้ เดี๋ยวพวกเราจะลองค้นคว้าวิธีบรรเทาผลข้างเคียงดู ซากุระบอกฉันว่าเธอวางแผนจะใช้ {b}คาถาล่องหน{/a} ในการสอบจูนินที่จะถึงนี้สินะ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:435
translate english arc2_sakura_quest1_7e971f56:

    # mn "Así es, y les agradecería mucho si me ayudaran con eso, de verdad"
    mn "ถูกต้องครับ แล้วก็ขอบคุณมากๆ เลยนะครับถ้าจะช่วยผมเรื่องนั้นจริงๆ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:437
translate english arc2_sakura_quest1_c5385c08:

    # sk "Bien, entonces ya podemos irnos"
    sk "งั้นพวกเราแยกย้ายกันตรงนี้เลยละกันนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:439
translate english arc2_sakura_quest1_23f740b2:

    # n "Sakura, Tsunade y [MN] se despiden y toman caminos diferentes"
    n "ซากุระ, ซึนาเดะ และ [MN] บอกลาและแยกย้ายกันไปคนละทาง"
# TODO: Translation updated at 2024-12-20 07:52

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:429
translate english arc2_sakura_quest1_548ee619:

    # sk "Eres invisible para los ojos de las personas, pero no sabemos si también se oculta tu Flujo de Chakra"
    sk "ตัวนายอาจจะล่องหนจากสายตาคนทั่วไป แต่เราก็ยังไม่รู้ว่าการไหลเวียนจักระของนายถูกซ่อนไปด้วยหรือเปล่าน่ะสิ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest1.rpy:431
translate english arc2_sakura_quest1_baebda17:

    # sk "Podríamos confirmar eso con la ayuda de Sarada, le pediré su ayuda mañana"
    sk "เรื่องนั้นเราน่าจะลองเช็คดูให้แน่ใจด้วยความช่วยเหลือของซาราดะได้นะ เดี๋ยวพรุ่งนี้ฉันจะลองถามเธอให้เอง"
