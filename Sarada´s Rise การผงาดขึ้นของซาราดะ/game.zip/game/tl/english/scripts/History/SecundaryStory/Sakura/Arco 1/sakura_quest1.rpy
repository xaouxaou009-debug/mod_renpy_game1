

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:9
translate english sakura_quest1_e5532ced:

    # mn "(Ahora que lo pienso... No llegué a saludar a Sakura...)"
    mn "(จะว่าไป... เรายังไม่ได้ทักทายคุณซากุระเลยแฮะ...)"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:11
translate english sakura_quest1_06909d1a:

    # mn "(Podría ir a visitarla ahora, tengo algo de tiempo libre)"
    mn "(แวะไปหาเธอตอนนี้เลยดีกว่า กำลังมีเวลาว่างอยู่พอดี)"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:15
translate english sakura_quest1_7e8bf6c1:

    # n "[MN] llega a casa de Sakura"
    n "[MN] มาถึงบ้านของซากุระ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:17
translate english sakura_quest1_d47b13c5:

    # "Knock Knock Knock"
    "ก๊อก ก๊อก ก๊อก"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:18
translate english sakura_quest1_f0b71949:

    # d "¡Un momento!"
    d "รอสักครู่นะคะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:27
translate english sakura_quest1_9e51d349:

    # n "Sakura abre la puerta"
    n "ซากุระเปิดประตู"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:29
translate english sakura_quest1_93a0ffa7:

    # mn "Hola, señorita Sakura"
    mn "สวัสดีครับ คุณซากุระ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:32
translate english sakura_quest1_844ec374:

    # sk "[MN], cuanto tiempo sin verte, ¿Cómo estás?"
    sk "[MN] ไม่ได้เจอกันนานเลยนะ เป็นยังไงบ้างจ๊ะ?"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:35
translate english sakura_quest1_53bb1d8a:

    # sk "¡Oh! ¿Qué te pasó en el ojo?"
    sk "อ้าว! เกิดอะไรขึ้นกับตาของเธอเหรอ?"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:37
translate english sakura_quest1_c10bfd4e:

    # sk "¿Son lentes de contacto o algo así?"
    sk "ใส่คอนแทกต์เลนส์หรือเปล่าจ๊ะ?"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:40
translate english sakura_quest1_f042f621:

    # mn "Jaja, es una larga historia..."
    mn "ฮะๆ เรื่องมันยาวน่ะครับ..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:42
translate english sakura_quest1_5aa85418:

    # mn "Puedo extenderme con los detalles, pero me tomaría un poco de tiempo"
    mn "ถ้าจะให้เล่ารายละเอียด คงต้องใช้เวลาสักหน่อยน่ะครับ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:45
translate english sakura_quest1_10a661db:

    # sk "Tienes tiempo sin visitarme, tomate tu tiempo para contármelo todo"
    sk "เธอไม่ได้มาหาฉันตั้งนาน ค่อยๆ เล่ามาให้ฟังทั้งหมดได้เลยจ้ะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:47
translate english sakura_quest1_a8f1574e:

    # mn "Está bien jaja"
    mn "โอเคครับ ฮ่าๆ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:51
translate english sakura_quest1_9e3d844b:

    # n "[MN] le cuenta a Sakura todo lo que le dijo Orochimaru sobre su clan"
    n "[MN] เล่าเรื่องทั้งหมดที่โอโรจิมารุบอกเกี่ยวกับตระกูลของเขาให้ซากุระฟัง"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:62
translate english sakura_quest1_828e54f4:

    # mn "Y eso sería todo"
    mn "เรื่องทั้งหมดก็มีเท่านี้แหละครับ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:65
translate english sakura_quest1_f9def403:

    # sk "Vaya..."
    sk "โอ้..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:67
translate english sakura_quest1_a7f2e095:

    # sk "Enserio... Lamento lo que le pasó a tu clan"
    sk "จริงๆ นะ... ฉันเสียใจด้วยเรื่องตระกูลของเธอนะจ๊ะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:69
translate english sakura_quest1_2bc34c27:

    # sk "Es algo... Muy fuerte"
    sk "มันเป็นเรื่องที่... สะเทือนใจมากเลยนะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:72
translate english sakura_quest1_84034983:

    # mn "Realmente... Yo tampoco sé como sentirme al respecto"
    mn "ผมเองก็... ไม่รู้เหมือนกันว่าจะต้องรู้สึกยังไงดี"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:74
translate english sakura_quest1_510cc7b7:

    # mn "Nunca los conocí, pero... Era mi clan..."
    mn "ผมไม่เคยเจอพวกเขามาก่อนเลย แต่... พวกเขาก็เป็นตระกูลของผม..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:76
translate english sakura_quest1_6fd2adae:

    # mn "Siempre me pregunté que fué de ellos... Y de donde provengo"
    mn "ผมเคยสงสัยมาตลอดว่าเกิดอะไรขึ้นกับพวกเขา... และผมมาจากไหนกันแน่"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:78
translate english sakura_quest1_76c51f87:

    # mn "Y ahora saber qué fue de ellos... Se siente algo raro..."
    mn "พอได้มารู้ว่าเกิดอะไรขึ้นกับพวกเขาแล้ว... มันเลยรู้สึกแปลกๆ ยังไงไม่รู้น่ะครับ..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:80
translate english sakura_quest1_639b733f:

    # sk "..."
    sk "..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:82
translate english sakura_quest1_95a9841a:

    # mn "Oh, lo siento..."
    mn "อ๊ะ ขอโทษนะครับ..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:84
translate english sakura_quest1_8f51aa30:

    # mn "¿Qué tal si hablamos de algo más agradable?"
    mn "เราเปลี่ยนไปคุยเรื่องที่สดใสกว่านี้กันดีกว่าไหมครับ?"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:87
translate english sakura_quest1_1018bbc9:

    # sk "Oh, no te preocupes jaja..."
    sk "อ๋อ ไม่ต้องคิดมากหรอกจ้ะ ฮ่าๆ..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:89
translate english sakura_quest1_7867eb73:

    # sk "Sabes que puedes contar conmigo para lo que sea"
    sk "เธอก็รู้ใช่ไหมว่าพึ่งพาฉันได้ทุกเรื่องน่ะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:92
translate english sakura_quest1_29e32bf7:

    # mn "Gracias..."
    mn "ขอบคุณนะครับ..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:95
translate english sakura_quest1_354dbbfc:

    # sk "Realmente aprecio que hayas venido a visitarme"
    sk "ดีใจจริงๆ นะที่เธอแวะมาหาฉัน"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:99
translate english sakura_quest1_3d3a6e7f:

    # sk "Las tardes se vuelves aburridas cuando no tienes trabajo, ¿Sabes?"
    sk "พอช่วงเย็นไม่มีงานทำ มันก็น่าเบื่อเหมือนกันเนอะ รู้ไหม?"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:101
translate english sakura_quest1_1abcb7d0:

    # sk "Últimamente hay menos trabajo en el hospital, y eso es bueno"
    sk "ช่วงนี้งานที่โรงพยาบาลน้อยลง ซึ่งก็ถือว่าเป็นเรื่องดีนะจ๊ะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:103
translate english sakura_quest1_25aacdd6:

    # sk "Pero eso me da más tiempo libre"
    sk "แต่มันก็ทำให้ฉันมีเวลาว่างมากขึ้น"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:105
translate english sakura_quest1_431bfb5f:

    # sk "Y cuando Sarada no está me siento sola, solo puedo pensar en beber o dormir"
    sk "และพอซาราดะไม่อยู่ ฉันก็รู้สึกเหงาขึ้นมา จนคิดออกแค่เรื่องดื่มไม่ก็นอนเท่านั้นเอง"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:107
translate english sakura_quest1_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:110
translate english sakura_quest1_26f0c973:

    # mn "¿No has recibido noticias de Sasuke?"
    mn "ไม่ได้ข่าวคราวจากคุณซาสึเกะบ้างเลยเหรอครับ?"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:113
translate english sakura_quest1_8ef1108b:

    # sk "No... Por desgracia no..."
    sk "ไม่เลยจ้ะ... น่าเสียดายที่ไม่มีเลย..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:115
translate english sakura_quest1_e3fb2a46:

    # mn "Lo suponía..."
    mn "ผมก็นึกว่า..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:117
translate english sakura_quest1_639b733f_1:

    # sk "..."
    sk "..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:120
translate english sakura_quest1_93f738ba:

    # sk "Me he acostumbrado a estar sin él, pero últimamente me siento más... Sola de lo normal..."
    sk "ฉันชินกับการอยู่โดยไม่มีเขาแล้วล่ะ แต่ช่วงนี้กลับรู้สึก... เหงามากกว่าปกติยังไงไม่รู้..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:123
translate english sakura_quest1_675a899b:

    # sk "Me pasa tanto aquí como en el Hospital..."
    sk "เป็นแบบนี้ทั้งตอนอยู่ที่นี่แล้วก็ที่โรงพยาบาลเลย..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:126
translate english sakura_quest1_0baf8988:

    # mn "¿Te ha ido mal en el Hospital?"
    mn "เกิดเรื่องไม่ดีขึ้นที่โรงพยาบาลเหรอครับ?"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:129
translate english sakura_quest1_08c5f3d9:

    # sk "Mi rendimiento ha bajado un poco..."
    sk "ผลการทำงานของฉันแย่ลงนิดหน่อยน่ะจ้ะ..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:131
translate english sakura_quest1_59966b19:

    # sk "Y eso solo hace que me deprima un poco más"
    sk "แล้วมันก็ยิ่งทำให้ฉันรู้สึกหดหู่ลงไปอีกนิดน่ะจ้ะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:133
translate english sakura_quest1_7324a0e7:

    # sk "Sé que no debo pensar ni sentime así, pues el está ocupado haciendo una misión de suma importancia"
    sk "ฉันรู้ว่าไม่ควรจะคิดหรือรู้สึกแบบนั้น เพราะเขากำลังยุ่งอยู่กับภารกิจที่สำคัญมาก"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:135
translate english sakura_quest1_981f2d40:

    # sk "Pero... Aveces no puedo evitarlo"
    sk "แต่... บางทีมันก็อดไม่ได้น่ะจ้ะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:137
translate english sakura_quest1_32462c4b_1:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:142
translate english sakura_quest1_3380490a:

    # sk "Por eso, aunque no lo creas realmente aprecio mucho que me hayas visitado"
    sk "เพราะอย่างนั้น ไม่ว่าจะเชื่อหรือไม่ก็ตาม ฉันดีใจจริงๆ นะที่เธอมาหา"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:145
translate english sakura_quest1_97cfb794:

    # sk "Tu compañía me ha alegrado mi descanso jaja"
    sk "การมีเธออยู่ด้วยช่วยให้เวลาพักผ่อนของฉันสดใสขึ้นเยอะเลย ฮ่าๆ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:148
translate english sakura_quest1_dea8cbbb:

    # mn "En ese caso"
    mn "ถ้าอย่างนั้น..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:150
translate english sakura_quest1_aa65f855:

    # mn "Trataré de visitarte más seguido, deveras"
    mn "ผมจะพยายามมาหาคุณให้บ่อยขึ้นนะครับ จริงๆ นะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:152
translate english sakura_quest1_b9d893b7:

    # mn "Incluso en el hospital, así no te sentirás más sola"
    mn "แม้กระทั่งที่โรงพยาบาลด้วย คุณจะได้ไม่ต้องรู้สึกเหงาอีก"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:155
translate english sakura_quest1_e09aef06:

    # sk "Mmm... Ahora que lo dices, no me vendría mal un asistente..."
    sk "หืม... พอเธอพูดแบบนี้ขึ้นมา ฉันก็คิดว่าอยากได้ผู้ช่วยสักคนอยู่เหมือนกันนะ..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:158
translate english sakura_quest1_c17d2429:

    # mn "¿Asistente...?"
    mn "ผู้ช่วย... เหรอครับ?"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:161
translate english sakura_quest1_514214e7:

    # sk "Si, puedes ir al Hospital y trabajar conmigo"
    sk "ใช่แล้วจ้ะ เธอมาทำงานกับฉันที่โรงพยาบาลได้เลยนะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:164
translate english sakura_quest1_f3d4fb1b:

    # sk "Bueno, siempre y cuando tú lo veas bien..."
    sk "ก็... ถ้าเธอคิดว่าดีล่ะก็นะ..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:166
translate english sakura_quest1_1c5ae35d:

    # sk "Sería un trabajo de medio tiempo, claramente te pagaría por tu tiempo"
    sk "มันจะเป็นงานพาร์ตไทม์นะ แน่นอนว่าฉันจะจ่ายค่าตอบแทนตามเวลาทำงานให้เธอจ้ะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:168
translate english sakura_quest1_f9ccbdec:

    # mn "Me parece una idea perfecta"
    mn "ผมว่าเป็นความคิดที่ดีเยี่ยมเลยครับ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:170
translate english sakura_quest1_72333caf:

    # sk "Muy bien, entonces ya está decidido"
    sk "เอาล่ะ ตกลงตามนี้นะจ๊ะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:172
translate english sakura_quest1_e2b63387:

    # sk "Te estaré esperando"
    sk "ฉันจะรอนะจ๊ะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:174
translate english sakura_quest1_13825fb8:

    # mn "Oh, creo que ya debería irme, ya es un poco tarde y tengo algunas cosas que hacer"
    mn "อ๊ะ ผมว่าผมคงต้องขอตัวก่อนแล้วล่ะครับ นี่ก็เริ่มดึกแล้ว แถมผมยังมีเรื่องต้องไปทำต่อด้วย"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:176
translate english sakura_quest1_bf4762c6:

    # sk "¿Enserio? Vaya, es una lástima"
    sk "เหรอจ๊ะ? ว้า เสียดายจัง"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:179
translate english sakura_quest1_e74b5102:

    # mn "Si, tengo que prepararme para un examen que nos hará Zubon-Sensei"
    mn "ครับ ผมต้องไปเตรียมตัวสำหรับการสอบที่อาจารย์ซูบงจะทดสอบพวกเราน่ะครับ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:181
translate english sakura_quest1_19ed6f4e:

    # mn "Si todo sale bien podrémos participar en los exámenes Chunnin"
    mn "ถ้าทุกอย่างราบรื่น พวกเราก็จะได้เข้าร่วมการสอบจูนินครับ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:184
translate english sakura_quest1_c07eeb85:

    # mn "Si, tengo que prepararme para mañana, Zubon-Sensei quiere que nos reunamos de mañana"
    mn "ครับ ผมต้องเตรียมตัวสำหรับวันพรุ่งนี้ อาจารย์ซูบงนัดพวกเราไปเจอพรุ่งนี้น่ะครับ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:188
translate english sakura_quest1_aec41434:

    # sk "Oh, entonces no te quito más tiempo"
    sk "อ๋อ ถ้าอย่างนั้นฉันไม่รบกวนเวลาเธอแล้วล่ะจ้ะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:190
translate english sakura_quest1_8bb97cb9:

    # sk "Pero ya cuando más tengas tiempo, recuerda que puedes quedarte más tiempo"
    sk "แต่ถ้าวันไหนเธอมีเวลาว่างมากขึ้น อย่าลืมว่าอยู่ต่อนานกว่านี้ได้นะจ๊ะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:194
translate english sakura_quest1_acb9a4f7:

    # mn "Lo tendré en mente jaja"
    mn "ผมจะจำไว้ครับ ฮ่าๆ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:197
translate english sakura_quest1_a9b9b5be:

    # mn "Nos vemos luego"
    mn "ไว้เจอกันนะครับ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest1.rpy:202
translate english sakura_quest1_6f37fe9c:

    # sk "Adios..."
    sk "แล้วเจอกันนะจ๊ะ..."
