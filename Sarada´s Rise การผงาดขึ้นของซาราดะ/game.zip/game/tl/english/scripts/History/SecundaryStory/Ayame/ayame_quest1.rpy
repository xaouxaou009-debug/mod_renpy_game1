

# game/scripts/History/SecundaryStory/Ayame/ayame_quest1.rpy:23
translate english ayame_quest1_e6365516:

    # mn "Hola, ¿Qué tal Ayame?"
    mn "สวัสดี อายาเมะ เป็นยังไงบ้าง?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest1.rpy:26
translate english ayame_quest1_67bdaff0:

    # ay "[MN], ¿Cómo te..."
    ay "[MN] เป็นอะไร...?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest1.rpy:30
translate english ayame_quest1_d9688ec9:

    # ay "¡!"
    ay "!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest1.rpy:32
translate english ayame_quest1_befc6e54:

    # ay "¿Q-Qué tienes en el ojo?"
    ay "ต-ตาเธอไปโดนอะไรมาน่ะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest1.rpy:35
translate english ayame_quest1_018992b1:

    # mn "Oh, es una larga historia jaja..."
    mn "อ๋อ เรื่องมันยาวน่ะ ฮ่าๆ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest1.rpy:38
translate english ayame_quest1_02494615:

    # mn "Pero no es nada importante, enserio"
    mn "แต่ไม่มีอะไรสำคัญหรอก จริงๆ นะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest1.rpy:41
translate english ayame_quest1_3527ea9b:

    # ay "Aah... Ninjas..."
    ay "อ่า... นินจานี่นะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest1.rpy:43
translate english ayame_quest1_c72ddbe4:

    # ay "Y bien, ¿Qué te trae por aquí?"
    ay "ว่าแต่ มีลมอะไรหอบเธอมาถึงนี่ล่ะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest1.rpy:45
translate english ayame_quest1_406c8b4b:

    # ay "No sueles venir solo a saludar"
    ay "ปกติเธอไม่ค่อยมาแค่เพราะแวะมาทักทายเฉยๆ หรอกนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest1.rpy:48
translate english ayame_quest1_2ce75a71:

    # mn "Bueno... Quería saber si aún está vigente esa oferta de antes..."
    mn "คือว่า... ฉันอยากรู้ว่าข้อเสนอก่อนหน้านี้เนี่ย มันยังใช้ได้อยู่รึเปล่า..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest1.rpy:51
translate english ayame_quest1_236ca290:

    # ay "¿Te refieres a...?"
    ay "หมายถึง...?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest1.rpy:54
translate english ayame_quest1_6f0fcd33:

    # mn "Sí, luego de pensarlo un poco, tal vez si deba aprovechar el que quieras ayudarme"
    mn "อือ หลังจากลองคิดดูสักหน่อยแล้ว ฉันคิดว่าฉันน่าจะลองใช้โอกาสที่เธออยากช่วยฉันดูน่ะนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest1.rpy:56
translate english ayame_quest1_0318d7a6:

    # mn "Seguro que aprendo algo nuevo"
    mn "ฉันมั่นใจว่าจะต้องได้เรียนรู้อะไรใหม่ๆ แน่ๆ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest1.rpy:59
translate english ayame_quest1_1fe0e2ba:

    # ay "Vaya... Pensé que lo habías descartado pero... Sí, esa oferta aún está vigente"
    ay "โห... นึกว่าเธอปัดตกไปซะอีก แต่... ได้สิ ข้อเสนอนั้นยังใช้ได้อยู่เสมอ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest1.rpy:62
translate english ayame_quest1_20327eec:

    # ay "Sólo que como podrás ver, en este momento no puedo irme"
    ay "เพียงแต่... อย่างที่เห็น ตอนนี้ฉันยังปลีกตัวไปไม่ได้"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest1.rpy:64
translate english ayame_quest1_7be428eb:

    # mn "¿Debería venir en otro momento?"
    mn "งั้นฉันควรมาใหม่วันหลังเหรอ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest1.rpy:68
translate english ayame_quest1_9ca4a33d:

    # ay "Ven en la noche"
    ay "มาตอนกลางคืนสิ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest1.rpy:70
translate english ayame_quest1_ecd0744a:

    # ay "Es cuando se hace el cambio de turno"
    ay "ตอนนั้นจะเป็นช่วงเปลี่ยนกะพอดี"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest1.rpy:73
translate english ayame_quest1_cf12cd14:

    # mn "Cierto, Yuriko trabaja en el turno de la noche"
    mn "จริงสินะ ยูริโกะเข้ากะดึกนี่นา"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest1.rpy:76
translate english ayame_quest1_61b3ae2a:

    # ay "Así es, aún así te estaré esperando cerca del local"
    ay "ถูกต้องแล้วล่ะ เดี๋ยวฉันจะรอเธออยู่แถวๆ ร้านก็แล้วกัน"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest1.rpy:79
translate english ayame_quest1_14921d88:

    # ay "Ven más tarde"
    ay "เอาไว้ค่อยมาทีหลังนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest1.rpy:82
translate english ayame_quest1_7e0394ca:

    # ay "Ya he acabado mi turno, solo debo de esperar a Yuriko para que siga su turno"
    ay "ฉันทำงานเสร็จพอดี เหลือแค่รอให้ยูริโกะมาเปลี่ยนกะน่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest1.rpy:84
translate english ayame_quest1_3eea4abb:

    # ay "Vuelve luego, yo te estaré esperando fuera del local"
    ay "ไวรัสค่อยกลับมาใหม่นะ ฉันจะรอเธออยู่ข้างนอกร้านเอง"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest1.rpy:86
translate english ayame_quest1_44bc009a:

    # ay "De hecho esa es la primera lección"
    ay "อันที่จริง นั่นคือบทเรียนแรกเลยล่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest1.rpy:88
translate english ayame_quest1_c44e1c48:

    # ay "Nunca dejes esperando a una dama"
    ay "อย่าปล่อยให้ผู้หญิงต้องรอนานสิ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest1.rpy:92
translate english ayame_quest1_b600428d:

    # mn "Está bien, vendré luego"
    mn "โอเค เดี๋ยวฉันค่อยมาใหม่นะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest1.rpy:95
translate english ayame_quest1_9ff28ccf:

    # n "Luego de la charla con Ayame, [MN] salió de Ichiraku Ramen"
    n "หลังจากการพูดคุยกับอายาเมะ [MN] ก็เดินออกจากร้านอิจิราคุ ราเมน"
