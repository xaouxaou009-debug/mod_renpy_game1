# TODO: Translation updated at 2024-02-17 12:30

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:5
translate english ino_quest1_42a8e141:

    # "{b}-En las calles de la Aldea de la hoja-{/a}"
    "{b}- บนถนนแห่งหมู่บ้านโคโนฮะ -{/a}"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:9
translate english ino_quest1_e99c757f:

    # mn "Hace días quedé en visitar a Ino"
    mn "ฉันตกลงว่าจะมาหาอิโนะตั้งแต่ไม่กี่วันก่อน"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:10
translate english ino_quest1_5060362b:

    # mn "Veré si está en la tienda"
    mn "ลองไปดูหน่อยดีกว่าว่าเธออยู่ในร้านไหม"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:12
translate english ino_quest1_bb3a19af:

    # n "[MN] entra en la tienda"
    n "[MN] เดินเข้าไปในร้าน"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:16
translate english ino_quest1_0d4661c0:

    # mn "¿Hola?"
    mn "มีใครอยู่ไหมครับ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:17
translate english ino_quest1_1273b8a3:

    # mn "Señorita Ino, ¿Está ahí?"
    mn "คุณอิโนะ อยู่หรือเปล่าครับ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:18
translate english ino_quest1_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:19
translate english ino_quest1_a3fa914e:

    # mn "No se escucha ni Mú"
    mn "เงียบกริบขนาดนี้ เสียงตูดหมึกก็คงไม่ได้ยินมั้งเนี่ย"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:20
translate english ino_quest1_c0863099:

    # mn "Aah, creo que puedo esperarla un poco..."
    mn "อา... รอเธอสักหน่อยก็แล้วกัน..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:22
translate english ino_quest1_782222e6:

    # n "Mientras [MN] espera a Ino en la tienda"
    n "ระหว่างที่ [MN] รออิโนะอยู่ที่ร้าน"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:25
translate english ino_quest1_1e43af4c:

    # n "Escucha un estruendo fuera de la tienda y va a revisar"
    n "เขาก็ได้ยินเสียงข้าวของตกแตกดังมาจากนอกร้าน จึงออกไปดู"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:28
translate english ino_quest1_e9a91995:

    # mn "¡¿S-Señorita Ino?!"
    mn "ค-คุณอิโนะ?!"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:29
translate english ino_quest1_dc64b689:

    # ino "A-Ah... ¿[MN]?"
    ino "อ-อ่า... [MN]?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:30
translate english ino_quest1_d7b68084:

    # mn "D-Déjeme ayudarle"
    mn "ด-เดี๋ยวผมช่วยครับ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:32
translate english ino_quest1_aca9e62b:

    # n "Después de ayudarle a levantarse, [MN] le ayuda a Ino a meter las cajas al almacén de la tienda"
    n "หลังจากช่วยเธอพยุงลุกขึ้น [MN] ก็ช่วยอิโนะขนกล่องเข้าไปเก็บในห้องเก็บของของร้าน"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:33
translate english ino_quest1_88a53a24:

    # n "Y así hasta que se hizo tarde..."
    n "แล้วก็ช่วยกันจนกระทั่งเย็นค่ำ..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:39
translate english ino_quest1_d99afdc4:

    # ino "Muchas gracias [MN]"
    ino "ขอบคุณมากเลยนะ [MN]"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:40
translate english ino_quest1_a6f35da7:

    # ino "Esas cajas eran muy pesadas, y ya he perdido un poco mi condición física por la edad..."
    ino "กล่องพวกนั้นมันหนักมากเลยล่ะ แถมช่วงนี้ฉันเริ่มแก่ลง สรรพกำลังก็เลยถดถอยไปบ้างแล้ว..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:41
translate english ino_quest1_caef3d5f:

    # mn "No se preocupe jaja..."
    mn "ไม่ต้องคิดมากเลยครับ ฮ่าๆ..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:42
translate english ino_quest1_cd088c2d:

    # mn "De hecho la estaba buscando"
    mn "ความจริงแล้วผมตั้งใจมาหาเธอนั่นแหละครับ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:43
translate english ino_quest1_edc13255:

    # ino "Oh, ¿Enserio?"
    ino "อ๋อ,  เหรอ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:44
translate english ino_quest1_93ebbd2b:

    # ino "¿Y qué hacías aquí?"
    ino "แล้วมาทำอะไรที่นี่ล่ะเนี่ย?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:45
translate english ino_quest1_a1caab1b:

    # ino "¿Necesitabas una flor para regalársela a tu enamorada?"
    ino "มาหาดอกไม้ไปให้แฟนสาวหรือยังไง?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:46
translate english ino_quest1_b141a6f3:

    # mn "Ah, no es eso jaja"
    mn "อ่า ไม่ใช่แบบนั้นหครับ ฮ่าๆ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:47
translate english ino_quest1_a427eb39:

    # ino "Oh, ¿Entonces no tienes una enamorada?"
    ino "อ้าว งั้นเหรอ แปลว่ายังไม่มีแฟนสินะ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:48
translate english ino_quest1_62b9cbd1:

    # mn "Mmm... Bueno, realmente no lo sé..."
    mn "อืม... คือผมก็ไม่ค่อยแน่ใจเหมือนกันครับ..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:49
translate english ino_quest1_f1b96b77:

    # ino "¿No lo sabes?"
    ino "ไม่แน่ใจเนี่ยนะ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:50
translate english ino_quest1_dce199eb:

    # mn "Es complicado, pero no es eso a lo que vine"
    mn "มันมีเรื่องซับซ้อนนิดหน่อยน่ะครับ แต่ว่าผมไม่ได้มาเรื่องนั้นหรอก"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:51
translate english ino_quest1_a42dde3c:

    # mn "Recuerdo que me dijo que volviera para charlar"
    mn "ผมจำได้ว่าคุณบอกให้ผมแวะมาคุยเล่นด้วยกันนี่นา"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:52
translate english ino_quest1_f8bff5a4:

    # mn "S-Se le olvidó?"
    mn "ห-หรือว่าจำไม่ได้แล้วครับ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:53
translate english ino_quest1_92e5dde9:

    # ino "..."
    ino "..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:54
translate english ino_quest1_5f5a34b7:

    # ino "Ah, no jaja"
    ino "อ๊ะ เปล่าสักหน่อย ฮ่าๆ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:55
translate english ino_quest1_35f1d513:

    # ino "Es solo que pensé que no vendrías"
    ino "แค่คิดว่าเธอคงจะไม่มาซะอีก"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:56
translate english ino_quest1_5c8ce9fb:

    # ino "Y menos que me vendrías así, llena de tierra..."
    ino "แถมยังโผล่มาหาฉันในสภาพเนื้อตัวมอมแมมแบบนี้อีก..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:57
translate english ino_quest1_4d7c620c:

    # mn "Bueno... Puedo venir otro día si así lo gusta"
    mn "งั้น... ผมมาวันอื่นก็ได้นะครับถ้าคุณสะดวก"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:58
translate english ino_quest1_59425907:

    # ino "Ah, no es necesario jaja"
    ino "อ่า ไม่จำเป็นหรอก ฮ่าๆ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:59
translate english ino_quest1_b6e4dd04:

    # ino "De hecho, ¿Qué te parece si esperas que me arregle y vamos a beber un poco?"
    ino "อันที่จริง... ถ้างั้นรอฉันเตรียมตัวสักครู่แล้วไปดื่มด้วยกันหน่อยไหมล่ะ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:60
translate english ino_quest1_d93194c0:

    # ino "Hace unos días abrió un bar en la aldea"
    ino "เมื่อไม่กี่วันก่อนมีบาร์เปิดใหม่ในหมู่บ้านด้วยล่ะ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:61
translate english ino_quest1_90dfa958:

    # ino "Se llama Succubu´s Bar, ¿Te parece si vamos?"
    ino "ชื่อว่าซัคคิวบัสส์บาร์ สนใจไปหน่อยไหมล่ะ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:62
translate english ino_quest1_1c5f3492:

    # mn "Claro, por mí perfecto"
    mn "เอาสิครับ เหมาะกับผมเลย"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:63
translate english ino_quest1_78b2237f:

    # mn "Pero, ¿Se irá así?"
    mn "แต่ว่า... จะไปในสภาพนี้เลยเหรอครับ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:64
translate english ino_quest1_37e706b1:

    # ino "No jaja, ¿Cómo crees?"
    ino "เปล่าสักหน่อย ฮ่าๆ คิดว่าไงล่ะเนี่ย?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:65
translate english ino_quest1_1f15c18e:

    # ino "Obvio me bañaré y me cambiaré de ropa"
    ino "ก็ต้องไปอาบน้ำเปลี่ยนชุดสิยะ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:66
translate english ino_quest1_00509c2d:

    # ino "Créeme que esta no es la primera ver que me cae tierra"
    ino "เชื่อฉันเถอะว่านี่ไม่ใช่ครั้งแรกที่เนื้อตัวเปอะเปื้อนหรอกนะ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:67
translate english ino_quest1_83784cef:

    # ino "Ha pasado más de lo que me gustaría..."
    ino "มันก็นานกว่าที่ฉันอยากให้เป็นนิดหน่อยล่ะนะ..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:68
translate english ino_quest1_7d101a1f:

    # mn "Bueno, en ese caso la esperaré aquí"
    mn "งั้นถ้าอย่างนั้นผมรออยู่ตรงนี้นะครับ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:69
translate english ino_quest1_1e7572f6:

    # ino "Bien, solo dame unos minutos para arreglarme"
    ino "โอเค รอแป๊บเดียว เดี๋ยวฉันไปเตรียมตัวก่อน"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:74
translate english ino_quest1_c6fc0e71:

    # n "Media hora más tarde"
    n "ครึ่งชั่วโมงต่อมา"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:76
translate english ino_quest1_85b77973:

    # mn "(...)"
    mn "(...)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:77
translate english ino_quest1_8924a8a7:

    # mn "(Ya se ha tardado mucho, ¿No?)"
    mn "(นานเกินไปแล้วมั้งเนี่ย?)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:81
translate english ino_quest1_fcd7107e:

    # mn "(¿Será que le pasó algo?)"
    mn "(จะมีอะไรเกิดขึ้นกับเธอหรือเปล่านะ?)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:82
translate english ino_quest1_568ce163:

    # ino "Vaya, aún sigues aquí"
    ino "โอ๊ะ ยังอยู่เหรอเนี่ย"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:85
translate english ino_quest1_d8643f12:

    # mn "¡S-Señorita Ino!"
    mn "ม-คุณอิโนะ!"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:88
translate english ino_quest1_c9af7981:

    # mn "¿P-Porqué anda solo una toalla?"
    mn "ท-ทำไมคุณถึงใส่แค่ผ้าขนหนูผืนเดียวล่ะครับเนี่ย?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:89
translate english ino_quest1_e01d65f2:

    # ino "¿Esto?"
    ino "นี่เหรอ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:90
translate english ino_quest1_0d406cc4:

    # ino "Pues, acabo de bañarme"
    ino "ก็ฉันเพิ่งอาบน้ำเสร็จนี่นา"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:91
translate english ino_quest1_95e58746:

    # ino "Solo quería verificar que no me hubieras dejado plantada"
    ino "แค่อยากจะออกมาเช็กดูหน่อยว่าเธอเบี้ยวฉันไปหรือยังต่างหาก"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:92
translate english ino_quest1_4c363d59:

    # mn "Y-Yo jamás haría eso..."
    mn "ผ-ผมไม่ทำแบบนั้นหรอกครับ..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:93
translate english ino_quest1_a5227c26:

    # mn "Yo nunca me retracto de mi palabra"
    mn "ผมเป็นคนรักษาคำพูดเสมอนั่นแหละครับ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:94
translate english ino_quest1_92e5dde9_1:

    # ino "..."
    ino "..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:95
translate english ino_quest1_7bef108d:

    # ino "Muy bien, así me gusta"
    ino "เยี่ยมไปเลย งั้นแหละที่ฉันชอบ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:96
translate english ino_quest1_90231010:

    # ino "Entonces ya regreso"
    ino "งั้นเดี๋ยวฉันมานะ ขอเวลาแป๊บเดียว"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:99
translate english ino_quest1_62ba6e1a:

    # "Ino regresa al almacén de la tienda"
    "อิโนะเดินกลับเข้าไปในห้องเก็บของของร้าน"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:101
translate english ino_quest1_32462c4b_1:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:104
translate english ino_quest1_13f776f2:

    # mn "(¿Enserio no le dió vergüenza salir en toalla)"
    mn "(ให้ตายสิ เธอไม่อายเลยหรือไงที่ใส่ผ้าขนหนูผืนเดียวเดินออกมาเนี่ย?)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:105
translate english ino_quest1_85b77973_1:

    # mn "(...)"
    mn "(...)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:106
translate english ino_quest1_c92751b7:

    # mn "(Siempre pensé que era bastante sexy, pero verla así...)"
    mn "(ผมคิดมาตลอดนะว่าเธอเซ็กซี่มากๆ แต่พอมาเห็นสภาพนี้...)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:108
translate english ino_quest1_bbf9c996:

    # mn "Me preguto si..."
    mn "สงสัยจังว่า..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:116
translate english ino_spy1_535722ff:

    # mn "Un vistazo no hará daño, ¿No?"
    mn "แอบมองนิดเดียวคงไม่เป็นไรหมั้ง?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:117
translate english ino_spy1_03b5f4b0:

    # mn "Ahora que ya controlo el Karugan, no me verá"
    mn "ในเมื่อตอนนี้ฉันควบคุมเนตรคารูกันได้แล้ว เธอจะต้องมองไม่เห็นฉันแน่"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:118
translate english ino_spy1_61a0d6d8:

    # mn "Se activa así, si no me equivoco..."
    mn "ถ้าจำไม่ผิด มันต้องเปิดใช้งานแบบนี้สินะ..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:129
translate english ino_spy1_5c381ae4:

    # mn "¡Karugan!"
    mn "คารูกัน!"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:131
translate english ino_spy1_5ea1dfd5:

    # mn "Muy bien, esto debe de ser rápido, y debo volver antes de que acabe de vestirse"
    mn "เอาล่ะ แป๊บเดียวก็คงเสร็จ แล้วต้องรีบกลับมาก่อนเธอแต่งตัวเสร็จด้วย"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:132
translate english ino_spy1_010c1862:

    # mn "Ahora, vamos"
    mn "เอาล่ะ ไปกันเลย"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:134
translate english ino_spy1_5bf12e50:

    # n "[MN] usando el {b}Jutsu de Invisibilidad{/a} entra al almacén para espiar a Ino"
    n "[MN] ใช้ {b}คาถาล่องหน{/a} แอบย่องเข้าไปในห้องเก็บของเพื่อแอบดูอิโนะ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:139
translate english ino_spy1_d6436d5a:

    # ino "Vaya... Parece que he subido un poco de peso..."
    ino "โฮห... ดูเหมือนช่วงนี้เราจะน้ำหนักขึ้นมานิดหน่อยแฮะ..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:141
translate english ino_spy1_7a8c388e:

    # mn "(Perfecto, si me quedo aquí no habrá riesgo de que escuche algo)"
    mn "(เยี่ยมเลย ถ้าอยู่ตรงนี้ก็ไม่มีความเสี่ยงที่จะโดนจับได้แน่)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:142
translate english ino_spy1_85b77973:

    # mn "(...)"
    mn "(...)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:144
translate english ino_spy1_fe227c80:

    # ino "Necesito hacer más ejercicio..."
    ino "สงสัยต้องออกกำลังกายเพิ่มซะแล้ว..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:145
translate english ino_spy1_6c894275:

    # ino "Estar sentada en todo el día me va a hacer mal"
    ino "นั่งอยู่เฉยๆ ทั้งวันแบบนี้ เดี๋ยวได้ป่วยเอาแน่ๆ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:147
translate english ino_spy1_1e136392:

    # ino "*suspiro* Si tan solo Sai no tuviera ese problema de {b}Disfunción{/a}"
    ino "*เฮ้อ* ถ้าซาอิไม่ได้มีปัญหาเรื่อง{b}เสื่อมสมรรถภาพ{/a}นั่นละก็..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:148
translate english ino_spy1_0dc3fc4c:

    # ino "Ese tipo de ejercicio podría ayudarme a quemar un poco calorías al menos"
    ino "การออกกำลังกายแบบนั้น อย่างน้อยก็น่าจะช่วยให้ฉันเผาผลาญแคลอรีไปได้บ้างล่ะน่า"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:149
translate english ino_spy1_e0c6998e:

    # ino "Tendré que empezar a correr de ahora en adelante"
    ino "สงสัยฉันต้องเริ่มไปวิ่งตั้งแต่วันนี้ซะแล้วสิ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:151
translate english ino_spy1_6a934d6f:

    # mn "(¿Sai tiene Disfunción erectil?)"
    mn "(ซาจินี่มีปัญหาเสื่อมสมรรถภาพทางเพศงั้นเหรอ?)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:152
translate english ino_spy1_e0fb98fd:

    # mn "(Pero... Si hasta tienen un hijo, ¿Cómo puede ser posible?)"
    mn "(แต่... ถ้าพวกเขามีลูกด้วยกันได้ มันจะเป็นไปได้ยังไงล่ะนั่น?)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:154
translate english ino_spy1_4069a296:

    # ino "Aah, ¿Porqué es tan difícil ponerme esto ahora?"
    ino "อ่า ทำไมตอนนี้ใส่มันยากเย็นนักนะ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:155
translate english ino_spy1_d410814d:

    # ino "¿En serio he subido tanto de peso?"
    ino "นี่ฉันน้ำหนักขึ้นมาเยอะขนาดนั้นเลยเหรอเนี่ย?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:156
translate english ino_spy1_dd590726:

    # ino "Maldita sea... Esto ya es serio..."
    ino "แย่ละ... ชักจะเรื่องใหญ่แล้วสิเนี่ย..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:157
translate english ino_spy1_5367ce5f:

    # ino "Me tengo que dar prisa, ya he hecho esperar mucho a [MN]"
    ino "ต้องรีบแล้ว ปล่อยให้ [MN] รอนานเกินไปแล้วด้วยสิ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:159
translate english ino_spy1_0e2b4708:

    # mn "(Creo que el espectáculo terminó)"
    mn "(ดูท่าความบันเทิงจะจบลงแค่นี้สินะ)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:160
translate english ino_spy1_d91b6cc1:

    # mn "(Mejor lo dejo aquí antes de escuchar más de su vida privada)"
    mn "(ชิ่งหนีตอนนี้ก่อนจะรู้เรื่องส่วนตัวของหมอนั่นไปมากกว่านี้ดีกว่า)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:162
translate english ino_spy1_66a3403b:

    # n "[MN] vuelve a la tienda sin hacer ruido"
    n "[MN] เดินกลับมาที่หน้าร้านโดยไม่ส่งเสียงดังเลยสักนิด"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:163
translate english ino_spy1_2c21a831:

    # n "Y espera a que Ino esté lista"
    n "แล้วยืนรอจนกว่าอิโนะจะเตรียมตัวเสร็จ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:169
translate english ino_quest1_2_d98fbe58:

    # n "Luego de unos cuantos minutos"
    n "ผ่านไปไม่กี่นาที"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:176
translate english ino_quest1_2_c1089847:

    # ino "Muy bien, ya estoy lista, ya podemos irnos"
    ino "โอเค ฉันพร้อมแล้ว ไปกันได้เลย"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:177
translate english ino_quest1_2_d1f9a623:

    # mn "Bien, pero, ¿Dónde está el Bar al que irémos?"
    mn "โอเค ว่าแต่บาร์ที่เราจะไปนี่มันอยู่ไหนเหรอ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:178
translate english ino_quest1_2_aaba7b63:

    # ino "Solo sígueme, yo te llevo"
    ino "เดินตามฉันมาก็พอ เดี๋ยวฉันพาไปเอง"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:180
translate english ino_quest1_2_deb0a470:

    # n "Ino y [MN] salen de la tienda, y se dirigen al nuevo Bar de la aldea"
    n "อิโนะกับ [MN] เดินออกจากร้าน แล้วมุ่งหน้าไปยังบาร์แห่งใหม่ของหมู่บ้าน"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:187
translate english ino_quest1_2_009fc254:

    # mn "Vaya..."
    mn "โห..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:188
translate english ino_quest1_2_34d91ec2:

    # ino "¿Está bonito el lugar no?"
    ino "บรรยากาศดีใช่ไหมล่ะ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:189
translate english ino_quest1_2_697fde80:

    # mn "Si, me gusta el estilo tradicional que tiene"
    mn "อืม ชอบสไตล์แบบดั้งเดิมของที่นี่จัง"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:190
translate english ino_quest1_2_2c15dd63:

    # ino "Ven, tomemos una mesa"
    ino "มาเถอะ ไปหาโต๊ะนั่งกัน"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:192
translate english ino_quest1_2_0cd9b0b2:

    # n "Ino y [MN] se sientan en una mesa"
    n "อิโนะกับ [MN] เลือกโต๊ะนั่งและหย่อนตัวลงนั่ง"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:193
translate english ino_quest1_2_02eb85a2:

    # n "Poco después [MN] le cuenta a Ino la historia de como obtuvo el Karugan"
    n "หลังจากนั้นไม่นาน [MN] ก็เล่าเรื่องที่ได้เนตรคารูกันมาให้อิโนะฟัง"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:195
translate english ino_quest1_2_84b18672:

    # ino "Vaya, ¿Entonces por eso es amarillo?"
    ino "งั้นหรอ มิน่าล่ะตาของนายถึงเป็นสีเหลือง?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:196
translate english ino_quest1_2_6fb2e43c:

    # mn "Si, aunque aún estoy dominándolo"
    mn "ใช่ ถึงฉันจะยังควบคุมมันได้ไม่เต็มที่ก็เถอะนะ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:197
translate english ino_quest1_2_4d625cc1:

    # ino "¿Y qué hace?"
    ino "แล้วมันทำอะไรได้บ้างล่ะ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:198
translate english ino_quest1_2_42e19283:

    # ino "Me refiero, El Sharingan que posees te otorga un gran poder"
    ino "แบบว่า เนตรวงแหวนที่นายมีน่ะมันมอบพลังที่ยิ่งใหญ่ให้เลยไม่ใช่เหรอ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:199
translate english ino_quest1_2_7a72a98a:

    # ino "¿Pero este {b}Karugan{/a} que hace?"
    ino "แล้วเจ้า {b}คารูกัน{/a} นี่มันทำอะไรได้บ้างล่ะ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:201
translate english ino_quest1_2_870bdddc:

    # mn "(¿Debería decirle lo de la invisibilidad?)"
    mn "(ควรบอกเรื่องคาถาล่องหนให้เธอรู้ดีไหมนะ?)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:202
translate english ino_quest1_2_ece80bc1:

    # mn "(Digo, hace un rato la usé para espiarla mientras se cambiaba)"
    mn "(แบบว่า เมื่อกี้ฉันเพิ่งใช้มันแอบดูตอนเธอเปลี่ยนเสื้อผ้าเองนะ)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:203
translate english ino_quest1_2_b9adf013:

    # mn "(No creo que me haya escuchado, fuí muy sigiloso)"
    mn "(คิดว่าเธอคงไม่ได้ยินหรอก ฉันยิ่งย่องเบาเก่งอยู่ด้วย)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:204
translate english ino_quest1_2_2f3fe112:

    # mn "(Pero no quiero un mal entendido...)"
    mn "(แต่ไม่อยากให้เข้าใจผิดกันนี่สิ...)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:205
translate english ino_quest1_2_b093afb0:

    # mn "(Creo que ya no la mencionaré de ahora en adelante)"
    mn "(งั้นไม่พูดถึงเรื่องนี้ดีกว่า)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:207
translate english ino_quest1_2_c3569409:

    # mn "Pues, realmente no estoy seguro"
    mn "อืม ฉันเองก็ไม่ค่อยแน่ใจเหมือนกัน"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:208
translate english ino_quest1_2_667de664:

    # mn "Quizás tenga algún poder que aún no he despertado"
    mn "บางทีฉันอาจจะมีพลังบางอย่างที่ยังไม่ได้ปลุกมันขึ้นมาก็ได้มั้ง"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:209
translate english ino_quest1_2_9190aae1:

    # ino "Entiendo..."
    ino "งั้นเหรอ..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:210
translate english ino_quest1_2_03b72925:

    # ino "Bueno, si necesitas ayuda en el futuro, no dudes en decirme"
    ino "งั้นถ้าในอนาคตมีเรื่องอะไรให้ช่วย อย่าลังเลที่จะบอกฉันนะ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:211
translate english ino_quest1_2_7956857a:

    # ino "No me vendría mal hacer algo de ejercicio"
    ino "ถือซะว่าได้ออกกำลังกายไปในตัวด้วย"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:212
translate english ino_quest1_2_86ce2826:

    # mn "Si, lo tendré en mente jaja"
    mn "อืม ฉันจะจำไว้ ฮ่าๆ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:213
translate english ino_quest1_2_bdb4400d:

    # ino "Oh, ahí viene la comida"
    ino "อ๊ะ อาหารมาแล้ว"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:215
translate english ino_quest1_2_9a6d18bf:

    # n "Llega la comida que pidieron, y poco después de acabarsela siguen charlando"
    n "อาหารที่สั่งไว้มาเสิร์ฟ และหลังจากทานเสร็จได้ไม่นานพวกเขาก็คุยกันต่อ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:217
translate english ino_quest1_2_befffd7a:

    # mn "Aaaah..."
    mn "อ่าห์..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:218
translate english ino_quest1_2_6edc960e:

    # mn "Muchas gracias por la comida"
    mn "ขอบคุณสำหรับอาหารนะ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:219
translate english ino_quest1_2_3286ad35:

    # mn "Venden comida muy rica en este lugar"
    mn "ที่นี่ทำอาหารอร่อยมากเลย"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:220
translate english ino_quest1_2_700ff747:

    # ino "Si, de vez en cuando vengo a beber con Sakura"
    ino "ใช่แล้ว นานๆ ทีฉันก็มาดื่มกับซากุระเหมือนกัน"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:221
translate english ino_quest1_2_7e896219:

    # mn "¿También venden Alcohol?"
    mn "ที่นี่มีขายแอลกอฮอล์ด้วยเหรอ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:222
translate english ino_quest1_2_403ec80c:

    # ino "Es un Bar, raro sería si no lo hicieran"
    ino "ก็นี่มันบาร์นี่ จะไม่ขายก็แปลกแล้วล่ะ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:223
translate english ino_quest1_2_339db34d:

    # mn "Buen punto jaja"
    mn "นั่นสินะ ฮ่าๆ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:224
translate english ino_quest1_2_07e3884d:

    # ino "¿Quieres un poco?"
    ino "นายเอาหน่อยไหมล่ะ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:225
translate english ino_quest1_2_d5a0ddb9:

    # ino "¿O aún eres muy pequeño para beber?"
    ino "หรือว่านายยังเด็กเกินกว่าจะดื่มกันล่ะเนี่ย?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:227
translate english ino_quest1_2_bbfd2dca:

    # mn "¡!"
    mn "!"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:228
translate english ino_quest1_2_ab96d5ef:

    # mn "¿A quién llama pequeño?"
    mn "ใครเด็กกันล่ะฮะ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:229
translate english ino_quest1_2_ccb48593:

    # mn "Ya no soy menor de edad, puedo beber todo lo que quiera"
    mn "ฉันไม่ใช่ผู้เยาว์แล้วนะ จะดื่มเท่าไหร่ก็ได้"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:230
translate english ino_quest1_2_4c605035:

    # ino "¿En serio? Demuéstramelo"
    ino "เหรอ? งั้นโชว์ให้ดูหน่อยสิ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:231
translate english ino_quest1_2_8bf4366a:

    # mn "Eh... ¿D-Demostrártelo?"
    mn "เอ๊ะ... ห-ให้โชว์เหรอ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:232
translate english ino_quest1_2_5d3f6477:

    # ino "Si, demuéstramelo"
    ino "ใช่ โชว์ให้ดูหน่อย"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:233
translate english ino_quest1_2_4b3d0838:

    # ino "¿Te parece una competición?"
    ino "นายจะว่าอะไรไหมถ้าเราจะมาแข่งดื่มกัน?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:234
translate english ino_quest1_2_8e39fee2:

    # ino "El que llegue primero a las 10 copas gana, y el perdedor tendrá que pagar la comida"
    ino "ใครซัดครบ 10 แก้วก่อนชนะ คนแพ้ต้องเป็นคนจ่ายค่าอาหารทั้งหมด"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:235
translate english ino_quest1_2_e23baea0:

    # mn "¿No te parece que 10 copas es mucho?"
    mn "เธอว่า 10 แก้วมันไม่เยอะไปหน่อยเหรอ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:237
translate english ino_quest1_2_af41e19b:

    # ino "Vaya, ¿Tienes miedo?"
    ino "โหว กลัวแล้วเหรอเนี่ย?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:238
translate english ino_quest1_2_ee48acb3:

    # ino "¿10 copas son mucho para tí?"
    ino "10 แก้วมันมากเกินไปสำหรับนายหรือไง?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:239
translate english ino_quest1_2_b612a4ce:

    # ino "Que lindo..."
    ino "น่ารักจังเลยนะ..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:241
translate english ino_quest1_2_bbfd2dca_1:

    # mn "¡!"
    mn "!"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:244
translate english ino_quest1_2_5940c319:

    # mn "¡MUY BIEN!"
    mn "เยี่ยมมาก!"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:245
translate english ino_quest1_2_a566ccbe:

    # mn "¡TRAIGAN EL ALCOHOL!"
    mn "จัดแอลกอฮอล์มาเลย!"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:246
translate english ino_quest1_2_1bf5af57:

    # ino "Jajaja, ¡Así se habla!"
    ino "ฮ่าๆ อย่างงี้ค่อยน่าคุยกันหน่อย!"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:248
translate english ino_quest1_2_a20cefa7:

    # "..."
    "..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:249
translate english ino_quest1_2_0fb5f00e:

    # n "10 Minutos más tarde..."
    n "ผ่านไป 10 นาที..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:251
translate english ino_quest1_2_25ae4728:

    # ino "¡OTRA!"
    ino "อีกแก้ว!"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:253
translate english ino_quest1_2_bd9b9dd8:

    # mn "¡OTRA!"
    mn "อีกแก้ว!"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:254
translate english ino_quest1_2_e7555ca6:

    # mn "¿Estás lista para perder?"
    mn "พร้อมจะแพ้หรือยังล่ะ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:255
translate english ino_quest1_2_f621bf73:

    # mn "Solo me falta una más para ganar ¡jajaja!"
    mn "ฉันต้องการอีกแค่แก้วเดียวก็จะชนะแล้ว ฮ่าๆๆ!"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:256
translate english ino_quest1_2_f5783e23:

    # ino "¿1? Si yo hace 3 copas pasé las diez"
    ino "แก้วเดียวงั้นเหรอ? ฉันซัดครบสิบไปตั้งแต่สามแก้วก่อนแล้วย่ะ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:257
translate english ino_quest1_2_6ab4b208:

    # mn "¿Qué? Pero si no llevas ni 6"
    mn "หา? แต่เธอยังไม่ถึงหกแก้วเลยนะ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:259
translate english ino_quest1_2_f1d7f06c:

    # ino "¡TÚ NO LLEVAS NI TRES!"
    ino "นายต่างหากที่ยังไม่ถึงสามแก้วด้วยซ้ำ!"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:260
translate english ino_quest1_2_a863e7af:

    # ino "Yo ya gané, así que paga"
    ino "ฉันชนะแล้ว เพราะงั้นจ่ายเงินมาซะดีๆ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:262
translate english ino_quest1_2_9a3e701a:

    # ino "¡CAMARERA!"
    ino "คุณพนักงานเสิร์ฟ!"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:264
translate english ino_quest1_2_aa52db23:

    # ino "¡TRAIGA LO MÁS FUERTE QUE TENGAN!"
    ino "เอาเครื่องดื่มที่แรงที่สุดที่คุณมีมาสิ!"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:265
translate english ino_quest1_2_95d9d614:

    # n "La camarera ignora a Ino, y regresa a la cocina"
    n "พนักงานเสิร์ฟเมินอิโนะแล้วเดินกลับเข้าห้องครัวไป"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:266
translate english ino_quest1_2_906157dc:

    # mn "¡Jajaja!"
    mn "ฮ่าๆๆ!"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:267
translate english ino_quest1_2_50fbd343:

    # mn "Parece que ya no puedes beber más"
    mn "ดูท่าเธอจะดื่มต่อไม่ไหวแล้วสินะ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:268
translate english ino_quest1_2_35b85cd7:

    # ino "Maldita... Eres una inútil"
    ino "ยัยบ้าเอ้ย... ใช้การไม่ได้เลยจริง ๆ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:269
translate english ino_quest1_2_bea67cf4:

    # ino "No necesito de ella para ponerme ebria"
    ino "ฉันไม่ต้องพึ่งยัยนั่นก็เมาได้น่า"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:271
translate english ino_quest1_2_894a693a:

    # ino "¡OYE! Dame tu cerveza"
    ino "นี่! เอาเบียร์ของนายมานี่เลยนะ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:272
translate english ino_quest1_2_fed5681d:

    # mn "Jaja, será mejor que ya no bebas jajaja..."
    mn "ฮ่าๆ เธอดื่มต่ออีกไม่ไหวแล้วมั้งเนี่ย ฮ่าๆ..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:273
translate english ino_quest1_2_b769a99f:

    # mn "Una más y seguro vomitas"
    mn "ถ้าอีกแก้วล่ะก็ อ้วกแตกแน่ ๆ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:274
translate english ino_quest1_2_b43a4c6b:

    # mn "Jajaja..."
    mn "ฮ่าๆๆ..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:275
translate english ino_quest1_2_92e5dde9:

    # ino "..."
    ino "..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:277
translate english ino_quest1_2_b05f6ed9:

    # ino "Bien... No necesito estar ebria"
    ino "โอเค... ฉันไม่ได้อยากเมาซะหน่อย"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:279
translate english ino_quest1_2_8207f0e2:

    # mn "(Maldición, me duele la cabeza...)"
    mn "(เวรเอ้ย ปวดหัวชะมัด...)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:281
translate english ino_quest1_2_f38d750b:

    # mn "Oye, ¿Te parece si ya nos vamos?"
    mn "นี่ เธอว่าเราควรกลับกันได้หรือยัง?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:282
translate english ino_quest1_2_54603123:

    # mn "¿Puedes caminar?"
    mn "ไหวไหมเนี่ย เดินไหวหรือเปล่า?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:283
translate english ino_quest1_2_92e5dde9_1:

    # ino "..."
    ino "..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:284
translate english ino_quest1_2_f0082fd0:

    # ino "Yo... No me quiero ir..."
    ino "ฉัน... ฉันไม่อยากกลับเลย..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:285
translate english ino_quest1_2_c8a7a966:

    # ino "No quiero ir... A mi casa..."
    ino "ไม่อยากกลับ... บ้านเลย..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:286
translate english ino_quest1_2_18791e76:

    # mn "¿Está todo bien en tu casa?"
    mn "ที่บ้านมีเรื่องอะไรรึเปล่า?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:287
translate english ino_quest1_2_1295b44a:

    # ino "No sé si diría bien..."
    ino "จะเรียกว่ามีเรื่องดีไหมนะ..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:288
translate english ino_quest1_2_09d708fc:

    # ino "Con Inojin no tengo problemas..."
    ino "กับอิโนะจินเนี่ยไม่มีปัญหาหรอก..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:289
translate english ino_quest1_2_0bbc24e7:

    # ino "Pero con Sai..."
    ino "แต่กับซาอินี่สิ..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:290
translate english ino_quest1_2_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:291
translate english ino_quest1_2_edc1098e:

    # mn "Puedes hablarlo conmigo si gustas"
    mn "ถ้าอยากเล่าให้ฟังก็ได้นะ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:292
translate english ino_quest1_2_f1277276:

    # mn "Puedes desahogarte"
    mn "ระบายความในใจออกมาได้เลย"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:293
translate english ino_quest1_2_92e5dde9_2:

    # ino "..."
    ino "..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:294
translate english ino_quest1_2_0afadf80:

    # ino "Es..."
    ino "ก็คือ..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:296
translate english ino_quest1_2_04969f39:

    # ino "Es ese bastardo de Sai"
    ino "ก็คือไอ้บ้านั่น... ซาอิตัวแสบนั่นแหละ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:297
translate english ino_quest1_2_84b9cae0:

    # ino "No me ha tocado desde hace años"
    ino "เขาไม่ได้แตะต้องตัวฉันมาหลายปีแล้ว"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:298
translate english ino_quest1_2_1447d50e:

    # ino "El muy insensible no entiende que su disfunción no es normal"
    ino "ไอ้คนไร้ความรู้สึกแถมไม่รู้ตัวเลยสักนิดว่าอาการเสื่อมสมรรถภาพของเขามันไม่ใช่เรื่องปกติ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:299
translate english ino_quest1_2_e90e3b13:

    # mn "¿Sai tiene disfunción?"
    mn "ซาอิมีปัญหาเรื่องเสื่อมสมรรถภาพงั้นเหรอ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:300
translate english ino_quest1_2_35685561:

    # ino "Si... Hace unos años los médicos le dijeron que tenía disfunción"
    ino "ใช่... เมื่อไม่กี่ปีមុន หมอบอกเขาว่าเขามีอาการเสื่อมสมรรถภาพทางเพศน่ะสิ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:301
translate english ino_quest1_2_ea849d69:

    # ino "¿Pero sabes qué es lo que más me molesta?"
    ino "แต่รู้ไหมว่าอะไรที่ทำให้ฉันหงุดหงิดที่สุด?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:302
translate english ino_quest1_2_3244ebae:

    # ino "Que el muy idiota dijo con una sonrisa que no le importaba"
    ino "ไอ้งั่งนั่นดันยิ้มแล้วบอกว่าเขาไม่สนใจด้วยซ้ำ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:304
translate english ino_quest1_2_aa4a9308:

    # ino "¡A MÍ SÍ ME IMPORTA!"
    ino "แต่ฉันสนใจโว้ย!"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:305
translate english ino_quest1_2_df7da0a0:

    # ino "¿Es normal que un hombre se tome tan a la ligera una noticia así?"
    ino "ผู้ชายที่ไหนเขาทำเป็นทองไม่รู้ร้อนกับเรื่องแบบนี้กันเล่า?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:306
translate english ino_quest1_2_25c3fddb:

    # ino "Es como..."
    ino "มันเหมือนกับว่า..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:308
translate english ino_quest1_2_92e5dde9_3:

    # ino "..."
    ino "..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:309
translate english ino_quest1_2_f657670c:

    # ino "Como si yo no le importase..."
    ino "เหมือนกับว่าเขาไม่แคร์ความรู้สึกฉันเลย..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:310
translate english ino_quest1_2_d35c8b19:

    # ino "Simplemente dijo que estaba bien..."
    ino "เขาเอาแต่บอกว่ามันไม่เป็นไร..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:311
translate english ino_quest1_2_68eb6806:

    # ino "Pero no me preguntó lo que yo pensaba..."
    ino "แต่ไม่เคยถามฉันสักคำว่าคิดยังไง..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:312
translate english ino_quest1_2_32462c4b_1:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:314
translate english ino_quest1_2_7d9b0dab:

    # mn "(¿Qué le digo?)"
    mn "(ฉันควรพูดอะไรดีล่ะเนี่ย?)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:315
translate english ino_quest1_2_4f91a9ef:

    # mn "(No quiero decir algo que no deba, más ahora que estoy ebrio)"
    mn "(ไม่อยากพูดอะไรที่ไม่เข้าท่าออกไปเลย โดยเฉพาะตอนที่กำลังเมาแบบนี้ด้วย)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:320
translate english ino_quest1_2_488750e0:

    # mn "Bueno, desde mi punto de vista..."
    mn "อืม ในมุมมองของฉันนะ..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:323
translate english ino_quest1_2_83b82d16:

    # mn "Bueno... Si necesitas quitarte las ganas..."
    mn "คือ... ถ้าเธอต้องการหาทางระบายความใคร่ล่ะก็..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:324
translate english ino_quest1_2_6cbb6e59:

    # mn "Yo puedo ayudarte..."
    mn "ฉันช่วยเธอได้นะ..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:325
translate english ino_quest1_2_716b6879:

    # mn "Claro, si no es el caso, puedes hacer como que no dije nada..."
    mn "แน่นอนว่า ถ้าเธอไม่ได้หมายถึงเรื่องนั้น ก็ถือซะว่าฉันไม่ได้พูดอะไรก็แล้วกัน..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:326
translate english ino_quest1_2_92e5dde9_4:

    # ino "..."
    ino "..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:327
translate english ino_quest1_2_774a5d9e:

    # mn "¿Ino?"
    mn "อิโนะ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:328
translate english ino_quest1_2_4503bb4c:

    # ino "Zzz..."
    ino "คร่อก... ฟี้..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:329
translate english ino_quest1_2_fb8c5c15:

    # mn "¿Eh?"
    mn "หา?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:330
translate english ino_quest1_2_96048725:

    # mn "¿Se durmió?"
    mn "หลับไปแล้วงั้นเหรอ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:331
translate english ino_quest1_2_540d74f1:

    # mn "Ey... Ino..."
    mn "นี่... อิโนะ..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:332
translate english ino_quest1_2_4503bb4c_1:

    # ino "Zzz..."
    ino "คร่อก... ฟี้..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:333
translate english ino_quest1_2_2a9ea2e8:

    # mn "Aaah... Maldita sea, ¿Ahora que hago?"
    mn "โธ่เว้ย... ให้ตายสิ ฉันควรทำยังไงต่อเนี่ย?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:335
translate english ino_quest1_2_e1468756:

    # n "Después de que Ino se durmiera, la camarera hizo acto de precencia, y le cobró toda la cuenta a [MN]"
    n "หลังจากอิโนะหลับไป พนักงานเสิร์ฟก็เดินมาคิดเงินค่าอาหารและเครื่องดื่มทั้งหมดกับ [MN]"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:336
translate english ino_quest1_2_123ce9a1:

    # n "Y los corrieron por perturbar el órden del bar"
    n "แถมยังไล่เขาออกจากร้านเพราะข้อหาทำ 3 ภายในบาร์วุ่นวายอีกด้วย"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:337
translate english ino_quest1_2_4eda1cc9:

    # n "Y [MN] decidió llevar a Ino a su apartamento, ya que este no sabe donde queda la casa de Ino"
    n "และเนื่องจาก [MN] ไม่รู้ว่าบ้านของอิโนะอยู่ที่ไหน เขาจึงตัดสินใจพาเธอมาที่อพาร์ตเมนต์ของตัวเอง"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:338
translate english ino_quest1_2_650efb1d:

    # n "Cuando llegan al apartamento, [MN] la recuesta sobre la cama"
    n "พอมาถึงอพาร์ตเมนต์ [MN] ก็พาเธอนอนลงบนเตียง"

translate english strings:

    # game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:109
    old "Espiarla"
    new "แอบดูเธอ"

    # game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:109
    old "No espiarla"
    new "ไม่แอบดูเธอ"

    # game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:317
    old "Darle un consejo para ayudarla"
    new "ให้คำแนะนำเพื่อช่วยเธอ"

    # game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:317
    old "Decirle que puede hacerlo contigo"
    new "บอกเธอว่าทำกับนายได้นะ"

# TODO: Translation updated at 2024-03-04 17:48

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:29
translate english ino_quest1_3ff7d4c1:

    # mn "Aaah, creo que puedo esperarla un poco..."
    mn "อ่า ฉันว่าฉันรอเธออีกสักหน่อยก็ได้..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:62
translate english ino_quest1_e271273d:

    # mn "Aún para mí están un poco pesadas, ¿Qué hay adentro?"
    mn "ขนาดฉันยังรู้สึกว่ามันหนักเลย ข้างในใส่อะไรมาเนี่ย?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:65
translate english ino_quest1_a675af44:

    # ino "Hay tierra para plantas, puede llgar a ser bastante pesado jaja"
    ino "ดินสำหรับปลูกต้นไม้น่ะค่ะ มันเลยค่อนข้างหนัก ฮ่าๆ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:67
translate english ino_quest1_b68aadca:

    # ino "De verdad es una bendición que estuvieras cerca"
    ino "ถือว่าเป็นโชคดีจริงๆ เลยนะที่มีเธออยู่แถวนี้เนี่ย"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:75
translate english ino_quest1_0025e474:

    # ino "¿Y para qué me necesitabas?"
    ino "แล้วมีอะไรให้ฉันช่วยเหรอ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:86
translate english ino_quest1_e8015b84:

    # mn "Eeeh... Bueno, realmente no lo sé..."
    mn "เอ่อ... คือ ฉันก็ไม่รู้เหมือนกันแฮะ..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:95
translate english ino_quest1_0f62bd7d:

    # mn "¿Recuerda que me dijo que volviera para charlar con ustes?"
    mn "จำที่เธอเคยบอกให้ฉันกลับมาคุยเล่นด้วยได้ไหมล่ะ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:97
translate english ino_quest1_90349189:

    # mn "¿S-Se le olvidó?"
    mn "ร-หรือว่าเธอลืมไปแล้ว?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:104
translate english ino_quest1_ec20cc17:

    # ino "Es solo que... No pensé que vendrías de verdad"
    ino "ก็แค่... ฉันไม่คิดว่านายจะมาจริงๆ นี่นา"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:106
translate english ino_quest1_a22820e2:

    # ino "Y menos que me verías así, llena de tierra..."
    ino "แถมยังมาเห็นฉันในสภาพเปื้อนดินเปื้อนโคลนแบบนี้อีก..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:115
translate english ino_quest1_e00ba27e:

    # ino "De hecho, ¿Qué te parece si vamos a beber un poco?"
    ino "งั้น... เราไปหาอะไรดื่มกันหน่อยไหมล่ะ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:131
translate english ino_quest1_2298e7fc:

    # ino "Créeme... Esta no es la primera ver que me cae tierra"
    ino "เชื่อฉันเถอะ... นี่ไม่ใช่ครั้งแรกที่ฉันโดนดินเปื้อนใส่หรอกนะ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:139
translate english ino_quest1_69526e3d:

    # ino "Perfecto, solo dame unos minutos para arreglarme"
    ino "เยี่ยมเลย รอฉันแป๊บเดียวนะ ขอไปเตรียมตัวก่อน"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:166
translate english ino_quest1_9d3175ee:

    # mn "¡¿P-Porqué anda solo una toalla?!"
    mn "ท-ทำไมเธอถึงใส่แค่ผ้าขนหนูผืนเดียวเนี่ยล่ะ?!"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:169
translate english ino_quest1_8f4f0096:

    # ino "¿Porqué ando una toalla?"
    ino "เหตุผลที่ฉันใส่ผ้าขนหนูเหรอ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:186
translate english ino_quest1_187d1df3:

    # ino "Entonces ya regreso guapo"
    ino "งั้นเดี๋ยวฉันกลับมานะพ่อหนุ่มรูปหล่อ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:213
translate english ino_spy1_e9f73009:

    # mn "Me servirá para entrenar el Karugan"
    mn "มันจะช่วยฉันฝึกคารูกันได้สินะ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:215
translate english ino_spy1_0a032615:

    # mn "Se activa así..."
    mn "เปิดใช้งานแบบนี้สินะ..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:261
translate english ino_spy1_cc012cd5:

    # mn "(Me está doliendo la vista...)"
    mn "(ปวดตาชะมัด...)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:262
translate english ino_spy1_b55748cc:

    # mn "(También dejo de escuchar más de su vida privada)"
    mn "(แถมไม่ได้ยินเรื่องส่วนตัวของเธอต่อแล้วด้วย)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:328
translate english ino_quest1_2_9f852c44:

    # ino "Me refiero, El Sharingan que posees te otorga varias habilidades"
    ino "หมายถึงเนตรวงแหวนที่เธอมีน่ะ มันมีความสามารถหลากหลายเลยนะ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:332
translate english ino_quest1_2_17c41509:

    # mn "(No quiero malos entendidos por esta habilidad...)"
    mn "(ฉันไม่อยากให้เกิดความเข้าใจผิดเกี่ยวกับทักษะนี้เลย...)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:473
translate english ino_quest1_2_b642662c:

    # mn "Aaaah... De verdad que es pesada..."
    mn "อ่า... เธอตัวหนักเป็นบ้าเลย..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:474
translate english ino_quest1_2_b62d32f4:

    # mn "Agh... Maldición... Me duele la cabeza..."
    mn "อึก... เวรเอ๊ย... ปวดหัวชะมัด..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:475
translate english ino_quest1_2_34ce08f8:

    # mn "Por esto no bebo Alcohol... Cuando estoy ebrio me duele mucho la cabeza...."
    mn "นี่แหละคือเหตุผลที่ฉันไม่ดื่มเหล้า... เวลาเมาทีไรแล้วปวดหัวตึบทุกที..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:476
translate english ino_quest1_2_32462c4b_2:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:477
translate english ino_quest1_2_3ca4b46d:

    # mn "¿Y ahora qué debería hacer?"
    mn "ทีนี้ฉันควรทำยังไงดีล่ะเนี่ย?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:478
translate english ino_quest1_2_228663d6:

    # mn "Estoy ebrio, me duele la cabeza, con Ino ebria en mi apartamento..."
    mn "ฉันก็เมา หัวก็ปวด แถมอิโนะดันมาเมาอยู่ในห้องฉันอีก..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:480
translate english ino_quest1_2_32462c4b_3:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:494
translate english ino_quest1_blowjob_0dc669af:

    # mn "(Mmm, tengo una idea...)"
    mn "(อืม ฉันมีไอเดียละ...)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:495
translate english ino_quest1_blowjob_ad7046b8:

    # mn "(Intentaré hacer esto sin que se despierte, porque si lo hace estaré en problemas...)"
    mn "(ลองทำแบบนี้ตอนเธอหลับอยู่ดีกว่า ถ้าเธอตื่นขึ้นมามีหวังซวยแน่...)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:496
translate english ino_quest1_blowjob_5cf0712f:

    # mn "(Bien, aquí voy)"
    mn "(เอาล่ะ ลุยเลยละกัน)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:501
translate english ino_quest1_blowjob_1310d795:

    # mn "¡Ah!"
    mn "อ๊า!"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:502
translate english ino_quest1_blowjob_0ce20af4:

    # mn "Mierda... Que bien se siente..."
    mn "เวรเอ๊ย... เสียวชะมัด..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:503
translate english ino_quest1_blowjob_faba5e41:

    # mn "Intentaré hacer esto sin que se despierte, porque si lo hace estaré en problemas..."
    mn "(ลองทำแบบนี้ตอนเธอหลับอยู่ดีกว่า ถ้าเธอตื่นขึ้นมามีหวังซวยแน่...)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:523
translate english ino_quest1_blowjob_cum_4a61dd09:

    # mn "Mierda... ¡Aquí viene!"
    mn "เวรเอ๊ย... จะมาแล้ว!"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:524
translate english ino_quest1_blowjob_cum_5bcd8b17:

    # mn "¡¡Me vengo!!"
    mn "จะแตกแล้ว!!"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:533
translate english ino_quest1_blowjob_cum_8ae18acc:

    # mn "Aaaaah..."
    mn "อ่าาาาห์..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:534
translate english ino_quest1_blowjob_cum_aecae2f5:

    # mn "Joder... Eso estuvo increíble"
    mn "ให้ตายสิ... สุดยอดไปเลยวะ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:535
translate english ino_quest1_blowjob_cum_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:536
translate english ino_quest1_blowjob_cum_74773814:

    # mn "Mierda... Mejor la limpio..."
    mn "เวรเอ๊ย... ไปเช็ดตัวทำความสะอาดให้เธอหน่อยดีกว่า..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:545
translate english ino_quest1_titjob_3bc679d9:

    # mn "(Mmm, veamos como usas esas tetas...)"
    mn "(อืม มาดูกันซิว่าเธอจะใช้สองเต้านั่นยังไง...)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:546
translate english ino_quest1_titjob_731f21b9:

    # mn "(Para satisfacer a mi pequeño amigo...)"
    mn "(เพื่อปรนเปรอเจ้าโลกน้อยของฉันให้ฟินหน่อย...)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:547
translate english ino_quest1_titjob_5cf0712f:

    # mn "(Bien, aquí voy)"
    mn "(เอาล่ะ ลุยเลยละกัน)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:550
translate english ino_quest1_titjob_c0317797:

    # mn "Joder..."
    mn "ซี๊ด..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:551
translate english ino_quest1_titjob_492c89ea:

    # mn "Que suaves son..."
    mn "นิ่มชะมัด..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:574
translate english ino_quest1_titjob_cum_f08da40b:

    # mn "Agh... Aquí viene..."
    mn "อึก... จะมาแล้ว..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:575
translate english ino_quest1_titjob_cum_596aa6c9:

    # mn "¡¡M-Me vengo!!"
    mn "จ-จะแตกแล้ว!!"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:585
translate english ino_quest1_titjob_cum_8ae18acc:

    # mn "Aaaaah..."
    mn "อ่าาาาห์..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:586
translate english ino_quest1_titjob_cum_aecae2f5:

    # mn "Joder... Eso estuvo increíble"
    mn "ให้ตายสิ... สุดยอดไปเลยวะ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:587
translate english ino_quest1_titjob_cum_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:588
translate english ino_quest1_titjob_cum_74773814:

    # mn "Mierda... Mejor la limpio..."
    mn "เวรเอ๊ย... ไปเช็ดทำความสะอาดหน้าอกให้เธอหน่อยดีกว่า..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:597
translate english ino_quest1_pussylick_60b178d6:

    # mn "(No sé si debería de hacer esto)"
    mn "(ไม่รู้ว่าฉันควรทำดีไหมเนี่ย)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:598
translate english ino_quest1_pussylick_85b77973:

    # mn "(...)"
    mn "(...)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:599
translate english ino_quest1_pussylick_c0e58cfa:

    # mn "(¿Y si se despierta? Es posible que no me de una paliza)"
    mn "(ถ้าเธอตื่นขึ้นมาล่ะ? เผลอๆ อาจโดนกระทืบเอาได้)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:600
translate english ino_quest1_pussylick_85b77973_1:

    # mn "(...)"
    mn "(...)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:601
translate english ino_quest1_pussylick_52c1c35d:

    # mn "(Bueno, el que no arriesga no gana)"
    mn "(ช่างเถอะ ไม่เสี่ยงก็ไม่ได้โชคหรอก)"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:604
translate english ino_quest1_pussylick_c0317797:

    # mn "Joder..."
    mn "ซี๊ด..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:605
translate english ino_quest1_pussylick_700dc536:

    # mn "Que rosada..."
    mn "ชมพูซะจริง..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:606
translate english ino_quest1_pussylick_b25ea4cf:

    # mn "He visto muchas revistas, pero en ninguna sale una vagina así"
    mn "ฉันเคยดูพวกนิตยสารมาก็เยอะ แต่ไม่มีเล่มไหนมีหอยสวยขนาดนี้เลย"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:630
translate english ino_quest1_pussylick_squirt_3ea0343b:

    # ino "Mmm..."
    ino "อืม..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:631
translate english ino_quest1_pussylick_squirt_ba22a166:

    # ino "Ah..."
    ino "อ่า..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:632
translate english ino_quest1_pussylick_squirt_d4ab4498:

    # ino "¡A-Aaaahh!"
    ino "อ-อ้ากกก!"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:642
translate english ino_quest1_pussylick_squirt_ecdfba4f:

    # mn "Mmmm..."
    mn "อืม..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:643
translate english ino_quest1_pussylick_squirt_aecae2f5:

    # mn "Joder... Eso estuvo increíble"
    mn "ให้ตายสิ... สุดยอดไปเลยวะ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:644
translate english ino_quest1_pussylick_squirt_61c3a693:

    # mn "Jamás había visto a una chica venirse con mis propios ojos"
    mn "นี่เป็นครั้งแรกเลยมั้งที่ได้เห็นผู้หญิงเสร็จต่อหน้าต่อตาเนี่ย"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:645
translate english ino_quest1_pussylick_squirt_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:655
translate english ino_quest1_final_931d3bfa:

    # mn "Aaaagh mierda, me duele mucho la cabeza..."
    mn "อ๊ากก เวรเอ๊ย ปวดหัวชิบหายเลย..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:656
translate english ino_quest1_final_130e185c:

    # mn "No vuelvo a tomar en unos cuantos días..."
    mn "อีกสักพักใหญ่ๆ ฉันจะไม่แตะเหล้าอีกแล้ว..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:657
translate english ino_quest1_final_0b168194:

    # mn "Aaagh"
    mn "อ๊ากก"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:662
translate english ino_quest1_final_a20cefa7:

    # "..."
    "..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:663
translate english ino_quest1_final_51730c53:

    # "{b}Por la Mañana{/a}"
    "{b}เช้าวันรุ่งขึ้น{/a}"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:670
translate english ino_quest1_final_01a324be:

    # mn "Mmmm"
    mn "อืมม"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:672
translate english ino_quest1_final_38c86c8e:

    # mn "¿Qué?"
    mn "อะไรนะ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:674
translate english ino_quest1_final_b701593a:

    # mn "Mierda... Mi cabeza..."
    mn "เวรเอ๊ย... ปวดหัวชิบ..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:676
translate english ino_quest1_final_4c17f67a:

    # mn "¿Qué pasó ayer?"
    mn "เมื่อวานเกิดอะไรขึ้นวะเนี่ย?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:678
translate english ino_quest1_final_01a324be_1:

    # mn "Mmmm"
    mn "อืมม"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:680
translate english ino_quest1_final_8e90e63a:

    # mn "Recuerdo que... Fui a beber con Ino..."
    mn "จำได้ว่า... ไปดื่มกับอิโนะ..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:682
translate english ino_quest1_final_442db6c1:

    # mn "Y... Charlamos de muchas cosas, luego ella se desmayó y..."
    mn "แล้วก็... เราคุยกันหลายเรื่องเลย จากนั้นเธอก็หมดสติไป แล้ว..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:684
translate english ino_quest1_final_c765b576:

    # mn "¿Yo la traje aquí?"
    mn "ฉันพาเธอกลับมาที่นี่งั้นเหรอ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:686
translate english ino_quest1_final_a73317bc:

    # mn "Mmm, no lo sé, si lo hice debería de estar aquí"
    mn "อืม ไม่รู้สิ ถ้าฉันทำจริง ๆ มันก็น่าจะอยู่แถวนี้แหละมั้ง"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:689
translate english ino_quest1_final_0ae9bcd0:

    # ""
    ""

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:691
translate english ino_quest1_final_58016ca9:

    # mn "¿Quién será tan temprano?"
    mn "ใครมาเช้าป่านนี้วะเนี่ย?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:694
translate english ino_quest1_final_e18791db:

    # mn "Ya voy..."
    mn "มาแล้ว ๆ..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:699
translate english ino_quest1_final_518eea39:

    # "[MN] abre la puerta"
    "[MN] เปิดประตู"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:705
translate english ino_quest1_final_04b233b4:

    # ino "Hola hola, buenos días guapetón"
    ino "ไฮ ไฮ อรุณสวัสดิ์จ่ะสุดหล่อ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:710
translate english ino_quest1_final_6e07f3c5:

    # mn "¡I-Ino!"
    mn "อ-อิโนะ!"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:712
translate english ino_quest1_final_4a5f57e9:

    # mn "Eh, ¿Qué hace aquí tan temprano?"
    mn "เฮ้ย มาทำอะไรที่นี่แต่เช้าเนี่ย?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:715
translate english ino_quest1_final_c713702b:

    # ino "¿Que qué hago aquí?"
    ino "ฉันมาทำอะไรที่นี่เหรอ?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:717
translate english ino_quest1_final_ad4ed72d:

    # ino "Pues... Aquí dormí anoche"
    ino "ก็... ฉันนอนที่นี่เมื่อคืนไง"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:721
translate english ino_quest1_final_6242d508:

    # mn "¿¡Qué!?"
    mn "อะไรนะ?!"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:724
translate english ino_quest1_final_81f36577:

    # mn "Entonces... ¿Si te traje a mi apartamento?"
    mn "งั้น... ฉันพาเธอกลับมาที่ห้องพักของฉันเหรอเนี่ย?"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:727
translate english ino_quest1_final_f2ea30e0:

    # ino "Eso creo... Desperté dormida en tu cama, y tú dormido en el suelo"
    ino "ก็ว่างั้นนะ... ฉันตื่นมาบนเตียงของนาย ส่วนนายก็นอนอยู่บนพื้น"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:730
translate english ino_quest1_final_4689905d:

    # ino "Lamento que te haya quitado tu cama, enserio no fue mi intención desmayarme"
    ino "ต้องขอโทษด้วยนะที่แย่งเตียงนายมา ฉันไม่ได้ตั้งใจจะสลบไปจริงๆ นะ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:733
translate english ino_quest1_final_5f3ade28:

    # mn "Oh, no se preocupe por eso..."
    mn "อ่า ไม่ต้องคิดมากเรื่องนั้นหรอก..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:736
translate english ino_quest1_final_a45aa3af:

    # mn "Creo que yo también me desmayé cuando vine..."
    mn "ฉันว่าฉันก็คงสลบไปตอนมาถึงเหมือนกัน..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:738
translate english ino_quest1_final_ea96e141:

    # mn "Aunque no estoy seguro... No recuerdo nada de cuando llegamos..."
    mn "แต่ก็ไม่แน่ใจแฮะ... จำอะไรตอนที่เรามาถึงไม่ได้เลย..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:741
translate english ino_quest1_final_6c7e1fa6:

    # ino "Bueno, sea como sea te lo agradezco"
    ino "เอาเป็นว่าไม่ว่ายังไงก็ขอบคุณนะ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:743
translate english ino_quest1_final_9f7808f3:

    # ino "Espero que volvamos a salir pronto, me gustó salir contigo"
    ino "หวังว่าเราจะได้ไปเที่ยวด้วยกันอีกเร็วนี้นะ ฉันชอบเวลาได้ไปไหนมาไหนกับนายจัง"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:746
translate english ino_quest1_final_2d8d39c1:

    # mn "Si, pero a la otra no bebamos alcohol por favor..."
    mn "อืม แต่คราวหน้าเพลาๆ เรื่องเหล้าเบียร์กันหน่อยเถอะนะ..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:749
translate english ino_quest1_final_6897dccf:

    # ino "Jaja, hecho"
    ino "ฮ่าๆ ตกลงตามนั้น"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:751
translate english ino_quest1_final_e7278815:

    # ino "Bueno, entonces ya me retiro"
    ino "งั้นฉันไปก่อนนะ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:753
translate english ino_quest1_final_0afbe3ae:

    # ino "Te dejé una pastilla para la resaca en tu cómoda"
    ino "ฉันวางยาแก้แฮงค์ไว้บนโต๊ะเครื่องแป้งให้นายด้วยล่ะ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:755
translate english ino_quest1_final_d086681d:

    # ino "Espero que sirva"
    ino "หวังว่าจะช่วยได้นะ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:758
translate english ino_quest1_final_e1494098:

    # mn "Oh, muchas gracias"
    mn "อ่า ขอบคุณมากเลยนะ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:760
translate english ino_quest1_final_99b3e1dc:

    # mn "Justo estaba pensando en comprar una"
    mn "ฉันก็กำลังคิดอยู่พอดีว่าจะออกไปซื้อมาทานสักหน่อย"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:763
translate english ino_quest1_final_a3678b7a:

    # ino "Bueno, entonces ya me voy"
    ino "งั้นฉันไปก่อนนะ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:768
translate english ino_quest1_final_1b06132d:

    # "Ino sale del apartamento"
    "อิโนะเดินออกจากห้องพักไป"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:771
translate english ino_quest1_final_35b70610:

    # mn "Espero no haber hecho nada ayer mientras estaba ebrio"
    mn "หวังว่าเมื่อวานตอนเมาฉันคงไม่ได้ทำอะไรลงไปหรอกนะ"

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:773
translate english ino_quest1_final_3643e2dc:

    # mn "No recuerdo nada..."
    mn "จำอะไรไม่ได้เลยแฮะ..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:775
translate english ino_quest1_final_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:778
translate english ino_quest1_final_37828ce6:

    # mn "Bueno, si hubiera hecho algo supongo que ella lo sabría..."
    mn "ช่างเถอะ ถ้าเกิดทำอะไรลงไปจริง ๆ เธอคงรู้ตัวไปแล้วล่ะมั้ง..."

# TODO: Translation updated at 2024-11-29 23:49

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:40
translate english ino_quest1_33930d1c:

    # mn "¡¿S-Señorita Ino?!" with vpunch
    mn "ค-คุณอิโนะ?!" with vpunch

# game/scripts/History/SecundaryStory/Ino/ino_quest1.rpy:54
translate english ino_quest1_05bfded9:

    # ino "Muchas gracias [MN]" with fade
    ino "ขอบคุณมากนะ [MN]" with fade
