# TODO: Translation updated at 2024-12-01 21:25

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:5
translate english arc2_ino_quest1_cca68c50:

    # n "[MN] luego de recibir un mensaje de Naruto la noche anterior, se dirige hacia la oficina del Hokage"
    n "[MN] มุ่งหน้าไปยังห้องทำงานของโฮคาเงะ หลังจากได้รับข้อความจากนารูโตะเมื่อคืนก่อน"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:6
translate english arc2_ino_quest1_e8476ef7:

    # n "Cuando entra, se encuentra con una cara conocida"
    n "เมื่อก้าวเข้าไป [MN] ก็ได้พบกับคนที่คุ้นเคย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:18
translate english arc2_ino_quest1_bb1d233d:

    # mn "Buen día Señor Séptimo, aquí estoy tal y como me lo pidió"
    mn "สวัสดีครับท่านรุ่นที่เจ็ด ผมมาตามที่เรียกแล้วครับ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:19
translate english arc2_ino_quest1_84b0de82:

    # mn "Oh, ¡Ino!, Que sorpresa verte aquí" with vpunch
    mn "อ้าว อิโนะ! ไม่คิดเลยว่าจะได้เจอเธอที่นี่นะเนี่ย" with vpunch

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:20
translate english arc2_ino_quest1_2eae8b70:

    # ino "[MN], que bueno verte de nuevo, ha pasado un tiempo"
    ino "[MN] ดีใจจังที่ได้เจอคุณอีก ไม่ได้เจอกันนานเลยนะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:21
translate english arc2_ino_quest1_a7449b00:

    # ino "¿Así que el será quien nos ayude en esta misión?"
    ino "งั้นเขาก็คือคนที่จะมาช่วยเราในภารกิจนี้สินะคะ?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:22
translate english arc2_ino_quest1_895e7397:

    # nt "Así es, confío en que las habilidades de [MN] nos serán muy útiles para esta misión"
    nt "ถูกต้องแล้ว ฉันเชื่อว่าความสามารถของ [MN] จะเป็นประโยชน์มากสำหรับภารกิจนี้"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:24
translate english arc2_ino_quest1_b7ef29f0:

    # nt "[MN], por lo que veo, ya conoces a Ino, ¿Cierto?"
    nt "[MN] ดูเหมือนว่าเธอจะรู้จักกับอิโนะอยู่แล้วสินะ?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:25
translate english arc2_ino_quest1_72c81275:

    # mn "Sí la conozco, nos hemos cruzado en varias ocaciones antes"
    mn "ครับ รู้จักครับ พวกเราเคยเจอกันมาก่อนหน้านี้บ้างแล้ว"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:26
translate english arc2_ino_quest1_c3dcd40d:

    # nt "Me alegra que se conozcan, eso facilitará el trabajo en equipo"
    nt "ดีแล้วล่ะที่รู้จักกัน จะได้ทำงานร่วมกันง่ายขึ้นหน่อย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:37
translate english arc2_ino_quest1_890d1647:

    # nt "Vayamos al grano entonces"
    nt "งั้นเข้าเรื่องกันเลยดีกว่า"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:38
translate english arc2_ino_quest1_6a16c2fa:

    # nt "Hace unos días, hubo varios robos en el Centro de Investigación de Herramientas Científicas Ninja"
    nt "เมื่อไม่กี่วันก่อน เกิดเหตุลักขโมยขึ้นหลายครั้งที่ศูนย์วิจัยเครื่องมือทางนินจาสาหร่าย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:39
translate english arc2_ino_quest1_e6dcd932:

    # nt "Lo curioso es que Ino no detectó nada inusual, y sabemos lo eficiente que es en su vigilancia de la aldea"
    nt "ที่น่าแปลกคือ อิโนะไม่ได้ตรวจพบความผิดปกติอะไรเลย ทั้งที่เราก็รู้ว่าเธอมีประสิทธิภาพในการเฝ้าระวังหมู่บ้านขนาดไหน"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:40
translate english arc2_ino_quest1_52adfdcf:

    # ino "Mi jutsu me permite sentir el chakra de todas las personas dentro de la Aldea de la Hoja"
    ino "วิชาของฉันช่วยให้สัมผัสจักระของทุกคนในหมู่บ้านโคโนฮะได้ค่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:41
translate english arc2_ino_quest1_128a2107:

    # ino "Es como una especie de domo que cubre toda la aldea, y puedo saber exactamente quién entra y sale de ella"
    ino "มันเหมือนกับโดมที่ครอบคลุมทั้งหมู่บ้านไว้ และฉันสามารถรู้ได้เลยว่าใครเข้าออกบ้าง"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:42
translate english arc2_ino_quest1_3e0added:

    # ino "Si algo o alguien hubiera entrado o actuado, lo habría notado... Pero no he sentido nada"
    ino "ถ้ามีบางสิ่งหรือใครบางคนเข้ามาหรือลงมือทำอะไร ฉันต้องสังเกตเห็นสิ... แต่ฉันกลับไม่รู้สึกอะไรเลย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:43
translate english arc2_ino_quest1_11b0d398:

    # mn "Entonces, ¿Cómo pudieron hacerlo sin que te dieras cuenta?"
    mn "งั้นพวกเขาทำแบบนั้นไปได้ยังไงโดยที่เธอไม่รู้ตัวล่ะ?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:44
translate english arc2_ino_quest1_00e13558:

    # nt "Eso es lo que queremos averiguar, han robado tecnología e información muy importante"
    nt "นั่นแหละคือสิ่งที่เราอยากรู้ พวกมันขโมยเทคโนโลยีและข้อมูลสำคัญมากๆ ไป"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:45
translate english arc2_ino_quest1_627161d3:

    # nt "Así que por eso los traje aquí, quiero asignarles esta misión"
    nt "ฉันถึงพาเธอมาที่นี่ไง ฉันอยากมอบหมายภารกิจนี้ให้"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:46
translate english arc2_ino_quest1_93874a91:

    # nt "A [MN] por tus habilidades en misiones que requieren ser {b}Sigiloso{/a}"
    nt "มอบหมายให้ [MN] เพราะทักษะในการทำภารกิจที่ต้องใช้ความ {b}ลี้ลับ{/a}"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:47
translate english arc2_ino_quest1_37a2dab3:

    # nt "Y tu Ino, por tus habilidades sensoriales, pueden ser muy útiles para ayudar a [MN]"
    nt "ส่วนเธอ อิโนะ ด้วยความสามารถด้านการรับสัมผัส จะช่วยสนับสนุน [MN] ได้เป็นอย่างดี"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:48
translate english arc2_ino_quest1_e4cb47f3:

    # nt "Quiero que trabajen juntos para recuperar la tecnología robada y descubrir quien la ha estado robando"
    nt "ฉันอยากให้พวกเธอร่วมมือกันเพื่อชิงเทคโนโลยีที่ถูกขโมยกลับคืนมา และสืบให้ได้ว่าใครเป็นคนขโมยไป"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:49
translate english arc2_ino_quest1_4c4d4fac:

    # mn "Entendido Señor Séptimo, me aseguraré de que no pase desapercibido nada más"
    mn "เข้าใจแล้วครับท่านรุ่นที่เจ็ด ผมจะไม่ปล่อยให้มีอะไรเล็ดลอดไปได้อีกแน่ครับ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:50
translate english arc2_ino_quest1_04e7388a:

    # nt "Bien. Ahora diríjanse al Centro de Investigación y hablen con {b}Amado y Sumire{/a}"
    nt "งั้นก็เดินทางไปที่ศูนย์วิจัยแล้วคุยกับ {b}อามาโดะและสุมิเระ{/a} ซะนะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:51
translate english arc2_ino_quest1_db848c9f:

    # nt "Ellos están al tanto de la situación y pueden tener información útil"
    nt "พวกเขารับรู้สถานการณ์แล้ว และอาจจะมีข้อมูลที่เป็นประโยชน์กับพวกเธอ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:52
translate english arc2_ino_quest1_0492fd42:

    # nt "Cuento con ustedes. Manténganme informado de cualquier novedad"
    nt "ฝากด้วยนะ มีความคืบหน้ายังไงรายงานฉันด้วย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:53
translate english arc2_ino_quest1_24b7d058:

    # mn "¡Sí señor!"
    mn "รับทราบครับ!"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:57
translate english arc2_ino_quest1_94026e7a:

    # n "Ino y [MN] se van de la Oficina del Hokage"
    n "อิโนะและ [MN] ออกจากห้องทำงานของโฮคาเงะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:58
translate english arc2_ino_quest1_8b161835:

    # n "Al salir, ambos se dirigen rápidamente al Centro de Investigación de Herramientas Científicas Ninja y se reúnen con {b}Sumire{/a} y {b}Amado{/a}"
    n "เมื่อออกมาแล้ว ทั้งสองก็รีบมุ่งหน้าไปยังศูนย์วิจัยเครื่องมือทางนินจา และพบกับ {b}สุมิเระ{/a} และ {b}อามาโดะ{/a}"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:71
translate english arc2_ino_quest1_b9004f11:

    # su "S-Señorita Ino... Y [MN]..."
    su "ค-คุณอิโนะ... กับ [MN]..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:73
translate english arc2_ino_quest1_94121999:

    # am "¿Así que el Hokage los mandó solo a ustedes? Espero si puedan ser de ayuda"
    am "งั้นโฮคาเงะก็ส่งมากันแค่สองคนเหรอ? หวังว่าจะช่วยอะไรได้บ้างนะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:74
translate english arc2_ino_quest1_56cceb7a:

    # ino "El Séptimo Hokage ya nos puso al tanto de la situación"
    ino "ท่านโฮคาเงะรุ่นที่เจ็ดได้อธิบายสถานการณ์ให้พวกเราฟังคร่าวๆ แล้วค่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:75
translate english arc2_ino_quest1_0e2505ba:

    # mn "¿Han encontrado algo que nos pueda ser de utilidad?"
    mn "พวกคุณพอจะมีเบาะแสอะไรที่เป็นประโยชน์กับพวกเราบ้างไหมครับ?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:76
translate english arc2_ino_quest1_1df64a7a:

    # am "Me gustaría... He revisado todos los registros y los sistemas de seguridad, pero no hay nada fuera de lo común"
    am "ก็อยากให้มีอยู่หรอก... ฉันตรวจสอบบันทึกและระบบรักษาความปลอดภัยทั้งหมดแล้ว แต่ไม่มีอะไรผิดปกติเลย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:77
translate english arc2_ino_quest1_36d72ca0:

    # am "Es como si el ladrón hubiera desaparecido sin dejar rastro"
    am "ราวกับว่าขโมยคนนั้นหายตัวไปอย่างไร้ร่องรอยยังไงอย่างงั้น"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:78
translate english arc2_ino_quest1_6a2e3b21:

    # mn "¿Ninguna pista? ¿Ni una mínima señal de intrusión?"
    mn "ไม่มีเบาะแสเลยเหรอ? ไม่มีร่องรอยการบุกรุกเลยสักนิดเลยงั้นเหรอ?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:79
translate english arc2_ino_quest1_3a157664:

    # su "No, los sistemas no detectaron ninguna presencia desconocida, y eso es precisamente lo que se nos hace extraño"
    su "ค่ะ ระบบไม่พบการมีอยู่ของผู้บุกรุกเลย และนั่นแหละคือสิ่งที่ทำให้พวกเราแปลกใจ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:80
translate english arc2_ino_quest1_7560b144:

    # su "Es como si ya estuvieran familiarizados con nuestra tecnología o, peor aún, como si no tuvieran chakra detectable"
    su "ราวกับว่าพวกเขารู้จักเทคโนโลยีของเราเป็นอย่างดี หรือที่แย่กว่านั้นคือ... เหมือนกับว่าพวกเขาไม่มีจักระที่ตรวจจับได้เลยค่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:81
translate english arc2_ino_quest1_11d7e74d:

    # ino "¿Sin chakra detectable? Eso explicaría por qué no sentí nada... ¿Siquiera es eso posible?"
    ino "ไม่มีจักระที่ตรวจจับได้งั้นเหรอ? ถ้างั้นก็อธิบายได้สิว่าทำไมฉันถึงไม่รู้สึกอะไรเลย... เป็นไปได้ด้วยเหรอเนี่ย?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:82
translate english arc2_ino_quest1_4b442caf:

    # am "Bueno, he oído rumores sobre tecnologías que podrían ocultar el chakra por completo..."
    am "อืม ฉันเคยได้ยินข่าวลือเกี่ยวกับเทคโนโลยีที่สามารถซ่อนจักระได้อย่างแนบเนียนอยู่หรอกนะ..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:83
translate english arc2_ino_quest1_081e9afd:

    # am "Aunque aún no conozco ninguna lo suficientemente avanzada para algo de este nivel"
    am "ถึงแม้ฉันจะไม่รู้ว่ามีเทคโนโลยีไหนที่ก้าวหน้าพอจะทำอะไรระดับนี้ได้นะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:84
translate english arc2_ino_quest1_b84ee691:

    # am "Incluso si fueran robots, estos necesitan {b}Chakra{/a} como una fuente de energía"
    am "ต่อให้พวกมันจะเป็นหุ่นยนต์ ก็ยังต้องใช้ {b}จักระ{/a} เป็นแหล่งพลังงานอยู่ดี"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:85
translate english arc2_ino_quest1_deeedfdf:

    # am "Pero hay algo claro, quien quiera que lo haya hecho, sabe exactamente lo que está haciendo"
    am "แต่มีสิ่งหนึ่งที่ชัดเจน คือไอ้คนที่ทำเรื่องนี้รู้ดีว่าตัวเองกำลังทำอะไรอยู่"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:86
translate english arc2_ino_quest1_a1c617d9:

    # mn "¿Qué fue lo que robaron específicamente?"
    mn "แล้วพวกมันขโมยอะไรไปบ้างล่ะครับ?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:87
translate english arc2_ino_quest1_21ce1506:

    # su "Se llevaron varias {b}Herramientas Científicas Ninja{/a} y algunos prototipos que estábamos desarrollando..."
    su "พวกเขากวาด {b}เครื่องมือทางนินจาศาสตร์{/a} ไปหลายชิ้นเลยค่ะ รวมถึงต้นแบบบางส่วนที่เรากำลังพัฒนาอยู่ด้วย..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:88
translate english arc2_ino_quest1_b2d15725:

    # su "También información sobre nuestras investigaciones"
    su "นอกจากนี้ยังเอาข้อมูลเกี่ยวกับการวิจัยของเราไปด้วยค่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:89
translate english arc2_ino_quest1_565454be:

    # su "Todo eso en manos equivocadas podría ser muy peligroso..."
    su "ถ้าของพวกนั้นตกไปอยู่ในมือคนผิดล่ะก็ คงอันตรายมากแน่ๆ..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:90
translate english arc2_ino_quest1_bbf143d1:

    # mn "¿Quién ha tenido acceso a esos proyectos recientemente?"
    mn "ช่วงนี้มีใครบ้างเหรอครับที่เข้าถึงโปรเจกต์เหล่านั้นได้?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:91
translate english arc2_ino_quest1_d0129f9a:

    # su "Tenemos una lista de los empleados y visitantes que han estado en el laboratorio en los últimos meses"
    su "เรามีรายชื่อของพนักงานและผู้มาเยือนที่เข้ามาในห้องทดลองตลอดช่วงไม่กี่เดือนที่ผ่านมาอยู่ค่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:92
translate english arc2_ino_quest1_5837c2ce:

    # am "La mayoría son personas de confianza... Sin embargo, hay alguien que me preocupa"
    am "ส่วนใหญ่เป็นคนที่ไว้ใจได้... แต่ว่านะ มีอยู่คนหนึ่งที่ฉันชักจะกังวลใจแฮะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:93
translate english arc2_ino_quest1_22a5e2a7:

    # ino "¿Quién?"
    ino "ใครเหรอคะ?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:94
translate english arc2_ino_quest1_536bbf7f:

    # su "A-Amado... ¿Acaso...?"
    su "อ-อามาโดะ... หรือว่าจะเป็น...?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:95
translate english arc2_ino_quest1_4b60b53f:

    # am "La actual asistente de Sumire..."
    am "ผู้ช่วยคนปัจจุบันของสุมิเระน่ะสิ..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:96
translate english arc2_ino_quest1_6fb79e02:

    # am "Llegó a la aldea de la hoja hace unos meses, y aunque no tengo pruebas, algo en ella no me cuadra..."
    am "เธอเพิ่งมาที่หมู่บ้านโคโนฮะเมื่อไม่กี่เดือนก่อน ถึงฉันจะไม่มีหลักฐาน แต่มีบางอย่างเกี่ยวกับเธอนี่แหละที่ทำให้ฉันรู้สึกะแคะะคัดใจ..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:97
translate english arc2_ino_quest1_24d9ad40:

    # am "Mi instinto me dice que deberían vigilarla de cerca"
    am "สัญชาตญาณของฉันบอกว่าควรจะจับตาดูเธอไว้ให้ดี"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:98
translate english arc2_ino_quest1_377b1918:

    # su "Amado... ¿De verdad sospechas de ella? No ha mostrado ningún comportamiento extraño desde que empezó a trabajar aquí"
    su "อามาโดะ... คุณสงสัยเธอจริงๆ เหรอคะ? ตั้งแต่เธอเริ่มทำงานที่นี่ เธอไม่เคยแสดงพฤติกรรมแปลกๆ ออกมาเลยนะตะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:99
translate english arc2_ino_quest1_24080494:

    # mn "Sumire, ¿quién es exactamente esta asistente de la que habla Amado?"
    mn "สุมิเระ ผู้ช่วยที่อามาโดะพูดถึงนี่คือใครเหรอ?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:100
translate english arc2_ino_quest1_4306ec5b:

    # su "Su nombre es {b}Akira{/a}. Llegó a la aldea hace unos meses buscando un puesto en el equipo de investigación"
    su "เธอชื่อ {b}อากิระ{/a} ค่ะ เธอมาที่หมู่บ้านเมื่อไม่กี่เดือนก่อนเพื่อสมัครเข้าทำงานในทีมวิจัย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:101
translate english arc2_ino_quest1_62de6e31:

    # su "Tiene un gran talento e inteligencia para la creación de Herramientas Científicas Ninja"
    su "เธอมีพรสวรรค์และความฉลาดเป็นเลิศในการสร้างเครื่องมือทางนินจาศาสตร์ค่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:102
translate english arc2_ino_quest1_9cde4456:

    # su "De hecho, varias de las herramientas que fueron robadas son invenciones suyas"
    su "อันที่จริง เครื่องมือหลายชิ้นที่ถูกขโมยไปก็เป็นสิ่งประดิษฐ์ของเธอนั่นแหละค่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:103
translate english arc2_ino_quest1_0544e4dc:

    # mn "¿Y cómo llegó a la aldea?, ¿Se le hizo algún tipo de evaluación o revisión antes de que se le permitiera trabajar en un lugar como este?"
    mn "แล้วเธอเข้ามาในหมู่บ้านได้ยังไงล่ะ? ก่อนจะอนุญาตให้ทำงานในที่แบบนี้ ได้มีการประเมินหรือตรวจสอบอะไรเธอบ้างไหม?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:104
translate english arc2_ino_quest1_7becfadc:

    # mn "Sería preocupante que aceptaran al primero que viene a pedir trabajo"
    mn "คงแย่แน่ๆ ถ้าพวกเรารับใครก็ได้ที่เดินดุ่มๆ เข้ามาสมัครงานคนแรกน่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:105
translate english arc2_ino_quest1_64062e34:

    # su "Sí claro, ella evaluada por la {b}Oficina de Inteligencia de la Aldea de la Hoja{/a}, y todo salió limpio"
    su "ค่ะ แน่นอนอยู่แล้ว เธอผ่านการประเมินจาก {b}กองหน่วยลับและข่าวกรองแห่งหมู่บ้านโคโนฮะ{/a} มาแล้ว แถมผลตรวจก็ใสสะอาดไม่มีประวัติอะไรเลยค่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:106
translate english arc2_ino_quest1_f58d0786:

    # su "No tiene ningún pasado criminal ni conexiones sospechosas, ella es una persona tímida y bastante reservada, dudo que esté involucrada en esto"
    su "เธอไม่มีประวัติอาชญากรรมหรือความสัมพันธ์ที่น่าสงสัยเลย แถมยังเป็นคนขี้อายและค่อนข้างเก็บตัวด้วย ฉันเลยไม่ค่อยเชื่อหรอกค่ะว่าเธอจะเกี่ยวข้องกับเรื่องนี้"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:107
translate english arc2_ino_quest1_c42096c3:

    # ino "Si ella ha trabajado en esas herramientas, y si fueron robadas... No tendría sentido que se robara su propia tecnología, ¿no?"
    ino "ถ้าเธอเป็นคนสร้างเครื่องพวกนั้น แล้วมันดันถูกขโมยไป... การที่เธอจะขโมยผลงานตัวเองมันก็ดูไม่ค่อยสมเหตุสมผลเท่าไหร่จริงไหมล่ะ?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:108
translate english arc2_ino_quest1_3971e440:

    # su "Exactamente. No puedo imaginar por qué haría algo así, además, nunca ha mostrado ningún comportamiento extraño desde que empezó a trabajar aquí"
    su "นั่นสิคะ ฉันก็นึกไม่ออกเหมือนกันว่าทำไมเธอถึงต้องทำแบบนั้น อีกอย่าง ตั้งแต่เริ่มทำงานที่นี่มา เธอก็ไม่เคยแสดงพฤติกรรมแปลกๆ ออกมาเลยด้วย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:109
translate english arc2_ino_quest1_c9a453ff:

    # am "No estoy diciendo que sea culpable, pero en una situación como esta, no podemos permitirnos descartar ninguna posibilidad"
    am "ฉันไม่ได้บอกว่าเธอมีความผิดหรอกนะ แต่ในสถานการณ์แบบนี้ เราจะมองข้ามความเป็นไปได้ข้อไหนไปไม่ได้ทั้งนั้นแหละ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:110
translate english arc2_ino_quest1_7bd3abd9:

    # am "Personalmente, no me agrada ni un poco"
    am "ส่วนตัวแล้ว ฉันไม่ชอบขี้หน้ายายเด็กนั่นเอาซะเลย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:111
translate english arc2_ino_quest1_d019c2af:

    # su "Tu viniste de una organización que atacó a la Aldea de la Hoja y al Séptimo Hokage, ¿Y vienes a echarle la culpa a ella?"
    su "คุณเองก็มาจากองค์กรที่เคยบุกโจมตีหมู่บ้านโคโนฮะกับท่านโฮคาเงะรุ่นที่ 7 ไม่ใช่เหรอคะ แล้วทำไมจู่ๆ ถึงมาโยนความผิดให้เธอล่ะ?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:112
translate english arc2_ino_quest1_943b5fbc:

    # mn "*ejem*... ¿Puedo saber qué descubrieron sobre su pasado?"
    mn "*แคะ*... งั้นฉันขอถามหน่อยได้ไหมว่าพวกเธอรู้อะไรเกี่ยวกับอดีตของเธอบ้าง?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:113
translate english arc2_ino_quest1_c9597416:

    # su "Lo que sabemos es que viene de de la {b}Aldea de la Hierba{/a}, ella perdió a su familia en un accidente hace unos años"
    su "เท่าที่เราทราบนี่คือเธอมาจาก {b}หมู่บ้านคุซะงาคุเระ{/a} ค่ะ เธอสูญเสียครอบครัวไปจากอุบัติเหตุเมื่อไม่กี่ปีมานี้"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:114
translate english arc2_ino_quest1_a9d78246:

    # su "Su interés por las Herramentas Científicas Ninja viene, porque gracias a que un hombre la salvó utilizándolas"
    su "ความสนใจในเครื่องมือทางนินจาศาสตร์ของเธอเริ่มต้นจากตอนที่มีผู้ชายใช้เครื่องมือเหล่านั้นช่วยชีวิตเธอเอาไว้น่ะค่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:115
translate english arc2_ino_quest1_6a57f52c:

    # su "Eso la impulsó a dedicarse a la Investigación y ayudar a otras personas"
    su "นั่นเลยเป็นแรงผลักดันให้เธอหันมาทำงานวิจัยและคอยช่วยเหลือผู้อื่นค่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:116
translate english arc2_ino_quest1_696a7c06:

    # ino "Suena a una historia creíble..."
    ino "ฟังดูเป็นเรื่องราวที่น่าเชื่อถือดีนี่..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:117
translate english arc2_ino_quest1_7df3d656:

    # su "Si, ella hasta ahora ha sido una empleada modelo, no he visto nada que me haga dudar de ella"
    su "ค่ะ เท่าที่ผ่านมาเธอก็เป็นพนักงานตัวอย่างมาตลอด ฉันยังไม่เห็นอะไรที่ทำให้รู้สึกสงสัยในตัวเธอเลยนะคะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:118
translate english arc2_ino_quest1_dfd15398:

    # am "Esa es la clave... Lo que no ves, a veces las personas más peligrosas son las que parecen invisibles hasta que ya es demasiado tarde"
    am "นั่นแหละประเด็น... สิ่งที่เรามองไม่เห็นนั่นแหละ บางทีคนอันตรายที่สุดก็คือคนที่ทำตัวกลมกลืนจนกว่าจะสายเกินไป"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:119
translate english arc2_ino_quest1_a12f7daf:

    # mn "Mmmm... Los proyectos en los que ha trabajado, ¿Cuáles son específicamente?"
    mn "อืม... แล้วโปรเจกต์ที่เธอทำอยู่เนี่ย มันคืออะไรกันแน่เหรอ?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:120
translate english arc2_ino_quest1_27555a64:

    # su "Ha estado desarrobando muchas, pero principalmente en el desarrollo de herramientas de espionaje y detección"
    su "เธอพัฒนาโปรเจกต์ไว้หลายอย่างเลยค่ะ แต่ส่วนใหญ่จะเป็นการพัฒนาเครื่องมือสำหรับใช้สอดแนมและตรวจจับนะคะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:121
translate english arc2_ino_quest1_1668e8cc:

    # su "De hecho, ella fue la clave en el diseño de una versión mejorada del dron de vigilancia, que lamentablemente fue uno de los primeros en ser robados"
    su "อันที่จริง เธอมีบทบาทสำคัญในการออกแบบโดรนสอดแนมรุ่นปรับปรุง ซึ่งน่าเสียดายที่เป็นหนึ่งในของชิ้นแรกๆ ที่ถูกขโมยไปค่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:122
translate english arc2_ino_quest1_0f53f6bf:

    # am "Exacto, lo que me parece sospechoso es que esos drones eran piezas únicas y aún en desarrollo, solo porcas personas tenían acceso a ese proyecto"
    am "นั่นแหละ สิ่งที่ฉันมองว่ามันน่าสงสัยก็คือโดรนพวกนั้นเป็นของที่มีชิ้นเดียวในโลกและยังอยู่ในระหว่างพัฒนา มีคนแค่ไม่กี่คนเท่านั้นที่เข้าถึงโปรเจกต์นั้นได้"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:123
translate english arc2_ino_quest1_a8dd200b:

    # am "¿Cómo es posible que alguien los robara tan fácilmente?"
    am "เป็นไปได้ยังไงที่มีคนขโมยมันไปได้ง่ายดายขนาดนี้?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:124
translate english arc2_ino_quest1_a8830254:

    # mn "Ella tuvo acceso directo a estos drones?"
    mn "เธอมีสิทธิ์เข้าถึงโดรนพวกนี้โดยตรงเลยงั้นเหรอ?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:125
translate english arc2_ino_quest1_bde0c7ed:

    # su "Sí, como cualquier miembro de nuestro equipo. Ella ha demostrado ser una de las más dedicadas"
    su "ใช่ค่ะ เหมือนกับสมาชิกคนอื่นๆ ในทีมเรา เธอพิสูจน์ให้เห็นแล้วว่าเป็นหนึ่งในคนที่ทุ่มเทมากที่สุด"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:126
translate english arc2_ino_quest1_c9bc9f29:

    # su "Ha trabajado en otros dispositivos de monitoreo de chakra y herramientas médicas también"
    su "เธอยังเคยมีส่วนร่วมในการพัฒนาอุปกรณ์ตรวจวัดจักระและเครื่องมือแพทย์ชิ้นอื่นๆ ด้วยค่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:127
translate english arc2_ino_quest1_ba6f739c:

    # am "Aún así, no podemos descartar la posibilidad de que esté filtrando información, la facilidad con la que estos robos ocurrieron es alarmante"
    am "ถึงอย่างนั้น เราก็ยังตัดความเป็นไปได้ที่เธออาจจะเป็นคนปล่อยข้อมูลออกไปไม่ได้หรอกนะ ความง่ายดายที่เกิดการโจรกรรมพวกนี้ขึ้นเนี่ยมันน่าตกใจเกินไป"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:128
translate english arc2_ino_quest1_2f94aef2:

    # mn "Entiendo... Pero si no ha mostrado signos de comportamiento extraño... ¿Hay algo más que pueda respaldar tus sospechas, Amado?"
    mn "ฉันเข้าใจ... แต่ถ้าเธอยังไม่เคยแสดงพฤติกรรมแปลกๆ ออกมาล่ะก็... มีหลักฐานอื่นอีกไหมที่จะสนับสนุนข้อสงสัยของคุณได้ อามาโดะ?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:129
translate english arc2_ino_quest1_6e65adbf:

    # am "Solo un instinto, he visto cosas así antes. Gente que parece inofensiva, pero tiene conexiones ocultas"
    am "ก็แค่ลางสังหรณ์น่ะ ฉันเคยเห็นเรื่องแบบนี้มาเยอะแล้ว พวกคนที่ดูไม่มีพิษมีภัย แต่เบื้องหลังกลับมีความสัมพันธ์ลับๆ ซ่อนอยู่"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:130
translate english arc2_ino_quest1_2806498f:

    # am "Lo mejor sería vigilarla de cerca, al menos hasta que las sospechas sobre ella se disipen"
    am "ทางที่ดีควรจับตาดูเธอเอาไว้ให้ดี อย่างน้อยก็จนกว่าข้อครหาเกี่ยวกับตัวเธอจะหมดไป"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:131
translate english arc2_ino_quest1_59a86e47:

    # su "Sigo creyendo que esto es un malentendido, pero si eso hace que la dejen tranquila, lo haré"
    su "ฉันยังเชื่อว่านี่คือความเข้าใจผิดนะ แต่ถ้ามันช่วยให้เธอไม่ต้องเดือดร้อน ฉันก็จะทำค่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:132
translate english arc2_ino_quest1_18b3a520:

    # am "Le diré que se tome unos días libres mientras el caso se resuelva"
    am "เดี๋ยวฉันจะบอกให้เธอหยุดงานสักสองสามวันระหว่างที่คดีนี้ยังไม่คลี่คลายก็แล้วกัน"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:133
translate english arc2_ino_quest1_b3b52cbb:

    # mn "Muy bien, gracias por la información. Mantendrémos un ojo en ella, me gustaría que todo esto quede entre nosotros por ahora"
    mn "งั้นก็ ขอบคุณสำหรับข้อมูลนะ เดี๋ยวพวกเราจะคอยจับตาดูเธอให้ แล้วฉันอยากให้เรื่องทั้งหมดนี้เก็บไว้เป็นความลับระหว่างเราก่อนนะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:134
translate english arc2_ino_quest1_f2e85ff8:

    # am "Así será"
    am "แน่นอนครับ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:137
translate english arc2_ino_quest1_efae4171:

    # n "Luego de tratar con Amado y con Sumire, Ino y [MN] salen del Centro de Investigación de Herramientas Científicas Ninja"
    n "หลังจากพูดคุยกับอามาโดะและสุมิเระเสร็จแล้ว อิโนะและ [MN] ก็ออกจากศูนย์วิจัยเครื่องมือทางนินจาศาสตร์"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:147
translate english arc2_ino_quest1_78859779:

    # ino "Bueno, no obtuvimos mucha información útil... Al menos nada que nos acerque más a los culpables..."
    ino "เฮ้อ ได้ข้อมูลที่มีประโยชน์มาไม่ค่อยเยอะเลย... อย่างน้อยก็ไม่มีอะไรที่ทำให้เราเข้าใกล้ตัวคนร้ายได้มากขึ้นเลยสินะ..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:148
translate english arc2_ino_quest1_9b5bc4cb:

    # mn "Si... Pero algo me tiene inquieto, Amado parece convencido de que la asistente de Sumire está involucrada de alguna manera."
    mn "นั่นสินะ... แต่มีบางอย่างที่คาใจฉันอยู่ อามาโดะดูมั่นอกมั่นใจเหลือเกินว่าผู้ช่วยของสุมิเระน่าจะมีส่วนเกี่ยวข้องกับเรื่องนี้"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:149
translate english arc2_ino_quest1_744bc0ee:

    # mn "Aunque Sumire confía en ella, no podemos ignorar la posibilidad de que algo no cuadre"
    mn "ถึงแม้ว่าสุมิเระจะไว้ใจเธอ แต่เราก็ละเลยความเป็นไปได้ที่ว่ามันมีบางอย่างที่ไม่ชอบมาพากลไปไม่ได้หรอก"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:150
translate english arc2_ino_quest1_af28aeac:

    # ino "Es difícil saber en quién confiar cuando estamos hablando de tecnología tan valiosa"
    ino "ยากจริงๆ เลยนะที่จะรู้ว่าควรจะเชื่อใจใครดี ในเมื่อเราต้องรับมือกับเทคโนโลยีที่มีมูลค่าสูงขนาดนี้"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:152
translate english arc2_ino_quest1_c883c349:

    # mnn "(Mmmm... Hablámos con los demás empleados pero todos dicen que no vieron ni escucharon nada)"
    mnn "(อืม... เราคุยกับพนักงานคนอื่นๆ แล้ว แต่ทุกคนก็บอกว่าไม่ได้เห็นหรือได้ยินอะไรเลย)"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:153
translate english arc2_ino_quest1_7ab820b5:

    # mnn "(El único sospechoso es la asistente de Sumire, me hubiera gustado hablar con ella, pero ya es tarde para eso)"
    mnn "(ผู้ต้องสงสัยมีแค่ผู้ช่วยของสุมิเระคนเดียว ฉันน่าจะได้ลองคุยกับเธอสักหน่อย แต่ตอนนี้คงสายไปซะแล้ว)"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:154
translate english arc2_ino_quest1_8f6e8461:

    # mnn "(Mmmm... Lo que podríamos hacer hoy es vigilar el lugar por la noche, y si vienen a robar podríamos ver quien es el que lo hace y como...)"
    mnn "(อืม... สิ่งที่เราทำได้ในคืนนี้คือการซุ่มดูลาดเลาที่นี่ ถ้าพวกมันมาขโมยของอีก เราจะได้เห็นว่าใครเป็นคนทำและทำยังไง...)"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:156
translate english arc2_ino_quest1_b53fa5da:

    # mn "He estado pensando... Tal vez lo mejor sea vigilar el lugar esta noche... Si el ladrón vuelve, quizá podamos atraparlo y ver como hace los robos"
    mn "ฉันลองคิดดูแล้ว... บางทีวิธีที่ดีที่สุดคือการเฝ้าดูที่นี่คืนนี้นี่แหละ... ถ้าคนร้ายกลับมาอีก เราอาจจะจับตัวมันได้และได้เห็นว่าพวกมันขโมยไปยังไงด้วย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:157
translate english arc2_ino_quest1_5878aff3:

    # ino "Me parece buena idea, yo también lo había pensado"
    ino "ฟังดูเข้าท่าดีนะ ฉันก็คิดเรื่องนั้นอยู่เหมือนกัน"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:158
translate english arc2_ino_quest1_298f867f:

    # mn "¿Te parece si nos reunimos esta noche?"
    mn "เธอว่าเราควรนัดเจอกันคืนนี้เลยดีไหม?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:159
translate english arc2_ino_quest1_e178ceea:

    # ino "Aquí estaré, yo me encargaré de cubrir otras áreas alrededor del Centro de Investigación"
    ino "เดี๋ยวฉันจะอยู่ที่นี่แหละ เดี๋ยวฉันช่วยรับหน้าที่คอยตรวจพื้นที่รอบๆ ศูนย์วิจัยให้อีกแรง"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:160
translate english arc2_ino_quest1_14da41c9:

    # mn "Bien, entonces nos vemos más tarde."
    mn "โอเค งั้นไว้เจอกันนะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:162
translate english arc2_ino_quest1_f2da4329:

    # n "Ino y [MN] se separan luego de decidir su siguiente movimiento"
    n "อิโนะและ [MN] แยกย้ายกันหลังจากตัดสินใจเรื่องแผนขั้นต่อไปได้แล้ว"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest1.rpy:164
translate english arc2_ino_quest1_0638ccf3:

    # n "Ambos acuerdan encontrarse en el Centro de Investigación de Herramientas Científicas Ninja por la noche"
    n "ทั้งคู่ตกลงที่จะมาพบกันที่ศูนย์วิจัยเครื่องมือทางนินจาศาสตร์ในตอนกลางคืน"

