# TODO: Translation updated at 2024-11-29 23:49

# game/scripts/History/SecundaryStory/Hanna/Messages/hanna_message_invitation.rpy:17
translate english hanna_message_invitation1_e4bda4d8:

    # mn "¿Podrá Hanna salir esta noche? Me dijo que le escribiera"
    mn "คืนนี้ฮันนะออกไปข้างนอกได้ไหมนะ เธอบอกให้ฉันส่งข้อความหาเธอน่ะ"

# game/scripts/History/SecundaryStory/Hanna/Messages/hanna_message_invitation.rpy:18
translate english hanna_message_invitation1_67432abc:

    # mn "Veamos..."
    mn "ลองดูหน่อย..."

# game/scripts/History/SecundaryStory/Hanna/Messages/hanna_message_invitation.rpy:44
translate english hanna_message_invitation1_6b6b63e9:

    # mn "Le escribí un poco tarde, seguramente ya está en su casa"
    mn "ฉันส่งข้อความหาเธอช้าไปหน่อย ป่านนี้คงถึงบ้านแล้วมั้ง"

# game/scripts/History/SecundaryStory/Hanna/Messages/hanna_message_invitation.rpy:45
translate english hanna_message_invitation1_05353a6b:

    # mn "Así que saldrémos mañana, entonces no hay problema"
    mn "งั้นไว้ไปเที่ยวพรุ่งนี้แทนก็แล้วกัน ไม่มีปัญหา"

# game/scripts/History/SecundaryStory/Hanna/Messages/hanna_message_invitation.rpy:47
translate english hanna_message_invitation1_dfd45d17:

    # mn "Perfecto, debo prepararme para ir a recogerla"
    mn "เยี่ยมเลย ฉันต้องเตรียมตัวไปรับเธอแล้วสิ"

# game/scripts/History/SecundaryStory/Hanna/Messages/hanna_message_invitation.rpy:48
translate english hanna_message_invitation1_13bd16dc:

    # mn "Jeje, ¿Qué harémos hoy? Tengo muchas ganas de comer ramen"
    mn "ฮ่าๆ วันนี้เราจะทำอะไรกันดีนะ? อยากกินราเม็งชะมัดเลย"

# game/scripts/History/SecundaryStory/Hanna/Messages/hanna_message_invitation.rpy:50
translate english hanna_message_invitation1_5b0e2905:

    # mn "Perfecto, solo tengo que esperar que se haga de noche para ir a recogerla"
    mn "ดีล่ะ แค่รอให้ถึงเวลากลางคืนแล้วก็ไปรับเธอสินะ"

# game/scripts/History/SecundaryStory/Hanna/Messages/hanna_message_invitation.rpy:73
translate english hanna_message_invitation2_7c083e61:

    # mn "Un mensaje de Hanna"
    mn "ข้อความจากฮันนะ"

# game/scripts/History/SecundaryStory/Hanna/Messages/hanna_message_invitation.rpy:83
translate english hanna_message_invitation2_dfd45d17:

    # mn "Perfecto, debo prepararme para ir a recogerla"
    mn "เยี่ยมเลย ฉันต้องเตรียมตัวไปรับเธอแล้วสิ"

# game/scripts/History/SecundaryStory/Hanna/Messages/hanna_message_invitation.rpy:86
translate english hanna_message_invitation2_ae0f5443:

    # mn "Jeje, ¿Qué harémos hoy? Tengo muchas ganas de comer ramen" with dissolve1
    mn "ฮ่าๆ วันนี้เราจะทำอะไรกันดีนะ? อยากกินราเม็งชะมัดเลย" with dissolve1

translate english strings:

    # game/scripts/History/SecundaryStory/Hanna/Messages/hanna_message_invitation.rpy:3
    old "Estás en la recepción"
    new "คุณอยู่ที่แผนกต้อนรับ"

