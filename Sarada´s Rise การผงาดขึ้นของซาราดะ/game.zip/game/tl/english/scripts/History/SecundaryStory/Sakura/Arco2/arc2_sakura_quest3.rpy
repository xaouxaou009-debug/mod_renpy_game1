# TODO: Translation updated at 2024-11-29 23:49

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:5
translate english arc2_sakura_quest3_4712cb0d:

    # n "[MN] sube al tercer piso del Hospital y entra en la habitación donde está Sakura"
    n "[MN] เดินขึ้นไปบนชั้นสามของโรงพยาบาลและเข้าไปในห้องที่ซากุระอยู่"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:12
translate english arc2_sakura_quest3_b0fefcda:

    # mn "Buen día Sakura, ya estoy aquí"
    mn "อรุณสวัสดิ์ครับซากุระ ผมมาแล้วครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:13
translate english arc2_sakura_quest3_1f85bdd2:

    # sk "[MN], llegas justo a tiempo"
    sk "[MN] มาได้เวลาพอดีเลย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:15
translate english arc2_sakura_quest3_3c4b04b4:

    # mn "¿Hoy no vino la señora Tsunade a trabajar?"
    mn "ท่านซึนาเดะไม่ได้มาทำงานวันนี้เหรอครับ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:16
translate english arc2_sakura_quest3_c2bbbe8b:

    # sk "Ella ya no trabaja aquí, solo vino a ayudarme con tus pruebas, pero ella ya se retiró hace unos años"
    sk "เธอไม่ได้ทำงานที่นี่แล้วล่ะค่ะ เธอก็แค่มาช่วยฉันตรวจร่างกายให้เธอเฉย ๆ แต่เธอเกษียณไปหลายปีแล้วค่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:17
translate english arc2_sakura_quest3_0270bffe:

    # mn "¿En serio? Pero aún parece muy joven"
    mn "จริงเหรอครับ? แต่เธอยังดูเด็กอยู่เลยนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:19
translate english arc2_sakura_quest3_11930e2a:

    # sk "Jajaja, a ella sin duda le gustaría escucharte decir eso"
    sk "ฮ่าๆๆ ถ้าเธอได้ยินเธอคงชอบใจแน่เลยล่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:21
translate english arc2_sakura_quest3_9c6be34a:

    # sk "Listo, aquí está la solución para tus problemas con el Karugan"
    sk "นี่จ่ะ วิธีแก้ปัญหาเรื่องคารูกันของเธอ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:22
translate english arc2_sakura_quest3_d6d50f79:

    # mn "¿Puedo preguntarte que es? Sé que es la solución a los efectos secundarios del Jutsu de Invisibilidad, ¿Pero qué es exactamente?"
    mn "ผมขอถามหน่อยได้ไหมครับว่ามันคืออะไร? ผมรู้ว่ามันเป็นวิธีแก้ผลข้างเคียงของคาถาล่องหน แต่จริง ๆ แล้วมันคืออะไรกันแน่เหรอครับ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:23
translate english arc2_sakura_quest3_ca4c09a6:

    # sk "Oh, siento si aún no te he explicado"
    sk "อ๊ะ ขอโทษทีนะถ้าฉันยังไม่ได้อธิบายให้ฟัง"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:24
translate english arc2_sakura_quest3_040dc9c6:

    # sk "Estas son unas gotas especiales que eliminarán por completo cualquier molestia que te cause el Karugan"
    sk "นี่คือยาหยอดตาสูตรพิเศษที่จะช่วยขจัดความรู้สึกไม่สบายตาที่เกิดจากคารูกันให้หมดไปเลยล่ะค่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:33
translate english arc2_sakura_quest3_1c46545c:

    # mn "Vaya, sí que son muchas"
    mn "โอ้โห เยอะจังเลยครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:35
translate english arc2_sakura_quest3_b7f896a0:

    # mn "Y las hiciste muy rápido, me sorprendes"
    mn "แถมยังทำเสร็จเร็วมากด้วย ผมทึ่งเลยล่ะครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:37
translate english arc2_sakura_quest3_70a1a922:

    # sk "Bueno, hice un poco de trampa"
    sk "ก็นิดหน่อยจ่ะ ฉันแอบโกงเวลานิดหน่อยน่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:39
translate english arc2_sakura_quest3_5e68bb6e:

    # sk "Ya tenía un prototipo hace unos años"
    sk "ฉันมีตัวต้นแบบอยู่แล้วตั้งแต่เมื่อไม่กี่ปีก่อนน่ะค่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:40
translate english arc2_sakura_quest3_6154a741:

    # sk "Estaba investigando especialmente para {b}Sarada{/a} esta solución"
    sk "ฉันวิจัยตัวยานี้ขึ้นมาเพื่อ {b}ซาราดะ{/a} โดยเฉพาะเลยนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:42
translate english arc2_sakura_quest3_a3a2c003:

    # mn "¿Porqué para Sarada, tiene algún problema?"
    mn "ทำไมถึงเป็นซาราดะล่ะครับ? เธอมีปัญหาอะไรเหรอครับ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:43
translate english arc2_sakura_quest3_67701712:

    # sk "No, para nada..."
    sk "เปล่าเลยค่ะ ไม่มีอะไรหรอก..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:45
translate english arc2_sakura_quest3_03bb8bba:

    # sk "Es solo que, es una {b}Uchiha{/a}, tengo miedo de que llegue a despertar el {b}Mangekyo Sharingan{/a}..."
    sk "ก็แค่แกเป็น {b}อุจิวะ{/a} น่ะค่ะ ฉันก็เลยกลัวว่าแกอาจจะเบิกเนตร {b}เนตรวงแหวนกระจกเงาหมื่นบุปผา{/a} ขึ้นมาสักวัน..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:46
translate english arc2_sakura_quest3_f05c4578:

    # sk "Y no sé si lo sepas, pero el uso de el Mangekyo Sharingan puede dañar mucho los ojos de su portador"
    sk "แล้วเธอรู้รึเปล่าว่าการใช้เนตรวงแหวนกระจกเงาหมื่นบุปผาน่ะ สามารถสร้างความเสียหายอย่างรุนแรงให้กับดวงตาของผู้ใช้ได้นะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:48
translate english arc2_sakura_quest3_a009b322:

    # mn "Entiendo... Es una gran idea planear esto antes de que eso pase"
    mn "งั้นเหรอครับ... การเตรียมตัวไว้ก่อนที่มันจะเกิดขึ้นเนี่ย เป็นความคิดที่ดีจริง ๆ นะครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:49
translate english arc2_sakura_quest3_93d82bd7:

    # mn "¿Y qué tal, si ayudan a prevenir los efectos secundarios?"
    mn "แล้วถ้าเกิดว่ามันช่วยป้องกันผลข้างเคียงล่ะครับ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:51
translate english arc2_sakura_quest3_58531469:

    # sk "Lamentablemente no, aún no he sido capaz de crear algo tan potente"
    sk "น่าเสียดายที่ยังค่ะ ฉันยังไม่สามารถสร้างยาที่ทรงพลังขนาดนั้นได้หรอกนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:53
translate english arc2_sakura_quest3_7e969e82:

    # sk "Aunque justo ahora no me preocupa, las aldeas justo ahora están en una época de paz y no hay indicios de que Sarada despierte su {b}Mangekyo Sharingan{/a}"
    sk "แต่ตอนนี้ฉันก็ไม่ได้กังวลอะไรหรอกค่ะ ช่วงนี้บรรดาหมู่บ้านต่าง ๆ อยู่ในช่วงเวลาแห่งความสงบสุข แล้วก็ยังไม่มีวแววว่าซาราดะจะเบิกเนตร {b}เนตรวงแหวนกระจกเงาหมื่นบุปผา{/a} เลยสักนิด"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:54
translate english arc2_sakura_quest3_8ad64c92:

    # sk "Pero aún así seguiré trabajando en ello, no me rendiré y seguiré trabajando para serles de utilidad"
    sk "ถึงอย่างนั้น ฉันก็จะยังคงศึกษาค้นคว้าต่อไปค่ะ จะไม่ยอมแพ้และตั้งใจพัฒนาตัวเองเพื่อจะได้ช่วยเหลือคนอื่นให้ได้ล่ะนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:55
translate english arc2_sakura_quest3_6b8b52c8:

    # sk "Me alegra mucho que al menos a tí te sirvan por ahora"
    sk "ฉันดีใจจริง ๆ นะคะ อย่างน้อยตอนนี้มันก็น่าจะช่วยบรรเทาอาการของเธอได้บ้างล่ะนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:57
translate english arc2_sakura_quest3_18fa69ef:

    # mn "De verdad te lo agradezco Sakura, sé que es algo que te ha costado mucho trabajo"
    mn "ผมซาบซึ้งใจจริง ๆ ครับซากุระ ผมรู้ว่ากว่าจะได้มันมา คุณต้องทุ่มเทแรงกายแรงใจไปไม่น้อยเลย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:58
translate english arc2_sakura_quest3_08699780:

    # mn "¿Cuánto te debo por esto?"
    mn "ผมต้องจ่ายเงินค่าพวกนี้เท่าไหร่เหรอครับ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:59
translate english arc2_sakura_quest3_9355a7cf:

    # sk "No te preocupes por eso. Tómalo como un regalo de mi parte"
    sk "ไม่ต้องคิดมากหรอกจ่ะ ถือซะว่าเป็นของขวัญจากฉันก็แล้วกันนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:62
translate english arc2_sakura_quest3_42d746e4:

    # mn "¡¿Q-Qué?!" with vpunch
    mn "ว-ว่าไงนะครับ?!" with vpunch

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:65
translate english arc2_sakura_quest3_a77c9312:

    # mn "N-No puedo aceptarlo así por así, me imagino que trabajaste mucho para hacerlas"
    mn "ผ-ผมรับไว้เฉยๆ ไม่ได้หรอกครับ ผมเดาว่าคุณต้องเหนื่อยยากมากเลยนะกว่าจะทำมันออกมาได้"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:66
translate english arc2_sakura_quest3_af168485:

    # sk "En serio, no hay problema"
    sk "จริงๆ นะคะ ไม่มีปัญหาเลย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:67
translate english arc2_sakura_quest3_44e0a5bb:

    # mnn "Mmm..."
    mnn "อืม..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:68
translate english arc2_sakura_quest3_6771fc2e:

    # mn "No puedo dejar las cosas así"
    mn "ปล่อยไว้แบบนี้ไม่ได้หรอกครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:70
translate english arc2_sakura_quest3_27239495:

    # mn "¿Qué tal si te invito a comer?"
    mn "งั้นผมขอเลี้ยงข้าวคุณสักมื้อก็แล้วกันนะครับ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:72
translate english arc2_sakura_quest3_0d060e5e:

    # sk "Jajaja, está bien, como quieras"
    sk "ฮ่าๆๆ ได้สิ ตามใจเธอเลย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:74
translate english arc2_sakura_quest3_dc09f43a:

    # sk "Aunque preferiría que fueramos a beber"
    sk "ถึงฉันจะอยากชวนไปดื่มมากกว่าก็เถอะนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:77
translate english arc2_sakura_quest3_b0241441:

    # mnn "(Mmm, la última vez que fui a beber con una chica no resultó tan bien)"
    mnn "(อืม ครั้งล่าสุดที่ฉันไปดื่มกับผู้หญิงเนี่ย มันจบลงไม่ค่อยสวยเท่าไหร่เลยแฮะ)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:79
translate english arc2_sakura_quest3_3c3b7721:

    # mnn "(Pero no creo que esta vez pase algo, después de todo es Sakura)"
    mnn "(แต่รอบนี้น่าจะไม่มีอะไรเกิดขึ้นหรอกมั้ง ยังไงซะนี่ก็ซากุระนะ)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:80
translate english arc2_sakura_quest3_0e69803c:

    # mnn "(A ella la veo como si fuera mi madre)"
    mnn "(ผมมองเธอเหมือนเป็นแม่แท้ๆ คนหนึ่งเลยล่ะ)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:82
translate english arc2_sakura_quest3_e869a8d0:

    # mn "Está bien, conozco un Bar al que podemos ir"
    mn "งั้นผมรู้จักบาร์แห่งหนึ่งที่เราไปกันได้อยู่ครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:83
translate english arc2_sakura_quest3_2452d3c5:

    # mn "¿Te parece si vengo esta noche a recogerte?"
    mn "คืนนี้ให้ผมไปรับไหมครับ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:84
translate english arc2_sakura_quest3_41cc46ea:

    # sk "Claro, por mí está bien"
    sk "ได้สิ ฉันไม่มีปัญหาอยู่แล้ว"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:85
translate english arc2_sakura_quest3_c9dd1873:

    # mn "Bien, entonces te veo luego"
    mn "งั้นเดี๋ยวเจอกันนะครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest3.rpy:87
translate english arc2_sakura_quest3_25d03538:

    # sk "Claro, aquí estaré"
    sk "จ้า เดี๋ยวรออยู่นี่นะ"

