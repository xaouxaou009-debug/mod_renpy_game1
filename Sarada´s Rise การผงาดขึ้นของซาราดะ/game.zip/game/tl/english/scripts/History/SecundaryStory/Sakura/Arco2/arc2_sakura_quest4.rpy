# TODO: Translation updated at 2024-12-01 21:25

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:12
translate english arc2_sakura_quest4_ffd2a867:

    # mn "Hola Sakura, lamento la tardanza"
    mn "ไงซากุระ ขอโทษที่มาสายนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:13
translate english arc2_sakura_quest4_4e24d27d:

    # sk "No te preocupes, llegaste justo a tiempo"
    sk "ไม่ต้องห่วง เธอมาถึงพอดีเวลาเลยล่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:14
translate english arc2_sakura_quest4_24eed7b1:

    # sk "Acabo de terminar mi turno"
    sk "ฉันเพิ่งจะเลิกงานน่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:15
translate english arc2_sakura_quest4_8c768ae4:

    # mn "Perfecto, ¿Nos vamos entonces?"
    mn "เยี่ยมเลย งั้นเราไปกันเลยไหม?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:16
translate english arc2_sakura_quest4_583964b5:

    # sk "Claro, hoy puedes llevame donde quieras"
    sk "ได้สิ วันนี้เธอพาฉันไปไหนก็ได้ตามใจชอบเลยนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:17
translate english arc2_sakura_quest4_9055ca5e:

    # sk "Tenemos que celebrar tu victoria en los exámenes"
    sk "เราต้องฉลองให้กับการสอบที่เธอชนะมาสักหน่อยแล้ว"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:19
translate english arc2_sakura_quest4_1cbad3c8:

    # mn "Es muy pronto para eso jaja"
    mn "ยังเร็วเกินไปที่จะฉลองมั้งเนี่ย ฮ่าๆ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:21
translate english arc2_sakura_quest4_c257a801:

    # sk "No seas modesto, con tu nivel es seguro que lo pasas, seguro"
    sk "อย่าถ่อมตัวไปหน่อยเลย ด้วยระดับฝีมือของเธอแล้ว ผ่านแน่ือนอนอยู่แล้วล่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:22
translate english arc2_sakura_quest4_979f7b3e:

    # sk "A los jóvenes de ahora ya no les interesa ser ninjas, creo que ustedes son la única excepción"
    sk "เด็กสมัยนี้ไม่ค่อยสนใจอยากจะเป็นนินจากันแล้วล่ะมั้ง ฉันว่าพวกเธอนี่แหละข้อยกเว้นกลุ่มเดียวเลย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:24
translate english arc2_sakura_quest4_9264b0cc:

    # mn "¿De verdad?"
    mn "ขนาดนั้นเลยเหรอ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:26
translate english arc2_sakura_quest4_ffe5734b:

    # sk "¿No te has fijado?, La mayoría prefiere estudiar otras cosas"
    sk "เธอไม่สังเกตเหรอ? ส่วนใหญ่หันไปเรียนเรื่องอื่นกันหมดแล้วล่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:27
translate english arc2_sakura_quest4_fc3c68e7:

    # sk "Con los tiempos de paz y el avance tan rápido de la tecnología, ya no hay tantos interesados en convertirse en ninjas"
    sk "พอมายยุคสมัยที่สงบสุขแถมเทคโนโลยีก็ก้าวหน้าอย่างรวดเร็ว คนที่สนใจอยากจะเป็นนินจาก็เลยลดน้อยลงไปเยอะเลย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:29
translate english arc2_sakura_quest4_9cc2825b:

    # sk "Es una pena, aunque no me quejo, como madre me alegro que mi hija no atraviese los mismos peligros que atravesé yo"
    sk "ก็น่าเสียดายนะ แม้ว่าฉันจะไม่ค่อยบ่นอะไรหรอก ในฐานะแม่แล้ว ฉันดีใจซะอีกที่ลูกสาวไม่ต้องมาเผชิญอันตรายแบบเดียวกับที่ฉันเคยเจอ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:31
translate english arc2_sakura_quest4_9ff5b505:

    # sk "O... Su propio padre..."
    sk "หรือ... พ่อของแกเอง..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:32
translate english arc2_sakura_quest4_5502cecb:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:34
translate english arc2_sakura_quest4_3d0b7eb5:

    # mn "Quita esa cara larga, ¿Qué fue lo que dijiste?"
    mn "เลิกทำหน้าหงิกหน้างอได้แล้วน่า ว่าแต่เมื่อกี้พูดถึงไหนแล้วนะ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:37
translate english arc2_sakura_quest4_0e4e6399:

    # mn "¡Hoy tenemos que celebrar!" with vpunch
    mn "วันนี้เราต้องฉลองกันนะ!" with vpunch

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:41
translate english arc2_sakura_quest4_39d105cc:

    # sk "Jeje"
    sk "แหะๆ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:43
translate english arc2_sakura_quest4_0c49d6a8:

    # sk "¡A celebrar!" with vpunch
    sk "เพื่อการเฉลิมฉลอง!" with vpunch

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:46
translate english arc2_sakura_quest4_75bac4a7:

    # n "Sakura y [MN] se van del Hospital"
    n "ซากุระและ [MN] เดินออกจากโรงพยาบาล"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:47
translate english arc2_sakura_quest4_82133afa:

    # n "Y ambos se dirigen al Bar al que fue [MN] con Ino"
    n "และทั้งคู่ก็มุ่งหน้าไปยังบาร์ที่ [MN] เคยไปกับอิโนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:48
translate english arc2_sakura_quest4_4d5960a7:

    # n "Para celebrar de antemano la victoria de [MN] en los exámenes Chunin"
    n "เพื่อเป็นการฉลองชัยชนะในการสอบจูหนินของ [MN] ล่วงหน้า"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:49
translate english arc2_sakura_quest4_bb2cf764:

    # n "..."
    n "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:50
translate english arc2_sakura_quest4_1f88ae78:

    # n "Aunque, [MN] lo hace para mejorar el estado de animo de Sakura, porque parece ser que extraña a su esposo Sasuke..."
    n "แม้ว่า [MN] จะทำเช่นนี้เพื่อช่วยปรับอารมณ์ของซากุระให้ดีขึ้น เพราะเธอดูเหมือนจะคิดถึงซาสึเกะผู้เป็นสามี..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:51
translate english arc2_sakura_quest4_9cd11bee:

    # n "Lleva muchos años sin verlo..."
    n "เธอไม่ได้พบเขามาหลายปีแล้ว..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:55
translate english arc2_sakura_quest4_0ea32ecd:

    # sk "Lo digo en serio, el jutsu mil años de muerte es lo más asqueroso que hay"
    sk "พูดจริงๆ นะ คาถานินจาสหัสปีแห่งความตายเนี่ย เป็นอะไรที่น่าขยะแขยงที่สุดเท่าที่เคยมีมาเลย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:56
translate english arc2_sakura_quest4_853458f6:

    # sk "Jajaja, y pensar que Kakashi-Sensei se lo hizo a Naruto en nuestra primera prueba"
    sk "ฮ่าๆ แล้วลองคิดดูสิว่าคาคาชิเซนเซย์เคยทำใส่ตนนารูโตะในการทดสอบแรกของเราด้วยนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:57
translate english arc2_sakura_quest4_bed03906:

    # mn "Que asco jajaja"
    mn "โคตรทุเรศเลย ฮ่าๆ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:58
translate english arc2_sakura_quest4_569ce769:

    # sk "Aaaah... De verdad te agradezco que me hayas traído aquí"
    sk "อ่าาห์... ขอบคุณจริงๆ นะที่พาฉันมาที่นี่"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:59
translate english arc2_sakura_quest4_8ba963d8:

    # sk "Charlar contigo es bastante divertido jajaja"
    sk "ได้คุยกับเธอแล้วสนุกจริงๆ เลย ฮ่าๆ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:60
translate english arc2_sakura_quest4_220584a9:

    # sk "Suelo venir con Ino, pero ella solo habla de sus problemas con Sai, y aveces es un poco molesto"
    sk "ปกติฉันมักจะมาที่นี่กับอิโนะน่ะนะ แต่เธอกเอาแต่พูดถึงปัญหาของเธอกับซาอิ แถมบางทีก็แอบน่ารำคาญนิดหน่อยด้วย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:62
translate english arc2_sakura_quest4_b68b4134:

    # mn "(Debe de hablar sobre su impotencia)"
    mn "(ยัยนั่นคงหมายถึงเรื่องที่เขาเสื่อมสมรรถภาพสินะ)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:63
translate english arc2_sakura_quest4_359d2d21:

    # mn "(Pobre cosita fea...)"
    mn "(น่าสงสารชะมัด...)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:65
translate english arc2_sakura_quest4_36b1c070:

    # mn "Para mí es un placer, el sentimiento es mutuo"
    mn "สำหรับผมแล้วถือเป็นเกียรติเลยล่ะ ผมก็รู้สึกเหมือนกันนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:66
translate english arc2_sakura_quest4_60ad68f5:

    # mn "De hecho, me gusta mucho pasar tiempo contigo, más que con cualquiera"
    mn "อันที่จริง ผมมีความสุขมากเลยนะที่ได้ใช้เวลาร่วมกับคุณ ยิ่งกว่าใครๆ ซะอีก"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:68
translate english arc2_sakura_quest4_3922e645:

    # sk "¡¿E-Eh, p-porqué?!" with vpunch
    sk "อ-อะไรกัน ทำ-ทำไมล่ะ?!" with vpunch

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:69
translate english arc2_sakura_quest4_1261d555:

    # mn "Ya sabes... Tu has sido muy importante para mí hasta donde recuerdo"
    mn "ก็รู้ 10... สำหรับผมแล้ว คุณเป็นคนสำคัญมากมาตั้งแต่จำความได้เลยนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:70
translate english arc2_sakura_quest4_e592e3e2:

    # mn "Fuiste la primera persona que vi al abrir los ojos..."
    mn "คุณเป็นคนแรกที่ผมเห็นตอนลืมตาตื่นขึ้นมาเลยนี่..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:72
translate english arc2_sakura_quest4_58e2b0db:

    # sk "Oh..." with dissolve5
    sk "อ๋อ..." with dissolve5

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:73
translate english arc2_sakura_quest4_211fdfff:

    # sk "De verdad tienes buena memoria para recordar eso..."
    sk "ความจำดีจังเลยนะที่ยังจำเรื่องนั้นได้เนี่ย..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:74
translate english arc2_sakura_quest4_a1110a1c:

    # mn "Dile eso a la memoria que perdí jajaja"
    mn "พูดซะนึกถึงความทรงจำที่หายไปของผมเลยนะ ฮ่าๆ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:75
translate english arc2_sakura_quest4_e5259c3a:

    # sk "¡Aah!, l-lo siento, no quise decir eso"
    sk "อ๊ะ! ฉ-ฉันขอโทษนะ ไม่ได้ตั้งใจจะพูดแบบนั้นเลย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:76
translate english arc2_sakura_quest4_912b45e5:

    # mn "No te preocupes jajaja, me hizo mucha gracia"
    mn "ไม่ต้องคิดมากเลย ฮ่าๆ สำหรับผมมันเป็นเรื่องตลกซะมากกว่าอีก"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:77
translate english arc2_sakura_quest4_aa404e19:

    # sk "Jeje..."
    sk "แหะๆ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:78
translate english arc2_sakura_quest4_85006ea7:

    # sk "De verdad no sabía que me tenías en tan alta estima"
    sk "ฉันไม่เคยรู้เลยนะเนี่ยว่าเธอจะยกย่องฉันขนาดนี้"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:79
translate english arc2_sakura_quest4_803d43ba:

    # mn "¿Porqué?, Para mí eres casi como una madre"
    mn "ทำไมล่ะครับ? สำหรับผมแล้ว คุณก็เหมือนกับคุณแม่คนหนึ่งเลยนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:80
translate english arc2_sakura_quest4_a9311452:

    # mn "Desde que desperté has estado ahí para mí, ¿No recuerdas?"
    mn "ตั้งแต่ผมตื่นขึ้นมา คุณก็คอยดูแลผมมาตลอด จำไม่ได้เหรอครับ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:83
translate english arc2_sakura_quest4_ac775f10:

    # mn "Antes tu eras quien me curaba cuando entrenaba"
    mn "เมื่อก่อนตอนที่ผมฝึกวิชา ก็มีแต่คุณนี่แหละที่คอยรักษาแผลให้"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:84
translate english arc2_sakura_quest4_85a6891e:

    # sk "Agh, si lo recuerdo, en ese entonces estabas aprendiendo a controlar tu chakra"
    sk "อืม ใช่ ฉันจำได้ ตอนนั้นเธอกำลังฝึกควบคุมจักระอยู่สินะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:86
translate english arc2_sakura_quest4_0d29ea61:

    # sk "Incluso venías con quemaduras graves aveces"
    sk "บางครั้งถึงกับเนื้อตัวไหม้เกรียมกลับมาเลยด้วยซ้ำ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:87
translate english arc2_sakura_quest4_c6bdef2c:

    # mn "Si jajaja"
    mn "ใช่ครับ ฮ่าๆ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:90
translate english arc2_sakura_quest4_76b1262c:

    # mn "También recuerdo que cuando no tenía para comer me dabas dinero para comprar Ramen"
    mn "แล้วก็จำได้ว่าตอนที่ไม่มีข้าวกิน คุณก็ยังให้เงินผมไปซื้อราเม็งกินด้วย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:91
translate english arc2_sakura_quest4_f23b2f0d:

    # sk "Desde entonces te encanta el Ramen, eres igual a Naruto"
    sk "ตั้งแต่นั้นมาเธอก็ติดราเม็งงอมแงมเลยสินะ เหมือนนารูโตะไม่มีผิด"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:93
translate english arc2_sakura_quest4_b85c0166:

    # mn "El Ramen es lo mejor que he probado sin duda"
    mn "ราเม็งนี่คือสิ่งที่อร่อยที่สุดเท่าที่ผมเคยลองมาเลยล่ะ ไม่มีข้อกังขาเลย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:96
translate english arc2_sakura_quest4_e9cf3dd2:

    # mn "También recuerdo que una vez tomé de una botella"
    mn "แล้วก็จำได้ด้วยว่ามีอยู่ครั้งหนึ่ง ที่ผมหยิบขวดนึงมาดื่ม"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:97
translate english arc2_sakura_quest4_1313cdaf:

    # mn "Y lo que había en esa botella era Sake jajaja"
    mn "แล้วสิ่งที่อยู่ในขวดนั้นดันเป็นเหล้าสาเกซะนี่ ฮ่าๆ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:99
translate english arc2_sakura_quest4_ae2d755c:

    # mn "Puedo decir que fue gracias a tí que probé el Alcohol"
    mn "เรียกได้ว่าเป็นเพราะคุณเลยนะเนี่ยที่ทำให้ผมได้ลองดื่มแอลกอฮอล์"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:100
translate english arc2_sakura_quest4_02fe8680:

    # sk "No me eches toda la culpa a mí, tú fuiste quien se lo tomó jajaja"
    sk "อย่ามาโยนความผิดให้ฉันคนเดียวสิ เธอนั่นแหละที่เป็นคนดื่มเข้าไปเอง ฮ่าๆ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:103
translate english arc2_sakura_quest4_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:104
translate english arc2_sakura_quest4_2e3b4bb2:

    # mn "De verdad te agradezco todo lo que has hecho Sakura"
    mn "ผมซาบซึ้งกับทุกสิ่งที่คุุณทำให้อย่างมากเลยนะ ซากุระ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:105
translate english arc2_sakura_quest4_dcac6279:

    # mn "No tengo palabras para demostrarte cuanto te lo agradezco"
    mn "ไม่รู้จะหาคำไหนมาแสดงความขอบคุณให้หมดดีเลยล่ะครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:106
translate english arc2_sakura_quest4_639b733f:

    # sk "..."
    sk "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:107
translate english arc2_sakura_quest4_24ba0b70:

    # sk "Y pensar que ese niño que encontramos se volvería un gran hombre"
    sk "ไม่นึกเลยว่าเด็กผู้ชายที่เราไปเจอในวันนั้น จะเติบโตมาเป็นผู้ชายที่ยอดเยี่ยมได้ขนาดนี้"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:108
translate english arc2_sakura_quest4_25687056:

    # sk "Sé que no soy tu madre biológica, pero..."
    sk "ฉันรู้ว่าฉันไม่ใช่แม่แท้ๆ ของเธอก็เถอะ แต่ว่านะ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:109
translate english arc2_sakura_quest4_158fefa4:

    # sk "Estoy muy orgullosa de tí..."
    sk "ฉันภูมิใจในตัวเธอจริงๆ นะ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:110
translate english arc2_sakura_quest4_8f6928a0:

    # mn "Sakura..."
    mn "ซากุระ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:112
translate english arc2_sakura_quest4_bbbfa183:

    # sk "¡¿E-Eh?!" with vpunch
    sk "อ-อะไรกัน?!" with vpunch

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:119
translate english arc2_sakura_quest4_d334a6bd:

    # sk "¿Porqué estás llorado?"
    sk "ทำไมถึงร้องไห้ล่ะเนี่ย?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:120
translate english arc2_sakura_quest4_8fd17689:

    # mn "¿Llorando?"
    mn "ร้องไห้เหรอครับ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:126
translate english arc2_sakura_quest4_af3ece6b:

    # mn "¡Ah! L-Lo siento..."
    mn "อ๊ะ! ข-ขอโทษครับ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:127
translate english arc2_sakura_quest4_2e641e4c:

    # mn "N-No sé que me pasa jaja"
    mn "ผ-ผมก็ไม่รู้เหมือนกันว่าเป็นอะไรเนี่ย ฮ่าๆ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:128
translate english arc2_sakura_quest4_a20cefa7:

    # "..."
    "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:129
translate english arc2_sakura_quest4_0fd4d656:

    # "......"
    "......"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:130
translate english arc2_sakura_quest4_89207145:

    # n "-{b}Luego de unos momentos{/a}-"
    n "-{b}ผ่านไปครู่หนึ่ง{/a}-"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:133
translate english arc2_sakura_quest4_b5f3934a:

    # sk "¿Ya estás bien?"
    sk "ตอนนี้โอเคขึ้นแล้วใช่ไหม?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:134
translate english arc2_sakura_quest4_626831c7:

    # mn "Si, de verdad lo siento"
    mn "ครับ ขอโทษจริงๆ นะครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:135
translate english arc2_sakura_quest4_6b66e6ad:

    # mn "No sé lo que me pasó la verdad..."
    mn "ผมก็ไม่รู้เหมือนกันว่าตัวเองเป็นอะไรไปจริงๆ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:136
translate english arc2_sakura_quest4_639b733f_1:

    # sk "..."
    sk "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:137
translate english arc2_sakura_quest4_e87c2bf6:

    # sk "[MN]... ¿Puedo preguntarte algo?"
    sk "[MN]... ฉันถามอะไรหน่อยได้ไหม?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:138
translate english arc2_sakura_quest4_edb3056c:

    # mn "Claro..."
    mn "ได้สครับ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:139
translate english arc2_sakura_quest4_acb79a47:

    # sk "Muy en el fondo... ¿Te gustaría haberla conocido?"
    sk "ลึกๆ แล้ว... เธออยากรู้จักเธอคนนั้นบ้างไหม?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:140
translate english arc2_sakura_quest4_32462c4b_1:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:141
translate english arc2_sakura_quest4_8886e682:

    # mn "Es complicado..."
    mn "มันก็ซับซ้อนอยู่นะครับ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:142
translate english arc2_sakura_quest4_2573bcef:

    # mn "Desde que supe lo que le pasó a mi Clan... He estado pensando..."
    mn "ตั้งแต่ที่ผมรู้ว่าเกิดอะไรขึ้นกับตระกูลของผม... ผมก็เอาแต่คิดเรื่องนี้มาตลอด..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:143
translate english arc2_sakura_quest4_046c2aae:

    # mn "Soy el último de mi Clan..."
    mn "ผมเป็นคนสุดท้ายของตระกูลแล้ว..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:144
translate english arc2_sakura_quest4_f8dbee97:

    # mn "¿Qué debería hacer ahora?"
    mn "ตอนนี้ผมควรทำยังไงต่อไปดีล่ะครับ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:145
translate english arc2_sakura_quest4_00cfe35e:

    # sk "[MN]..."
    sk "[MN]..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:146
translate english arc2_sakura_quest4_95a9841a:

    # mn "Oh, lo siento..."
    mn "อ๊ะ ขอโทษด้วยครับ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:147
translate english arc2_sakura_quest4_280834e4:

    # mn "No quiero aburrirte con mis pensamientos estúpidos... Estamos aquí para celebrar"
    mn "ผมไม่อยากเอาความคิดงี่เง่าของตัวเองมาทำให้คุณเบื่อหรอกนะ... เรามาฉลองกันแท้ๆ นอกเรื่องซะได้"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:149
translate english arc2_sakura_quest4_6d44fba0:

    # sk "Puedes contármelo, confía en mí"
    sk "เล่าให้ฉันฟังได้นะ เชื่อใจฉันสิ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:150
translate english arc2_sakura_quest4_32462c4b_2:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:151
translate english arc2_sakura_quest4_b90d7359:

    # sk "Vamos, no lo retengas más. Puedes contar conmigo para lo que sea"
    sk "เอาน่า อย่าเก็บไว้ในใจเลย มีอะไรพึ่งพาฉันได้เสมอนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:152
translate english arc2_sakura_quest4_32462c4b_3:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:153
translate english arc2_sakura_quest4_29e32bf7:

    # mn "Gracias..."
    mn "ขอบคุณครับ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:154
translate english arc2_sakura_quest4_cbbc039c:

    # mn "Verás..."
    mn "คือว่านะ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:155
translate english arc2_sakura_quest4_5a460dee:

    # mn "Ser el último de mi clan... Es algo que no puedo aceptar"
    mn "การที่เป็นคนสุดท้ายของตระกูล... เป็นเรื่องที่ผมทำใจยอมรับไม่ได้เลยครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:156
translate english arc2_sakura_quest4_8b2e7cfd:

    # mn "Y no sé qué debería hacer de ahora en adelante"
    mn "แล้วผมก็ไม่รู้ด้วยว่าจากนี้ไปควรจะทำยังไงดี"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:158
translate english arc2_sakura_quest4_60da4aa9:

    # mn "Hasta ahora, no sabía nada sobre mi pasado. Lo último que recuerdo es... Despertar en aquel lugar"
    mn "จนถึงตอนนี้ ผมไม่รู้อะไรเกี่ยวกับอดีตของตัวเองเลย สิ่งสุดท้ายที่จำได้ก็คือ... การได้ตื่นขึ้นมาในที่แห่งนั้น"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:159
translate english arc2_sakura_quest4_9074debd:

    # mn "Me convertí en ninja porque veía a todos ustedes esforzándose para proteger la aldea y a sus seres queridos..."
    mn "ผมมาเป็นนินจาก็เพราะเห็นพวกคุณทุกคนพยายามปกป้องหมู่บ้านและคนที่รัก..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:160
translate english arc2_sakura_quest4_d01b5425:

    # mn "Ver al Séptimo salir victorioso en su lucha contra Isshiki... Fue increíble"
    mn "ตอนที่ได้เห็นท่านรุ่นที่เจ็ดเอาชนะการต่อสู้กับอิชิกิได้... มันสุดยอดมากเลยล่ะครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:161
translate english arc2_sakura_quest4_d5dc76bc:

    # mn "Yo también quería tener algo por lo que luchar"
    mn "ผมเองก็อยากจะมีอะไรสักอย่างให้สู้เพื่อสิ่งนั้นเหมือนกัน"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:162
translate english arc2_sakura_quest4_6e529ad0:

    # mn "Así que me propuse ser un ninja para seguir su camino, para proteger la aldea y a las personas que me acogieron cuando ni siquiera sabía quién era"
    mn "ผมก็เลยตัดสินใจเป็นนินจาเพื่อเดินตามรอยเท้าของท่าน เพื่อปกป้องหมู่บ้านและคนที่คอยรับผมเข้ามาตอนที่ผมยังไม่รู้ด้วยซ้ำว่าตัวเองเป็นใคร..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:163
translate english arc2_sakura_quest4_639b733f_2:

    # sk "..."
    sk "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:164
translate english arc2_sakura_quest4_f7518e21:

    # mn "Pero ahora que sé sobre mi clan... No sé si debería hacer algo al respecto. Estoy confundido"
    mn "แต่พอตอนนี้ผมมารู้เรื่องตระกูลของตัวเองแล้ว... ผมก็ไม่รู้เลยว่าควรจะทำอะไรกับมันดี ผมสับสนไปหมดแล้วครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:165
translate english arc2_sakura_quest4_4c322075:

    # mn "¿Debería buscar más información sobre ellos? ¿Debería buscar si hay algún sobreviviente?"
    mn "ผมควรจะหาข้อมูลเกี่ยวกับพวกเขาเพิ่มดีไหม? หรือควรจะไปตามหาว่ายังมีใครรอดชีวิตอยู่บ้างรึเปล่า?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:166
translate english arc2_sakura_quest4_800d900a:

    # mn "Por las noches, esos pensamientos me carcomen la cabeza"
    mn "พอตกกลางคืน ความคิดพวกนั้นก็คอยกัดกินจิตใจของผมไปเรื่อยๆ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:167
translate english arc2_sakura_quest4_42b5af6b:

    # mn "¿Y sabes qué es lo peor?"
    mn "แล้วคุณรู้ไหมว่าอะไรคือส่วนที่แย่ที่สุด?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:168
translate english arc2_sakura_quest4_c1cf42f2:

    # mn "Que no sé exactamente lo que siento..."
    mn "นั่นก็คือผมไม่รู้ด้วยซ้ำว่าตัวเองรู้สึกยังไงกันแน่..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:169
translate english arc2_sakura_quest4_c3cf2c31:

    # mn "Es una mezcla de tristeza, impotencia y rabia"
    mn "มันเป็นความรู้สึกปะปนกันระหว่างความเศร้า ความไร้หนทาง และความโกรธครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:170
translate english arc2_sakura_quest4_55cf9a58:

    # sk "¿Por qué?"
    sk "ทำไมล่ะ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:171
translate english arc2_sakura_quest4_8e8226aa:

    # mn "Me entristece, porque no queda nadie... Ni mi verdadera familia..."
    mn "ผมเศร้าเพราะไม่มีใครหลงเหลืออยู่เลย... แม้แต่ครอบครัวแท้ๆ ของผม..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:172
translate english arc2_sakura_quest4_95ebb237:

    # mn "Siento impotencia porque... No puedo ni recordar sus rostros, no recuerdo nada sobre ellos..."
    mn "ผมรู้สึกไร้หนทางเพราะ... แค่หน้าตาของพวกเขาผมยังจำไม่ได้เลย ผมจำอะไรเกี่ยวกับพวกเขาไม่ได้สักอย่าง..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:173
translate english arc2_sakura_quest4_30b9f96e:

    # mn "Y rabia porque no puedo hacer nada contra quienes acabaron con ellos, porque según dicen, ya no queda ninguno con vida..."
    mn "ส่วนความโกรธก็เพราะผมทำอะไรคนที่ฆ่าพวกเขาไม่ได้เลย แถมพวกเขายังบอกว่าไม่มีใครรอดชีวิตอยู่แล้วอีก..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:174
translate english arc2_sakura_quest4_639b733f_3:

    # sk "..."
    sk "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:175
translate english arc2_sakura_quest4_b925f22c:

    # sk "¿Qué crees que es lo mejor que puedes hacer?"
    sk "แล้วเธอคิดว่าอะไรคือสิ่งที่ดีที่สุดที่เธอจะทำได้ล่ะ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:176
translate english arc2_sakura_quest4_3dd48b25:

    # sk "¿Quedarte en la aldea de brazos cruzados?"
    sk "อยู่เฉยๆ ในหมู่บ้านโดยไม่ทำอะไรเลยงั้นเหรอ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:177
translate english arc2_sakura_quest4_a2c49fea:

    # mn "No..."
    mn "เปล่าครับ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:178
translate english arc2_sakura_quest4_b1ac0c6d:

    # sk "Si realmente quieres buscar información sobre tu clan, tendrás que salir de la aldea"
    sk "ถ้าเธออยากจะหาข้อมูลเกี่ยวกับตระกูลจริงๆ เธอก็จำเป็นจะต้องออกจากหมู่บ้านนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:179
translate english arc2_sakura_quest4_503b6cd2:

    # sk "Orochimaru podría ayudarte, pero los Genin no tienen permitido verlo en persona"
    sk "โอโรจิมารุอาจจะช่วยเธอได้ แต่เกะนินได้รับอนุญาตให้ไปพบเขาแบบตัวต่อตัวซะที่ไหนล่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:180
translate english arc2_sakura_quest4_94b2a0ea:

    # sk "También podrías investigar en el Laboratorio de Shin Uchiha"
    sk "เธออาจจะไปสืบหาข้อมูลที่ห้องทดลองของชิน อุจิวะก็ได้นะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:181
translate english arc2_sakura_quest4_bfa3d683:

    # sk "Pero desde que te rescatamos, lo sellaron para evitar que alguien toque esa tecnología. Solo Orochimaru y unos pocos más pueden acceder"
    sk "แต่ตั้งแต่ที่เราช่วยเธอออกมา ที่นั่นก็ถูกปิดตายเพื่อไม่ให้ใครเข้าไปยุ่งกับเทคโนโลยีพวกนั้น มีแค่โอโรจิมารุกับคนอื่นๆ อีกไม่กี่คนเท่านั้นที่เข้าไปได้"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:182
translate english arc2_sakura_quest4_7a235503:

    # sk "Y además, está demasiado lejos. Como Genin, no puedes ir hasta allí; es una zona muy peligrosa"
    sk "แถมมันยังอยู่ไกลมากด้วย ในฐานะเกะนินเธอไปที่นั่นไม่ได้หรอกนะ มันเป็นเขตอันตรายมากๆ เลยล่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:183
translate english arc2_sakura_quest4_b7954d44:

    # mn "Orochimaru..."
    mn "โอโรจิมารุ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:185
translate english arc2_sakura_quest4_40991c75:

    # sk "Si quieres mi consejo, primero céntrate en pasar los exámenes Chunin"
    sk "ถ้าเธออยากฟังคำแนะนำจากฉันล่ะก็... ก่อนอื่นก็ตั้งสมาธิไปกับการสอบจูนินให้ผ่านก่อนดีกว่านะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:186
translate english arc2_sakura_quest4_a9fbfecc:

    # sk "El pasado ya no se puede cambiar"
    sk "อดีตเป็นสิ่งที่เปลี่ยนแปลงไม่ได้อีกแล้ว"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:187
translate english arc2_sakura_quest4_1b2f9838:

    # sk "Pero tu futuro sí. Con disciplina y dedicación, puedes lograr cualquier cosa que te propongas"
    sk "แต่อนาคตของเธอเปลี่ยนได้ ด้วยวินัยและความตั้งใจ เธอจะสามารถบรรลุทุกสิ่งที่เธอตั้งเป้าไว้ได้แน่นอน"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:188
translate english arc2_sakura_quest4_32462c4b_4:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:189
translate english arc2_sakura_quest4_ca7db4b4:

    # sk "Cuando seas Chunin, pídele permiso a Naruto para ir a ver a Orochimaru y buscar más información"
    sk "เมื่อไหร่ที่เธอได้เป็นจูนินแล้ว ค่อยไปขออนุญาตจากนารูโตะเพื่อไปพบโอโรจิมารุและหาข้อมูลเพิ่มเติมนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:190
translate english arc2_sakura_quest4_32462c4b_5:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:192
translate english arc2_sakura_quest4_545179ef:

    # mn "(Es una gran idea...)"
    mn "(เป็นความคิดที่ดีจริงๆ...)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:193
translate english arc2_sakura_quest4_0968b160:

    # mn "(Aunque dudo que me deje ir solo... Tal vez si voy con Sarada y otro ninja de alto rango me dejen ir)"
    mn "(ถึงจะลังเลว่าพวกเขาจะยอมให้ฉันไปคนเดียวรึเปล่า... แต่ถ้าไปกับซาราดะและนินจาระดับสูงคนอื่นด้วย พวกเขาก็น่าจะยอมให้ไปนะ)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:194
translate english arc2_sakura_quest4_cc952339:

    # mn "(Pero es un buen plan. Todo dependerá de que me convierta en Chunin)"
    mn "(แต่มันก็เป็นแผนที่ดีทีเดียว ทุกอย่างขึ้นอยู่กับการที่ฉันต้องสอบจูนินให้ผ่านแล้วล่ะ)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:197
translate english arc2_sakura_quest4_842e8031:

    # mn "¡MUY BIEN!" with vpunch
    mn "งั้นเอาตามนี้ครับ!" with vpunch

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:198
translate english arc2_sakura_quest4_6ef85030:

    # sk "¡Aaah, no grites tan de repente!"
    sk "อ๊า อย่าตะโกนขึ้นมาซะดียๆ สิฟะเนี่ย!"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:199
translate english arc2_sakura_quest4_c7faf379:

    # mn "Entonces, ya he decidido lo que voy a hacer"
    mn "งั้นผมตัดสินใจได้แล้วล่ะว่าจะทำยังไงต่อไป"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:200
translate english arc2_sakura_quest4_69483352:

    # mn "No sirve de nada lamentarme por algo que pasó hace años, ¿cierto?"
    mn "มานั่งคร่ำครวญถึงเรื่องที่เกิดขึ้นไปหลายปีแล้วมันก็ไม่มีประโยชน์อะไรใช่ไหมล่ะครับ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:202
translate english arc2_sakura_quest4_2b8348a1:

    # sk "Exacto"
    sk "ถูกต้องแล้วล่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:203
translate english arc2_sakura_quest4_230b7b38:

    # sk "Lo mejor que puedes hacer es pensar en tu futuro"
    sk "สิ่งที่เธอควรทำที่สุดตอนนี้คือการคิดถึงอนาคตของตัวเองต่างหาก"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:204
translate english arc2_sakura_quest4_e7a89990:

    # sk "Entonces, ¿qué es lo primero que harás?"
    sk "แล้วอย่างแรกที่เธอจะทำคืออะไรล่ะ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:205
translate english arc2_sakura_quest4_40c785ee:

    # mn "¡Pasar los exámenes Chunin!"
    mn "สอบจูนินให้ผ่านครับ!"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:206
translate english arc2_sakura_quest4_745cf5fe:

    # sk "¡Exactamente!"
    sk "ถูกต้องที่สุด!"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:207
translate english arc2_sakura_quest4_684ce759:

    # sk "Y después de ser Chunin, ¿qué harás?"
    sk "แล้วหลังจากได้เป็นจูนินแล้ว เธอจะทำอะไรต่อล่ะ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:208
translate english arc2_sakura_quest4_02b04693:

    # mn "Voy a..."
    mn "ผมจะ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:209
translate english arc2_sakura_quest4_200cdf3a:

    # mn "Voy a restablecer mi clan..."
    mn "ผมจะฟื้นฟูตระกูลของผมขึ้นมาใหม่ครับ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:211
translate english arc2_sakura_quest4_f7507354:

    # sk "¡¿Ah?!" with vpunch
    sk "ว่าไงนะ?!" with vpunch

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:212
translate english arc2_sakura_quest4_cf12bedf:

    # mn "Dominaré el Karugan y buscaré toda la información posible sobre el Clan Karui"
    mn "ผมจะฝึกฝนคารูกันให้เชี่ยวชาญและค้นหาข้อมูลทั้งหมดเท่าที่จะหาได้เกี่ยวกับตระกูลคารุยครับ!"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:213
translate english arc2_sakura_quest4_639b733f_4:

    # sk "..."
    sk "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:215
translate english arc2_sakura_quest4_4682312a:

    # sk "(Por un momento... Se escuchó como Sasuke...)"
    sk "(ชั่วขณะหนึ่ง... เขาฟังดูเหมือนซาสึเกะเลย...)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:216
translate english arc2_sakura_quest4_53aa7c91:

    # sk "(...)"
    sk "(...)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:217
translate english arc2_sakura_quest4_28577389:

    # sk "(Viéndolo bien, se parece bastante...)"
    sk "(พอมองดูดีๆ แล้ว เขาก็มีส่วนคล้ายอยู่เหมือนกันนะ...)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:218
translate english arc2_sakura_quest4_e8382afa:

    # sk "(Aunque su forma de ser es más como la de Naruto...)"
    sk "(ถึงนิสัยใจคอจะเหมือนนารูโตะมากกว่าก็เถอะ...)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:222
translate english arc2_sakura_quest4_4de20e49:

    # sk "Muy bien, A-Así se habla jaja"
    sk "ง...งั้นเหรอ ดีแล้วล่ะที่ฮึดสู้ ฮ่าๆๆ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:223
translate english arc2_sakura_quest4_2e9a1a43:

    # mn "¿Sabes? También me gustaría saber cual es el símbolo de mi Clan"
    mn "นี่รู้ไหมครับ? ผมก็อยากรู้เหมือนกันนะว่าสัญลักษณ์ตระกูลของผมคืออะไร"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:224
translate english arc2_sakura_quest4_a2d1709d:

    # mn "Me haría ilusión portarlo..."
    mn "ถ้าได้ใส่สัญลักษณ์นั้นคงจะตื่นเต้นน่าดู..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:225
translate english arc2_sakura_quest4_d161963a:

    # sk "Si... ¿Hasta ahora no has llevado ningún simbolo cierto?"
    sk "นั่นสินะ... ตั้งแต่ไหนแต่ไรมาเธอก็ไม่ได้ใส่สัญลักษณ์ของตระกูลไหนเลยสินะ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:226
translate english arc2_sakura_quest4_84ea772e:

    # mn "Como no pertenecía a ningún Clan, pensé que no debía llevar ninguno, pero ahora que sé que pertenezco a uno debería portarlo"
    mn "ก็เพราะผมไม่ได้สังกัดตระกูลไหนเลยคิดว่าไม่จำเป็นต้องใส่นี่ครับ แต่ตอนนี้รู้แล้วว่าตัวเองมีตระกูล ก็เลยอยากจะใส่มันดูบ้าง"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:227
translate english arc2_sakura_quest4_e3489802:

    # sk "Ahora siento curiosidad, me gustaría verte portándolo jaja"
    sk "ชักอยากเห็นเวลาเธอใส่สัญลักษณ์นั้นขึ้นมาจริงๆ แล้วสิ ฮ่าๆๆ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:228
translate english arc2_sakura_quest4_5ab69361:

    # mn "No comas ansias jaja"
    mn "อย่าเพิ่งตื่นเต้นไปเลยครับ ฮ่าๆๆ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:229
translate english arc2_sakura_quest4_fab15623:

    # sk "Jajaja"
    sk "ฮ่าๆๆๆ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:230
translate english arc2_sakura_quest4_ec9abf6d:

    # mn "Gracias por escucharme Sakura, la verdad me has ayudado a quitarme un peso de encima"
    mn "ขอบคุณที่รับฟังนะครับซากุระ ช่วยให้ผมรู้สึกโล่งอกขึ้นเยอะเลย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:231
translate english arc2_sakura_quest4_e3e6a264:

    # sk "Sin problema, puedes contar conmigo cuando quieras"
    sk "ไม่เป็นไรหรอก พึ่งพาฉันได้เสมอแหละ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:232
translate english arc2_sakura_quest4_43cb21bc:

    # mn "También ahora estoy súper motivado, ya quiero que lleguen los exámenes"
    mn "ตอนนี้ผมไฟแรงสุดๆ เลยล่ะ อยากให้ถึงวันสอบเร็วๆ จัง"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:233
translate english arc2_sakura_quest4_c557c725:

    # sk "No comas ansias, faltan semanas para los exámenes"
    sk "อย่าเพิ่งรีบตื่นเต้นไปเลยน่า การสอบยังอีกตั้งหลายสัปดาห์แน่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:234
translate english arc2_sakura_quest4_377e0a14:

    # mn "*suspiro* Ojalá mi motivación dure hasta entonces..."
    mn "*ถอนหายใจ* หวังว่าไฟในตัวผมจะลุกโชนไปจนถึงตอนนั้นนะ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:235
translate english arc2_sakura_quest4_fab15623_1:

    # sk "Jajaja"
    sk "ฮ่าๆๆๆ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:236
translate english arc2_sakura_quest4_1b495e0a:

    # mn "Oh, por cierto, ¿Sabes como serán los exámenes de este año?"
    mn "อ้อ ว่าแต่คุณพอจะรู้ไหมครับว่าปีนี้การสอบจะเป็นยังไงบ้าง?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:237
translate english arc2_sakura_quest4_29c50dec:

    # sk "Mmmm, no sé, pero estoy segura que serán más difíciles este año"
    sk "อืม ฉันก็ไม่รู้เหมือนกัน แต่เชื่อว่าปีนี้คงจะยากขึ้นกว่าเดิมแน่ๆ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:238
translate english arc2_sakura_quest4_7ad6b757:

    # mn "¿M-Más difíciles?"
    mn "ย...ยากขึ้นเหรอครับ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:239
translate english arc2_sakura_quest4_a1d36943:

    # sk "Si, hasta hace unos años los exámenes se fueron haciendo más fáciles, ya sabes, por los tiempos de paz"
    sk "ใช่ จนถึงไม่กี่ปีมานี้ข้อสอบมันง่ายขึ้นเรื่อยๆ น่ะรู้ไหม ก็เพราะว่าเป็นช่วงเวลาแห่งความสงบสุขน่ะนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:240
translate english arc2_sakura_quest4_db0c6a10:

    # sk "Pero este años los {b}Cinco Kages{/a} decidieron que iban a ser iguales que en nuestros tiempos"
    sk "แต่ว่าปีนี้ {b}คาเงะทั้งห้า{/a} ตัดสินใจว่ามันจะยากเท่ากับสมัยของพวกเราน่ะสิ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:241
translate english arc2_sakura_quest4_d85f4a20:

    # sk "Y si son así, pues sí serán difíciles"
    sk "และถ้ามันเป็นแบบนั้นล่ะก็ รับรองว่ายากแน่ๆ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:242
translate english arc2_sakura_quest4_9bdeca30:

    # mn "¿Puedes contarme cómo serán?"
    mn "พอจะเล่าให้ฟังคร่าวๆ ได้ไหมครับว่ามันจะเป็นยังไง?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:243
translate english arc2_sakura_quest4_dd6828c4:

    # mn "O no, mejor no me digas nada, no quiero ir con ninguna ventaja"
    mn "เอ๊ะ หรือว่าไม่ต้องบอกดีกว่าครับ ผมไม่อยากได้เปรียบคนอื่นหรอกนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:244
translate english arc2_sakura_quest4_0c7bdf7c:

    # sk "¿Estás seguro? La información en el mundo de los Shinobi es muy importante"
    sk "แน่ใจนะ? ข้อมูลข่าวสารในโลกนินจาน่ะเป็นเรื่องสำคัญมากๆ เลยนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:245
translate english arc2_sakura_quest4_cb20cf47:

    # mn "Ya me las arreglaré, pero igual gracias"
    mn "ผมจัดการเองได้ครับ แต่ก็ขอบคุณนะคะ... เอ้ย ขอบคุณนะครับ!"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:246
translate english arc2_sakura_quest4_4c5ddcfb:

    # sk "Muy bien"
    sk "งั้นก็ตามใจจ่ะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:247
translate english arc2_sakura_quest4_d855abe8:

    # mn "Jeje, entonces... ¿Ya compramos Sake?"
    mn "แหะๆ ว่าแต่... เราซื้อสาเกกันรึยังนะ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:248
translate english arc2_sakura_quest4_40ed4f1a:

    # mn "No hemos probado nada de Alcohol"
    mn "พวกเรายังไม่เคยลองดื่มเหล้ากันเลยนะครับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:249
translate english arc2_sakura_quest4_3552cf1c:

    # sk "Por supuesto, ya te habías tardado"
    sk "นั่นสินะ เธอก็มาสายแล้วด้วยนี่"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:253
translate english arc2_sakura_quest4_ecef9d74:

    # n "Al cabo de unos minutos, la mesera le lleva una botella de Sake a [MN] y Sakura"
    n "ผ่านไปสักครู่ พนักงานเสิร์ฟก็นำสาเกหนึ่งขวดมาเสิร์ฟให้ [MN] และซากุระ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:256
translate english arc2_sakura_quest4_85f24ac1:

    # sk "No sabes cuanto deseaba... *hip* Una noche así..."
    sk "เธอไม่รู้หรอกว่าฉันอยาก... *เอื๊อก* ค่ำคืนแบบนี้มากแค่ไหน..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:257
translate english arc2_sakura_quest4_1951f41e:

    # sk "Necesitaba olvidarme de todo..."
    sk "ฉันแค่อยากจะลืมทุกๆ อย่าง..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:258
translate english arc2_sakura_quest4_46add438:

    # mn "¿Qué te preocupa?"
    mn "มีอะไรกลุ้มใจอยู่เหรอครับ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:259
translate english arc2_sakura_quest4_e3fc2a7f:

    # mn "A simple vista *hip*... No parece que te afecte algo..."
    mn "มองเผินๆ *เอื๊อก*... เธอก็ดูเหมือนไม่มีอะไรมารบกวนจิตใจเลยนะ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:261
translate english arc2_sakura_quest4_639b733f_5:

    # sk "..."
    sk "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:262
translate english arc2_sakura_quest4_5e6f9575:

    # sk "Es una fachada... ¿Sabes?"
    sk "มันก็แค่ฉากหน้า... รู้ไหม?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:263
translate english arc2_sakura_quest4_566047f4:

    # sk "Ya han pasado 8 años desde que {b}Sasuke{/a} se fue de la aldea... Y no he sabido nada de él..."
    sk "ก็มัน 8 ปีแล้วนะตั้งแต่ {b}ซาสึเกะ{/a} ออกจากหมู่บ้านไป... แล้วฉันก็ไม่ได้ข่าวคราวอะไรจากเขาเลย..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:264
translate english arc2_sakura_quest4_8f0ef224:

    # sk "Siempre es lo mismo... Se va de la aldea y no sé nada de él hasta años después... Así ha sido desde siempre..."
    sk "มันเป็นแบบนี้ตลอด... เขาออกจากหมู่บ้านไปแล้วฉันก็ไม่ได้ข่าวเขาอีกเลยจนกระทั่งหลายปีผ่านไป... เป็นแบบนี้มาตลอดเลย..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:265
translate english arc2_sakura_quest4_fc83c93a:

    # sk "Siempre igual... Y yo solo debo esperar..."
    sk "เหมือนเดิมทุกที... แล้วฉันก็ทำได้แค่รอ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:266
translate english arc2_sakura_quest4_86b03b55:

    # sk "Y mientras espero {b}la soledad se siente más pesada{/a}"
    sk "และในระหว่างที่รอ {b}ความเหงามันก็ยิ่งกัดกินหัวใจให้หนักอึ้งขึ้นเรื่อยๆ{/a}"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:267
translate english arc2_sakura_quest4_32462c4b_6:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:268
translate english arc2_sakura_quest4_217dcfea:

    # mn "Eres increíble Sakura... Eres una persona muy fuertes... Has aguantado tanto y sigues de pie"
    mn "คุณซากุระสุดยอดไปเลยนะครับ... คุณเป็นคนเข้มแข็งมากๆ เลย อดทนมาตั้งเยอะแต่ก็ยังยืนหยัดอยู่ได้"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:269
translate english arc2_sakura_quest4_a7efa0f5:

    # sk "Ser fuerte no siempre significa no sentir dolor... A veces desearía que las cosas fueran diferentes"
    sk "การทำตัวเข้มแข็งไม่ได้แปลว่าไม่รู้สึกเจ็บปวดซะหน่อย... บางครั้งฉันก็ภาวนาให้ทุกอย่างมันต่างออกไปนะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:270
translate english arc2_sakura_quest4_7fa3c8ec:

    # sk "¿Sabes?... A veces cuando te veo... es como si viera a Sasuke. Es tan doloroso y reconfortante al mismo tiempo..."
    sk "รู้ไหม?... บางเวลาที่ฉันมองเธอ... มันเหมือนกับได้เห็นซาสึเกะเลยล่ะ ทั้งเจ็บปวดแล้วก็อบอุ่นหัวใจในเวลาเดียวกัน..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:271
translate english arc2_sakura_quest4_8f6928a0_1:

    # mn "Sakura..."
    mn "คุณซากุระ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:272
translate english arc2_sakura_quest4_50c5134e:

    # sk "*suspiro* Sasuke... ¿Cuándo volverás?"
    sk "*ถอนหายใจ* ซาสึเกะ... เมื่อไหร่เธอจะกลับมานะ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:273
translate english arc2_sakura_quest4_32462c4b_7:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:275
translate english arc2_sakura_quest4_c3fb969d:

    # sk "Ah... Lo siento..."
    sk "อ๊ะ... ขอโทษทีนะ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:276
translate english arc2_sakura_quest4_c00716fa:

    # sk "No quería amargar la noche jaja"
    sk "ฉันไม่อยากมาทำลายบรรยากาศค่ำคืนนี้เลย ฮ่าๆ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:277
translate english arc2_sakura_quest4_56101fbc:

    # mn "No te preocupes, tu escuchaste mis lamentos, tengo que hacer lo mismo"
    mn "ไม่ต้องคิดมากหครับ คุณยังอุส่าห์ฟังผมบ่นเลย ผมก็ต้องรับฟังคุณเหมือนกันสิ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:278
translate english arc2_sakura_quest4_b9fc3b57:

    # sk "Gracias, es un alivio desahogarse con alguien de vez en cuando"
    sk "ขอบคุณนะ การได้ระบายความในใจให้ใครสักคนฟังบ้างเนี่ย มันโล่งอกจริงๆ เลย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:279
translate english arc2_sakura_quest4_9150d80d:

    # sk "¿Qué tal si tomamos unos tragon más y nos vamos?"
    sk "งั้นเราดื่มกันอีกสักหน่อยแล้วค่อยกลับกันดีไหม?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:280
translate english arc2_sakura_quest4_bbac25e1:

    # sk "Ya se está haciendo un poco tarde"
    sk "นี่ก็เริ่มดึกมากแล้วด้วย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:281
translate english arc2_sakura_quest4_3738e5d7:

    # mn "Claro, uno más"
    mn "ได้เลยครับ อีกสักแก้วละกัน"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:284
translate english arc2_sakura_quest4_327e7ae8:

    # n "Luego de tomar unos tragos más, [MN] y Sakura se emborrachan poco a poco"
    n "หลังจากดื่มเพิ่มเข้าไปอีกหลายแก้ว [MN] และซากุระก็เริ่มเมากันเรื่อยๆ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:285
translate english arc2_sakura_quest4_1f52209c:

    # n "Hasta llegar al punto donde llamaban mucho la atención, y la mesera tuvo que ponerse seria y sacarlos del bar"
    n "จนกระทั่งเริ่มเป็นจุดสนใจของคนอื่น พนักงานเสิร์ฟจึงต้องเข้ามาตักเตือนอย่างจริงจังและไล่พวกเขาสองคนออกจากร้าน"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:286
translate english arc2_sakura_quest4_896a5344:

    # n "Tanto [MN] como Sakura estaban demasiado ebrios, así que la mesera llamó a Sarada para que los fuera a traer"
    n "เนื่องจากทั้ง [MN] และซากุระเมากันจนเละเทะ พนักงานเสิร์ฟจึงต้องโทรเรียกซาราดะให้มารับพวกเขากลับ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:287
translate english arc2_sakura_quest4_e573bc5c:

    # n "Parece ser que no es la primera vez que le pasa a Sakura..."
    n "ดูเหมือนว่านี่จะไม่ใช่ครั้งแรกที่เกิดเหตุการณ์แบบนี้กับซากุระสินะ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:298
translate english arc2_sakura_quest4_a3294f1f:

    # sr "Lo que me faltaba..."
    sr "มีเรื่องให้ปวดหัวเพิ่มขึ้นมาอีกจนได้สินะ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:300
translate english arc2_sakura_quest4_6aef7b96:

    # sr "Primero mi madre, ¿Y ahora tú también?"
    sr "เริ่มจากแม่ แล้วตอนนี้ยังมาเป็นนายอีกเหรอเนี่ย?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:301
translate english arc2_sakura_quest4_a54e2e87:

    # sk "Sarada... Que bueno *hip* verte..."
    sk "ซาราดะ... ดีใจจัง *เอือก* ที่ได้เจอ...รูก..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:302
translate english arc2_sakura_quest4_b09a7f4f:

    # mn "*hip* ¿Quién está Varada?... *hip*"
    mn "*เอือก* ใครคือวาลาดะเนี่ย?... *เอือก*"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:303
translate english arc2_sakura_quest4_1943d87b:

    # mn "¿Estamos varados? *hip*"
    mn "พวกเราติดเกาะกันเหรอเนี่ย? *เอือก*"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:304
translate english arc2_sakura_quest4_d2fd55d0:

    # sk "¿Qué?"
    sk "หา?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:305
translate english arc2_sakura_quest4_0ed9dd88:

    # mn "¿Khé?..."
    mn "ฮะ?... อืม..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:308
translate english arc2_sakura_quest4_16278896:

    # sr "..."
    sr "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:311
translate english arc2_sakura_quest4_5c4d5ddd:

    # sr "*suspiro* ¿Qué hice para merecer esto?"
    sr "*ถอนหายใจ* ฉันทำกรรมอะไรไว้เนี่ย ถึงต้องมาเจอเรื่องแบบนี้?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:312
translate english arc2_sakura_quest4_70edf47c:

    # sr "Andando par de inútiles, vamos a casa"
    sr "มานี่เลย คู่หูตัวถ่วง กลับบ้านกันได้แล้ว"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:315
translate english arc2_sakura_quest4_f6b48a25:

    # n "Sarada toma a ambos y se los lleva consigo a su casa"
    n "ซาราดะพาทั้งสองคนกลับมาที่บ้านของเธอ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:325
translate english arc2_sakura_quest4_157816a8:

    # sr "Maldita sea, por fin..."
    sr "ให้ตายสิ ในที่สุดก็ถึง..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:326
translate english arc2_sakura_quest4_3854d094:

    # mnn "Mmmm..."
    mnn "อืมมม..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:327
translate english arc2_sakura_quest4_f62e60a9:

    # sr "¿En serio se durmieron? Argh..."
    sr "หลับไปกันจริงๆ เหรอเนี่ย? โธ่เอ๊ย..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:329
translate english arc2_sakura_quest4_96fe7cc0:

    # sk "*ronquidos*"
    sk "*คร่อก... ฟี้...*"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:332
translate english arc2_sakura_quest4_1082b5b2:

    # sr "¿Y ahora que hago con [MN]?"
    sr "แล้วทีนี้ฉันจะเอายังไงกับ [MN] ดีล่ะเนี่ย?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:333
translate english arc2_sakura_quest4_4057bdd5:

    # sr "Su apartamento está demasiado lejos y no puedo dejarlo durmiendo aquí en el suelo"
    sr "อพาร์ตเมนต์ของเขาก็อยู่ตั้งไกล จะปล่อยให้นอนกองอยู่บนพื้นตรงนี้ก็ไม่ได้ด้วยสิ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:334
translate english arc2_sakura_quest4_048c8f9e:

    # mnn "*ronquidos*"
    mnn "*คร่อก... ฟี้...*"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:337
translate english arc2_sakura_quest4_a33ba1e9:

    # sr "Oh, ya sé"
    sr "อ๋อ นึกออกแล้ว"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:338
translate english arc2_sakura_quest4_9283bb09:

    # sr "Creo recordar que mi madre tiene un Futón para visitas"
    sr "รู้สึกว่าแม่น่าจะมีฟูกนอนสำหรับแขกอยู่นี่นะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:339
translate english arc2_sakura_quest4_886890af:

    # sr "Veamos..."
    sr "ลองหาดูหน่อย..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:341
translate english arc2_sakura_quest4_4c34bd80:

    # n "Sarada saca y prepara un Futón para [MN] y recuesta a Sakura en su habitación"
    n "ซาราดะหยิบฟูกออกมาปูเตรียมไว้ให้ [MN] ก่อนจะพยุงซากุระไปนอนในห้องของเธอ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:343
translate english arc2_sakura_quest4_efc7add0:

    # sr "Listo, ahora solo tengo que..."
    sr "เรียบร้อย ทีนี้ก็เหลือแค่..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:345
translate english arc2_sakura_quest4_813c00d8:

    # sr "Llevarlo a la habitación..."
    sr "พาเขาไปที่ห้อง..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:346
translate english arc2_sakura_quest4_2545a71c:

    # sr "¿Debería dejarlo en la habitación de mi mamá?"
    sr "จะให้เขานอนในห้องของแม่ดีไหมนะ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:348
translate english arc2_sakura_quest4_16278896_1:

    # sr "..."
    sr "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:350
translate english arc2_sakura_quest4_c71b69e7:

    # sr "Podría dejarlo en mi habitación pero... Tengo una misión mañana temprano..."
    sr "จะให้เขานอนห้องฉันก็ได้นะ แต่... ฉันมีภารกิจแต่เช้าตรู่เลยพรุ่งนี้..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:352
translate english arc2_sakura_quest4_19507ca2:

    # sr "Bueno, no creo que pase algo la verdad"
    sr "ช่างเถอะ พูดตามตรงคือคิดว่าคงไม่มีอะไรเกิดขึ้นหรอกมั้ง"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:353
translate english arc2_sakura_quest4_7c553a92:

    # sr "La relación entre estos dos es como de madre e hijo"
    sr "ความสัมพันธ์ระหว่างสองคนนี้ก็เหมือนแม่กับลูกนั่นแหละ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:355
translate english arc2_sakura_quest4_2ae33148:

    # n "Sarada mueve a [MN] y lo acuesta en el futón"
    n "ซาราดะย้ายตัว [MN] แล้วพาไปนอนลงบนฟูก"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:362
translate english arc2_sakura_quest4_fb00fcc3:

    # sr "Listo"
    sr "เสร็จสักที"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:363
translate english arc2_sakura_quest4_57a6aaf5:

    # sr "Ya verán mañana, de esta no se salvan"
    sr "พรุ่งนี้แกเจอดีแน่ ไม่มีทางรอดตัวไปได้ง่ายๆ หรอก"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:366
translate english arc2_sakura_quest4_88ae01d0:

    # n "Sarada sale de la habitación y los deja a ambos dormir"
    n "ซาราดะเดินออกจากห้องและปล่อยให้ทั้งสองคนนอนหลับไป"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:367
translate english arc2_sakura_quest4_0bea99c8:

    # n "En la misma habitación..."
    n "อยู่ในห้องเดียวกัน..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:368
translate english arc2_sakura_quest4_36ef102f:

    # n "Solos..."
    n "ลำพัง..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:369
translate english arc2_sakura_quest4_1e03fc31:

    # n "A oscuras..."
    n "ในความมืด..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:370
translate english arc2_sakura_quest4_29821c8e:

    # n "Y ebrios..."
    n "แถมยังเมาแอ๋..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:371
translate english arc2_sakura_quest4_bb2cf764_1:

    # n "..."
    n "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:377
translate english arc2_sakura_quest4_6a7b1dfa:

    # mn "Mmm..."
    mn "อืม..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:378
translate english arc2_sakura_quest4_46f1e72a:

    # mn "Mmm... Tengo que ir al baño..."
    mn "อืม... ปวดฉี่แฮะ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:379
translate english arc2_sakura_quest4_91cc8b7f:

    # mn "Maldición, que dolor de cabeza..."
    mn "เวรเอ๊ย ปวดหัวชะมัด..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:381
translate english arc2_sakura_quest4_57c94009:

    # n "[MN], sin preguntarse si quiera porqué está en la casa de los Uchiha"
    n "[MN] เดินไปเข้าห้องน้ำโดยไม่ได้เอะใจเลยสักนิดว่าทำไมตัวเองถึงมาโผล่อยู่ที่บ้านตระกูลอุจิวะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:382
translate english arc2_sakura_quest4_043c6663:

    # n "Se dirige al baño a hacer sus necesidades"
    n "จัดการธุระส่วนตัวเสร็จเรียบร้อย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:383
translate english arc2_sakura_quest4_8b085fe2:

    # n "Para luego volver a la habitación de Sakura"
    n "แล้วก็เดินกลับมาที่ห้องของซากุระ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:386
translate english arc2_sakura_quest4_dc703e4d:

    # n "Cuando entra, se da cuenta que Sakura despertó, y está sentada en la cama"
    n "พอเดินเข้ามา เขาก็สังเกตเห็นว่าซากุระตื่นแล้วและกำลังนั่งอยู่บนเตียง"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:387
translate english arc2_sakura_quest4_14f3c891:

    # n "Sakura, mientras abre los ojos, ve que alguien está entrando a la habitación"
    n "ซากุระค่อยๆ ลืมตาขึ้นมาและเห็นใครบางคนกำลังเดินเข้ามาในห้อง"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:388
translate english arc2_sakura_quest4_e303a304:

    # sk "Mmm... ¿Eh?"
    sk "อืม... ฮะ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:392
translate english arc2_sakura_quest4_cd2c52d7:

    # sk "¿S-Sasuke?"
    sk "ซ-ซาสึเกะเหรอ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:393
translate english arc2_sakura_quest4_5dc344cb:

    # n "Sakura estaba ebria y confundida mientras contemplaba al hombre que tenía frente a ella"
    n "เนื่องจากความเมาและอาการมึนงง ซากุระจึงมองผู้ชายที่อยู่ตรงหน้า"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:394
translate english arc2_sakura_quest4_59a3026a:

    # sk "En su estado de embriaguez, confundió a [MN] con su esposo Sasuke, que se encontraba de viaje desde hace unos años"
    sk "ในสภาพที่เมามาย เธอเข้าใจผิดคิดว่า [MN] คือซาสึเกะสามีของเธอที่ออกเดินทางไปข้างนอกหลายปีแล้ว"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:395
translate english arc2_sakura_quest4_3c56c6f0:

    # mn "¿Sakura?"
    mn "ซากุระ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:397
translate english arc2_sakura_quest4_94c550d0:

    # sk "Que bueno verte... Bienvenido a casa..."
    sk "ดีใจจังที่ได้เจอคุณ... ยินดีต้อนรับกลับบ้านนะ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:398
translate english arc2_sakura_quest4_424e716f:

    # mn "Sakura... ¿D-Dónde estamos?"
    mn "ซากุระ... ท-ที่นี่ที่ไหนเนี่ย?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:399
translate english arc2_sakura_quest4_b1d09efa:

    # sk "¿Cómo que dónde estamos? *hip*"
    sk "ถามอะไรแปลกๆ ที่นี่ก็บ้านเราสิยะ *เอื๊อก*"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:400
translate english arc2_sakura_quest4_56c09acc:

    # sk "Estamos en casa..."
    sk "เราอยู่บ้านกัน..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:401
translate english arc2_sakura_quest4_2ce40dd1:

    # sk "Esta es nuestra habitación, ¿No lo recuerdas?"
    sk "นี่ห้องของเราไง จำไม่ได้เหรอ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:402
translate english arc2_sakura_quest4_26da2a6d:

    # mn "¿Nuestra habitación?"
    mn "ห้องของเราเนี่ยนะ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:403
translate english arc2_sakura_quest4_6d065051:

    # mn "Pero... ¿Yo no vivía en un apartamento? *hip*"
    mn "แต่... ปกติฉันไม่ได้อยู่ห้องพักเหรอเนี่ย? *เอื๊อก*"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:404
translate english arc2_sakura_quest4_99f04ba5:

    # sk "¿Qué dices? Claro que no"
    sk "พูดอะไรของคุณน่ะ? ไม่ใช่สักหน่อย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:406
translate english arc2_sakura_quest4_9a15ffb1:

    # n "Sakura se levanta de la cama"
    n "ซากุระลุกขึ้นจากเตียง"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:407
translate english arc2_sakura_quest4_f7cc6b0d:

    # n "Y se acerca a [MN]..."
    n "แล้วเดินเข้าไปหา [MN]..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:414
translate english arc2_sakura_quest4_746aca9e:

    # sk "Esta es nuestra habitación..."
    sk "นี่มันห้องของเรา..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:415
translate english arc2_sakura_quest4_e9baa419:

    # sk "Aquí hemos dormido juntos"
    sk "เราเคยนอนด้วยกันที่นี่"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:416
translate english arc2_sakura_quest4_0d9065ff:

    # sk "Y aquí, hemos tenido nuestras noches de pasión..."
    sk "และที่นี่ เราก็เคยมีค่ำคืนที่เร่าร้อนด้วยกัน..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:417
translate english arc2_sakura_quest4_b9970a70:

    # mn "Aquí... Hemos dormido... Y tenido noches de pasión"
    mn "ที่นี่... เราเคยนอน... แล้วก็มีค่ำคืนที่เร่าร้อน..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:418
translate english arc2_sakura_quest4_e7baa608:

    # mn "Noches... De pasión... ¿Nosotros?"
    mn "ค่ำคืน... อันเร่าร้อน... งั้นเหรอ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:419
translate english arc2_sakura_quest4_a2d996d9:

    # n "Y así..."
    n "แล้วจากนั้น..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:421
translate english arc2_sakura_quest4_82a8b95e:

    # n "Sakura, en su embriaguez, tomó a [MN] y lo atrajo hacia sus labios, creyendo que era su esposo"
    n "ในอาการเมามาย ซากุระคว้าตัว [MN] เข้ามาแล้วดึงเข้าไปประกบปากทันที โดยคิดว่าเขาคือสามีของเธอ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:422
translate english arc2_sakura_quest4_4806af48:

    # n "Aquella habitación había sido testigo de momentos de pasión y amor entre ella y su esposo, quien ahora estaba de viaje"
    n "ห้องนั้นเคยเป็นพยานในความเร่าร้อนและความรักระหว่างเธอกับสามีผู้ซึ่งตอนนี้กำลังเดินทางไปต่างบ้านต่างเมือง"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:423
translate english arc2_sakura_quest4_6de5d678:

    # n "Debe de ser un sueño, pensó [MN], mientras sentía la calidez de sus labios"
    n "นี่ต้องเป็นความฝันแน่ๆ [MN] คิดในใจขณะที่สัมผัสได้ถึงความอบอุ่นจากริมฝีปากของเธอ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:425
translate english arc2_sakura_quest4_c0f40fb1:

    # n "Pero cuando la lengua de Sakura salió disparada, rodeando la suya con una intensidad inesperada..."
    n "แต่ทว่า เมื่อลิ้นของซากุระสอดแทรกเข้ามาและตวัดเกี่ยวพันกับลิ้นของเขาอย่างเร่าร้อนเกินคาด..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:426
translate english arc2_sakura_quest4_5a212866:

    # n "[MN] supo que aquello no podía ser real"
    n "[MN] ก็รู้ได้ทันทีว่านี่ไม่ใช่เรื่องจริงแน่ๆ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:427
translate english arc2_sakura_quest4_f3c030d0:

    # n "Sakura nunca lo había besado de una manera tan apasionada..."
    n "ซากุระไม่เคยจูบเขาด้วยความเร่าร้อนขนาดนี้มาก่อน..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:428
translate english arc2_sakura_quest4_e7f61260:

    # n "Así que esto debe ser un sueño, volvió a pensar"
    n "งั้นนี่ก็คงเป็นความฝันสินะ เขากลับมาคิดอีกครั้ง"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:429
translate english arc2_sakura_quest4_3efd62f8:

    # n "Decidido a disfrutar del momento, se hundió más en las suaves caricias de Sakura"
    n "เมื่อตัดสินใจได้ว่าจะขอเพลิดเพลินกับช่วงเวลานี้ เขาก็ปล่อยตัวเคลิบเคลิ้มไปกับการสัมผัสอันอ่อนโยนของซากุระ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:430
translate english arc2_sakura_quest4_7b12580b:

    # n "Ambos se dejaron llevar, sumergiéndose en un beso hermoso y apasionado, perdiéndose en la ilusión de la noche"
    n "ทั้งคู่ผ่อนคลายร่างกายแล้วดำดิ่งลงไปในจูบอันแสนงดงามและเร่าร้อน ปล่อยให้ตัวเองหลงใหลไปกับภาพลวงตาแห่งค่ำคืนนี้"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:432
translate english arc2_sakura_quest4_f6354f22:

    # n "Pero de repente... Sakura dejó de besarlo dando un paso hacia atrás"
    n "แต่ทว่า... อยู่ๆ ซากุระก็หยุดจูบแล้วถอยหลังกลับไปหนึ่งก้าว"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:433
translate english arc2_sakura_quest4_0e298ae7:

    # n "Mientras [MN] observaba con asombro cómo Sakura se arrodillaba ante él"
    n "ในขณะที่ [MN] ยืนมองด้วยความประหลาดใจเมื่อซากุระคุกเข่าลงตรงหน้าเขา"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:438
translate english arc2_sakura_quest4_de0cff71:

    # n "Luego le sacó el pene de los pantalones y comenzó a chuparlo..."
    n "จากนั้นเธอก็รูดซิบกางเกงควักท่อนเอ็นของเขาออกมาแล้วเริ่มใช้ปากอมดูดมัน..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:439
translate english arc2_sakura_quest4_c218c5de:

    # n "La forma en que Sakura devoraba cada centímetro era hipnotizante"
    n "ลีลาที่ซากุระกลืนกินทุกตารางนิ้วนั้นช่างน่าหลงใหลเสียเหลือเกิน"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:440
translate english arc2_sakura_quest4_3c913843:

    # n "Sus manos se movían delicadamente sobre el pene de [MN]..."
    n "เรียวนิ้วของเธอเคล้นคลำท่อนเอ็นของ [MN] อย่างแผ่วเบา..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:441
translate english arc2_sakura_quest4_b123f53b:

    # n "Sus labios se deslizaban húmedos sobre la piel sensible..."
    n "ริมฝีปากฉ่ำน้ำของเธอลูบไล้ไปตามผิวหนังอันอ่อนไหว..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:442
translate english arc2_sakura_quest4_1f4dd4a7:

    # n "Dejando un rastro de calor y deseo a su paso"
    n "ทิ้งร่องรอยแห่งความร้อนรุ่มและความปรารถนาเอาไว้เบื้องหลัง"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:443
translate english arc2_sakura_quest4_cc0094a3:

    # n "Sus respiraciones se entrecortaron a medida que la pasión entre ellos crecía... "
    n "ลมหายใจของทั้งคู่เริ่มหอบกระชั้นเมื่อความเร่าร้อนระหว่างพวกเขาทวีความรุนแรงยิ่งขึ้น..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:444
translate english arc2_sakura_quest4_88cc5436:

    # n "Parecía tan irreal..."
    n "มันช่างดูเหมือนเรื่องที่ไม่ใช่ความจริงเอาเสียเลย..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:445
translate english arc2_sakura_quest4_054bf6b1:

    # n "Como un sueño del que ambos no quisieran despertar jamás..."
    n "ราวกับความฝันที่ไม่มีใครอยากตื่นขึ้นมาเลยสักคน..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:449
translate english arc2_sakura_quest4_5b095b5e:

    # n "Luego [MN] gimió suavemente, y sus dedos se enredaron en el cabello de Sakura..."
    n "จากนั้น [MN] ก็ครางเบาๆ พร้อมกับใช้นิ้วสอดพันไปกับเรือนผมของซากุระ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:450
translate english arc2_sakura_quest4_c9bf3df0:

    # n "Mientras se entregaba por completo a sus deliciosas caricias"
    n "ในขณะที่เขาปล่อยตัวปล่อยใจไปกับการสัมผัสอันแสนอร่อยของเธออย่างเต็มที่"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:451
translate english arc2_sakura_quest4_73dab763:

    # n "[MN] sintió cómo cada movimiento de Sakura lo llevaba más y más hacia el éxtasis"
    n "[MN] รู้สึกว่าทุกการเคลื่อนไหวของซากุระยิ่งโหมกระหน่ำพาเขาดิ่งลึกสู่ห้วงแห่งความสุขสมยิ่งขึ้นไปอีก"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:469
translate english sakura_blowjob1_cum_371c38f9:

    # n "Durante un largo momento, [MN] se perdió en las sensaciones que Sakura le estaba haciendo sentir"
    n "อยู่ชั่วครู่ใหญ่ที่ [MN] เคลิบเคลิ้มไปกับสัมผัสที่ซากุระมอบให้"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:470
translate english sakura_blowjob1_cum_8968db95:

    # n "Pero ya no podía soportarlo más"
    n "แต่ทว่าเขาเริ่มทนไม่ไหวอีกต่อไปแล้ว"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:471
translate english sakura_blowjob1_cum_ba8d1e93:

    # n "Sentía que ya había llegado al Clímax, y fue así como dejó salir un torrente de sus calidos líquidos en la boca de Sakura"
    n "เขารู้สึกเหมือนไปถึงจุดสุดยอดแล้ว และนั่นทำให้เขาปลดปล่อยของเหลวอุ่นร้อนทะลักเข้าไปในปากของซากุระ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:477
translate english sakura_blowjob1_cum_132c8562:

    # n "Sakura, aún sumida en su propio éxtasis, se tragó instintivamente todo el viscoso líquido"
    n "ซากุระที่ยังคงเคลิบเคลิ้มอยู่ในห้วงอารมณ์ของตัวเอง กลืนของเหลวข้นหนืดนั้นลงคอไปโดยสัญชาตญาณ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:478
translate english sakura_blowjob1_cum_a4772d74:

    # n "Al hacerlo, sus labios se apretaron alrededor de su pene, y ella pudo sentir cada vena palpitante, cada sacudida de su excitación"
    n "ในจังหวะนั้น ริมฝีปากของเธอกระชับแน่นรอบแก่นกายของเขา และเธอก็สัมผัสได้ถึงทุกเส้นเลือดที่เต้นตุบ ทุกการกระตุกจากความกำหนัด"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:479
translate english sakura_blowjob1_cum_fc6d38fc:

    # n "La sensación le produjo un escalofrío y, con un último movimiento, lo liberó de su boca"
    n "ความรู้สึกนั้นทำให้เธอเสียวซ่านไปทั้งตัว และด้วยการขยับครั้งสุดท้าย เธอก็ถอนปากออกจากแก่นกายของเขา"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:481
translate english sakura_blowjob1_cum_e108e3ca:

    # n "[MN] observó con asombro cómo ella abría la boca, revelando el semen que brillaba en su lengua"
    n "[MN] มองด้วยความทึ่งขณะที่เธออ้าปากออก เผยให้เห็นน้ำรักที่เปรอะเปื้อนเป็นประกายอยู่บนลิ้นของเธอ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:482
translate english sakura_blowjob1_cum_fedd63a0:

    # n "Su mirada llena de lujuria se encontró con la de él, mientras saboreaba los últimos restos de su placer compartido"
    n "สายตาที่เต็มไปด้วยความใคร่ของเธอสบกับเขา ในขณะที่เธอกำลังดื่มด่ำกับรสชาติสุดท้ายแห่งความสุขที่พวกเขามีร่วมกัน"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:483
translate english sakura_blowjob1_cum_043d5952:

    # n "Con un suspiro de satisfacción, Sakura se desplomó, con el pecho agitado mientras recuperaba el aliento"
    n "พร้อมกับเสียงถอนหายใจด้วยความสุข ซากุระทิ้งตัวลงนอน หน้าอกของเธอกระเพื่อมขึ้นลงขณะพยายามสูดลมหายใจเข้าปอด"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:484
translate english sakura_blowjob1_cum_4ba78f2b:

    # n "[MN], aún aturdido por la intensidad de su encuentro, la siguió, y su propio cuerpo se estrelló contra el suelo"
    n "[MN] ซึ่งยังคงมึนงงกับความรุนแรงของบทรักที่ผ่านมา ได้ทิ้งตัวลงนอนตามเธอ ร่างกายของเขาฟุบลงกับพื้น"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:487
translate english sakura_blowjob1_cum_1c37c860:

    # n "Allí tumbados, la habitación empezó a difuminarse lentamente a su alrededor..."
    n "ในขณะที่พวกเขานอนอยู่ตรงนั้น ห้องรอบตัวก็เริ่มพร่าเลือนทีละน้อย..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:488
translate english sakura_blowjob1_cum_084dadaf:

    # n "El mundo se desvanecía mientras sus corazones latían al unísono"
    n "โลกใบนี้ค่อยๆ เลือนหายไปพร้อมกับเสียงหัวใจของทั้งสองที่เต้นเป็นจังหวะเดียวกัน"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:493
translate english sakura_blowjob1_cum_a20cefa7:

    # "..."
    "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:494
translate english sakura_blowjob1_cum_db2b5608:

    # "-{b}Al día siguiente por la mañana{/a}-"
    "-{b}เช้าวันรุ่งขึ้น{/a}-"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:499
translate english sakura_blowjob1_cum_80f97f02:

    # n "[MN] abre los ojos..."
    n "[MN] ลืมตาขึ้น..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:500
translate english sakura_blowjob1_cum_6a7b1dfa:

    # mn "Mmm..."
    mn "อืม..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:501
translate english sakura_blowjob1_cum_d7f37bc8:

    # mn "¿Dónde estoy..."
    mn "ที่นี่... ที่ไหนเนี่ย..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:502
translate english sakura_blowjob1_cum_f3b53832:

    # n "[MN] se despertó con la luz del sol filtrándose a través de las cortinas"
    n "[MN] ตื่นขึ้นมาพร้อมกับแสงแดดที่ส่องลอดผ่านผ้าม่านเข้ามา"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:503
translate english sakura_blowjob1_cum_fb713212:

    # n "Se encontró en una habitación que no reconocía de inmediato, hasta que su mirada se posó en los detalles familiares..."
    n "เขาพบว่าตัวเองอยู่ในห้องที่ไม่คุ้นเคยในแวบแรก จนกระทั่งสายตาไปสะดุดเข้ากับรายละเอียดคุ้นตา..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:504
translate english sakura_blowjob1_cum_6b6cb4b4:

    # n "El jarrón con flores cuidadosamente arregladas y una foto enmarcada de Sakura y su familia en la mesa frente a él..."
    n "แจกันดอกไม้ที่จัดไว้อย่างประณีตและกรอบรูปครอบครัวของซากุระที่ตั้งอยู่บนโต๊ะเบื้องหน้า..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:506
translate english sakura_blowjob1_cum_768d05b0:

    # mn "(Esta es... La habitación de Sakura...)"
    mn "(นี่มัน... ห้องของซากุระนี่...)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:507
translate english sakura_blowjob1_cum_2bd35199:

    # mn "(Yo... ¿Qué hago aquí?... {b}¿Qué pasó ayer?{/a})"
    mn "(ฉัน... ฉันมาทำอะไรที่นี่เนี่ย... {b}เมื่อวานนี้มันเกิดอะไรขึ้นกันแน่?{/a})"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:508
translate english sakura_blowjob1_cum_3fe4afb7:

    # mn "(Agh... Que dolor de cabeza...)"
    mn "(ออฆ... ปวดหัวชะมัด...)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:510
translate english sakura_blowjob1_cum_30f58b2a:

    # n "De pronto, su mente nublada poco a poco recuperaba los recuerdos de la noche anterior"
    n "ทันใดนั้น สมองที่มึนงงของเขาก็เริ่มรำลึกความทรงจำของเมื่อคืนก่อนกลับมาทีละน้อย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:511
translate english sakura_blowjob1_cum_406024ad:

    # mn "(No... No puede ser...)"
    mn "(ไม่... เป็นไปไม่ได้น่า...)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:515
translate english sakura_blowjob1_cum_b9ff5bda:

    # n "Al darse la cuenta, vio a su lado Sakura dormida"
    n "เมื่อรู้ตัว เขาก็เห็นซากุระกำลังนอนหลับอยู่ข้างๆ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:516
translate english sakura_blowjob1_cum_c1f5b162:

    # n "Su cabeza latía de dolor por la resaca, y los recuerdos de la noche anterior llegaban a él por fragmentos"
    n "ศีรษะของเขาปวดตุบๆ จากอาการเมาค้าง และความทรงจำจากเมื่อคืนก็ไหลย้อนกลับมาเป็นฉากๆ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:517
translate english sakura_blowjob1_cum_aea6e4e7:

    # n "Recordó charlas con Sakura, risas, alcohól... Hasta que lo recordó todo..."
    n "เขานึกถึงตอนที่คุยกับซากุระ หัวเราะ ดื่มเหล้าด้วยกัน... จนกระทั่งจำเรื่องทุกอย่างได้ทั้งหมด..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:518
translate english sakura_blowjob1_cum_bfb05a30:

    # n "Recordó como ayer, vió la cara de Sakura con una expresión lujuriosa, mientras tenía su semen caliente en su lengua..."
    n "เขานึกออกว่าเมื่อวานนี้ เขาได้เห็นใบหน้าที่เต็มไปด้วยความใคร่ของซากุระ ตอนที่เธอกำลังมีน้ำอสุจิร้อนๆ ของเขาอยู่บนลิ้น..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:519
translate english sakura_blowjob1_cum_11b5020b:

    # n "[MN] estaba en Shock... Pues nunca creyó que vería con su propio ojo a Sakura de esa manera..."
    n "[MN] ช็อกไปเลย... เอาจริงๆ เขาไม่เคยคิดเลยว่าจะได้เห็นซากุระในสภาพแบบนี้ด้วยตาตัวเอง..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:524
translate english sakura_blowjob1_cum_7416f0ac:

    # mn "(Sakura...)"
    mn "(ซากุระ...)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:525
translate english sakura_blowjob1_cum_d89bf95c:

    # mn "(Tú... ¿Estás consciente de lo que hacías ayer?)"
    mn "(เธอ... รู้ตัวบ้างไหมเนี่ยว่าเมื่อวานทำอะไรลงไป?)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:528
translate english sakura_blowjob1_cum_a3aa55b5:

    # n "Poco después, Sakura comenzó a despertar"
    n "อีกสักพักต่อมา ซากุระก็เริ่มรู้สึกตัวตื่นขึ้น"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:529
translate english sakura_blowjob1_cum_d8c70c92:

    # sk "Mmmm..."
    sk "อืม..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:530
translate english sakura_blowjob1_cum_512c6ed8:

    # sk "¿Dónde estoy?"
    sk "ที่นี่... ที่ไหนเนี่ย?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:531
translate english sakura_blowjob1_cum_cd2c52d7:

    # sk "¿S-Sasuke?"
    sk "ซ-ซาสึเกะ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:532
translate english sakura_blowjob1_cum_d19b0b2b:

    # n "Abriendo los ojos mientras procesaba dónde estaba, al ver a [MN], su expresión se llenó de sorpresa y confusión."
    n "เธอค่อยๆ ลืมตาขึ้นในขณะที่กำลังประมวลผลว่าตัวเองอยู่ที่ไหน และพอเห็น [MN] สีหน้าของเธอก็เต็มไปด้วยความตกใจและความสับสน"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:535
translate english sakura_blowjob1_cum_ef0eba70:

    # sk "¿Q-QUÉ?"
    sk "อ-อะไรนะ?!"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:537
translate english sakura_blowjob1_cum_473b0ef1:

    # mn "(Maldición... ¿Qué hago ahora?)"
    mn "(เวรแล้ว... เอาไงต่อดีล่ะเนี่ย?)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:538
translate english sakura_blowjob1_cum_a80dfc17:

    # mn "(¿Recordará lo que pasó anoche?)"
    mn "(เธอจะจำเรื่องที่เกิดขึ้นเมื่อคืนได้ไหมนะ?)"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:540
translate english sakura_blowjob1_cum_8f6928a0:

    # mn "Sakura..."
    mn "ซากุระ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:541
translate english sakura_blowjob1_cum_68456455:

    # mn "Tu..."
    mn "เธอ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:542
translate english sakura_blowjob1_cum_3b2db0cd:

    # n "En ese momento se le abrumó la mente a Sakura..."
    n "ในตอนนั้นเอง สมองของซากุระก็แทบจะรับไม่ไหว..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:543
translate english sakura_blowjob1_cum_025dd035:

    # n "Ella recuerda lo que pasó anoche, pero... Ella creía que le hizo eso a su esposo Sasuke..."
    n "เธอนึกถึงเรื่องที่เกิดขึ้นเมื่อคืนได้ แต่... เธอกลับคิดว่าเธอทำแบบนั้นกับซาสึเกะผู้เป็นสามี..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:544
translate english sakura_blowjob1_cum_a36d1fb5:

    # sk "Anoche... Tú y yo... ¿Pasó algo?"
    sk "เมื่อคืน... ฉันกับเธอ... มีอะไรเกิดขึ้นงั้นเหรอ?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:545
translate english sakura_blowjob1_cum_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:546
translate english sakura_blowjob1_cum_ae40cee3:

    # mn "Tu... ¿Recuerdas lo que pasó?"
    mn "เธอ... จำได้ไหมว่าเกิดอะไรขึ้นบ้าง?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:547
translate english sakura_blowjob1_cum_639b733f:

    # sk "..."
    sk "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:550
translate english sakura_blowjob1_cum_c9919603:

    # n "Sakura, al darse cuenta de lo que le hizo a [MN] se levantó del suelo"
    n "ซากุระพอจะนึกออกว่าเธอทำอะไรลงไปกับ [MN] ก็ลุกพรวดขึ้นมาจากเตียง"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:551
translate english sakura_blowjob1_cum_21ef6782:

    # n "A su vez, [MN] también hizo lo mismo"
    n "ในขณะเดียวกัน [MN] ก็ลุกขึ้นตามเหมือนกัน"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:560
translate english sakura_blowjob1_cum_639b733f_1:

    # sk "..."
    sk "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:561
translate english sakura_blowjob1_cum_8a352ae1:

    # n "El silencio se hizo pesado mientras ambos intentaban procesar lo ocurrido, Sakura sentía una gran confusión, y con el dolor de cabeza por la resaca no podía pensar bien"
    n "ความเงียบเข้าปกคลุมในขณะที่ทั้งสองต่างพยายามประมวลเรื่องที่เกิดขึ้น ซากุระรู้สึกสับสนมาก บวกกับอาการปวดหัวจากอาการเมาค้างทำให้เธอคิดอะไรไม่ออกเลย"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:565
translate english sakura_blowjob1_cum_0f421ef5:

    # sk "[MN]... No mencionarémos esto a nadie..."
    sk "[MN]... เรื่องนี้เราจะไม่บอกใครนะ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:566
translate english sakura_blowjob1_cum_79d27e49:

    # sk "Lo que pasó ayer... Quedará entre nosotros..."
    sk "เรื่องที่เกิดขึ้นเมื่อวาน... จะเก็บไว้เป็นความลับระหว่างเรา..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:567
translate english sakura_blowjob1_cum_5502cecb:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:569
translate english sakura_blowjob1_cum_d6701bec:

    # mn "Si..."
    mn "อืม..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:570
translate english sakura_blowjob1_cum_c28bb6df:

    # mn "Espero que... Lo que haya pasado no afecte nuestra relación"
    mn "ผมหวังว่า... เรื่องที่เกิดขึ้นมันจะไม่ส่งผลกระทบกับความสัมพันธ์ของเรานะ"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:572
translate english sakura_blowjob1_cum_639b733f_2:

    # sk "..."
    sk "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:577
translate english sakura_blowjob1_cum_f3150200:

    # sk "N-No te preocupes... Todo está bien..."
    sk "ไ-ไม่ต้องห่วง... ทุกอย่างปกติดี..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:578
translate english sakura_blowjob1_cum_13dde376:

    # sk "Ahora, ¿Puedes dejarme sola? Tengo que prepararme para ir a trabajar..."
    sk "ตอนนี้... ช่วยออกไปก่อนได้ไหม? ฉันต้องเตรียมตัวไปทำงานแล้ว..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:579
translate english sakura_blowjob1_cum_c0981d4c:

    # mn "Oh, si, por supuesto"
    mn "อ่า ได้สิ แน่นอนอยู่แล้ว"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:580
translate english sakura_blowjob1_cum_3c0df37b:

    # mn "Entonces..."
    mn "งั้น... คร่าวๆ ก็..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:581
translate english sakura_blowjob1_cum_2063832a:

    # mn "¿Te veo en los Exámenes Chunin?"
    mn "แล้วผมจะได้เจอคุณที่งานสอบจูหนินไหม?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:582
translate english sakura_blowjob1_cum_3595d649:

    # sk "Si, ahí estaré..."
    sk "อืม ฉันจะไปที่นั่น..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:584
translate english sakura_blowjob1_cum_f895f50b:

    # mn "Bien, entonces me retiro..."
    mn "งั้นผมขอตัวก่อนนะ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:585
translate english sakura_blowjob1_cum_1239b7ae:

    # mn "Yo... Lamento todos los inconvenientes..."
    mn "ผม... ต้องขอโทษด้วยสำหรับเรื่องวุ่นวายทั้งหมด..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:586
translate english sakura_blowjob1_cum_10bfcfeb:

    # sk "Ve con cuidado..."
    sk "ดูแลตัวเองด้วย..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:590
translate english sakura_blowjob1_cum_00321501:

    # n "[MN] sale de la habitación"
    n "[MN] เดินออกจากห้องไป"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:591
translate english sakura_blowjob1_cum_5dc6cee8:

    # n "Dejando sola a Sakura para prepararse para ir a trabajar"
    n "ปล่อยให้ซากุระอยู่ตามลำพังเพื่อเตรียมตัวไปทำงาน"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:592
translate english sakura_blowjob1_cum_ce750eba:

    # n "Pero Sakura..."
    n "แต่ทว่าซากุระ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:593
translate english sakura_blowjob1_cum_eb84e7dc:

    # n "Ella no podía dejar de pensar en lo sucedido..."
    n "เธอไม่สามารถหยุดคิดถึงเรื่องที่เกิดขึ้นได้เลย..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:594
translate english sakura_blowjob1_cum_c129feff:

    # n "Había sido tanto tiempo desde que alguien había logrado despertar en ella sentimientos tan intensos y confusos"
    n "นานมากแล้วที่ไม่มีใครสามารถปลุกเร้าความรู้สึกที่รุนแรงและสับสนในตัวเธอได้ขนาดนี้"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:597
translate english sakura_blowjob1_cum_204a55fb:

    # sk "¡Aaah!" with vpunch
    sk "อ๊า!" with vpunch

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:599
translate english sakura_blowjob1_cum_2888aa29:

    # sk "Maldición... ¿Qué carajos hice?"
    sk "ให้ตายสิ... ฉันทำบ้าอะไรลงไปเนี่ย?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:601
translate english sakura_blowjob1_cum_82f9f0fc:

    # sk "¿Con qué cara lo veré ahora?"
    sk "แล้วฉันจะกล้าสู้หน้าเขาได้ยังไงล่ะเนี่ย?"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:603
translate english sakura_blowjob1_cum_639b733f_3:

    # sk "..."
    sk "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:609
translate english sakura_blowjob1_cum_0d47deac:

    # sk "Ya me había acostumbrado a estar sola desde que Sasuke partió..."
    sk "ฉันชินกับการอยู่คนเดียวมาตั้งแต่ซาสึเกะจากไปแล้วแท้ๆ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:610
translate english sakura_blowjob1_cum_6c27bce8:

    # sk "Pero desde que [MN] comenzó a visitarme... He sentido este raro sentimiento..."
    sk "แต่ตั้งแต่ที่ [MN] เริ่มมาหาฉัน... ความรู้สึกแปลกๆ นี่มันก็เกิดขึ้น..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:611
translate english sakura_blowjob1_cum_b20ef2c4:

    # sk "Siempre hubo algo en él que me recuerda a Sasuke..."
    sk "ในตัวเขามักจะมีบางอย่างที่ทำให้ฉันนึกถึงซาสึเกะอยู่เสมอ..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:612
translate english sakura_blowjob1_cum_1f54bf11:

    # sk "Pero..."
    sk "แต่ว่า..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:616
translate english sakura_blowjob1_cum_24edb44d:

    # sk "Ahora, su mirada irradia un brillo mucho más fuerte"
    sk "ตอนนี้ สายตาของเขามีประกายที่เจิดจ้ากว่าเดิมมาก"

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:617
translate english sakura_blowjob1_cum_5ccf1a92:

    # sk "Ahora es diferente..."
    sk "ตอนนี้เขาเปลี่ยนไปแล้ว..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:618
translate english sakura_blowjob1_cum_639b733f_4:

    # sk "..."
    sk "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:619
translate english sakura_blowjob1_cum_0c99b6c1:

    # sk "Ya no es el niño indefenso de antes..."
    sk "เขาไม่ใช่เด็กน้อยที่พึ่งพาใครไม่ได้เหมือนเมื่อก่อนอีกต่อไปแล้ว..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:626
translate english sakura_blowjob1_cum_a20cefa7_1:

    # "..."
    "..."

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:490
translate english sakura_blowjob1_cum_e7968ec9:

    # n "Tumbados en la habitación, empezó a difuminarse lentamente a su alrededor..."
    n "ท่ามกลางแสงสว่างในห้องที่ค่อยๆ เลือนหายไปช้าๆ..."

# TODO: Translation updated at 2024-12-20 07:52

# game/scripts/History/SecundaryStory/Sakura/Arco2/arc2_sakura_quest4.rpy:120
translate english arc2_sakura_quest4_c3497354:

    # sk "¿Porqué estás llorando?"
    sk "เธอร้องไห้ทำไมเนี่ย?"
