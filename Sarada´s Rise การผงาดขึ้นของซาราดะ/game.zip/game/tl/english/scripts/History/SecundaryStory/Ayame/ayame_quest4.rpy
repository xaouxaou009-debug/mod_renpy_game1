

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:14
translate english ayame_quest4_b21141b6:

    # ay "Aquí está mi ninja favorito"
    ay "นั่นไง นินจาคนโปรดของฉันมาแล้ว"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:17
translate english ayame_quest4_95788faf:

    # mn "Hola Ayame"
    mn "ว่าไง อายาเมะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:20
translate english ayame_quest4_37f3f970:

    # ay "..."
    ay "..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:23
translate english ayame_quest4_29f61c87:

    # ay "*Ejem* Aquí está mi ninja favorito"
    ay "*แฮ่ม* นี่ไงล่ะ นินจาคนโปรดของฉัน"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:26
translate english ayame_quest4_0b9bb3cc:

    # mn "Eeh, si... Hola Ayame"
    mn "หา อ๋อ... ว่าไง อายาเมะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:29
translate english ayame_quest4_2a5b6b43:

    # ay "Debes practicar más como saludar a una chica..."
    ay "นายควรไปฝึกวิธีทักทายผู้หญิงให้มากกว่านี้นะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:32
translate english ayame_quest4_38c86c8e:

    # mn "¿Qué?"
    mn "อะไรนะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:35
translate english ayame_quest4_74e33e14:

    # ay "Olvídao..."
    ay "ช่างเถอะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:37
translate english ayame_quest4_0bc262fd:

    # ay "¿Quieres ir directamente al callejón?"
    ay "อยากตรงไปที่ตรอกนั้นเลยไหมล่ะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:40
translate english ayame_quest4_242ea2da:

    # mn "¿Tan rápido?"
    mn "เร็วขนาดนี้เลยเหรอ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:43
translate english ayame_quest4_a9ba27b7:

    # ay "¿No quieres?"
    ay "ไม่อยากไปงั้นเหรอ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:46
translate english ayame_quest4_36e13500:

    # mn "Ah, si, es solo que..."
    mn "อ่า ใช่ คือว่า..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:49
translate english ayame_quest4_e682f388:

    # ay "Bien, entonces vámonos"
    ay "งั้นก็ไปกันเถอะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:52
translate english ayame_quest4_e9f246ce:

    # n "Sigues a Ayame hasta el callejón"
    n "คุณเดินตามอายาเมะไปที่ตรอก"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:68
translate english ayame_quest4_2c3cdb6b:

    # ay "Bien, ya estando aquí podemos empezar"
    ay "เอาล่ะ ในเมื่อเรามาถึงกันแล้ว ก็เริ่มกันเลยดีกว่า"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:71
translate english ayame_quest4_89ff8ced:

    # mn "¿Qué haremos hoy?"
    mn "วันนี้เราจะทำอะไรกันเหรอ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:74
translate english ayame_quest4_c616adf0:

    # ay "Seguiremos en dónde lo dejamos en la sesión anterior"
    ay "เราจะต่อจากสิ่งที่เราค้างไว้ในรอบก่อน"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:76
translate english ayame_quest4_111c6d0a:

    # ay "Hiciste algo muy interesante"
    ay "นายทำอะไรที่น่าสนใจเอามากๆ เลยล่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:79
translate english ayame_quest4_d9584fd7:

    # mn "La sesión en la que también me mostraste algo interesante..."
    mn "ก็รอบเดียวกับที่เธอแสดงอะไรน่าสนใจให้ฉันดูเหมือนกันนี่นะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:82
translate english ayame_quest4_db77c318:

    # ay "Alguien está aprendiendo a usar el tono correcto..."
    ay "แหม เริ่มรู้จักใช้โทนเสียงให้ถูกจังหวะแล้วสินะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:85
translate english ayame_quest4_9f4d9da2:

    # mn "¿Cuál es el tono correcto?"
    mn "โทนเสียงที่ถูกต้องเนี่ย มันเป็นยังไงเหรอ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:88
translate english ayame_quest4_67c1e208:

    # ay "El tono de voz perfecto para la seducción..."
    ay "ก็โทนเสียงที่สมบูรณ์แบบสำหรับการยั่วเย้ายังไงล่ะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:91
translate english ayame_quest4_f67e814c:

    # mn "Aaah, entiendo..."
    mn "อ่าา ฉันเข้าใจแล้ว...ซะที่ไหนล่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:94
translate english ayame_quest4_82afa52a:

    # mn "Entonces, ¿Qué harémos hoy?"
    mn "งั้นวันนี้เราจะทำอะไรกันล่ะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:97
translate english ayame_quest4_1c396898:

    # ay "Hoy quiero enseñarte algo"
    ay "วันนี้น่ะฉันอยากจะให้นายดูอะไรหน่อย"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:100
translate english ayame_quest4_545dfdb7:

    # mn "¿Qué cosa?"
    mn "อะไรเหรอ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:103
translate english ayame_quest4_f0dd2677:

    # ay "Te enseñaré a como hacer correctamente lo que intentaste hacer ayer"
    ay "เดี๋ยวฉันจะสอนวิธีทำสิ่งที่นายพยายามจะทำเมื่อวานให้มันถูกต้องเอง"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:105
translate english ayame_quest4_6c683390:

    # ay "Verás..."
    ay "ดูนี่นะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:111
translate english ayame_quest4_2ff791f8:

    # ay "Te faltó tocar la entrepierna..."
    ay "นายพลาดเป้าตรงเป้ากางเกงไปนิดนะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:112
translate english ayame_quest4_6d6d752f:

    # mn "Oh, santo cielo..."
    mn "โอ้ ให้ตายสิ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:113
translate english ayame_quest4_90ab2bc6:

    # ay "¿Te gusta?"
    ay "ชอบไหมล่ะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:114
translate english ayame_quest4_f67f6c0f:

    # mn "Aah, sí..."
    mn "อ่า ใช่... ดีมากเลย..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:115
translate english ayame_quest4_08b71204:

    # ay "Bien, ahora contéstame una cosa..."
    ay "เอาล่ะ บอกอะไรฉันหน่อยสิ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:116
translate english ayame_quest4_a55cba82:

    # ay "¿Sí saco tu pene y comienzo a frotar mi mano con él te gustaría aún más?"
    ay "ถ้าฉันหยิบไอ้จู๋ของนายออกมาแล้วเอามือรูดมัน นายจะยิ่งชอบมากกว่าเดิมไหมล่ะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:117
translate english ayame_quest4_6e172b10:

    # mn "Seguramente sí..."
    mn "ชอบอยู่แล้วล่ะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:118
translate english ayame_quest4_949dc4d4:

    # ay "Intentémoslo..."
    ay "งั้นลองดูหน่อยสิ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:119
translate english ayame_quest4_a7ca5003:

    # n "Ayame saca tu pene del pantalón y comienza a mover su mano sobre él"
    n "อายาเมะควักท่อนเอ็นของคุณออกมาจากกางเกงแล้วเริ่มใช้มือสาวขึ้นลง"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:124
translate english ayame_quest4_58bd5532:

    # ay "Vya... Que bien dotado estás..."
    ay "ว้าว... ของนายเนี่ยใหญ่โตเอาเรื่องเลยนะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:125
translate english ayame_quest4_7c01bd75:

    # mn "Joder, Ayame..."
    mn "ซี๊ด อายาเมะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:126
translate english ayame_quest4_fb7256e4:

    # mn "E-Eso se siente muy bien..."
    mn "ม-มันรู้สึกดีสุดๆ เลย..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:127
translate english ayame_quest4_aaf7f3c8:

    # ay "El objetivo de esto es llevarte al punto máximo de satisfacción..."
    ay "เป้าหมายของเรื่องนี้คือการทำให้นายไปถึงจุดสุดยอดแห่งความพึงพอใจ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:128
translate english ayame_quest4_2635cd5b:

    # ay "Siempre tienes que hacer venir a tu pareja para desmotrarle que la quieres..."
    ay "เธอต้องทำให้อีกฝ่ายเสร็จสมเพื่อแสดงให้เห็นว่าเธอรักเขาเสมอนะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:129
translate english ayame_quest4_62952e92:

    # mn "Yo te quiero mucho Ayame..."
    mn "ฉันรักเธอมากๆ เลยนะ อายาเมะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:130
translate english ayame_quest4_ade640e0:

    # ay "¿Me quieres?"
    ay "รักฉันงั้นเหรอ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:131
translate english ayame_quest4_33956230:

    # mn "Sí y quiero demostrartelo..."
    mn "รักสิ แล้วฉันก็อยากจะพิสูจน์ให้ดูด้วย..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:132
translate english ayame_quest4_3bbb5695:

    # ay "En ese caso..."
    ay "ถ้าอย่างนั้นล่ะก็..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:133
translate english ayame_quest4_2bb29bbd:

    # ay "Bien, entonces demuéstramelo"
    ay "งั้นก็แสดงให้ฉันเห็นสิ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:134
translate english ayame_quest4_59f7333a:

    # ay "Sí lo haces bien, te daré otra recompensa..."
    ay "ถ้านายทำได้ดีล่ะก็ ฉันจะมีรางวัลให้อีกอย่างนะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:135
translate english ayame_quest4_53be5ad6:

    # mn "(¿Como podría negarme a una petición así?)"
    mn "(ฉันจะปฏิเสธคำขอแบบนั้นลงได้ยังไงล่ะ?)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:140
translate english ayame_quest4_d569b855:

    # n "[MN] le baja las bragas a Ayame"
    n "[MN] ดึงกางเกงในของอายาเมะลง"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:142
translate english ayame_quest4_5bfd7256:

    # ay "Te guiaré..."
    ay "เดี๋ยวฉันจะนำทางให้เอง..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:143
translate english ayame_quest4_880c3f4a:

    # ay "Empieza masajeando el clítoris"
    ay "เริ่มจากการนวดคลิตอริสก่อนเลย"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:144
translate english ayame_quest4_bcf21bfa:

    # ay "Siempre tienes que empezar lento..."
    ay "เธอต้องเริ่มจากช้าๆ เสมอ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:148
translate english ayame_quest4_e4a26eb5:

    # mn "¿Así?"
    mn "แบบนี้เหรอ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:149
translate english ayame_quest4_a4c5e638:

    # ay "Sí, justo así..."
    ay "ใช่ แบบนั้นแหละ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:150
translate english ayame_quest4_653b1311:

    # ay "Sólo debes ir rápido cuando ella te lo pida"
    ay "นายควรจะเร่งจังหวะก็ต่อเมื่อเธอขอให้ทำเท่านั้นแหละนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:151
translate english ayame_quest4_4635d511:

    # mn "Está muy mojado"
    mn "แฉะสุดๆ เลยแฮะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:152
translate english ayame_quest4_9bcfdffc:

    # ay "*jadeo* E-Eso demuestra que lo haces bien..."
    ay "*หอบ* น-นั่นแสดงว่านายทำถูกวิธีแล้ว..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:153
translate english ayame_quest4_d8a250e1:

    # ay "Cuando la vagina está en ese estado puedes empezar a meter tus dedos"
    ay "พอแคมเปียกได้ที่แล้ว นายก็เริ่มสอดนิ้วเข้าไปได้เลย"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:154
translate english ayame_quest4_a6ec98e3:

    # mn "¿Puedo hacerlo ahora?"
    mn "ตอนนี้เลยได้ไหม?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:155
translate english ayame_quest4_074a1b86:

    # ay "*jadeo* S-Solo hazlo..."
    ay "*หอบ* ส-สอดเข้ามาเลย..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:162
translate english ayame_quest4_17fda519:

    # ay "¡A-Aah!"
    ay "อ๊า-อ๊าห์!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:163
translate english ayame_quest4_5e888e5b:

    # ay "J-Justo así... *jadeo*"
    ay "อ-แบบนั้นแหละ... *หอบ*"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:164
translate english ayame_quest4_5cab040d:

    # mn "¿Lo estoy haciendo bien?"
    mn "ฉันทำถูกวิธีใช่ไหม?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:165
translate english ayame_quest4_4006e114:

    # ay "¿Eh?"
    ay "หือ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:166
translate english ayame_quest4_fcd41eb7:

    # ay "¡C-Claro que lo estás haciendo bien! Estás volviéndome loca..."
    ay "ก-ก็ต้องถูกอยู่แล้วสิ! นายทำฉันจะบ้าตายอยู่แล้วนะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:167
translate english ayame_quest4_6006d379:

    # mn "Se siente tan cálido y mojado..."
    mn "ข้างในทั้งอุ่นทั้งแฉะเลย..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:168
translate english ayame_quest4_a4a7e008:

    # ay "N-No describas como se siente, es vergonzoso..."
    ay "ม-ไม่ต้องมาบรรยายความรู้สึกได้ไหม มันน่าอายนะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:169
translate english ayame_quest4_08d4fc11:

    # mn "Pensé que para este punto ya no sentirías vergüenza conmigo"
    mn "นึกว่าเธอจะไม่เขินเวลากับฉันแล้วซะอีกนะเนี่ย"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:170
translate english ayame_quest4_e3c2dca1:

    # ay "¡Ah, solo guarda silencio y besame"
    ay "่าห์ เงียบแล้วก็จูบฉันซะทีสิ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:178
translate english ayame_quest4_95b03c03:

    # ay "[MN]..."
    ay "[MN]..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:179
translate english ayame_quest4_0711ca67:

    # mn "Ayame..."
    mn "อายาเมะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:180
translate english ayame_quest4_789f2e08:

    # ay "Se siente tan bien..."
    ay "รู้สึกดีสุดๆ เลย..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:181
translate english ayame_quest4_1bcc55a4:

    # ay "Tanto así que estoy a punto de..."
    ay "รู้สึกดีจนฉันแทจะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:182
translate english ayame_quest4_547f6e1d:

    # ay "¡Ah...!"
    ay "อ๊า...!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:188
translate english ayame_quest4_6aeefa3c:

    # ay "¡Aaaaaahh!"
    ay "อ่าาาาาห์!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:190
translate english ayame_quest4_94433e68:

    # ay "¡Q-Qué rico!"
    ay "ฟ-ฟินสุดๆ ไปเลย!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:191
translate english ayame_quest4_9363a79e:

    # ay "¡Mis piernas... Mis piernas t-tiemblan!"
    ay "ขาของฉัน... ขาสั่นไปหมดแล้วเนี่ย!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:194
translate english ayame_quest4_a20cefa7:

    # "..."
    "..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:195
translate english ayame_quest4_f227d721:

    # n "Minutos después"
    n "หลายนาทีต่อมา"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:203
translate english ayame_quest4_82332daf:

    # mn "¿Lo hice bien?"
    mn "ฉันทำได้ดีไหมล่ะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:206
translate english ayame_quest4_e6209a49:

    # ay "¡Estuvo increíble!"
    ay "ยอดเยี่ยมมากเลยต่างหากล่ะ!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:208
translate english ayame_quest4_20ae814e:

    # ay "Definitivamente te has ganado una recompensa"
    ay "นายสมควรได้รับรางวัลแล้วล่ะนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:211
translate english ayame_quest4_d528e811:

    # mn "¿Qué es esta vez?"
    mn "คราวนี้คืออะไรเหรอ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:214
translate english ayame_quest4_007178c4:

    # ay "Ya que hiciste bien tu parte"
    ay "ในเมื่อนายทำหน้าที่ของตัวเองได้ดีแล้ว"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:216
translate english ayame_quest4_74f0747d:

    # ay "Ahora me toca a mí..."
    ay "คราวนี้ก็ตาฉันบ้างล่ะนะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:218
translate english ayame_quest4_a0b17b15:

    # ay "Sólo quédate quieto y déjame el resto a mí"
    ay "ก็นอนนิ่งๆ แล้วปล่อยที่เหลือให้ฉันจัดการเองก็พอ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:221
translate english ayame_quest4_de89add6:

    # mn "Está bien..."
    mn "ก็ได้..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:225
translate english ayame_quest4_b086bd53:

    # n "Ayame se agacha y saca el pene de [MN]"
    n "อายาเมะก้มตัวลงแล้วหยิบแก่นกายของ [MN] ออกมา"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:232
translate english ayame_quest4_a887378e:

    # n "Y luego lo introduce en su boca"
    n "จากนั้นเธอก็อมมันเข้าไปในปาก"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:233
translate english ayame_quest4_07597b2f:

    # mn "¡Oh, mierda!"
    mn "อื้อหือ ซี้ด!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:237
translate english ayame_quest4_1050cc41:

    # n "Lentamente, comienza a chuparlo"
    n "จากนั้นเธอค่อยๆ เริ่มใช้ปากดูดกลืนมัน"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:238
translate english ayame_quest4_30be2621:

    # mn "(Realmente está chupando mi pene...)"
    mn "(เธอมันแก่นกายของฉันจริงๆ ด้วย...)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:241
translate english ayame_quest4_69b9265c:

    # n "Ayame comienza hacerlo más rápido"
    n "อายาเมะเริ่มขยับเร็วขึ้นเรื่อยๆ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:242
translate english ayame_quest4_f723d061:

    # mn "¡Mierdaaa...!"
    mn "ให้ตายสี้...!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:243
translate english ayame_quest4_7e2df194:

    # mn "¡Qué bien se siente en tu boca, joder!"
    mn "เสียวปากชะมัดเลย ให้ตายสิ!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:244
translate english ayame_quest4_db8385af:

    # ay "Puedes venirte cuando quieras"
    ay "นายจะแตกเมื่อไหร่ก็ได้เลยนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:245
translate english ayame_quest4_8b24284d:

    # ay "Pienso tomarme hasta la última gota"
    ay "ฉันตั้งใจจะกินให้หมดทุกหยดเลยล่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:246
translate english ayame_quest4_6cfc4be7:

    # ay "Así qué hazlo si gustas"
    ay "งั้นก็ทำเลยสิถ้าชอบน่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:247
translate english ayame_quest4_3e1bedfe:

    # mn "Sí continuas así pronto yo..."
    mn "ถ้าเธอทำแบบนี้ต่อไปเรื่อยๆ ฉัน..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:248
translate english ayame_quest4_3bb7e65c:

    # mn "¡Me vengooo!"
    mn "ฉันจะแตกแล้ว!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:258
translate english ayame_quest4_06a212da:

    # n "Ayame se toma hasta la última gota de semen"
    n "อายาเมะกลืนน้ำอสุจิลงไปจนหยดสุดท้าย"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:259
translate english ayame_quest4_455d58bd:

    # n "Luego de eso se levanta"
    n "หลังจากนั้นเธอก็ลุกขึ้นยืน"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:265
translate english ayame_quest4_2ad839f4:

    # mn "*suspiro* Eso estuvo increíble..."
    mn "*ถอนหายใจ* สุดยอดจริงๆ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:267
translate english ayame_quest4_b91d82f8:

    # mn "Se sintió demasiado bien..."
    mn "มันฟินจนแทบทนไม่ไหว..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:270
translate english ayame_quest4_eda77b4e:

    # ay "Me alegra que te gustara"
    ay "ดีใจที่ชอบนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:273
translate english ayame_quest4_ee373d88:

    # ay "Aunque debo decirte que poco más te puedo enseñar a partir de aquí"
    ay "แต่ฉันต้องบอกไว้ก่อนนะว่า จากนี้ไปฉันคงสอนอะไรนายเพิ่มได้อีกไม่มากเท่าไหร่แล้วล่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:276
translate english ayame_quest4_7f8b9229:

    # mn "¿A qué te refieres?"
    mn "หมายความว่ายังไงเหรอ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:278
translate english ayame_quest4_b3d617d7:

    # mn "¿Dices que esta fue la última lección?"
    mn "จะบอกว่านี่คือบทเรียนสุดท้ายแล้วงั้นเหรอ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:281
translate english ayame_quest4_bca3a731:

    # ay "No, no he dicho eso"
    ay "เปล่า ฉันไม่ได้หมายความแบบนั้นซะหน่อย"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:283
translate english ayame_quest4_bafb4046:

    # ay "Sin embargo, puede que la siguiente sesión si sea el caso..."
    ay "เพียงแต่ว่า... ในเซสชันหน้าน่าจะเป็นแบบนั้นน่ะนะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:286
translate english ayame_quest4_1bb34dac:

    # mn "Entiendo..."
    mn "เข้าใจแล้ว..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:289
translate english ayame_quest4_7b9aef90:

    # ay "Oye, eso no significa que no podremos seguir poniendo en práctica lo que aprendiste"
    ay "เฮ้ นั่นไม่ได้แปลว่าเราจะเอาสิ่งที่นายเรียนรู้ไปฝึกต่อกันไม่ได้ซะหน่อย"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:291
translate english ayame_quest4_d033fa24:

    # ay "De hecho tengo algo en mente... Sé que te gustará"
    ay "อันที่จริงฉันมีแผนอยู่ในใจแล้วล่ะ... รู้ว่านายต้องชอบแน่ๆ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:294
translate english ayame_quest4_545dfdb7_1:

    # mn "¿Qué cosa?"
    mn "เรื่องอะไรเหรอ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:297
translate english ayame_quest4_53fe9fd5:

    # ay "Es una sorpresa, no puedo decírtelo, de momento creo que ya tenemos que irnos"
    ay "มันคือเซอร์ไพรส์ บอกตอนนี้ไม่ได้หรอก ตอนนี้ฉันว่าเราต้องไปกันก่อนดีกว่า"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:299
translate english ayame_quest4_763a782d:

    # ay "Ya es un poco tarde"
    ay "นี่ก็ดึกมากแล้วด้วย"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:301
translate english ayame_quest4_a9522eda:

    # ay "Recuerda que también debo de levantarme temprano para trabajar"
    ay "อย่าลืมสิว่าฉันต้องตื่นไปทำงานแต่เช้าเหมือนกันนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:304
translate english ayame_quest4_ec4af495:

    # mn "Lo sé, no te preocupes"
    mn "รู้แล้วน่า ไม่ต้องห่วงหรอก"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:306
translate english ayame_quest4_82028729:

    # mn "Nos vemos luego entonces"
    mn "งั้นไว้เจอกันนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest4.rpy:310
translate english ayame_quest4_2b59152a:

    # ay "Adiosito"
    ay "ไว้เจอกันจ่ะ"
