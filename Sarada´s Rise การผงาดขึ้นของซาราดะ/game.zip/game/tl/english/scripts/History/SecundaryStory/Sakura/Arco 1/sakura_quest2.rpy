

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:8
translate english sakura_quest2_1_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:10
translate english sakura_quest2_1_12e12f3c:

    # mn "Hace mucho que no vengo por aquí..."
    mn "ไม่ได้มาที่นี่ตั้งนานแล้วนะ..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:12
translate english sakura_quest2_1_da97881a:

    # mn "Aunque, ahora que lo pienso... No sé donde está Sakura..."
    mn "แต่จะว่าไป... ฉันยังไม่รู้เลยว่าคุณซากุระอยู่ที่ไหน..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:17
translate english sakura_quest2_1_7bca1642:

    # hn "Buen día, ¿Puedo ayudarlo en algo?"
    hn "อรุณสวัสดิ์ค่ะ มีอะไรให้ฉันช่วยไหมคะ?"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:20
translate english sakura_quest2_1_5de2c748:

    # mn "Oh, si... ¿Sabe dónde se encuentra la señorita Sakura?"
    mn "อ๋อ ครับ... พอจะรู้ไหมครับว่าคุณซากุระอยู่ที่ไหน?"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:23
translate english sakura_quest2_1_9d544cac:

    # hn "¿Tiene una cita con ella?"
    hn "มีนัดกับเธอไว้เหรอคะ?"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:26
translate english sakura_quest2_1_61cc00ed:

    # mn "Eh, no... Estoy aquí porque me ofreció un trabajo como su asistente"
    mn "เอ๋ เปล่าครับ... ที่ผมมาเพราะเธอเสนอให้ผมมาทำงานเป็นผู้ช่วยน่ะครับ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:29
translate english sakura_quest2_1_1bc73811:

    # hn "Oh, entiendo..."
    hn "อ๋อ เข้าใจแล้วค่ะ..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:32
translate english sakura_quest2_1_79d3e66f:

    # hn "La señorita Sakura se encuentra en el cuarto piso, use el ascensor y siguiendo el pasillo la primera puerta de la derecha"
    hn "คุณซากุระอยู่ที่ชั้นสี่ค่ะ ขึ้นลิฟต์ไปแล้วเดินตามทางเดินไป ประตูแรกทางขวามือนะคะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:35
translate english sakura_quest2_1_ac774ff3:

    # mn "Vale, muchas gracias señorita..."
    mn "โอเค ขอบคุณมากครับคุณ..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:38
translate english sakura_quest2_1_ce99a0c3:

    # hn "Un placer ayudarlo"
    hn "ยินดีที่ได้ช่วยค่ะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:43
translate english sakura_quest2_1_e5677ef0:

    # mn "(Vaya, es una chica muy linda, no recuerdo haberla visto antes)"
    mn "(ว้าว เธอเป็นผู้หญิงที่สวยมากเลยนะ ไม่เห็นจำได้ว่าเคยเจอมาก่อนเลย)"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:46
translate english sakura_quest2_1_f25ab24d:

    # mn "(¿Será nueva aquí?)"
    mn "(เธอเพิ่งมาใหม่ที่นี่รึเปล่านะ?)"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:48
translate english sakura_quest2_1_2e19ecf9:

    # n "[MN] sube por el ascensor y se dirige donde está Sakura"
    n "[MN] ขึ้นลิฟต์แล้วมุ่งหน้าไปตรงที่ซากุระอยู่"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:57
translate english sakura_quest2_1_bf7c399a:

    # mn "Hola, ¿Hay alguien?"
    mn "สวัสดีครับ มีใครอยู่ไหมครับ?"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:61
translate english sakura_quest2_1_c482e294:

    # sk "[MN], hola"
    sk "[MN] สวัสดีจ้ะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:64
translate english sakura_quest2_1_7329b4ee:

    # sk "Sí viniste, justo estaba preguntándome si vendrías"
    sk "มาจนได้นะ กำลังสงสัยอยู่เลยว่าเธอจะมารึเปล่า"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:67
translate english sakura_quest2_1_6f80ff68:

    # mn "Dije que lo haría, tengo que ser un hombre de palabra"
    mn "ผมบอกว่าจะทำ ก็ต้องรักษาคำพูดสิครับ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:70
translate english sakura_quest2_1_904952b5:

    # sk "Así me gusta jaja"
    sk "ฉันชอบตรงนี้แหละ ฮ่าๆ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:73
translate english sakura_quest2_1_55da7d8d:

    # mn "Y bien, ¿Cuál es mi primer trabajo?"
    mn "แล้ว งานแรกของผมคืออะไรเหรอครับ?"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:76
translate english sakura_quest2_1_c9c0d97f:

    # sk "Verás, necesito que me hagas un encargo"
    sk "คือว่านะ ฉันอยากให้เธอช่วยไปทำธุระให้หน่อยน่ะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:79
translate english sakura_quest2_1_ae206d67:

    # sk "¿Recuerdas a Ino?"
    sk "จำอิโนะได้ไหมจ๊ะ?"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:82
translate english sakura_quest2_1_6f343701:

    # mn "¿La madre de Inojin? Si, la recuerdo"
    mn "แม่ของอิโนะจินเหรอครับ? ครับ ผมจำเธอได้"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:85
translate english sakura_quest2_1_624f039a:

    # sk "Me dijo que recientemente le llegó una flor bastate rara, esta flor contiene propiedades medicinales"
    sk "เธอบอกฉันว่าเพิ่งได้ดอกไม้หายากมาน่ะ ดอกไม้นี้มีสรรพคุณทางยาด้วยนะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:87
translate english sakura_quest2_1_2f1aae45:

    # sk "Me la va a regalar para ayudar a las personas aquí en el hospital, así que necesito que la vayas a traer"
    sk "เธอจะมอบมันให้ฉันเอามาช่วยคนที่โรงพยาบาลนี้ ฉันเลยอยากให้เธอช่วยไปเอามาให้น่ะจ้ะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:89
translate english sakura_quest2_1_aec3eab5:

    # sk "Iría yo misma, pero necesito completar un informe antes de que oscurezca"
    sk "จริง ๆ ฉันว่าจะไปเอง แต่ต้องทำรายงานให้เสร็จก่อนค่ำน่ะสิ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:92
translate english sakura_quest2_1_98c9c7f7:

    # mn "Es un encargo fácil, déjalo en mis manos"
    mn "ธุระง่าย ๆ เองครับ ไว้ใจผมได้เลย"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:95
translate english sakura_quest2_1_ba0140c5:

    # sk "Te lo agradezco mucho, enserio"
    sk "ขอบใจมากจริง ๆ นะจ๊ะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:98
translate english sakura_quest2_1_a6860a0b:

    # mn "No te preocupes jaja"
    mn "ไม่ต้องห่วงครับ ฮ่าๆ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:101
translate english sakura_quest2_1_702c6f29:

    # mn "Vuelvo enseguida"
    mn "เดี๋ยวผมกลับมาครับ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:105
translate english sakura_quest2_1_17a63c3f:

    # n "[MN] sale del Hospital"
    n "[MN] เดินออกจากโรงพยาบาล"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:123
translate english sakura_quest2_2_64f492be:

    # mn "Hola, buen día"
    mn "สวัสดีครับ สวัสดียามเช้าครับ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:126
translate english sakura_quest2_2_b17b4721:

    # ino "Bienvenido a la Florería Yamanaka, ¿En qué puedo ayudarlo?"
    ino "ยินดีต้อนรับสู่ร้านดอกไม้ยามานากะค่ะ มีอะไรให้ช่วยไหมคะ?"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:129
translate english sakura_quest2_2_d219de06:

    # mn "Vengo aquí por parte de la señorita Sakura a recoger un encargo"
    mn "ผมมาแทนคุณซากุระเพื่อมารับของน่ะครับ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:132
translate english sakura_quest2_2_b13396a0:

    # ino "Oh, Sakura"
    ino "อ๋อ ซากุระเหรอจ๊ะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:136
translate english sakura_quest2_2_3e763762:

    # ino "¿Desde cuando envía a chicos tan guapos a hacer recados?"
    ino "ตั้งแต่เมื่อไหร่กันนะที่ยัยนั่นส่งเด็กหนุ่มหล่อขนาดนี้มาทำธุระให้น่ะ?"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:139
translate english sakura_quest2_2_fda1b136:

    # mn "Oh, jeje, soy su asistente... O algo parecido"
    mn "อ่า ฮ่าๆ ผมเป็นผู้ช่วยของเธอน่ะครับ... หรืออะไรทำนองนั้น"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:142
translate english sakura_quest2_2_9190aae1:

    # ino "Entiendo..."
    ino "เข้าใจแล้วจ้ะ..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:146
translate english sakura_quest2_2_ee88b126:

    # ino "Hmm, siento que te he visto en algún otro lado... ¿Nos hemos visto antes?"
    ino "หืม รู้สึกเหมือนเคยเห็นเธอจากที่ไหนมาก่อนเลยนะ... เราเคยเจอกันมาก่อนรึเปล่าจ๊ะ?"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:149
translate english sakura_quest2_2_81835d64:

    # mn "Eh, soy [MN]..."
    mn "เอ่อ ผม [MN] ครับ..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:152
translate english sakura_quest2_2_78749616:

    # ino "Oh, ¿[MN]?"
    ino "อ้าว [MN] เหรอจ๊ะ?"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:154
translate english sakura_quest2_2_5483bccf:

    # ino "¿El amigo de Sarada?"
    ino "เพื่อนของซาราดะใช่ไหมจ๊ะ?"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:157
translate english sakura_quest2_2_b895c77f:

    # mn "Sí, nos vimos un par de veces en casa de Sakura..."
    mn "ครับ เราเคยเจอกันสองสามครั้งที่บ้านคุณซากุระ..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:160
translate english sakura_quest2_2_f85f51ac:

    # ino "Ooh, ya te recuerdo jajaja"
    ino "อ๋อ ฉันจำเธอได้แล้ว ฮ่าๆๆ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:162
translate english sakura_quest2_2_93cb4134:

    # ino "Discúlpame, es solo que..."
    ino "ขอโทษทีนะ พอดีว่า..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:164
translate english sakura_quest2_2_3744c1b4:

    # ino "Estás... Mucho más grande..."
    ino "เธอ... ตัวโตขึ้นเยอะเลย..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:167
translate english sakura_quest2_2_884ec90e:

    # mn "Eh, jeje... ¿Gracias?"
    mn "เอ่อ ฮิๆ... ขอบคุณครับ?"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:170
translate english sakura_quest2_2_fa83b76f:

    # ino "Aunque, ciertamente no recuerdo que tus ojos fueran amarillo..."
    ino "แต่ว่านะ ฉันจำไม่ได้เลยว่าตาเธอเคยเป็นสีเหลือง..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:173
translate english sakura_quest2_2_880e621e:

    # mn "Oh, eso... Es una larga historia la verdad..."
    mn "อ๋อ เรื่องนั้น... จริง ๆ มันเป็นเรื่องยาวเลยครับ..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:176
translate english sakura_quest2_2_2bf5cf38:

    # ino "Bueno, resulta que a mí me gustan las historias..."
    ino "แหม พอดีเลยว่าฉันชอบฟังเรื่องยาว ๆ ซะด้วย..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:180
translate english sakura_quest2_2_cff8f2b0:

    # ino "¿Qué te parece si regresas y me cuentas tu {b}Larga{/a} historia más tranquilamente?"
    ino "เอาไว้เธอกลับมาเล่าเรื่อง{b}ยาวๆ{/a} ของเธอให้ฟังแบบสบาย ๆ กว่านี้ดีไหมจ๊ะ?"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:181
translate english sakura_quest2_2_1ecd6854:

    # ino "Me gusta mucho tu compañía"
    ino "ฉันชอบที่มีเธออยู่ด้วยจริง ๆ นะจ๊ะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:182
translate english sakura_quest2_2_a45be988:

    # ino "Estar aquí sola puede ser... Muy aburrido"
    ino "การต้องอยู่คนเดียวที่นี่มัน... น่าเบื่อมากเลยล่ะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:183
translate english sakura_quest2_2_2a67f5dc:

    # mn "C-Claro... Puedo intentar venir en otro momento..."
    mn "ด-ได้ครับ... เดี๋ยวผมจะลองหาเวลามาวันหลังนะครับ..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:184
translate english sakura_quest2_2_f6311cb7:

    # ino "Muy bien, entonces sé un buen chico y espera aquí mientras traigo la flor"
    ino "ตกลงจ้ะ งั้นเป็นเด็กดีแล้วรอตรงนี้แป๊บหนึ่งนะ เดี๋ยวฉันไปหยิบดอกไม้มาให้"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:185
translate english sakura_quest2_2_cc60c3b9:

    # mn "B-Bien..."
    mn "ค-ครับ..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:196
translate english sakura_quest2_2_1c9b966f:

    # mn "(No recordaba que la señorita Ino fuese tan...)"
    mn "(ผมจำไม่ได้เลยว่าคุณอิโนะจะ...)"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:198
translate english sakura_quest2_2_3dfc0d08:

    # mn "(Atractiva...)"
    mn "(มีเสน่ห์ขนาดนี้...)"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:199
translate english sakura_quest2_2_c3ccc1f8:

    # mn "(Sin duda tengo que volver)"
    mn "(ผมต้องกลับมาอีกให้ได้เลย)"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:207
translate english sakura_quest2_2_1c138ff2:

    # ino "Aquí tienes guapo, recuerda volver a visitarme"
    ino "ได้แล้วจ้ะสุดหล่อ อย่าลืมแวะมาหาฉันอีกนะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:211
translate english sakura_quest2_2_667c754f:

    # mn "Muchas gracias, volveré en otro momento"
    mn "ขอบคุณมากครับ ไว้ผมจะกลับมาใหม่นะครับ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:215
translate english sakura_quest2_2_a33ae09f:

    # ino "Espero que así sea..."
    ino "หวังว่าจะอย่างนั้นนะจ๊ะ..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:235
translate english sakura_quest2_3_ddf2dd93:

    # mn "Hola hola"
    mn "สวัสดีครับ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:239
translate english sakura_quest2_3_1d9ea1f6:

    # mn "Aquí traigo la flor, tal y como me lo pediste"
    mn "ผมเอาดอกไม้มาให้แล้วครับ ตามที่คุณขอเลย"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:243
translate english sakura_quest2_3_f9015918:

    # sk "Perfecto, justo acabo de terminar el informe"
    sk "เยี่ยมเลยจ้ะ ฉันเพิ่งทำรายงานเสร็จพอดี"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:245
translate english sakura_quest2_3_e138bb86:

    # sk "Ya puedo comenzar con el análisis y las pruebas"
    sk "ทีนี้ฉันจะได้เริ่มวิเคราะห์และทดสอบซะที"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:248
translate english sakura_quest2_3_7ab3a67e:

    # mn "¿No deberías de dejarle ese trabajo al centro de investigación?"
    mn "งานแบบนั้นปล่อยให้เป็นหน้าที่ของศูนย์วิจัยไม่ได้เหรอครับ?"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:251
translate english sakura_quest2_3_cd2805bb:

    # sk "Si lo hiciera, de igual forma me pedirán a mí o a la señora Tsunade que nos encarguemos"
    sk "ถึงปล่อยไป สุดท้ายพวกเขาก็คงขอให้ฉันหรือท่านซึนาเดะเป็นคนจัดการอยู่ดีนั่นแหละจ้ะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:253
translate english sakura_quest2_3_3aba28a2:

    # sk "Ambas estamos calificadas para el análisis de hierbas, flores e incluso hongos con potencial medicinal"
    sk "พวกเราทั้งคู่มีความเชี่ยวชาญในการวิเคราะห์สมุนไพร ดอกไม้ หรือแม้กระทั่งเห็ดที่มีสรรพคุณทางยา"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:256
translate english sakura_quest2_3_0d19a201:

    # mn "Entiendo, me encantaría ver como lo haces"
    mn "เข้าใจแล้วครับ ผมอยากเห็นจังว่าคุณทำยังไง"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:259
translate english sakura_quest2_3_ae759f72:

    # sk "Con gusto te mostraré, aunque si te aburres eres libre de irte por hoy"
    sk "ฉันยินดีสาธิตให้ดูเลยจ้ะ แต่ถ้าเธอเริ่มเบื่อ วันนี้จะขอตัวกลับก่อนก็ได้นะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:262
translate english sakura_quest2_3_dfe13314:

    # mn "Claro"
    mn "ได้ครับ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:266
translate english sakura_quest2_3_bd339198:

    # n "Sakura procedió con el análisis de la flor en compañía de [MN]"
    n "ซากุระลงมือวิเคราะห์ดอกไม้ต่อ โดยมี [MN] อยู่เป็นเพื่อน"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:267
translate english sakura_quest2_3_f7333adf:

    # n "El cuál prestaba total atención a lo que le decía Sakura"
    n "ซึ่งเขาก็ตั้งอกตั้งใจฟังสิ่งที่ซากุระอธิบายอย่างเต็มที่"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:268
translate english sakura_quest2_3_7e103fb3:

    # sk "¿Sabes qué son los flavonoides?"
    sk "เธอรู้ไหมจ๊ะว่าฟลาโวนอยด์คืออะไร?"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:269
translate english sakura_quest2_3_7af38ea2:

    # mn "Eh, no..."
    mn "เอ่อ ไม่รู้ครับ..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:270
translate english sakura_quest2_3_97202d9d:

    # sk "Son una serie de metabolitos secundarios de las plantas"
    sk "มันคือกลุ่มสารเมแทบอไลต์ทุติยภูมิของพืชน่ะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:271
translate english sakura_quest2_3_4b257faa:

    # sk "Son una familia muy diversa..."
    sk "เป็นกลุ่มที่มีความหลากหลายมาก..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:272
translate english sakura_quest2_3_7c4f86a6:

    # sk "Y un poco complejo para que lo entiendas..."
    sk "และอาจจะซับซ้อนไปหน่อยสำหรับเธอที่จะเข้าใจ..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:273
translate english sakura_quest2_3_937f0dea:

    # sk "Pero si lo que estoy viendo es correcto..."
    sk "แต่ถ้าสิ่งที่ฉันเห็นอยู่นี้ถูกต้องล่ะก็..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:274
translate english sakura_quest2_3_799a2511:

    # sk "Significa que esto posiblemente pueda servir igual o mejor que la hierba medicinal tradicional..."
    sk "นั่นหมายความว่า ดอกไม้นี้อาจจะใช้ประโยชน์ได้ดีเท่ากับ หรือดียิ่งกว่าสมุนไพรดั้งเดิมซะอีก..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:275
translate english sakura_quest2_3_1d8d3b61:

    # mn "¿Pero de que sirve si es una flor tan rara y difícil de encontrar?"
    mn "แต่จะมีประโยชน์อะไรเหรอครับ ในเมื่อมันเป็นดอกไม้ที่หายากและหาลำบากขนาดนี้?"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:276
translate english sakura_quest2_3_ce477296:

    # mn "¿No sería mejor seguir usando la que se usa actualmente?"
    mn "สู้ใช้แบบที่ใช้อยู่ตอนนี้ต่อไปไม่ดีกว่าเหรอครับ?"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:277
translate english sakura_quest2_3_5bf05138:

    # sk "Claro, de no ser porque las propiedades de esta flor probablemente sirvan para mucho más que solo sanar heridas..."
    sk "ก็ใช่น่ะสิจ๊ะ ถ้าไม่ใช่เพราะสรรพคุณของดอกไม้นี้อาจจะทำอะไรได้มากกว่าแค่รักษาแผลล่ะก็..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:278
translate english sakura_quest2_3_228f2bf7:

    # mn "Ahora estoy confundido"
    mn "ตอนนี้ผมเริ่มงงแล้วครับ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:279
translate english sakura_quest2_3_6fb25238:

    # sk "No te culpo, nada de lo que estoy diciendo acerca de la flor es seguro de todos modos..."
    sk "ฉันไม่โทษเธอหรอกจ้ะ เพราะยังไงสิ่งที่ฉันพูดเกี่ยวกับดอกไม้นี้ก็ยังไม่มีอะไรแน่นอนอยู่แล้ว..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:280
translate english sakura_quest2_3_c65dbd6b:

    # sk "Para saberlo al 100 por ciento, tendría que usar el equipo del laboratorio del centro de investigación"
    sk "ถ้าจะให้รู้แน่ชัด 100 เปอร์เซ็นต์ ฉันคงต้องใช้อุปกรณ์ในห้องทดลองของศูนย์วิจัยน่ะจ้ะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:281
translate english sakura_quest2_3_6ae3776e:

    # sk "Pero como adelanto fue un gran avance"
    sk "แต่เท่าที่ดูคร่าวๆ นี่ก็ถือเป็นความก้าวหน้าที่ดีมากเลยนะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:282
translate english sakura_quest2_3_b8ff95ac:

    # mn "Genial"
    mn "เจ๋งไปเลยครับ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:287
translate english sakura_quest2_3_d7bd681a:

    # sk "Bueno, muchas gracias por todo"
    sk "เอาเป็นว่า ขอบใจมากนะจ๊ะสำหรับทุกอย่าง"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:289
translate english sakura_quest2_3_e1fd2365:

    # sk "Me ayudaste mucho el día de hoy"
    sk "วันนี้เธอช่วยฉันไว้เยอะเลย"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:292
translate english sakura_quest2_3_849aab6d:

    # mn "No hay de qué, jeje..."
    mn "ยินดีครับ ฮิฮิ..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:294
translate english sakura_quest2_3_2a9f8fa4:

    # mn "Nada mal para ser mi primer día como asistente"
    mn "ถือว่าไม่เลวเลยสำหรับวันแรกในฐานะผู้ช่วย"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:296
translate english sakura_quest2_3_c531e8e8:

    # sk "Creo que para terminar su primer día, mi asistente necesita una recompensa"
    sk "ฉันคิดว่าเพื่อเป็นการส่งท้ายวันแรก ผู้ช่วยของฉันควรได้รับรางวัลนะจ๊ะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:299
translate english sakura_quest2_3_5a300e8a:

    # n "Sakura se acerca a [MN] y le da un adorable beso en la mejilla"
    n "ซากุระเดินเข้าไปหา [MN] แล้วหอมแก้มเขาอย่างน่ารักน่าเอ็นดู"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:300
translate english sakura_quest2_3_bbfd2dca:

    # mn "¡!"
    mn "!!"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:301
translate english sakura_quest2_3_8fec13bb:

    # sk "En verdad te agradezco que me ayudes..."
    sk "ฉันขอบใจเธอจริงๆ นะที่มาช่วยฉัน..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:302
translate english sakura_quest2_3_da7da1db:

    # mn "N-No es nada... Tú has hecho mucho más por mí..."
    mn "ม-ไม่เป็นไรหรอกครับ... คุณทำเพื่อผมตั้งเยอะกว่านี้อีก..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:309
translate english sakura_quest2_3_b6c86329:

    # sk "Y aquí tienes tu pago"
    sk "แล้วก็ นี่คือค่าตอบแทนของเธอจ้ะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:312
translate english sakura_quest2_3_e332f772:

    # mn "Gracias... Señorita Sakura..."
    mn "ขอบคุณครับ... คุณซากุระ..."

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:315
translate english sakura_quest2_3_8fb0fe9c:

    # sk "Cuando termine con la investigación de la flor te avisaré"
    sk "ถ้าวิจัยดอกไม้นี้เสร็จเมื่อไหร่ เดี๋ยวฉันจะบอกเธออีกทีนะจ๊ะ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:318
translate english sakura_quest2_3_f929624e:

    # mn "B-Bien"
    mn "ด-ดีเลยครับ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:320
translate english sakura_quest2_3_2f06819d:

    # mn "Entonces, creo que ya me voy por ahora"
    mn "ถ้าอย่างนั้น ผมขอตัวกลับก่อนนะครับ"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:323
translate english sakura_quest2_3_150e182c:

    # sk "Está bien, no olvides que puedes visitarme siempre que quieras"
    sk "จ้ะ อย่าลืมนะว่าแวะมาหาฉันได้ทุกเมื่อที่เธอต้องการเลย"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:327
translate english sakura_quest2_3_3a2597bd:

    # mn "Si, está bien"
    mn "ครับผม"

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:332
translate english sakura_quest2_3_7cff6471:

    # mn "Adiós"
    mn "ไปก่อนนะครับ"

translate english strings:

    # game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:206
    old "+1 Flor Extraña"
    new "+1 ดอกไม้ประหลาด"
# TODO: Translation updated at 2024-03-28 15:40

# game/scripts/History/SecundaryStory/Sakura/sakura_quest2.rpy:170
translate english sakura_quest2_2_789ec937:

    # ino "Aunque, ciertamente no recuerdo que tus ojos fueran amarillos..."
    ino "แต่ว่านะ ฉันจำไม่ได้เลยจริงๆ ว่าตาของนายเป็นสีเหลือง..."

# TODO: Translation updated at 2024-11-29 23:49

# game/scripts/History/SecundaryStory/Sakura/Arco 1/sakura_quest2.rpy:180
translate english sakura_quest2_2_4a972644:

    # ino "¿Qué te parece si regresas y me cuentas tu {b}Larga{/a} historia más tranquilamente?" with fade
    ino "เอาเป็นว่าค่อยกลับมาเล่าเรื่อง{b}ยาวๆ{/a} ของนายให้ฉันฟังแบบใจเย็นๆ กว่านี้ดีไหม?" with fade

# game/scripts/History/SecundaryStory/Sakura/Arco 1/sakura_quest2.rpy:196
translate english sakura_quest2_2_7a4bb63e:

    # mn "(No recordaba que la señorita Ino fuese tan...)" with fade
    mn "(ผมจำไม่ได้เลยว่าคุณอิโนะจะ... ขนาดนี้)" with fade
