# TODO: Translation updated at 2024-11-29 23:49

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:5
translate english arc2_tenten_quest3_79a83db2:

    # n "Mientras [MN] se dirige hacia la tienda de Tenten, recibe un mensaje de Zubon"
    n "ในระหว่างที่ [MN] กำลังมุ่งหน้าไปยังร้านของเท็นเท็น ก็ได้รับข้อความจากซูบง"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:13
translate english arc2_tenten_quest3_3f8213b1:

    # mn "Un mensaje de Zubon-Sensei"
    mn "ข้อความจากอาจารย์ซูบงงั้นเหรอ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:14
translate english arc2_tenten_quest3_686788db:

    # mn "¿Qué será ahora?"
    mn "จะมีเรื่องอะไรอีกนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:25
translate english arc2_tenten_quest3_c6493670:

    # mn "¡Eso es!" with vpunch
    mn "จริงด้วยสิ!" with vpunch

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:26
translate english arc2_tenten_quest3_644ffc2a:

    # mn "¡Ya nos recomendó para los exámenes!"
    mn "เขาเสนอชื่อพวกเราเข้าร่วมการสอบไปแล้วนี่!"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:29
translate english arc2_tenten_quest3_5502cecb:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:30
translate english arc2_tenten_quest3_2aee76b7:

    # mn "Zubon-Sensei pide mucho, seguro ahora hará un comentario..."
    mn "อาจารย์ซูบงเรื่องมากจะตาย ป่านนี้คงจะเริ่มบ่นอะไรอีกแน่ๆ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:32
translate english arc2_tenten_quest3_5502cecb_1:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:38
translate english arc2_tenten_quest3_5502cecb_2:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:43
translate english arc2_tenten_quest3_5b74cb8e:

    # mn "Bueno, tengo que decirle a Tenten sobre esto"
    mn "เอาเถอะ ฉันต้องรีบไปบอกเรื่องนี้กับเท็นเท็นก่อน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:48
translate english arc2_tenten_quest3_02c211c1:

    # n "[MN] retoma su camino hacia la tienda de Tenten"
    n "[MN] เดินทางต่อไปยังร้านของเท็นเท็น"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:49
translate english arc2_tenten_quest3_306db5c6:

    # n "Con una gran noticia"
    n "พร้อมกับข่าวดีสุดๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:59
translate english arc2_tenten_quest3_28540a31:

    # mn "Hola Tenten, hoy es un gran día"
    mn "ว่าไง เท็นเท็น วันนี้เป็นวันที่ดีสุดๆ เลยล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:60
translate english arc2_tenten_quest3_a8de5c2a:

    # mn "Zubon-Sensei nos acaba de dar una gran noticia"
    mn "อาจารย์ซูบงเพิ่งจะส่งข่าวดีมาล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:61
translate english arc2_tenten_quest3_5f35bddc:

    # tt "¿Ya se comportará como una persona normal?"
    tt "งั้นตาบ้านั่นก็เริ่มทำตัวเป็นคนปกติแล้วสิ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:62
translate english arc2_tenten_quest3_524325e3:

    # tt "¿Dejará de ser un pervertido?"
    tt "เลิกทำตัวเป็นตาแก่ลามกแล้วเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:65
translate english arc2_tenten_quest3_6a501e38:

    # mn "Tenten, no sueñes con algo imposible"
    mn "เท็นเท็น อย่าไปฝันถึงเรื่องที่เป็นไปไม่ได้เลยน่า"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:66
translate english arc2_tenten_quest3_19c6e87c:

    # mn "Zubon no dejará de ser así, ya lo intentamos"
    mn "ซูบงไม่เปลี่ยนไปเป็นแบบนั้นหรอก พวกเราลองพยายามดูกันแล้วนี่"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:69
translate english arc2_tenten_quest3_5be1601a:

    # tt "Maldición, ¿Entonces qué noticia les dió?"
    tt "ให้ตายสิ ว่าแต่เขาบอกข่าวอะไรมาล่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:71
translate english arc2_tenten_quest3_f2a993f1:

    # mn "¡Ya estamos recomendados para los exámenes Chunin!" with vpunch
    mn "พวกเราได้รับการเสนอชื่อให้เข้าสอบจูนินแล้วล่ะ!" with vpunch

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:74
translate english arc2_tenten_quest3_0d6e1f1a:

    # tt "¿De verdad? ¡Felicidades!" with vpunch
    tt "จริงเหรอเนี่ย? ยินดีด้วยนะ!" with vpunch

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:76
translate english arc2_tenten_quest3_125d6bda:

    # tt "Ya verás que dejarémos a todos con la boca abierta con nuestra espada"
    tt "รอดูเถอะน่า ด้วยดาบเล่มนี้ เราจะทำให้ทุกคนต้องอึ้งกันไปเลย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:77
translate english arc2_tenten_quest3_25130d0a:

    # mn "¡Ya verás que sí!"
    mn "รอดูได้เลย พวกเราทำได้แน่!"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:78
translate english arc2_tenten_quest3_f11ee93f:

    # mn "¿Has avanzado con la espada?"
    mn "แล้วเรื่องดาบไปถึงไหนแล้วล่ะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:80
translate english arc2_tenten_quest3_cd8837cb:

    # tt "Si, ya solo faltan unos pequeños retoques y está lista"
    tt "อ๋อ เหลือปรับแต่งอีกนิดหน่อยก็จะเสร็จแล้วล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:81
translate english arc2_tenten_quest3_463aba50:

    # tt "Solo dame unos momentos y la tendré lista"
    tt "รอแป๊บเดียวนะ เดี๋ยวฉันทำให้เสร็จเดี๋ยวนี้แหละ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:82
translate english arc2_tenten_quest3_756f6131:

    # tt "Aunque, quería pedirte un favor mientras"
    tt "แต่ระหว่างนี้ ฉันอยากจะวานให้ช่วยอะไรหน่อยน่ะสิ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:83
translate english arc2_tenten_quest3_63f97a1c:

    # mn "Claro, ¿Qué ocurre?"
    mn "ได้สิ มีอะไรเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:85
translate english arc2_tenten_quest3_5949889a:

    # tt "Verás, no puedo dejar la tienda sola, ¿Te molestaría ayudarme a atender?"
    tt "คือว่าฉันทิ้งร้านไว้คนเดียวไม่ได้ รบกวนช่วยเฝ้าร้านให้หน่อยได้ไหม?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:86
translate english arc2_tenten_quest3_60c42378:

    # tt "Te pagaré, solo debes de atender a las personas que lleguen y darles lo que piden"
    tt "เดี๋ยวฉันจ้างเอง แค่คอยต้อนรับลูกค้าแล้วก็หยิบของที่พวกเขาต้องการให้ก็พอ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:88
translate english arc2_tenten_quest3_6dbae239:

    # tt "Y no te preocupes por los precios, cada artículo tiene su precio anotado"
    tt "แล้วก็ไม่ต้องห่วงเรื่องราคานะ สินค้าทุกชิ้นติดราคาไว้หมดแล้ว"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:89
translate english arc2_tenten_quest3_0bebf90c:

    # mn "Bueno, entonces no hay problema"
    mn "งั้นก็ไม่มีปัญหา"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:90
translate english arc2_tenten_quest3_ddb9ca9b:

    # tt "Bien, entonces seguiré con la espada"
    tt "โอเค งั้นฉันไปทำดาบต่อล่ะนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:91
translate english arc2_tenten_quest3_dfb8ada5:

    # tt "Ya vuelvo"
    tt "เดี๋ยวมานะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:94
translate english arc2_tenten_quest3_3808fd73:

    # n "Tenten se dirigen a la forja nuevamente"
    n "เท็นเท็นเดินกลับไปที่เตาตีเหล็กอีกครั้ง"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:95
translate english arc2_tenten_quest3_295018a8:

    # n "Y mientras Tenten termina los últimos detalles de la espada, [MN] espera se hace cargo de la tienda de Tenten"
    n "และในระหว่างที่เท็นเท็นกำลังเก็บรายละเอียดขั้นสุดท้ายของดาบ [MN] ก็คอยดูแลร้านแทนเท็นเท็น"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:96
translate english arc2_tenten_quest3_421fb1d9:

    # n "Hasta que finalmente la terminó"
    n "จนกระทั่ง ในที่สุดเธอก็ทำมันเสร็จ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:105
translate english arc2_tenten_quest3_d19cb1d1:

    # tt "¡¡[MN]!!" with vpunch
    tt "¡¡[MN]!!" with vpunch

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:108
translate english arc2_tenten_quest3_ef9fbd93:

    # mnn "¡T-TENTEEN!" with hpunch
    mnn "เทะ-เท็นเท็น!" with hpunch

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:111
translate english arc2_tenten_quest3_86f16dba:

    # mn "¿Q-Qué pasa?"
    mn "ม-มีอะไรเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:114
translate english arc2_tenten_quest3_8110b4bd:

    # tt "..."
    tt "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:116
translate english arc2_tenten_quest3_e5221fbc:

    # tt "¿Estabas dormido?"
    tt "แอบหลับอยู่หรือเปล่าเนี่ย?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:119
translate english arc2_tenten_quest3_4a1be9bb:

    # mn "Eh, p-para nada..."
    mn "เอ่อ เปล่าสักหน่อย..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:121
translate english arc2_tenten_quest3_8110b4bd_1:

    # tt "..."
    tt "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:125
translate english arc2_tenten_quest3_eb95c5c5:

    # mn "Ejem... ¿P-Porqué vienes gritando, pasó algo?"
    mn "อะแฮ่ม... ต-ตะโกนทำไมเนี่ย มีเรื่องอะไรเกิดขึ้นเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:127
translate english arc2_tenten_quest3_c5ea45cf:

    # tt "Jeje, verás..."
    tt "ฮะๆ คือว่า..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:128
translate english arc2_tenten_quest3_79808d22:

    # tt "Ya he acabado la espada"
    tt "ฉันทำดาบเสร็จแล้วล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:129
translate english arc2_tenten_quest3_47d23790:

    # tt "Mira"
    tt "นี่ดูสิ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:136
translate english arc2_tenten_quest3_b5d60e2e:

    # n "Con una sonrisa de satisfacción, Tenten se acercó a [MN]"
    n "เท็นเท็นเดินเข้าไปหา [MN] พร้อมกับรอยยิ้มแห่งความพึงพอใจ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:137
translate english arc2_tenten_quest3_211d1c1e:

    # n "En sus manos, Tenten sostenía la espada en la que tan arduamente había estado trabajando"
    n "ในมือของเท็นเท็นถือดาบเล่มที่เธอทุ่มเทแรงกายแรงใจตีมันขึ้นมาอย่างหนักหน่วง"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:138
translate english arc2_tenten_quest3_8a15d7db:

    # n "La hoja era de un azul profundo, un tono que evocaba la calma de un océano"
    n "ตัวใบดาบเป็นสีน้ำเงินเข้ม เฉดสีที่ชวนให้นึกถึงความสงบเงียบของท้องมหาสมุทร"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:139
translate english arc2_tenten_quest3_88c62a7e:

    # n "La superficie de la hoja parecía estar viva, con un color azul tan vivo"
    n "พื้นผิวของใบดาบดูราวกับมีชีวิตชีวา ด้วยสีน้ำเงินที่สดใสสะดุดตา"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:140
translate english arc2_tenten_quest3_699c79f9:

    # n "El guardamanos era de un negro intenso"
    n "กระบังดาบเป็นสีดำสนิท"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:141
translate english arc2_tenten_quest3_a2af1894:

    # n "Contrastando elegantemente con el azul brillante de la Hoja y la Seppa y Kashira dorada"
    n "ตัดกันอย่างสง่างามกับสีฟ้าสดใสของใบดาบ รวมถึงแผ่นรองกระบังและปุ่มท้ายด้ามจับสีทอง"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:142
translate english arc2_tenten_quest3_807ddc39:

    # n "Su sencillez era su mayor virtud, uniendo la belleza y la fuerza de la espada en un equilibrio perfecto"
    n "ความเรียบง่ายคือจุดเด่นที่สุดของมัน ผสมผสานความงามและความแข็งแกร่งของดาบเข้าด้วยกันได้อย่างลงตัว"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:143
translate english arc2_tenten_quest3_2019a294:

    # n "[MN] no pudo evitar sonreir, sabía que Tenten había puesto todo su esfuerzo y habilidad en forjar esta espada única para él"
    n "[MN]อดไม่ได้ที่จะยิ้มออกมา เมื่อรู้ว่าเท็นเท็นได้ทุ่มเทแรงกายและฝีมือทั้งหมดเพื่อตีดาบเล่มพิเศษนี้ให้กับเขา"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:144
translate english arc2_tenten_quest3_3d340c34:

    # n "Un arma que no solo era una extensión de su voluntad, sino también una pieza de arte incomparable"
    n "อาวุธชิ้นนี้ไม่เพียงแต่เป็นส่วนขยายของเจตจำนงของเขาเท่านั้น แต่ยังเป็นงานศิลปะที่หาที่เปรียบมิได้อีกด้วย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:145
translate english arc2_tenten_quest3_26e85365:

    # mn "Tenten... Es..."
    mn "เท็นเท็น... มัน..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:150
translate english arc2_tenten_quest3_140e86bd:

    # n "Antes de que pudiera terminar la frase, [MN] se lanzó hacia Tenten, rodeándola con un fuerte abrazo"
    n "ก่อนที่เขาจะพูดจบ [MN] ก็โผเข้ากอดเท็นเท็นแน่นทันที"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:151
translate english arc2_tenten_quest3_65832c31:

    # mn "Es hermosa... Gracias"
    mn "มันสวยมาก... ขอบคุณนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:152
translate english arc2_tenten_quest3_489a6879:

    # n "Tenten se quedó sorprendida por un momento, pero luego sonrió, sintiendo el calor del abrazo de [MN]"
    n "เท็นเท็นตกใจอยู่ครู่หนึ่งก่อนจะยิ้มออกมาเมื่อสัมผัสได้ถึงความอบอุ่นจากอ้อมกอดของ [MN]"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:157
translate english arc2_tenten_quest3_55a8b48f:

    # n "Sabía que había logrado más que solo crear una espada... Había forjado un vínculo aún más fuerte entre ambos..."
    n "เธอรู้ว่าเธอทำได้มากกว่าแค่สร้างดาบขึ้นมา... เธอกำลังหลอมรวมสายสัมพันธ์ระหว่างกันให้แน่นแฟ้นยิ่งขึ้น..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:158
translate english arc2_tenten_quest3_84ea10e8:

    # n "Y sin darse cuenta, el abrazo se volvió más íntimo"
    n "และโดยไม่รู้ตัว อ้อมกอดนั้นก็แนบแน่นและลึกซึ้งยิ่งขึ้น"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:159
translate english arc2_tenten_quest3_d4f947bb:

    # n "Sus miradas se encontraron y, sin decir palabra, ambos se inclinaron lentamente"
    n "สายตาของทั้งคู่ประสานกัน และโดยไม่ต้องเอ่ยคำใดๆ ทั้งสองก็ค่อยๆโน้มตัวเข้าหากันช้าๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:163
translate english arc2_tenten_quest3_cefe78bf:

    # n "Sus labios se encontraron en un suave beso..."
    n "ริมฝีปากของทั้งคู่ประกบเข้าหากันด้วยจุมพิตแสนอ่อนโยน..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:164
translate english arc2_tenten_quest3_42f1e7a5:

    # n "Suave, pero cargado de mucho sentimiento"
    n "นุ่มนวล ทว่าเต็มเปี่ยมไปด้วยความรู้สึกอันลึกซึ้ง"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:165
translate english arc2_tenten_quest3_285aec58:

    # n "El tiempo pareció detenerse por un instante"
    n "เวลาเหมือนหยุดเดินไปชั่วขณะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:166
translate english arc2_tenten_quest3_31b415c3:

    # n "Un momento perfecto que ninguno de los dos quería romper..."
    n "ช่วงเวลาอันแสนสมบูรณ์แบบที่ไม่มีใครอยากให้หยุดลง..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:167
translate english arc2_tenten_quest3_74666cfb:

    # n "La suave brisa entraba por la ventana"
    n "สายลมอ่อนโชยพัดผ่านหน้าต่างเข้ามา"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:168
translate english arc2_tenten_quest3_a6704804:

    # n "Y los rayos de luz del atardecer iluminaban la tan hermosa escena..."
    n "และแสงอาทิตย์ยามอัสดงอาบไล้ฉากอันงดงามนี้ไว้ด้วยแสงเรืองรอง..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:169
translate english arc2_tenten_quest3_0a8ff1fb:

    # n "Sin duda es un momento precioso, como si de una novela se tratase..."
    n "ไม่ต้องสงสัยเลยว่านี่คือช่วงเวลาที่งดงามราวกับหลุดออกมาจากนิยาย..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:170
translate english arc2_tenten_quest3_90b4b5db:

    # n "Sin embargo..."
    n "ทว่า..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:174
translate english arc2_tenten_quest3_a19826e8:

    # n "De repente, ambos se dieron cuenta de lo que había ocurrido" with vpunch
    n "ฉับพลัน ทั้งคู่ก็เพิ่งรู้ตัวว่าเพิ่งทำอะไรลงไป" with vpunch

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:175
translate english arc2_tenten_quest3_cacd41ed:

    # n "Se separaron rápidamente"
    n "พวกเขารีบผละออกจากกันอย่างรวดเร็ว"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:176
translate english arc2_tenten_quest3_2efb4316:

    # n "Mientras sus corazones latían con fuerza y el calor del momento aún se reflejado en sus rostros sonrojados..."
    n "หัวใจเต้นระส่ำ และความเขินอายจากเหตุการณ์เมื่อครู่ยังคงฉายชัดอยู่บนใบหน้าที่แดงก่ำ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:188
translate english arc2_tenten_quest3_debc397e:

    # mn "Yo... L-Lo siento..."
    mn "ฉัน... ผ-ผมขอโทษ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:189
translate english arc2_tenten_quest3_c85985cc:

    # tt "N-No te preocupes... Y-Yo también..."
    tt "ไ-ไม่ต้องห่วงนะ... ฉ-ฉันเองก็..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:190
translate english arc2_tenten_quest3_15f0d20f:

    # mn "N-No sé que me pasó, de verdad lo siento mucho..."
    mn "ผ-ผมไม่รู้ว่าอะไรดลใจให้ทำแบบนั้น ผมขอโทษจริงๆ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:191
translate english arc2_tenten_quest3_efd29854:

    # tt "N-No te preocupes... Fue mi culpa"
    tt "ม-ไม่ต้องห่วงนะ... ฉันเองก็ผิดเหมือนกัน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:192
translate english arc2_tenten_quest3_54de03e3:

    # tt "Me dejé llevar..."
    tt "ฉันเผลอตัวไปหน่อย..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:193
translate english arc2_tenten_quest3_5ff12742:

    # tt "De verdad lo siento..."
    tt "ขอโทษจริงๆนะ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:196
translate english arc2_tenten_quest3_9eca4354:

    # mn "No, tu no tienes la culpa, de veras"
    mn "ไม่หรอก เธอไม่ได้ผิดสักหน่อย จริงๆ นะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:197
translate english arc2_tenten_quest3_8f3a3080:

    # mn "Es solo que, no pude evitarlo..."
    mn "เพียงแต่ว่า... มันอดใจไม่ไหว..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:199
translate english arc2_tenten_quest3_8110b4bd_2:

    # tt "..."
    tt "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:202
translate english arc2_tenten_quest3_d9f4c7d6:

    # tt "B-Bueno, ¿Qué tal si salimos?"
    tt "อ-งั้น... เราออกไปข้างนอกกันดีไหม?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:204
translate english arc2_tenten_quest3_f2890757:

    # tt "Ya sabes, tenemos que probar la espada"
    tt "ก็นะ เราต้องไปทดสอบดาบกันนี่นา"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:206
translate english arc2_tenten_quest3_49049d5a:

    # mn "S-Si... Vamos a probarla"
    mn "จ-จริงด้วย... ไปทดสอบกันเถอะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:215
translate english arc2_tenten_quest3_8f90e079:

    # n "[MN] y Tenten salen de la tienda"
    n "[MN] และเท็นเท็นเดินออกจากร้าน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:225
translate english arc2_tenten_quest3_1f5bc507:

    # tt "Muy bien, ya estamos aquí"
    tt "เอาล่ะ ถึงแล้วล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:226
translate english arc2_tenten_quest3_414e26a3:

    # tt "Listo, ya eres libre de probarla"
    tt "เชิญเลย ตามสบาย เต็มที่ได้เลยนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:227
translate english arc2_tenten_quest3_dfb90b3c:

    # mn "Bien, aquí vamos..."
    mn "งั้น... ลุยล่ะนะ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:231
translate english arc2_tenten_quest3_bd24cbaa:

    # n "Tenten le da la espada a [MN] para que la pruebe"
    n "เท็นเท็นยื่นดาบให้ [MN] นำไปทดสอบ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:232
translate english arc2_tenten_quest3_7dc8f4fe:

    # n "Luego de unos momentos probándola"
    n "หลังจากทดสอบอยู่ครู่หนึ่ง"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:240
translate english arc2_tenten_quest3_52a091cd:

    # mn "¡Está increíble!" with vpunch
    mn "สุดยอดไปเลย!" with vpunch

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:241
translate english arc2_tenten_quest3_63fbfe4a:

    # mn "Se nota mucho la diferencia"
    mn "รู้สึกถึงความแตกต่างได้ชัดเจนเลย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:242
translate english arc2_tenten_quest3_7e037921:

    # mn "El filo, el balance, el agarre, incluso el peso"
    mn "ทั้งความคม ความสมดุล การจับถือ หรือแม้แต่น้ำหนัก"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:243
translate english arc2_tenten_quest3_ac434560:

    # mn "Todo es muy superior a la anterior"
    mn "ทุกอย่างเหนือกว่าเล่มก่อนหน้านี้มากเลยล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:245
translate english arc2_tenten_quest3_f198b76c:

    # mn "De verdad te luciste Tenten, es increíble"
    mn "เธอทำได้ดีเกินคาดจริงๆ นะเท็นเท็น มันสุดยอดมากเลย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:247
translate english arc2_tenten_quest3_1a24239e:

    # mn "Con esta espada no tendré rival en los exámenes Chunin"
    mn "ด้วยดาบเล่มนี้ ฉันจะต้องไร้เทียมทานในการสอบจูยูนอย่างแน่นอน"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:249
translate english arc2_tenten_quest3_d2c36096:

    # tt "Más te vale que así sea, porque no aceptaré una derrota"
    tt "ทำให้ได้อย่างที่พูดก็แล้วกัน เพราะฉันไม่ยอมแพ้ใครง่ายๆ หรอกนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:252
translate english arc2_tenten_quest3_5502cecb_3:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:253
translate english arc2_tenten_quest3_1af16ce6:

    # mn "Tengo una idea, ¿Qué tal si le ponemos un nombre?"
    mn "ฉันมีไอเดียล่ะ เรามาตั้งชื่อให้มันกันดีไหม?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:255
translate english arc2_tenten_quest3_ca671acc:

    # tt "Jajaja, ¿Un nombre?"
    tt "ฮ่าๆ ตั้งชื่อเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:257
translate english arc2_tenten_quest3_cfa5bf15:

    # tt "Me parece buena idea, ¿Tienes algo en mente?"
    tt "ฟังดูเข้าท่าดีนะ นายมีชื่ออะไรอยู่ในใจแล้วล่ะสิ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:258
translate english arc2_tenten_quest3_3ef40ae7:

    # mn "Mmm... ¿Qué tal Super Espada?"
    mn "อืม... ซูเปอร์ซอร์ด ดีไหมนะ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:259
translate english arc2_tenten_quest3_ffe7fcb1:

    # mn "Oh, ya sé"
    mn "อ๋อ งั้นอันนี้ล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:260
translate english arc2_tenten_quest3_394d4574:

    # mn "Excalibur, la espada suprema!" with vpunch
    mn "เอ็กซ์คาลิเบอร์ ดาบผู้พิชิต!" with vpunch

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:262
translate english arc2_tenten_quest3_49315ce2:

    # tt "Jajajaja"
    tt "ฮ่าๆๆๆๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:266
translate english arc2_tenten_quest3_bbf40aa6:

    # mn "Oye, ¿De qué te ríes?"
    mn "เฮ้ เธอหัวเราะอะไรเนี่ย?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:268
translate english arc2_tenten_quest3_56691ca5:

    # tt "No son ideas muy originales jajaja"
    tt "ชื่อไม่ค่อยสร้างสรรค์เอาซะเลย ฮ่าๆๆ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:271
translate english arc2_tenten_quest3_17f0a8ec:

    # mn "Bueno, ¿Entonces tienes alguna mejor?"
    mn "งั้น... เธอมีชื่อที่ดีกว่านี้รึไง?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:273
translate english arc2_tenten_quest3_e9fc9f89:

    # tt "Bueno..."
    tt "เอ่อ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:274
translate english arc2_tenten_quest3_42ab232a:

    # n "Tenten piensa un nombre para la espada"
    n "เท็นเท็นครุ่นคิดหาชื่อให้กับดาบ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:276
translate english arc2_tenten_quest3_d95008ba:

    # tt "¿Qué tal {b}Kasairyu{/a}?"
    tt "เป็นไง {b}คาซาริว{/a} ดีไหม?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:277
translate english arc2_tenten_quest3_b7c3c48c:

    # tt "Ya que tu naturaleza de chakra es {b}Fuego{/a} y esta espada absorverá sus propiedades, podemos usar el Kanji {b}Kasai{/a} que significa {b}Fuego{/a}"
    tt "ในเมื่อธาตุจักระของนายคือ {b}ไฟ{/a} และดาบเล่มนี้ก็จะดูดซับคุณสมบัตินั้นเข้าไป เราก็ใช้คันจิคำว่า {b}คาไซ{/a} ที่แปลว่า {b}ไฟ{/a}"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:278
translate english arc2_tenten_quest3_c30ac1eb:

    # tt "Y usar el Kanju {b}Ryu{/a}, que significa {b}Dragón{/a}"
    tt "แล้วก็ใช้คันจิคำว่า {b}ริว{/a} ที่แปลว่า {b}มังกร{/a}"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:280
translate english arc2_tenten_quest3_92159e06:

    # tt "Va perfecto con tu nombre {b}[MN]{/a}"
    tt "แถมมันยังเข้ากันได้ดีกับชื่อของนายด้วยนะ {b}[MN]{/a}"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:281
translate english arc2_tenten_quest3_6ba26a8d:

    # tt "Así que podría traducirse como:"
    tt "แปลความหมายได้ประมาณนี้เลย:"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:282
translate english arc2_tenten_quest3_29ff2d5a:

    # tt "La Espada {b}Kasairyu, La Espada Fuego de Dragón{/a}"
    tt "{b}ดาบคะซาริว ดาบมังกรเพลิง{/a}"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:283
translate english arc2_tenten_quest3_5502cecb_4:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:284
translate english arc2_tenten_quest3_ee822794:

    # tt "Pero si quieres ponerle Super espa..."
    tt "แต่ถ้านายอยากจะเรียกว่า ซูเปอร์ซอ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:288
translate english arc2_tenten_quest3_e791d6ce:

    # mn "¡ES PERFECTO!" with vpunch
    mn "มันยอดเยี่ยมมากเลย!" with vpunch

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:291
translate english arc2_tenten_quest3_86a3c565:

    # mn "Es increíble Tenten"
    mn "สุดยอดไปเลยนะ เท็นเท็น"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:293
translate english arc2_tenten_quest3_22ce0912:

    # tt "¿T-Te gustó?"
    tt "ช-ชอบงั้นเหรอ?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:294
translate english arc2_tenten_quest3_16c42e83:

    # mn "Me encanta, entonces"
    mn "ฉันชอบมันสุดๆ เลยล่ะ เพราะงั้น"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:297
translate english arc2_tenten_quest3_8e7cb6d3:

    # mn "En nombre de nuestra espada, {b}Kasairyu{/a}"
    mn "ในนามของดาบของเรา {b}คาซาริว{/a}"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:298
translate english arc2_tenten_quest3_78d458ee:

    # mn "Pasaré los Exámenes Chunin a como dé lugar" with vpunch
    mn "ฉันจะต้องสอบผ่านจูยูนให้ได้ไม่ว่าจะทางไหนก็ตาม" with vpunch

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:301
translate english arc2_tenten_quest3_8110b4bd_3:

    # tt "..."
    tt "..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:304
translate english arc2_tenten_quest3_d6eafb20:

    # tt "Es una promesa, así que no me defraudes"
    tt "สัญญาแล้วนะ ห้ามทำให้ฉันผิดหวังล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:305
translate english arc2_tenten_quest3_77da1a22:

    # tt "¿Entendiste?"
    tt "เข้าใจไหม?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:306
translate english arc2_tenten_quest3_d129f12a:

    # mn "Entendido"
    mn "รับทราบครับ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:309
translate english arc2_tenten_quest3_8d911b7d:

    # mn "De verdad te agradezco mucho tu ayuda Tenten"
    mn "ฉันซาบซึ้งในความช่วยเหลือของเธอจริงๆ นะ เท็นเท็น"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:311
translate english arc2_tenten_quest3_f1ee40ee:

    # mn "Significa mucho para mí, más de lo que imaginas"
    mn "มันมีความหมายกับฉันมาก มากกว่าที่เธอจะจินตนาการได้เลยล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:312
translate english arc2_tenten_quest3_0738a819:

    # mn "A partir de ahora, no solo será un símbolo de mi evolución y de cómo afinaré mis habilidades..."
    mn "ต่อจากนี้ไป มันจะไม่เป็นแค่สัญลักษณ์แห่งการเติบโตและการขัดเกลาฝีมือของฉันเท่านั้น..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:315
translate english arc2_tenten_quest3_68e60f9c:

    # mn "También será un reflejo de tu evolución, del esfuerzo que has puesto para superar tus propios límites como herrera"
    mn "แต่มันยังสะท้อนถึงการเติบโตของเธอด้วย สะท้อนถึงความพยายามที่เธอทุ่มเทเพื่อก้าวข้ามขีดจำกัดของตัวเองในฐานะช่างตีเหล็ก"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:317
translate english arc2_tenten_quest3_a45617fd:

    # tt "¿Eh...? ¿Qué estás diciendo?"
    tt "หา...? พูดอะไรของนายเนี่ย?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:318
translate english arc2_tenten_quest3_ba078902:

    # mn "También simboliza..."
    mn "และมันยังเป็นสัญลักษณ์ของ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:320
translate english arc2_tenten_quest3_f974e9cc:

    # mn "El desarrollo de nuestra relación"
    mn "การเติบโตในความสัมพันธ์ของเราด้วย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:322
translate english arc2_tenten_quest3_11852eac:

    # tt "D-Deja de decir cosas tan embarazosas..."
    tt "พ-พูดอะไรน่าอายแบบนั้นเล่า..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:323
translate english arc2_tenten_quest3_568a63a8:

    # mn "De verdad muchísimas gracias Tenten"
    mn "ขอบคุณจริงๆ นะ เท็นเท็น"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:324
translate english arc2_tenten_quest3_c9d4fdcb:

    # mn "A partir de ahora te debo la vida"
    mn "จากนี้ไป ฉันติดหนี้ชีวิตเธอเลยล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:325
translate english arc2_tenten_quest3_d50ae323:

    # mn "Cualquier cosa que necesites, puedes contar conmigo, de veras"
    mn "ไม่ว่าเธอต้องการอะไร พึ่งพาฉันได้เสมอเลยนะ สาบานเลย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:327
translate english arc2_tenten_quest3_eda9d749:

    # tt "C-Con que pases los exámenes me basta..."
    tt "ข-ขอแค่สอบให้ผ่านก็พอแล้วสำหรับฉัน..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:329
translate english arc2_tenten_quest3_bde0748d:

    # tt "Ahora ya deja de hacer que me sonroje..."
    tt "เลิกทำให้ฉันเขินได้แล้ว..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:331
translate english arc2_tenten_quest3_ea1bed21:

    # mn "Jeje, lo siento"
    mn "ฮ่าๆ ขอโทษที"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:334
translate english arc2_tenten_quest3_b0174a6c:

    # tt "Tonto..."
    tt "ตาบ้าเอ๊ย..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:337
translate english arc2_tenten_quest3_4ceaf2a5:

    # tt "Bueno, yo me iré por ahora"
    tt "งั้นฉันขอตัวก่อนนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:338
translate english arc2_tenten_quest3_375c170b:

    # tt "Ya se hizo tarde y tengo que cerrar la tienda"
    tt "นี่ก็ดึกมากแล้ว ฉันต้องปิดร้านด้วย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:339
translate english arc2_tenten_quest3_2abfc519:

    # mn "Oh, si, ya no te quito más tiempo"
    mn "อ่า จริงด้วย งั้นฉันไม่กวนเวลาเธอแล้วล่ะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:340
translate english arc2_tenten_quest3_91e2f0cf:

    # mn "¿Irás a ver los Exámenes Chunin?"
    mn "เธอจะไปดูการสอบจูนินด้วยไหม?"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:341
translate english arc2_tenten_quest3_43b227cf:

    # tt "Ahí estaré, iré a darte ánimos, así que no te preocupes"
    tt "ไปอยู่แล้วล่ะ เดี๋ยวฉันไปช่วยเชียร์ด้วย ไม่ต้องห่วงหรอก"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:342
translate english arc2_tenten_quest3_b7a70cd8:

    # tt "Nos vemos luego"
    tt "ไว้เจอกันนะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:343
translate english arc2_tenten_quest3_fd38c9e3:

    # mn "Adiós Tenten, de verdad gracias"
    mn "ลาละนะเท็นเท็น ขอบคุณมากๆ เลย"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:348
translate english arc2_tenten_quest3_8abc440a:

    # n "Tenten se va del campo de entrenamiento"
    n "เท็นเท็นเดินออกจากค่ายฝึก"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:349
translate english arc2_tenten_quest3_703d0268:

    # mn "Espada {b}Kasairyu{/a}..."
    mn "ดาบ {b}คาไซริว{/a} เล่มนี้..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:350
translate english arc2_tenten_quest3_8a819534:

    # mn "Es increíble..."
    mn "สุดยอดจริงๆ..."

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:351
translate english arc2_tenten_quest3_a21c7593:

    # mn "Ahora solo tengo que entrenar para dominarla y sacarle todo el provecho, pero tengo que esperar que {b}Sarada{/a} tenga tiempo"
    mn "ตอนนี้ฉันแค่ต้องฝึกฝนเพื่อใช้มันให้คล่องและรีดประสิทธิภาพออกมาให้ได้มากที่สุด แต่ก็ต้องรอให้ {b}ซาราดะ{/a} มีเวลาว่างก่อนสินะ"

# game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:354
translate english arc2_tenten_quest3_f46c8540:

    # n "[MN] se va del campo de entrenamiento"
    n "[MN] ออกจากค่ายฝึก"

# TODO: Translation updated at 2024-12-20 07:52

translate english strings:

    # game/scripts/History/SecundaryStory/Tenten/Arco2/arc2_tenten_quest3.rpy:365
    old "{b}Espada Kasairyu{/a} añadida al {b}Inventario{/a}!"
    new "เพิ่ม {b}ดาบคาไซริว{/a} ลงใน {b}ช่องเก็บของ{/a} แล้ว!"
