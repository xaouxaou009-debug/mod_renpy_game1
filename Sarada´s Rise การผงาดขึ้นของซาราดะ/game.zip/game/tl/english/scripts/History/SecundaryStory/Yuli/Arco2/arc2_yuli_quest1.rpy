# TODO: Translation updated at 2024-11-29 23:49

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:9
translate english arc2_yuli_quest1_5bca0f79:

    # mn "Maldita sea... Ya fui a varias tiendas y no encuentro equipo decente"
    mn "เวรเอ๊ย... เดินหามาตั้งหลายร้านแล้ว ยังหาชุดดีๆ ใส่ไม่ได้เลย"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:10
translate english arc2_yuli_quest1_21a64ca2:

    # mn "Solo me queda una opción"
    mn "ตอนนี้เหลือทางเลือกเดียวแล้วล่ะนะ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:11
translate english arc2_yuli_quest1_83e33f3c:

    # mn "Voy a preguntarle a {b}Yuli{/a} si conoce a alguien que me pueda ayudar"
    mn "ฉันจะลองไปถาม {b}ยูริ{/b} ดูหน่อยว่าพอจะรู้จักใครที่ช่วยฉันได้บ้างไหม"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:13
translate english arc2_yuli_quest1_4d5f663e:

    # n "[MN] se dirige a la tienda de Yuli para preguntarse si puede ayudarle con su nuevo traje"
    n "[MN] มุ่งหน้าไปยังร้านของยูริเพื่อสอบถามว่าเธอพอจะช่วยเรื่องชุดใหม่ให้เขาได้หรือเปล่า"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:22
translate english arc2_yuli_quest1_5dde540c:

    # mn "Hola Yuli, buen día"
    mn "ไงยูริ สวัสดี"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:24
translate english arc2_yuli_quest1_a2a03e68:

    # yl "¡[MN]! Bienvenido nuevamente"
    yl "[MN]! ยินดีต้อนรับจ่ะ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:27
translate english arc2_yuli_quest1_0ce36528:

    # yl "¿Te puedo ayudar en algo Cariño?"
    yl "มีอะไรให้พี่สาวคนนี้ช่วยไหมจ๊ะ ที่รัก?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:29
translate english arc2_yuli_quest1_fe778456:

    # mn "¿Cariño?"
    mn "ที่รักงั้นเหรอ?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:31
translate english arc2_yuli_quest1_10efb752:

    # yl "Oh, no me prestes atención"
    yl "โอ๊ะ อย่าไปใส่ใจเลยน่า"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:33
translate english arc2_yuli_quest1_a0a8e51d:

    # yl "¿Deseas algo?"
    yl "สรุปว่ามาหาอะไรเหรอเรา?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:36
translate english arc2_yuli_quest1_65e4e7e0:

    # yl "¿Alguna lencería sexy para regalársela a Yuna?" with vpunch
    yl "ชุดชั้นในเซ็กซี่เอาไปฝากยูนะไ งล่ะ?" with vpunch

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:37
translate english arc2_yuli_quest1_81641da9:

    # yl "Si es así te aseguro que le encantan de color violeta"
    yl "ถ้าอย่างนั้นล่ะก็ พี่รับรองเลยว่าเธอชอบสีม่วงแน่นอน"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:39
translate english arc2_yuli_quest1_cb1603f4:

    # yl "Seguramente así te vuelvas a ganar su corazón nuevamente"
    yl "แบบนั้นช่วยให้เธอใจอ่อนยอมคืนดีด้วยได้แน่ๆ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:41
translate english arc2_yuli_quest1_df283751:

    # mn "¡N-No!" with vpunch
    mn "ม-ไม่ใช่นะ!" with vpunch

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:44
translate english arc2_yuli_quest1_7f409f8a:

    # mn "No es nada de eso... de veras"
    mn "มันไม่ใช่อย่างนั้นเลย... จริงๆ นะ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:47
translate english arc2_yuli_quest1_afb32d6e:

    # yl "Vaya, ¿Entonces no necesitas mi ayuda?"
    yl "อ่าว งั้นก็ไม่ได้ต้องการความช่วยเหลือจากพี่สินะ?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:49
translate english arc2_yuli_quest1_70c9654f:

    # mn "Si, la necesito, pero no es para eso..."
    mn "ต้องการสิครับ แต่ไม่ใช่เรื่องนั้นสักหน่อย..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:52
translate english arc2_yuli_quest1_b30577a0:

    # mn "Ya se acercan los Exámenes Chunin y vamos a participar en ellos, pero antes quiero mejorar mi traje"
    mn "การสอบจูนินกำลังจะมาถึงแล้ว และพวกเราก็จะเข้าร่วมด้วย แต่ก่อนอื่น ผมอยากจะอัปเกรดชุดของตัวเองซะก่อน"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:53
translate english arc2_yuli_quest1_e42594c4:

    # mn "Quería saber si puedes ayudarme, anduve buscando y no encuentro nada en ninguna tienda"
    mn "ผมเลยอยากรู้ว่าพี่พอจะช่วยอะไรผมได้บ้างไหม ผมเดินหาดูหมดทุกร้านแล้วแต่ก็ไม่เจออะไรถูกใจเลยสักร้าน"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:54
translate english arc2_yuli_quest1_6e82c3d0:

    # yl "Como ya te dije antes, de momento solo vendo ropa para mujer, no vendo ropa para hombre"
    yl "อย่างที่เคยบอกไปนั่นแหละ ตอนนี้พี่ขายแต่เสื้อผ้าผู้หญิงจ่ะ ไม่ได้ขายเสื้อผ้าผู้ชายซะหน่อย"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:56
translate english arc2_yuli_quest1_fc111665:

    # mn "Si... No perdía nada preguntándo..."
    mn "นั่นสินะ... ลองถามดูก็ไม่เสียหายอะไรนี่เนอะ..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:58
translate english arc2_yuli_quest1_f2b9d118:

    # mn "¿Y no conoces a alguien que pueda ayudarme?"
    mn "แล้วพอจะรู้จักใครที่พอจะช่วยผมได้บ้างไหมครับ?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:59
translate english arc2_yuli_quest1_af5abfe5:

    # yl "No, no conozco a nadie"
    yl "อืม ไม่แฮะ พี่ไม่รู้จักใครหรอก"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:61
translate english arc2_yuli_quest1_4e86405a:

    # yl "Aún así, creo que puedo ayudarte"
    yl "แต่ถึงอย่างนั้น พี่ก็คิดว่าพี่ช่วยเธอได้นะ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:63
translate english arc2_yuli_quest1_553205d1:

    # mn "¡¿En serio?!" with vpunch
    mn "จริงเหรอครับ?!" with vpunch

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:66
translate english arc2_yuli_quest1_7dea8a5b:

    # yl "Si, verás, hace unos años aprendí sobre sastrería"
    yl "ใช่แล้ว คือว่าเมื่อไม่กี่ปีก่อนพี่เคยไปเรียนตัดเย็บเสื้อผ้ามาน่ะ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:67
translate english arc2_yuli_quest1_eff9fced:

    # yl "Así que yo misma puedo hacer tu traje, ¿Qué dices?"
    yl "งั้นเดี๋ยวพี่ตัดชุดให้เธอเอง ว่าไงล่ะ?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:69
translate english arc2_yuli_quest1_f9a46de7:

    # mn "¡¿DE VERDAD?!" with vpunch
    mn "จริงเหรอครับเนี่ย?!" with vpunch

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:70
translate english arc2_yuli_quest1_99307474:

    # yl "Si, cuando me retiré de Kunoichi tenía que trabajar de algo ¿No?"
    yl "ใช่สิ ตอนที่ถอนตัวจากการเป็นนินจาหญิง พี่ก็ต้องหาอะไรทำเป็นอาชีพเสริมจริงไหมล่ะ?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:71
translate english arc2_yuli_quest1_f2e9e800:

    # yl "Pero... Voy a necesitar tu ayuda en el futuro, te ayudaré si me ayudas también, ¿Qué dices?"
    yl "แต่... ในอนาคตพี่อาจจะต้องให้เธอช่วยอะไรหน่อยนะ ช่วยพี่แล้วพี่ก็จะช่วยเธอเหมือนกัน ว่าไง ตกลงไหม?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:73
translate english arc2_yuli_quest1_1ef6e8cf:

    # mn "Por tí lo que sea Yuli, ¡De veras!" with vpunch
    mn "เพื่อพี่พรกแล้ว ผมยอมทุกอย่างเลยครับ! จริงๆ นะ!" with vpunch

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:77
translate english arc2_yuli_quest1_ac80a5b6:

    # yl "Aaah... ¿Lo que sea?"
    yl "อ่าา... ทุกอย่างเลยงั้นเหรอ?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:80
translate english arc2_yuli_quest1_6538caef:

    # mn "Eh, bueno..."
    mn "เอ่อ คือว่า..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:83
translate english arc2_yuli_quest1_dccf4b74:

    # yl "Muy bien, entonces tomo tu palabra"
    yl "ก็ได้ งั้นพี่จะถือว่าเธอพูดแล้วนะ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:84
translate english arc2_yuli_quest1_330241a3:

    # yl "Sé que eres un hombre que nunca se retracta Cariño"
    yl "พี่รู้ว่าเธอเป็นลูกผู้ชายที่พูดคำไหนคำนั้นอยู่แล้วนี่เนอะ ที่รัก"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:85
translate english arc2_yuli_quest1_5502cecb:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:87
translate english arc2_yuli_quest1_363f34e4:

    # mnn "(Maldición...)"
    mnn "(แย่แล้วสิ...)"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:88
translate english arc2_yuli_quest1_7018d47f:

    # mnn "(¿Ahora en qué me metí?)"
    mnn "(นี่เราเอาตัวไปผูกมัดกับเรื่องอะไรเนี่ย?)"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:91
translate english arc2_yuli_quest1_0dabfdf3:

    # yl "Bueno, yo me ocuparé de que el material sea del más resistente"
    yl "งั้นเดี๋ยวพี่จะเลือกใช้วัสดุที่ทนทานที่สุดให้ก็แล้วกัน"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:92
translate english arc2_yuli_quest1_884c3171:

    # yl "Ahora dime... ¿Cómo quieres que sea el diseño del traje?"
    yl "ทีนี้บอกพี่มาซิ... อยากให้ออกแบบชุดออกมาเป็นแบบไหนดีล่ะ?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:93
translate english arc2_yuli_quest1_f44f13c2:

    # yl "Puede ser como está la moda actualmente, con muchas fajas... O los zapatos muy altos"
    yl "จะให้ตามแฟชั่นช่วงนี้ที่มีเข็มขัดเยอะๆ ดี... หรือว่าใส่รองเท้าส้นสูงมากๆ ดีล่ะ?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:94
translate english arc2_yuli_quest1_a85ec0fe:

    # yl "También dime los colores que te gustaría"
    yl "แล้วก็ บอกสีที่เธออยากได้มาด้วยนะ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:97
translate english arc2_yuli_quest1_09925efc:

    # mn "Jeje, he pensado muy detalladamente como lo quiero"
    mn "แหะๆ ผมคิดรายละเอียดชุดที่อยากได้ไว้หมดแล้วล่ะครับ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:99
translate english arc2_yuli_quest1_5c91abee:

    # n "[MN] le cuenta a Yuli con lujo de detalle como quiere su traje nuevo"
    n "[MN] อธิบายรายละเอียดชุดใหม่ที่เขาต้องการให้ยูริฟังอย่างละเอียด"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:102
translate english arc2_yuli_quest1_ae784e80:

    # yl "Vaya, me alegra que te guste el estilo tradicional"
    yl "โหว พี่ดีใจนะเนี่ยที่เธอชอบสไตล์ดั้งเดิมน่ะ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:104
translate english arc2_yuli_quest1_a60dc5a2:

    # yl "Sin suda las fajas por todos lados no te gustan, ¿Cierto?"
    yl "คงไม่ต้องใส่เข็มขัดรุงรังเต็มตัวแบบนั้นหรอกเนอะ?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:105
translate english arc2_yuli_quest1_0f22df59:

    # mn "Jeje, la verdad es que no..."
    mn "แหะๆ เอาจริงก็ไม่ค่อยชอบเท่าไหร่ครับ..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:106
translate english arc2_yuli_quest1_e71dc53e:

    # yl "Muy bien, eso sería todo ¿No?"
    yl "งั้นก็แค่นี้สินะ?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:107
translate english arc2_yuli_quest1_083b34ea:

    # mn "Así es, lo único que le faltaría es el logo de mi Clan, pero creo que eso será hasta después"
    mn "ใช่ครับ จะขาดก็แค่สัญลักษณ์ตระกูลของผมน่ะแหละ แต่เอาไว้ค่อยใส่ทีหลังก็ได้"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:108
translate english arc2_yuli_quest1_3a8d5ca4:

    # mn "¿Cree que me quedará bien?"
    mn "พี่ว่าผมใส่แล้วจะออกมาดูดีไหมครับเนี่ย?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:110
translate english arc2_yuli_quest1_30023794:

    # yl "No te preocupes por eso"
    yl "เรื่องนั้นไม่ต้องเป็นห่วงเลย"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:112
translate english arc2_yuli_quest1_63410775:

    # yl "Te haré un traje que te haga ver mucho más apuesto y masculino de lo que eres"
    yl "เดี๋ยวพี่จะตัดชุดที่ทำให้เธอดูล่ำสันและเป็นผู้ชายขึ้นกว่าเดิมเยอะเลยให้เอง"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:114
translate english arc2_yuli_quest1_6e508eba:

    # yl "Ese traje que usas ahora te hace ver un poco... Infantil por decirlo de alguna manera..."
    yl "ชุดที่เธอใส่อยู่ตอนนี้มันทำให้เธอดูลักษณะ... ออกจะเด็กๆ ไปหน่อยนะ พูดตามตรง..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:117
translate english arc2_yuli_quest1_5502cecb_1:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:118
translate english arc2_yuli_quest1_9264b0cc:

    # mn "¿De verdad?"
    mn "จริงเหรอครับเนี่ย?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:119
translate english arc2_yuli_quest1_3471a2f7:

    # yl "No te lo digo por ser mala pero... ¿Hace cuanto no cambias tu vestimenta?"
    yl "พี่ไม่ได้จะเสียมารยาทหรอกนะ แต่... ตั้งแต่ครั้งล่าสุดที่เธอเปลี่ยนชุดนี่มันกี่ปีมาแล้วเนี่ย?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:120
translate english arc2_yuli_quest1_6759fd2c:

    # mn "Mmmm... Buena pregunta"
    mn "อืมมม... เป็นคำถามที่ดีครับ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:121
translate english arc2_yuli_quest1_b00b7ff1:

    # mn "Creo que desde que me gradué de la academia hace unos años"
    mn "น่าจะตั้งแต่ตอนที่ผมจบจากโรงเรียนนินจาเมื่อหลายปีก่อนมั้งครับ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:124
translate english arc2_yuli_quest1_030a290c:

    # yl "..."
    yl "..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:126
translate english arc2_yuli_quest1_0f8faa99:

    # yl "Si, necesitas un nuevo traje urgentemente"
    yl "เห็นไหมล่ะ เธอจำเป็นต้องเปลี่ยนชุดใหม่ด่วนๆ เลย"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:129
translate english arc2_yuli_quest1_63e38fb9:

    # yl "Por suerte aquí tienes a {b}Mami Yuli{/a} que te lo hará"
    yl "โชคดีนะเนี่ยที่มี{b}คุณแม่ยูริ{/b}คนนี้คอยตัดชุดให้"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:131
translate english arc2_yuli_quest1_556b986e:

    # mn "Jeje... Muchas gracias..."
    mn "แหะๆ... ขอบคุณมากเลยนะครับ..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:133
translate english arc2_yuli_quest1_717eed67:

    # yl "Bueno, ahora lo que debemos hacer es medir tu cuerpo"
    yl "เอาล่ะ ทีนี้สิ่งที่เราต้องทำก็คือ... วัดตัวเธอก่อนสินะ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:134
translate english arc2_yuli_quest1_5502cecb_2:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:137
translate english arc2_yuli_quest1_0c5fde6b:

    # mn "¿Khé?"
    mn "อะ-อะไรนะครับ?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:139
translate english arc2_yuli_quest1_1cc49228:

    # yl "Jajaja, que lindo te ves sonrojado"
    yl "ฮ่าๆๆ หน้าแดงใหญ่เลย น่ารักจังนะเนี่ย"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:141
translate english arc2_yuli_quest1_a169491e:

    # yl "Pero sí, debo tomar las medidas de tu cuerpo, es necesario para que todo salga bien"
    yl "แต่ว่านะ พี่ต้องวัดตัวเธอก่อน จำเป็นต้องทำเพื่อให้ชุดออกมาสมบูรณ์แบบที่สุดจ่ะ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:142
translate english arc2_yuli_quest1_5d7bf2e9:

    # yl "Si no, puede resultar muy grande o muy pequeño, tienen que ser tus medidas exactas"
    yl "ไม่งั้นชุดอาจจะใหญ่หรือเล็กเกินไป มันต้องใช้สัดส่วนที่เป๊ะๆ ของเธอเลยล่ะ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:143
translate english arc2_yuli_quest1_5502cecb_3:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:144
translate english arc2_yuli_quest1_677829af:

    # mn "E-Entiendo..."
    mn "คะ-เข้าใจแล้วครับ..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:146
translate english arc2_yuli_quest1_bc0d5223:

    # yl "¿Estás nervioso? No te haré nada que no quieras"
    yl "ประหม่าเหรอ? พี่ไม่ทำอะไรที่เธอไม่ต้องการหรอกน่า"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:147
translate english arc2_yuli_quest1_6c47600f:

    # yl "Podémos comenzar cuando quieras"
    yl "เริ่มเมื่อไหร่ก็ได้นะจ๊ะ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:148
translate english arc2_yuli_quest1_e8891afe:

    # mn "N-No, para nada..."
    mn "ปะ-เปล่าสักหน่อยครับ..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:149
translate english arc2_yuli_quest1_ef5e9f30:

    # mn "P-Podemos comenzar ya..."
    mn "เระ-เริ่มเลยก็ได้ครับ..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:150
translate english arc2_yuli_quest1_75cf0f28:

    # yl "Muy bien, entonces entra al vestidor, yo entraré cuando estés listo"
    yl "งั้นก็เข้าไปในห้องลองชุดก่อนเลย เดี๋ยวพี่ตามเข้าไปนะจ๊ะ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:151
translate english arc2_yuli_quest1_44853bbf:

    # yl "Si quieres puedo ayudarte a desvestirte..."
    yl "ถ้าเธอต้องการ เดี๋ยวพี่ช่วยถอดเสื้อผ้าให้ก็ได้นะ..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:152
translate english arc2_yuli_quest1_8ca6a0f1:

    # mn "Eeh... Creo que paso por esta vez..."
    mn "เอ่อ... ครั้งนี้ผมขอผ่านก่อนดีกว่าครับ..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:154
translate english arc2_yuli_quest1_f37713e5:

    # yl "Bueno, entonces traeré las herramientas, puedes irte desvistiendo"
    yl "งั้นก็ตามใจจ่ะ เดี๋ยวพี่ไปหยิบอุปกรณ์ก่อน เธอเริ่มถอดเสื้อผ้ารอได้เลยนะ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:155
translate english arc2_yuli_quest1_a9b50da4:

    # mn "C-Claro..."
    mn "ค-ครับ..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:158
translate english arc2_yuli_quest1_9f6920e0:

    # n "Mientras [MN] se desvestía en el vestidor"
    n "ระหว่างที่ [MN] กำลังถอดเสื้อผ้าอยู่ในห้องลองชุด"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:159
translate english arc2_yuli_quest1_eede1295:

    # n "Yuli fue a traer las herramientas para medir el cuerpo de [MN]"
    n "ยูริก็เดินไปหยิบอุปกรณ์สำหรับวัดตัวของ [MN]"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:160
translate english arc2_yuli_quest1_c70e6782:

    # n "Y cuando ya está todo listo, Yuli entra al vestidor y comienza a medir el cuerpo de [MN], con una sonrisa de par en par"
    n "เมื่อทุกอย่างพร้อมแล้ว ยูริก็เดินเข้าห้องลองชุดแล้วเริ่มวัดสัดส่วนของ [MN] ด้วยรอยยิ้มกว้างจนแก้มปริ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:161
translate english arc2_yuli_quest1_4a7bcc27:

    # n "Yuli comenzó a medir el cuerpo de [MN]"
    n "ยูริเริ่มทำการวัดตัว [MN]"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:162
translate english arc2_yuli_quest1_f8baf2ff:

    # n "Ella se colocó detrás de él para tomar medidas de su pecho y cintura"
    n "เธอยืนซ้อนอยู่ด้านหลังเขาเพื่อวัดรอบอกและรอบเอว"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:163
translate english arc2_yuli_quest1_7c10a775:

    # n "El corazón de [MN] se aceleró cuando sintió los pechos de Yuli tocar su espalda"
    n "หัวใจของเขาเต้นรัวเมื่อรู้สึกได้ถึงหน้าอกของยูริที่แนบชิดติดกับแผ่นหลังของเขา"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:164
translate english arc2_yuli_quest1_a52ead7b:

    # n "Pero luego Yuli dejó de medir, y con una voz sensual dijo:"
    n "แต่แล้วยูริก็หยุดวัด แล้วพูดด้วยน้ำเสียงยั่วยวนว่า:"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:169
translate english arc2_yuli_quest1_feb959f9:

    # yl "¿Sabes? Siempre he admirado tu físico..."
    yl "รู้ไหม? พี่ชื่นชมรูปร่างของเธอมาตลอดเลยนะ..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:170
translate english arc2_yuli_quest1_cc5b5150:

    # yl "Estos músculos tan tonificados..."
    yl "กล้ามเนื้อที่ฟิตแอนด์เฟิร์มพวกนี้..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:171
translate english arc2_yuli_quest1_2fa03a5b:

    # yl "Y estas cicatrices... Tan varoniles y llenas de historias..."
    yl "แล้วก็แผลเป็นพวกนี้อีก... ดูแมนแล้วก็มีเรื่องราวน่าค้นหาจัง..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:172
translate english arc2_yuli_quest1_3cdfae02:

    # yl "Cada una de ellas me hace imaginarte enfrentándote a peligros inimaginables, luchando con mucha valentía..."
    yl "พอมองพวกมันทีไร พี่อดจินตนาการไม่ได้เลยว่าเธอต้องเผชิญกับอันตรายขนาดไหน และต้องต่อสู้ด้วยความกล้าหาญแค่ไหน..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:173
translate english arc2_yuli_quest1_a2a33756:

    # yl "No puedo evitar sentir un deseo incontrolable de descubrir más... De saborear cada parte de este cuerpo..."
    yl "มันทำให้พี่อดใจไม่ไหวจนมีความรู้สึกอยากรู้อยากเห็นมากกว่านี้... อยากจะสัมผัสลิ้มลองทุกส่วนของเรือนร่างนี้..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:174
translate english arc2_yuli_quest1_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:175
translate english arc2_yuli_quest1_3baae7e2:

    # mn "Y-Yuli... Yo..."
    mn "ย-ยูริ... ผม..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:176
translate english arc2_yuli_quest1_e6b8637a:

    # n "Al escuchar esto, [MN] sintió un vuelco en el estómago"
    n "พอได้ยินดังนั้น [MN] ก็รู้สึกปั่นป่วนในท้องขึ้นมาทันที"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:177
translate english arc2_yuli_quest1_f910e25b:

    # n "Las palabras de Yuli lo habían dejado sin aliento, incapaz de encontrar las palabras adecuadas para responder"
    n "คำพูดของยูริทำให้เขาแทบสิ้นลมหายใจจนนึกหาคำมาตอบกลับไม่ถูก"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:178
translate english arc2_yuli_quest1_8046a0b3:

    # n "Nunca en su vida se habría imaginado que Yuli, la madre de su ex novia, lo miraría con esos ojos, con esa intensidad y deseo"
    n "เขาไม่เคยคาดคิดมาก่อนเลยในชีวิตว่ายูริ แม่ของแฟนเก่า จะมองเขาด้วยสายตาแบบนั้น... สายตาที่เต็มไปด้วยความเร่าร้อนและความปรารถนา"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:179
translate english arc2_yuli_quest1_b7998975:

    # n "Por un momento, el tiempo pareció detenerse, la habitación se llenó de mucha tensión..."
    n "ชั่วขณะหนึ่ง เวลาคล้ายจะหยุดนิ่ง และบรรยากาศในห้องก็เต็มไปด้วยความตึงเครียดอันเข้มข้น..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:180
translate english arc2_yuli_quest1_e134ebed:

    # n "Mientras Yuli, con mucha calma volvía a tomar la cinta métrica"
    n "ในขณะเดียวกัน ยูริก็หยิบสายวัดขึ้นมาวัดต่อด้วยท่าทางใจเย็น"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:181
translate english arc2_yuli_quest1_271d6645:

    # n "Sus dedos rozaron suavemente la piel de [MN] al medir su pecho"
    n "ปลายนิ้วของเธอสัมผัสเบาๆ ลงบนผิวของ [MN] ขณะที่เธอกำลังวัดรอบอกให้เขา"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:182
translate english arc2_yuli_quest1_42723958:

    # n "Podía sentir su respiración agitarse, cada contacto de ella encendía un fuego dentro de él"
    n "เขารู้สึกได้ว่าลมหายใจของตัวเองเริ่มถี่กระชั้น ทุกสัมผัสจากเธอจุดไฟเร่าร้อนขึ้นในกายของเขา"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:183
translate english arc2_yuli_quest1_a52e5d19:

    # yl "No tienes que decir nada..."
    yl "เธอไม่ต้องพูดอะไรหรอก..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:184
translate english arc2_yuli_quest1_edb80cb2:

    # yl "Ya falta un poco más... Permíteme seguir midiendo..."
    yl "อีกนิดเดียวนะ... ให้พี่วัดต่อเถอะนะ..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:188
translate english arc2_yuli_quest1_ce1b35dc:

    # n "Es un silencio muy incomodo para [MN], Yuli terminó de medir"
    n "มันเป็นความเงียบที่น่าอึดอัดใจมากสำหรับ [MN] แต่ในที่สุดยูริก็วัดตัวเสร็จเรียบร้อย"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:189
translate english arc2_yuli_quest1_324f9957:

    # yl "Muy bien, ya tengo tocas las medidas necesarias"
    yl "เรียบร้อย ได้ขนาดที่ต้องการครบหมดแล้วจ่ะ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:190
translate english arc2_yuli_quest1_98e01687:

    # n "Yuli terminó su tarea, se dio la vuelta y se marchó, dejando a [MN] solo en el vestidor"
    n "ยูริจัดการงานของเธอเสร็จ หมุนตัวเดินออกไป และปล่อยให้ [MN] อยู่ในห้องลองชุดตามลำพัง"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:191
translate english arc2_yuli_quest1_5502cecb_4:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:201
translate english arc2_yuli_quest1_cc0a3ef1:

    # yl "Muy bien, yo te haré saber cuando esté listo, ¿De acuerdo?"
    yl "โอเค เดี๋ยวถ้าเสร็จแล้วพี่จะบอกอีกทีนะจ๊ะ?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:202
translate english arc2_yuli_quest1_0d376bc1:

    # mn "S-Si... D-De verdad gracias por la ayuda"
    mn "ครับ... ข-ขอบคุณมากนะครับที่ช่วย"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:204
translate english arc2_yuli_quest1_1daa3f72:

    # yl "Un placer Cariño, por tí lo que sea"
    yl "ด้วยความยินดีจ่ะที่รัก เพื่อเธอแล้วพี่ทำได้ทุกอย่างอยู่แล้ว"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:206
translate english arc2_yuli_quest1_c237d428:

    # yl "Te enviaré un mensaje para que vengas cuando esté listo"
    yl "เดี๋ยวเสร็จแล้วพี่จะส่งข้อความไปบอกให้มารับนะจ๊ะ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:208
translate english arc2_yuli_quest1_02f0b5a3:

    # mn "Claro... Nos vemos entonces"
    mn "ครับ... ไว้เจอกันครับ"

# TODO: Translation updated at 2024-12-20 07:52

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest1.rpy:190
translate english arc2_yuli_quest1_9bf4920d:

    # yl "Muy bien, ya tengo todas las medidas necesarias"
    yl "เอาล่ะ ได้ขนาดที่ต้องการครบหมดแล้วจ่ะ"
