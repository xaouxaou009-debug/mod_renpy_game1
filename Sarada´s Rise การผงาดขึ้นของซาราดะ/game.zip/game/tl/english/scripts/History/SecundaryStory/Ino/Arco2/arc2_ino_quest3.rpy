# TODO: Translation updated at 2024-12-01 21:25

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:6
translate english arc2_ino_quest3_76d03af2:

    # n "Al día siguiente, Ino y [MN] se encuentran en la oficina del Hokage para darle el informe sobre lo ocurrido la noche anterior"
    n "วันต่อมา อิโนะและ [MN] ได้มาพบกันที่ห้องทำงานโฮคาเงะเพื่อรายงานเรื่องที่เกิดขึ้นเมื่อคืนก่อน"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:19
translate english arc2_ino_quest3_b1436b1f:

    # mn "Buen día Señor Séptimo"
    mn "สวัสดีครับ ท่านรุ่นที่เจ็ด"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:20
translate english arc2_ino_quest3_6a58d16b:

    # nt "Ino, [MN], los estaba esperando"
    nt "อิโนะ, [MN] ฉันรอกำลังพวกเธออยู่พอดีเลย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:21
translate english arc2_ino_quest3_5ead109f:

    # nt "Gracias por venir tan rápido, ¿Qué pudieron averiguar?"
    nt "ขอบคุณนะที่มากันเร็วมาก พอจะสืบรู้อะไรมาบ้างไหมล่ะ?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:22
translate english arc2_ino_quest3_ea2f603f:

    # mn "Lamentablemente, no traémos muy buenas noticias..."
    mn "น่าเสียดายครับที่เราไม่ได้เอาข่าวดีมาสักเท่าไหร่..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:23
translate english arc2_ino_quest3_cf9abab5:

    # mn "Verá..."
    mn "คือว่านะ..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:26
translate english arc2_ino_quest3_3b703f3f:

    # n "Ino y [MN] le cuentan al Hokage todo lo que vieron la noche anterior"
    n "อิโนะและ [MN] เล่าทุกสิ่งที่เห็นเมื่อคืนให้ท่านโฮคาเงะฟังจนหมดเปลือก"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:27
translate english arc2_ino_quest3_ad627f73:

    # n "Contándole que se tratan de Drones los que están siendo usado para los robos en el Centro de Investigación"
    n "เล่าให้ฟังว่ามีการใช้โดรนในการก่อเหตุขโมยของที่ศูนย์วิจัย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:28
translate english arc2_ino_quest3_75bb2fb1:

    # n "Que aunque los drones normales utilicen Chakra para funcionar, era imposible detectar el Chakra que provenía de estos drones"
    n "และถึงแม้ว่าโดรนทั่วไปจะต้องใช้จักระในการทำงาน แต่กลับเป็นไปไม่ได้เลยที่จะตรวจจับจักระที่มาจากโดรนเหล่านี้"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:29
translate english arc2_ino_quest3_3eb75b42:

    # n "Y lo más preocupante, estos drones poseen una habilidad con la cual se pueden volver invisibles o desaparecer por completo"
    n "และที่น่ากังวลที่สุดคือ โดรนพวกนี้มีความสามารถในการล่องหนหรือหายตัวไปได้อย่างสมบูรณ์"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:33
translate english arc2_ino_quest3_b6be76ea:

    # nt "Maldición..."
    nt "แย่ล่ะ..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:34
translate english arc2_ino_quest3_1949aedf:

    # nt "Esto es más grave de lo que pensaba... Si están ocultando su chakra y aparte usan tecnología aún desconocida, podrían representar una amenaza mucho mayor"
    nt "เรื่องนี้มันชักจะบานปลายกว่าที่คิดแฮะ... ถ้าพวกมันซ่อนจักระแถมยังใช้เทคโนโลยีแปลกปลอมอีก มันอาจจะกลายเป็นภัยคุกคามครั้งใหญ่ได้เลย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:35
translate english arc2_ino_quest3_0fbb19cf:

    # nt "Voy a encargarle este asunto a las fuerzas especiales Anbu para que lo investiguen más a fondo"
    nt "ฉันจะมอบหมายให้หน่วยลับอนบุเป็นคนรับเรื่องนี้ไปสืบสวนต่อเอง"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:37
translate english arc2_ino_quest3_6ddae36a:

    # nt "Lamento decir que ya no podrán participar en esta misión, pero es una decisión necesaria"
    nt "ฉันเสียใจด้วยนะที่ต้องบอกว่าพวกเธอจะไม่มีส่วนร่วมกับภารกิจนี้ต่อแล้ว แต่มันก็เป็น,การตัดสินใจที่จำเป็นน่ะนะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:38
translate english arc2_ino_quest3_2722ea86:

    # ino "Entendido..."
    ino "เข้าใจแล้วค่ะ..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:39
translate english arc2_ino_quest3_5502cecb:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:40
translate english arc2_ino_quest3_382ca2a2:

    # nt "Muy bien, muchas gracias a ambos, lamento hacerlos de lado"
    nt "งั้นก็ตามนี้ ขอบคุณทั้งสองคนมากนะ แล้วก็ขอโทษด้วยที่ต้องให้พวกเธอถอนตัว"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:42
translate english arc2_ino_quest3_f468176c:

    # ino "No hay problema, sé que yo ya no seré muy útil de ahora en adelante"
    ino "ไม่เป็นไรค่ะ ฉันรู้ว่าต่อจากนี้ไปคงช่วยอะไรได้ไม่มากเท่าไหร่แล้ว"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:43
translate english arc2_ino_quest3_85cabbbc:

    # ino "Solo espero que este asunto pueda solucionarse pronto"
    ino "ฉันแค่หวังว่าเรื่องนี้จะคลี่คลายได้เร็ว ๆ นี้ก็พอค่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:44
translate english arc2_ino_quest3_c79b1de9:

    # ino "Y si llegas a necesitar mi ayuda ya sabes que cuentas conmigo"
    ino "แล้วถ้าท่านต้องการความช่วยเหลือเมื่อไหร่ ก็รู้ใช้วัยว่าพึ่งพาฉันได้เสมอนะคะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:45
translate english arc2_ino_quest3_d0b83876:

    # nt "Muchas gracias Ino"
    nt "ขอบคุณมากนะ, อิโนะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:47
translate english arc2_ino_quest3_95dab205:

    # n "Luego de informar al Hokage, ambos son despachados de la Oficina"
    n "หลังจากรายงานให้ท่านโฮคาเงะฟังเสร็จ ทั้งสองก็ออกจากห้องทำงาน"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:49
translate english arc2_ino_quest3_44633158:

    # n "Pero tan pronto Ino sale de la Oficina..."
    n "แต่ทันทีที่อิโนะเดินออกไปจากห้อง..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:51
translate english arc2_ino_quest3_2813f3b4:

    # nt "[MN], un momento"
    nt "[MN] เดี๋ยวอยู่คุยกันก่อน"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:52
translate english arc2_ino_quest3_046571ce:

    # mn "Eh, ¿Si?"
    mn "เอ๊ะ ครับ?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:53
translate english arc2_ino_quest3_a6045eac:

    # nt "Me gustaría hablar de algo contigo, aún no te vayas"
    nt "ฉันมีเรื่องอยากจะคุยด้วยหน่อย อย่าเพิ่งรีบไปล่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:54
translate english arc2_ino_quest3_89c543e6:

    # mn "¿Qué sucede Señor?"
    mn "มีอะไรเหรอครับท่าน?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:55
translate english arc2_ino_quest3_e39dda7d:

    # nt "Sé que no te gusta que te haga a un lado en este punto"
    nt "ฉันรู้ว่าเธอไม่ชอบถูกสั่งให้ถอนตัวในสถานการณ์แบบนี้"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:56
translate english arc2_ino_quest3_5502cecb_1:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:57
translate english arc2_ino_quest3_ca8a36a8:

    # nt "Pero por tu rango actual no puedo hacer que sigas en esta misión"
    nt "แต่ด้วยระดับนินจาปัจจุบันของเธอ ฉันปล่อยให้เธอทำภารกิจนี้ต่อไม่ได้หรอก"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:58
translate english arc2_ino_quest3_d278c621:

    # mn "Lo entiendo..."
    mn "ผมเข้าใจครับ..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:60
translate english arc2_ino_quest3_651703f7:

    # nt "Por eso, quiero que te centres en entrenar para los Exámenes Chunin"
    nt "นั่นแหละคือเหตุผลที่ฉันอยากให้เธอไปโฟกัสกับการฝึกเพื่อสอบจูนินซะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:61
translate english arc2_ino_quest3_31044f68:

    # nt "Cuando seas rango chunin, tendrás el rango suficiente para aceptar más misiones importantes"
    nt "พอเธอเลื่อนขั้นเป็นจูนินแล้ว เธอก็จะมีระดับยศที่จำเป็นสำหรับการรับภารกิจสำคัญพวกนี้ได้"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:62
translate english arc2_ino_quest3_663e67ec:

    # nt "Necesito tu {b}Karugan{/a} para estos casos, serás de suma importancia"
    nt "ฉันต้องการ {b}ค{/a} ของเธอสำหรับเคสพวกนี้ เธอนับว่ามีความสำคัญสูงสุดเลยล่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:63
translate english arc2_ino_quest3_25ff9e27:

    # mn "Señor Séptimo..."
    mn "ท่านโฮคาเงะ..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:64
translate english arc2_ino_quest3_79c92699:

    # nt "Es por eso que, hice llamar a alguien para que te entrene"
    nt "นั่นแหละคือเหตุผลที่ฉันเรียกใครบางคนมาช่วยฝึกให้เธอ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:65
translate english arc2_ino_quest3_255669d0:

    # nt "Ya puedes entrar"
    nt "เข้ามาได้เลย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:71
translate english arc2_ino_quest3_4328177e:

    # n "Sarada entra a la Oficina del Hokage"
    n "ซาราดะเดินเข้าไปในห้องทำงานโฮคาเงะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:73
translate english arc2_ino_quest3_c91080be:

    # mn "¡Sarada!" with vpunch
    mn "ซาราดะ!" with vpunch

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:75
translate english arc2_ino_quest3_4543f4b3:

    # sr "Hola hola, ¿Sorprendido?"
    sr "ว่าไง ๆ แปลกใจล่ะสิ?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:77
translate english arc2_ino_quest3_0572c9b7:

    # sr "¿O estás contento? Siempre me pedías entrenar contigo, y ahora no tienes escapatoria"
    sr "หรือว่าดีใจกันแน่? เธอคอยตื๊อขอให้ฉันช่วยฝึกให้อยู่เรื่อย แล้วคราวนี้ก็หนีไม่พ้นแล้วนะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:79
translate english arc2_ino_quest3_7a01cde7:

    # mn "Claro que lo estoy, ¡Por fin!" with vpunch
    mn "ดีใจสิ ในที่สุดก็จะได้เริ่มสักที!" with vpunch

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:80
translate english arc2_ino_quest3_ef44c52f:

    # sr "Esta vez no es solo un favor, el mismo Hokage me ha asignado oficialmente para entrenarte"
    sr "คราวนี้ไม่ใช่แค่การช่วยกันส่วนตัวนะ ท่านโฮคาเงะเป็นคนมอบหมายให้ฉันมาฝึกเธออย่างเป็นทางการเลยล่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:82
translate english arc2_ino_quest3_2e8b9db9:

    # sr "Te haré mejorar en cada aspecto, será un {b}Entrenamiento Intensivo{/a}"
    sr "ฉันจะทำให้เธอเก่งขึ้นในทุก ๆ ด้าน มันจะเป็นการ {b}ฝึกแบบเข้มข้น{/a} เลยล่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:85
translate english arc2_ino_quest3_0773ada9:

    # mn "Estoy listo, he estado esperando esto por mucho tiempo"
    mn "ผมพร้อมอยู่แล้ว รอเวลานี้มาตั้งนานแล้วเหมือนกัน"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:87
translate english arc2_ino_quest3_21481054:

    # nt "Este año los exámenes Chunin serán más desafiantes que los anteriores"
    nt "ปีนี้การสอบจูนินจะท้าทายกว่าปีที่ผ่าน ๆ มา"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:88
translate english arc2_ino_quest3_08b83a8f:

    # nt "Los años anteriores se simplificaron, pero este año he decidido que volverán a ser como cuando era joven"
    nt "ปีก่อนหน้านี้มันถูกลดระดับความยากลงไป แต่ปีนี้ฉันตัดสินใจแล้วว่าจะให้มันกลับมายากเหมือนสมัยที่ฉันยังเด็ก"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:89
translate english arc2_ino_quest3_2837b779:

    # nt "Los rivales que enfrentarás también son más fuertes y experimentados de lo que imaginas"
    nt "คู่แข่งที่เธอต้องเจอเองก็แข็งแกร่งและมีประสบการณ์มากกว่าที่เธอจะจินตนาการถึงด้วยซ้ำ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:90
translate english arc2_ino_quest3_20e4b68c:

    # nt "Así que por eso este entrenamiento, debes estar listo o podrías incluso morir en los exámenes"
    nt "นั่นแหละคือเหตุผลที่เธอต้องเตรียมตัวให้พร้อมสำหรับฝึกครั้งนี้ ไม่งั้นเธออาจจะตายเอาได้จริง ๆ ตอนสอบเลยนะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:91
translate english arc2_ino_quest3_f35e90d7:

    # nt "Pero confío en tí Sarada, sé que eres la mejor para esta tarea, asegúrate de que [MN] esté preparado para lo que se avecina"
    nt "แต่ฉันเชื่อใจเธอนะซาราดะ ฉันรู้ว่าเธอเหมาะสมที่สุดสำหรับงานนี้ ช่วยทำให้ [MN] พร้อมสำหรับสิ่งที่กำลังจะมาถึงด้วยล่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:92
translate english arc2_ino_quest3_86061d4a:

    # sr "Si Señor, cuando termine con él será mucho mejor ninja de lo que es ahora"
    sr "รับทราบค่ะท่านโฮคาเงะ เมื่อฉันติวเขาเสร็จ รับรองว่าเขาจะเป็นนินจาที่เก่งขึ้นกว่าเดิมเยอะเลยล่ะค่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:93
translate english arc2_ino_quest3_549a95fe:

    # mn "¡No lo defraudaré Señor Séptimo!" with vpunch
    mn "ผมจะไม่ทำให้ผิดหวังเลยครับ ท่านโฮคาเงะ!" with vpunch

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:94
translate english arc2_ino_quest3_a252f9b9:

    # sr "Muy bien, empezarémos mañana a primera hora del día, asegúrate de {b}Completar todo lo que tengas pendiente{/a} porque ya no habrá marcha atrás"
    sr "งั้นก็ตามนี้ เราจะเริ่มกันตั้งแต่เช้ามืดพรุ่งนี้ {b}จัดการธุระที่คั่งค้างให้เรียบร้อยซะล่ะ{/a} เพราะงานนี้ไม่มีทางให้ถอยกลับหรอกนะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:95
translate english arc2_ino_quest3_d129f12a:

    # mn "Entendido"
    mn "เข้าใจแล้วครับ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:96
translate english arc2_ino_quest3_c2d8e77c:

    # sr "Bien, me retiro entonces"
    sr "งั้นฉันขอตัวก่อนล่ะกัน"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:101
translate english arc2_ino_quest3_8230d432:

    # n "Sarada sale de la Oficina del Hokage"
    n "ซาราดะเดินออกจากห้องทำงานโฮคาเงะไป"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:102
translate english arc2_ino_quest3_b7d44cc8:

    # nt "Muy bien, esfuérzate al máximo [MN], te necesito fuerte luego de los exámenes, ¿Entendido?"
    nt "ดีมาก ตั้งใจเข้าล่ะ [MN] ฉันอยากให้เธอแข็งแกร่งเข้าไว้หลังการสอบ เข้าใจไหม?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:103
translate english arc2_ino_quest3_54138933:

    # mn "¡Entendido Señor!" with vpunch
    mn "เข้าใจแล้วครับท่าน!" with vpunch

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:104
translate english arc2_ino_quest3_8dd48e79:

    # nt "Bien, así me gusta"
    nt "ดี พูดได้เข้าหูดีนี่"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:105
translate english arc2_ino_quest3_0004e16f:

    # nt "Ya puedes retirarte"
    nt "ออกไปได้แล้วล่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:108
translate english arc2_ino_quest3_6619a236:

    # n "Luego de la reunión, [MN] sale de la Oficina del Hokage"
    n "หลังจากการประชุมสิ้นสุดลง [MN] ก็เดินออกจากห้องทำงานโฮคาเงะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:121
translate english arc2_ino_quest3_9f3a8508:

    # n "Para su sorpresa, se encuentra con Ino, quien aún no se ha ido, y está acompañada por Sai"
    n "เขากลับต้องประหลาดใจเมื่อพบว่าอิโนะยังไม่ได้กลับไปไหน แถมเธอยังมากับซาอิด้วย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:122
translate english arc2_ino_quest3_4e2be656:

    # ino "Oh, [MN], me alegra que estés aquí. Déjame presentarte a mi esposo, Sai"
    ino "โอ้ [MN] ดีใจจังที่เธออยู่ตรงนี้ นี่ซาอิ สามีของฉันเองนะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:123
translate english arc2_ino_quest3_2ffa407d:

    # sa "Un placer [MN]"
    sa "ยินดีที่ได้รู้จักนะ [MN]"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:124
translate english arc2_ino_quest3_ed7c3f40:

    # mn "El placer es mío, Ino me ha hablado mucho de usted"
    mn "ยินดีเช่นกันครับ คุณอิโนะเล่าเรื่องของคุณให้ผมฟังไว้เยอะเลย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:127
translate english arc2_ino_quest3_202a52cf:

    # n "Después de un breve intercambio de saludos, Ino cambia el tema de conversación"
    n "หลังจากทักทายกันสั้น ๆ อิโนะก็เปลี่ยนเรื่องคุย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:133
translate english arc2_ino_quest3_74cc87cb:

    # ino "Sai... ¿Podríamos salir esta noche?"
    ino "ซาอิ... คืนนี้เราออกไปข้างนอกด้วยกันหน่อยได้ไหม?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:134
translate english arc2_ino_quest3_229f278d:

    # ino "Hace mucho tiempo que no tenémos tiempo juntos, ¿Qué di..."
    ino "พวกเราไม่ได้ใช้เวลาร่วมกันนานแล้วนะ เธอคิดว่า..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:138
translate english arc2_ino_quest3_7fef1866:

    # sa "Lo siento Ino, el Hokage me ha encargado una misión importante"
    sa "ขอโทษนะอิโนะ ท่านโฮคาเงะมอบหมายภารกิจสำคัญให้ฉันน่ะสิ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:140
translate english arc2_ino_quest3_9dd2f5dc:

    # ino "Pero no es necesario que vayas tú personalmente... Podrías enviar un equipo Anbu a..."
    ino "แต่เธอไม่ต้องไปทำเองด้วยก็ได้นี่นา... ส่งหน่วยลับไปจัดการแทนก็ได้ไม่ใช่เหรอ..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:141
translate english arc2_ino_quest3_10dd3196:

    # sa "No hay suficiente personal disponible entre los Anbu en este momento, así que tengo que ir yo"
    sa "ตอนนี้กำลังพลของหน่วยลับไม่พอ ฉันเลยจำเป็นต้องไปเอง"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:142
translate english arc2_ino_quest3_74d5bb90:

    # sa "También quiero ver personalmente este caso, ya me informó el Hokage de todo"
    sa "อีกอย่างฉันอยากไปดูคดีนี้ด้วยตาตัวเองด้วย ท่านโฮคาเงะแจ้งรายละเอียดทุกอย่างให้ฉันทราบหมดแล้ว"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:145
translate english arc2_ino_quest3_92e5dde9:

    # ino "..."
    ino "..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:147
translate english arc2_ino_quest3_331656eb:

    # ino "Está bien... Buena suerte con tu trabajo..."
    ino "งั้นเหรอ... ขอให้ทำงานราบรื่นนะ..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:149
translate english arc2_ino_quest3_b4c5e378:

    # ino "Yo también tengo asuntos que atender"
    ino "ฉันเองก็มีธุระต้องไปจัดการเหมือนกัน"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:153
translate english arc2_ino_quest3_ee28f661:

    # n "Ino se despide rápidamente, dejando a [MN] solo con Sai"
    n "อิโนะรีบกล่าวลา ปล่อยให้ [MN] อยู่กับซาอิสองต่อสอง"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:154
translate english arc2_ino_quest3_8e1dd396:

    # n "La incomodidad en el aire es evidente, [MN] sabe de los problemas matrimoniales entre Ino y Sai..."
    n "บรรยากาศอึดอัดลอยอบอวลไปทั่ว [MN] รู้ดีถึงปัญหาชีวิตคู่ระหว่างอิโนะกับซาอิ..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:158
translate english arc2_ino_quest3_7bd8d60d:

    # sa "*Suspiro*"
    sa "*ถอนหายใจ*"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:161
translate english arc2_ino_quest3_72cc365a:

    # sa "Las mujeres son un misterio, ¿cierto?"
    sa "ผู้หญิงนี่เข้าใจยากชะมัดว่าไหม?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:162
translate english arc2_ino_quest3_b1f9a43e:

    # sa "Las relaciones y los sentimientos nunca han sido mi fuerte, y ahora, con todo el trabajo que tengo... Se me es más difícil aprender sobre ellas..."
    sa "เรื่องความสัมพันธ์และความรู้สึกเนี่ยไม่เคยเป็นจุดเด่นของฉันเลย ยิ่งตอนนี้งานรัดตัวด้วยแล้ว... ยิ่งยากเข้าไปใหญ่ที่จะทำความเข้าใจเรื่องพวกนี้..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:163
translate english arc2_ino_quest3_c4284829:

    # mn "Pues..."
    mn "เอ่อ..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:166
translate english arc2_ino_quest3_7ea02e3d:

    # mn "A veces, es necesario dejar el trabajo de lado para tratar asuntos más importantes"
    mn "บางครั้งเราก็จำเป็นต้องพักเรื่องงานไว้ก่อนเพื่อจัดการกับเรื่องที่สำคัญกว่านะครับ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:168
translate english arc2_ino_quest3_275a7894:

    # mn "No soy quien para decirte qué hacer, pero deberías encontrar tiempo para estar con tu familia"
    mn "ผมคงไม่กล้าสั่งหรอกนะว่าคุณควรทำยังไง แต่คุณน่าจะหาเวลาอยู่กับครอบครัวบ้างนะครับ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:169
translate english arc2_ino_quest3_36d949a9:

    # n "Sai reflexiona brevemente, pero su expresión no cambia"
    n "ซาอิชะงักไปครู่หนึ่ง แต่สีหน้าของเขากลับไม่มีความเปลี่ยนแปลงเลย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:170
translate english arc2_ino_quest3_ef297690:

    # sa "Lo entiendo, pero mi trabajo es vital para la seguridad de la Aldea de la Hoja"
    sa "ฉันเข้าใจ แต่ว่างานของฉันมีความสำคัญต่อความปลอดภัยของหมู่บ้านโคโนะฮะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:171
translate english arc2_ino_quest3_1d345350:

    # sa "Si no hago mi parte, podría poner en peligro a otros, e incluso a mi familia, ahora mismo no puedo permitirme distracciones"
    sa "ถ้าฉันไม่ทำหน้าที่ของตัวเอง มันอาจเป็นอันตรายต่อคนอื่น หรือแม้แต่ครอบครัวของฉัน ตอนนี้ฉันจะปล่อยให้มีเรื่องอื่นมาดึงความสนใจไม่ได้"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:172
translate english arc2_ino_quest3_d9c6979d:

    # mn "Bueno, supongo que cada uno tiene sus prioridades..."
    mn "งั้นเหรอครับ... ดูเหมือนว่าทุกคนจะมีสิ่งที่ให้ความสำคัญเป็นอันดับแรกต่างกันสินะ..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:174
translate english arc2_ino_quest3_86673be2:

    # sa "Gracias por tu comprensión. Debo regresar al trabajo. Te deseo suerte en los exámenes"
    sa "ขอบคุณที่เข้าใจนะ ฉันต้องกลับไปทำงานก่อนล่ะ ขอให้โชคดีกับการสอบก็แล้วกัน"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:175
translate english arc2_ino_quest3_86f9563e:

    # sa "Ya deseo que trabajemos juntos"
    sa "หวังว่าเราจะได้ร่วมงานกันอีกนะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:178
translate english arc2_ino_quest3_e929058e:

    # n "Sai entra en la Oficina del Hokage, dejando a [MN] pensando..."
    n "ซาอิเดินเข้าห้องทำงานโฮคาเงะไป ปล่อยให้ [MN] จมอยู่ในห้วงความคิด..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:184
translate english arc2_ino_quest3_41a06b9a:

    # mnn "(Me pregunto... ¿Es bueno estar tan enfocado en una sola cosa es realmente lo mejor?... El trabajo es importante, pero...)"
    mnn "(ฉันสงสัยจัง... การทุ่มเทสมาธิให้กับเรื่องใดเรื่องหนึ่งมันดีที่สุดแล้วจริงๆ งั้นเหรอ?... งานน่ะมันก็สำคัญนะ แต่ว่า...)"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:186
translate english arc2_ino_quest3_0ee646d9:

    # mnn "(Ino es su esposa... Es su familia...)"
    mnn "(อิโนะเป็นภรรยาของเขานะ... เธอคือครอบครัวของเขานะ...)"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:188
translate english arc2_ino_quest3_3a8fa72a:

    # mnn "(...)"
    mnn "(...)"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:189
translate english arc2_ino_quest3_7e591d03:

    # mnn "(No entiendo como no le dedica tiempo... Yo...)"
    mnn "(ฉันไม่เข้าใจเลยจริงๆ ว่าทำไมเขาถึงไม่มีเวลาให้เธอบ้างเลย... ฉัน...)"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:190
translate english arc2_ino_quest3_3a8fa72a_1:

    # mnn "(...)"
    mnn "(...)"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:193
translate english arc2_ino_quest3_c1f29fcf:

    # mn "No puedo quedarme de brazos cruzados..." with vpunch
    mn "(จะอยู่เฉยๆ ทำเป็นไม่รู้ไม่ชี้ไม่ได้หรอก...)" with vpunch

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:195
translate english arc2_ino_quest3_cd76779d:

    # n "Decidiendo que no podía quedarse de brazos cruzados, [MN] se dirige hacia la Florería para ver cómo está Ino"
    n "หลังจากตัดสินใจได้แล้วว่าไม่อาจปล่อยให้เรื่องนี้ผ่านไปเฉยๆ [MN] จึงมุ่งหน้าไปยังร้านดอกไม้เพื่อดูอาการของอิโนะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:204
translate english arc2_ino_quest3_e1d470ba:

    # n "[MN] entra a la Florería, y para su sorpresa, encuentra a Ino con una expresión de frustración y tristeza"
    n "[MN] เดินเข้าไปในร้านดอกไม้ และต้องประหลาดใจเมื่อพบว่าอิโนะกำลังแสดงสีหน้าหงุดหงิดและเศร้าสร้อย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:205
translate english arc2_ino_quest3_3e957767:

    # mn "Ino... ¿Estás bien?"
    mn "อิโนะ... เป็นอะไรหรือเปล่าครับ?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:206
translate english arc2_ino_quest3_c96734e1:

    # mn "Si te sientes mal puedes contar conmigo..."
    mn "ถ้าไม่สบายใจ... ระบายให้ผมฟังได้นะ..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:209
translate english arc2_ino_quest3_0465e63e:

    # ino "E-Estoy... B-Bien..."
    ino "ฉ-ฉัน... ม-ไม่เป็นไร..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:210
translate english arc2_ino_quest3_7a7353c4:

    # n "Ino, al ver a [MN], intenta forzar una sonrisa, pero la tristeza es obvia en su rostro"
    n "เมื่ออิโนะเห็น [MN] เธอก็พยายามฝืนยิ้มออกมา แต่ความเศร้าบนใบหน้านั้นปิดไม่มิดเลย"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:211
translate english arc2_ino_quest3_fa7e7791:

    # n "Está temblando por la ira y tristeza que siente en ese momento..."
    n "เธอกำลังตัวสั่นด้วยความโกรธและความเสียใจที่อัดอั้นอยู่ในตอนนี้..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:214
translate english arc2_ino_quest3_e602688a:

    # n "Hasta que finalmente no lo soporta..."
    n "จนกระทั่งในที่สุด เธอก็ทนไม่ไหวอีกต่อไป..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:215
translate english arc2_ino_quest3_95cdf1a2:

    # n "Y con lágrimas en los ojos, se desahoga..."
    n "และด้วยน้ำตาที่คลอเบ้า เธอจึงระบายมันออกมา..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:217
translate english arc2_ino_quest3_6419103e:

    # ino "No..."
    ino "เปล่าเลย..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:219
translate english arc2_ino_quest3_fe915a79:

    # ino "N-No estoy bien..."
    ino "ไ-ไม่ ฉันไม่ไหวแล้ว..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:220
translate english arc2_ino_quest3_bc621203:

    # ino "Ya no lo soporto... Él..."
    ino "ฉันไม่ไหวแล้วล่ะ... เขา..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:222
translate english arc2_ino_quest3_6d3ede8e:

    # ino "Sai siempre es así, prestándole más atención a su trabajo..."
    ino "ซาอิเป็นแบบนี้ตลอด เอาแต่สนใจงานของตัวเอง..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:223
translate english arc2_ino_quest3_057a847d:

    # ino "Nunca tiene tiempo para mí..."
    ino "เขาไม่เคยมีเวลาให้ฉันเลย..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:224
translate english arc2_ino_quest3_e449f5af:

    # ino "Siento que estoy perdiendo la esperanza de que las cosas cambien..."
    ino "ฉันรู้สึกเหมือนหมดหวังแล้วว่าทุกอย่างจะเปลี่ยนแปลงไป..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:225
translate english arc2_ino_quest3_72f264c6:

    # ino "Siempre que quiero hablar con él, me evita..."
    ino "เวลาที่ฉันอยากคุยกับเขา เขาก็จะคอยหลบหน้าตลอด..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:226
translate english arc2_ino_quest3_fb23b0ec:

    # ino "Estoy cansada..."
    ino "ฉันเหนื่อยเหลือเกิน..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:228
translate english arc2_ino_quest3_c4a2303d:

    # ino "Siempre me dice que está ocupado y que lo hablará luego..."
    ino "เขาเอาแต่บอกว่ายุ่งอยู่ แล้วค่อยคุยกันทีหลัง..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:229
translate english arc2_ino_quest3_c9840427:

    # ino "Hace más de 20 años que estámos casados..."
    ino "เราแต่งงานกันมาตั้งกว่า 20 ปีแล้วนะ..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:230
translate english arc2_ino_quest3_4e437393:

    # ino "Seguramente ya se ha cansado de mí..."
    ino "เขาคงจะเบื่อฉันแล้วล่ะมั้งตอนนี้..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:232
translate english arc2_ino_quest3_e25f54a3:

    # ino "Quizás ya no le parezco atractiva..."
    ino "บางทีเขาอาจจะมองว่าฉันหมดเสน่ห์ไปแล้วก็ได้..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:233
translate english arc2_ino_quest3_0af0c793:

    # ino "O sencillamente, ya no me ama..."
    ino "หรือไม่งั้น... เขาอาจจะไม่ได้รักฉันอีกต่อไปแล้วก็ได้..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:238
translate english arc2_ino_quest3_3650afc1:

    # mn "Oye, detende ahí por favor" with vpunch
    mn "เดี๋ยวสิครับ หยุดพูดแบบนั้นเถอะนะ" with vpunch

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:240
translate english arc2_ino_quest3_ae3ccf13:

    # mn "No digas eso"
    mn "อย่าพูดแบบนั้นเลยครับ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:242
translate english arc2_ino_quest3_33f7cde1:

    # mn "No creo que ya no le parezcas hermosa a Sai, lo dudo mucho"
    mn "ผมไม่คิดหรอกนะว่าซาอิจะมองว่าคุณสวยน้อยลง ผมไม่เชื่อเรื่องนั้นเด็ดขาด"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:243
translate english arc2_ino_quest3_a3f8e1fa:

    # mn "No creo que esté tan ciego como para no ver lo increíble que eres"
    mn "ผมว่าเขาไม่ได้ตาบอดจนมองไม่เห็นหรอกนะว่าคุณยอดเยี่ยมแค่ไหน"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:244
translate english arc2_ino_quest3_0d2cc1d3:

    # mn "Trabajas arduamente todos los días para sacar adelante tu tienda y tu familia"
    mn "คุณทำงานหนักทุกวันเพื่อดูแลทั้งร้านแล้วก็ครอบครัว"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:245
translate english arc2_ino_quest3_7f2d799b:

    # mn "Además, eres una mujer hermosa"
    mn "อีกอย่าง คุณเป็นผู้หญิงที่สวยมากเลยนะครับ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:247
translate english arc2_ino_quest3_db24aba7:

    # mn "A mi parecer, eres una de las mujeres más hermosas de la Aldea de la Hoja"
    mn "ในสายตาผม คุณคือหนึ่งในผู้หญิงที่สวยที่สุดในหมู่บ้านโคโนฮะเลยล่ะครับ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:248
translate english arc2_ino_quest3_86fb4e7e:

    # mn "Y si Sai realmente ya no te ve atractiva..."
    mn "และถ้าหากซาอิไม่เห็นคุณค่าในความสวยของคุณอีกแล้วล่ะก็..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:250
translate english arc2_ino_quest3_4b66b3c1:

    # mn "Pues es realmente ciego"
    mn "งั้นเขาก็คงตาบอดสนิทแล้วล่ะครับ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:252
translate english arc2_ino_quest3_c1be68a7:

    # mn "No ve la increíble mujer que tiene a su lado"
    mn "เขาคงมองไม่เห็นผู้หญิงที่ยอดเยี่ยมที่สุดที่อยู่ข้างกายตัวเองเลยสักนิด"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:254
translate english arc2_ino_quest3_87e5a8e7:

    # n "Ino escucha atentamente cada palabra que le dice [MN]"
    n "อิโนะตั้งใจฟังทุก ๆ คำพูดของ [MN] อย่างตั้งใจ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:255
translate english arc2_ino_quest3_294c2133:

    # n "Cada una resuena muy profundo dentro de su ser"
    n "ทุกคำพูดนั้นสะท้อนลึกลงไปในจิตใจของเธอ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:256
translate english arc2_ino_quest3_402dd438:

    # n "Y sin pensarlo dos veces..."
    n "และโดยไม่ต้องคิดอะไรให้มากความ..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:260
translate english arc2_ino_quest3_b564c553:

    # n "Ino abraza a [MN] con fuerza, mientras sus lágrimas caen de sus ojos..."
    n "อิโนะก็โผเข้ากอด [MN] แน่น ในขณะที่น้ำตาไหลอาบแก้ม..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:261
translate english arc2_ino_quest3_4ba51762:

    # ino "Gracias, [MN]... De verdad muchas gracias"
    ino "ขอบคุณนะ [MN]... ขอบคุณจริง ๆ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:262
translate english arc2_ino_quest3_77af91e2:

    # n "[MN] sonríe suavemente, devolviendo el abrazo con cuidado"
    n "[MN] ยิ้มบาง ๆ พร้อมกับโอบกอดเธอกลับอย่างอ่อนโยน"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:263
translate english arc2_ino_quest3_69d8fc42:

    # mn "Siempre estaré aquí para escucharte, Ino"
    mn "ผมคอยรับฟังคุณเสมอแหละครับ อิโนะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:264
translate english arc2_ino_quest3_1371cfb9:

    # mn "No tienes que pasar por esto sola"
    mn "คุณไม่ต้องเผชิญหน้ากับเรื่องพวกนี้คนเดียวหรอกนะครับ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:265
translate english arc2_ino_quest3_0f0e8923:

    # mn "Llámame siempre que me necesites, ¿Bien?"
    mn "โทรหาผมได้ตลอดเวลาที่คุณต้องการนะ เข้าใจไหมครับ?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:266
translate english arc2_ino_quest3_f4dd1f94:

    # ino "Si ♥"
    ino "อื้ม ♥"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:267
translate english arc2_ino_quest3_fdc42ea0:

    # ino "Muchas gracias... De verdad..."
    ino "ขอบคุณมากจริง ๆ นะ..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:270
translate english arc2_ino_quest3_8389981a:

    # n "-{b}Momentos Después{/a}-"
    n "-{b}เวลาต่อมา{/a}-"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:282
translate english arc2_ino_quest3_318e0f47:

    # n "Ino ya se ha relajado"
    n "ตอนนี้อิโนะสงบสติอารมณ์ลงได้แล้ว"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:284
translate english arc2_ino_quest3_124988b3:

    # ino "Gracias de nuevo [MN]... De verdad aprecio que hayas venido..."
    ino "ขอบคุณอีกครั้งนะ [MN]... ดีใจจริง ๆ ที่เธอมา..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:286
translate english arc2_ino_quest3_3fe991a3:

    # mn "No hay de qué, para eso estamos, ¿Cierto?"
    mn "ด้วยความยินดีครับ เรามีไว้คอยช่วยเหลือกันอยู่แล้วใช่ไหมล่ะครับ?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:288
translate english arc2_ino_quest3_91d50377:

    # mn "Pero más importante, ¿Qué harás ahora?"
    mn "แต่ที่สำคัญกว่านั้น ตอนนี้คุณจะเอายังไงต่อล่ะครับ?"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:290
translate english arc2_ino_quest3_1d403584:

    # mn "No es que quiera meterme en este asunto pero..."
    mn "ไม่ใช่ว่าผมอยากจะก้าวก่ายหรอกนะ แต่ว่า..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:291
translate english arc2_ino_quest3_29a9cadb:

    # mn "No pareces feliz en tu matrimonio..."
    mn "ดูคุณจะไม่ค่อยมีความสุขกับชีวิตแต่งงานเลยนะครับ..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:293
translate english arc2_ino_quest3_5de4dcbe:

    # ino "Pues..."
    ino "อืม..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:294
translate english arc2_ino_quest3_81efc07d:

    # ino "No lo sé... Han sido más de 20 años... Y es el padre de mi hijo..."
    ino "ฉันก็ไม่รู้เหมือนกัน... ผ่านมาตั้ง 20 กว่าปีแล้ว... แล้วเขาก็เป็นพ่อของลูกฉันด้วย..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:295
translate english arc2_ino_quest3_2ceb62a3:

    # mn "Entiendo... Pero, si no eres feliz con él..."
    mn "ผมเข้าใจครับ... แต่ถ้าคุณไม่มีความสุขกับเขา..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:297
translate english arc2_ino_quest3_c0ebc59d:

    # ino "[MN], no te preocupes, estaré bien"
    ino "[MN] ไม่ต้องห่วงนะ ฉันไม่เป็นไรหรอก"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:299
translate english arc2_ino_quest3_10e233dc:

    # ino "Hace tiempo me dí cuenta que este matrimonio ya no funciona... No soy tan tonta..."
    ino "ฉันรู้ตัวมาสักพักแล้วล่ะว่าชีวิตแต่งงานนี้มันไปต่อไม่ได้แล้ว... ฉันไม่ได้ใสซื่อขนาดนั้น..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:301
translate english arc2_ino_quest3_ca3f0774:

    # ino "Tonta fui al creer que podría cambiar algo..."
    ino "ฉันเองต่างหากที่โง่เง่าที่คิดว่าจะเปลี่ยนแปลงอะไรได้..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:304
translate english arc2_ino_quest3_adb03582:

    # ino "Es solo que... Tengo que pensar bien las cosas..."
    ino "เพียงแต่ว่า... ฉันต้องขอเวลาทบทวนอะไร ๆ ให้ดีก่อน..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:306
translate english arc2_ino_quest3_60e5ed33:

    # mn "Si... No es fácil que una relación de tanto tiempo se termine así como así..."
    mn "นั่นสินะครับ... ความสัมพันธ์ที่ยาวนานขนาดนั้น มันไม่ใช่เรื่องง่ายเลยที่จะจบลงแบบนี้..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:308
translate english arc2_ino_quest3_5e45c45a:

    # mn "Pues, creo que me retiraré para que pienses mejor..."
    mn "งั้นผมขอตัวกลับก่อนดีกว่า คุณจะได้มีเวลาคิดทบทวนอะไร ๆ ได้ชัดเจนขึ้น..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:310
translate english arc2_ino_quest3_539b85a5:

    # mn "Pero ya sabes, siempre que necesites ayuda puedes contar conmigo"
    mn "แต่ก็อย่างว่านะครับ ไม่ว่าเมื่อไหร่ที่คุณต้องการความช่วยเหลือ พึ่งพาผมได้เสมอเลยนะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:312
translate english arc2_ino_quest3_d8c81446:

    # ino "Gracias por comprender... De verdad te lo agradezco..."
    ino "ขอบคุณที่เข้าใจนะ... ซาบซึ้งใจจริง ๆ..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:313
translate english arc2_ino_quest3_f306cfc1:

    # mn "No hay de qué, nos vemos pronto Ino"
    mn "ด้วยความยินดีครับ แล้วเจอกันนะ อิโนะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:315
translate english arc2_ino_quest3_eef1bec2:

    # ino "Nos vemos, estaré observándote bien durante los Exámenes Chunin"
    ino "แล้วเจอกัน ฉันจะคอยจับตาดูเธอให้ดีระหว่างการสอบจููนินเลยล่ะ"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:318
translate english arc2_ino_quest3_f3ed771e:

    # n "Con una despedida, [MN] sale de la Florería, dejando a Ino más relajada"
    n "หลังจากกล่าวอำลา [MN] ก็เดินออกจากร้านดอกไม้ไป ทำให้อิโนะรู้สึกผ่อนคลายขึ้นมาบ้าง"

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:319
translate english arc2_ino_quest3_bb2cf764:

    # n "..."
    n "..."

# game/scripts/History/SecundaryStory/Ino/Arco2/arc2_ino_quest3.rpy:323
translate english arc2_ino_quest3_84aa4093:

    # n "Aunque su problema aún no se ha solucionado..."
    n "แม้ว่าปัญหาของคุณจะยังไม่ได้รับการแก้ไข...ก็ตามที"

