# TODO: Translation updated at 2024-11-29 23:49

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:5
translate english arc2_hanna_quest1_ad82385f:

    # "-{b}Por la noche en el Hospital{/a}-"
    "-{b}ตกดึก ณ โรงพยาบาล{/a}-"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:15
translate english arc2_hanna_quest1_f901f9fe:

    # mn "Hola Hanna, lamento haberte hecho esperar"
    mn "ฮันนะ ขอโทษที่ปล่อยให้รอนะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:16
translate english arc2_hanna_quest1_f10646a4:

    # hn "[MN], que alegría verte, no te preocupes"
    hn "[MN] ดีใจจังที่ได้เจอคุณ ไม่เป็นไรเลยค่ะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:17
translate english arc2_hanna_quest1_070395b3:

    # mn "Aún así lo siento, hoy fue un día un poco largo jaja"
    mn "ถึงอย่างนั้นก็เถอะ ขอโทษด้วยนะ วันนี้ยาวนานไปหน่อย ฮ่าๆ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:20
translate english arc2_hanna_quest1_a0134b2f:

    # hn "Oh, ¿De verdad? Si quieres podemos salir otro día para que descanses"
    hn "อ้าว เหรอคะ? ถ้าอยากพักผ่อน เราเลื่อนไปวันอื่นก็ได้นะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:22
translate english arc2_hanna_quest1_385a497c:

    # mn "No no, claro que no, no puedo dejarte plantada cuando fui yo quien te invitó a salir"
    mn "ไม่ๆ แน่นอนอยู่แล้ว ผมจะเบี้ยวนัดคุณได้ยังไงในเมื่อผมเป็นคนชวนคุณมาเอง"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:26
translate english arc2_hanna_quest1_61ba4582:

    # hn "Bueno jaja, ¿Pero seguro estás bien?"
    hn "งั้นเหรอคะ ฮ่าๆ แต่แน่ใจนะว่าไหว?"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:29
translate english arc2_hanna_quest1_f69888ff:

    # mn "Por supuesto, no hay nada que pueda pararme, de veras"
    mn "แน่นอน ไม่มีอะไรหยุดผมได้หรอก เอาจริงนะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:32
translate english arc2_hanna_quest1_b507df67:

    # hn "Bien, eso me alegra jaja"
    hn "ดีจัง ฟังแล้วค่อยชื่นใจหน่อย ฮ่าๆ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:34
translate english arc2_hanna_quest1_c22f12df:

    # mn "Bueno, ¿Nos vamos ya?"
    mn "งั้น เราไปกันเลยไหม?"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:35
translate english arc2_hanna_quest1_f0ae3911:

    # hn "Claro, ¿Dónde irémos?"
    hn "ได้สิคะ ว่าแต่เราจะไปไหนกันดีล่ะ?"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:37
translate english arc2_hanna_quest1_fe78a5f4:

    # mn "Mmm, hay muchos lugares a los que comer en la aldea..."
    mn "อืม ในหมู่บ้านมีร้านของกินตั้งหลายร้านนะ..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:39
translate english arc2_hanna_quest1_e4266ee3:

    # mn "Dime, ¿Qué te gustaría comer? Hoy invito yo"
    mn "ว่ามาสิ อยากกินอะไรเป็นพิเศษไหม? วันนี้ผมเลี้ยงเอง"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:42
translate english arc2_hanna_quest1_65879a46:

    # hn "Veamos..."
    hn "อืม..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:43
translate english arc2_hanna_quest1_c07731d4:

    # hn "Me gustan las cosas heladas... Aunque ya es tarde para eso..."
    hn "ฉันชอบอะไรเย็นๆ นะคะ... ถึงจะดึกไปหน่อยก็เถอะ..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:46
translate english arc2_hanna_quest1_de456fac:

    # hn "¡Oh! ¡Ya sé!" with vpunch
    hn "อ๊ะ! รู้แล้วค่ะ!" with vpunch

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:48
translate english arc2_hanna_quest1_52bba081:

    # hn "¿Qué tal el Ramen? Es mi comida favorita"
    hn "ราเม็งเป็นไงคะ? ของโปรดฉันเลยล่ะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:49
translate english arc2_hanna_quest1_3a5871d7:

    # mn "¡¿De verdad?!" with vpunch
    mn "จริงเหรอ?!" with vpunch

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:50
translate english arc2_hanna_quest1_43ecb3fa:

    # mn "¡La mía igual!"
    mn "ผมก็เหมือนกัน!"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:52
translate english arc2_hanna_quest1_e0d210e6:

    # hn "¿De verdad? Jajaja"
    hn "จริงเหรอคะ? ฮ่าๆๆ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:54
translate english arc2_hanna_quest1_4bbd09c8:

    # mn "Bien, pues vamos a comer el mejor Ramen de la aldea"
    mn "งั้นไปกินราเม็งที่อร่อยที่สุดในหมู่บ้านกันเถอะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:55
translate english arc2_hanna_quest1_cf37b84f:

    # mn "Vamos a Ichiraku Ramen"
    mn "ไปร้านราเม็งอิจิราคุ ูกัน"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:57
translate english arc2_hanna_quest1_b6202fc4:

    # hn "¡Yeeiii!"
    hn "เย้!"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:60
translate english arc2_hanna_quest1_7de560aa:

    # n "[MN] y Hanna partieron hacia {b}Ichiraku Ramen{/a}"
    n "[MN] กับฮันนะมุ่งหน้าไปยัง {b}ร้านราเม็งอิจิราคุ{/a}"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:61
translate english arc2_hanna_quest1_17753b1a:

    # n "Ambos parecían ir muy contentos"
    n "ทั้งคู่ดูมีความสุขกันมาก"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:62
translate english arc2_hanna_quest1_e9931635:

    # n "Pero, eso no duraría por mucho tiempo..."
    n "แต่ความสุขนั้นคงอยู่ได้ไม่นาน..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:71
translate english arc2_hanna_quest1_8fe4cac1:

    # hn "¿De verdad pasó eso?"
    hn "เรื่องนั้นเกิดขึ้นจริงๆ เหรอคะ?"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:73
translate english arc2_hanna_quest1_cd56d689:

    # mn "Si jaja, luego Hideo hizo..."
    mn "จริงสิ ฮ่าๆ แล้วฮิเดโอะก็ทำ..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:78
translate english arc2_hanna_quest1_2e4dc47b:

    # d "¡HANNAA!" with vpunch
    d "ฮันนะ!" with vpunch

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:80
translate english arc2_hanna_quest1_576c0153:

    # hn "..." with dissolve1
    hn "..." with dissolve1

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:83
translate english arc2_hanna_quest1_45d8ea00:

    # hn "No... No puede ser"
    hn "ไม่... เป็นไปไม่ได้สิ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:95
translate english arc2_hanna_quest1_aa735819:

    # hn "Tú, pensé que ya me dejarías tranquila"
    hn "แก นึกว่าป่านนี้จะเลิกยุ่งกับฉันไปแล้วซะอีก"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:98
translate english arc2_hanna_quest1_9d80efcd:

    # tkd "Hanna... ¿Q-Qué haces... *Hip*"
    tkd "ฮันนะ... ท-ทำไมเธอถึง... *เอื๊อก*"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:99
translate english arc2_hanna_quest1_7e5b5bd3:

    # tkd "¿Con otro hombre...? *Hip*"
    tkd "ไปอยู่กับผู้ชายคนอื่นล่ะเนี่ย...? *เอื๊อก*"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:101
translate english arc2_hanna_quest1_289bc85d:

    # mn "¿Lo conoces?"
    mn "เธอรู้จักเขาเหรอ?"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:102
translate english arc2_hanna_quest1_30fe482a:

    # hn "Si... Desafortunadamente..."
    hn "ค่ะ... น่าเสียดายที่... รู้จัก..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:103
translate english arc2_hanna_quest1_54bf10e5:

    # tkd "Hanna... ¿Quien es este tipo?..."
    tkd "ฮันนะ... ไอ้งั่งนี่มันใครกัน...?"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:104
translate english arc2_hanna_quest1_6e3de54e:

    # tkd "¡HABLA!" with vpunch
    tkd "พูดสิฟะ!" with vpunch

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:107
translate english arc2_hanna_quest1_f53f465f:

    # hn "E-Eso no te incumbe... Y-Ya no somos nada, déjame t-tranquila..."
    hn "ม-มันไม่ใช่เรื่องสักหน่อย... พ-พวกเราไม่ได้เป็นอะไรกันแล้วนะ ปล่อยฉัน-ฉันไปเถอะ..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:110
translate english arc2_hanna_quest1_b5ecc29d:

    # hn "P-Por... Por favor... D-Déjame..."
    hn "ช-ช่วยด้วย... ป-ปล่อยฉันไป..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:112
translate english arc2_hanna_quest1_13fb885b:

    # mnn "(Tiene mucho miedo...)"
    mnn "(เธอกลัวจริงๆ ด้วยแฮะ...)"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:113
translate english arc2_hanna_quest1_93c93568:

    # mnn "(Sea quien sea este tipo, no puedo dejar que le hable de esa forma)"
    mnn "(ไม่ว่าไอ้หมอนี่จะเป็นใคร แต่ฉันจะปล่อยให้มันมาพูดจาแบบนี้กับเธอไม่ได้หรอก)"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:114
translate english arc2_hanna_quest1_0ce77ec6:

    # mnn "(Peor aún que le haga daño)"
    mnn "(แถมยิ่งทำให้เธอเจ็บช้ำอีก ยิ่งยอมไม่ได้ใหญ่)"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:121
translate english arc2_hanna_quest1_a1148b4e:

    # mn "¿Tienes algún problema con ella?"
    mn "มีปัญหากับเธอหรือไง?"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:126
translate english arc2_hanna_quest1_2b29cd1c:

    # mn "Ella viene conmigo."
    mn "เธอจะไปกับฉัน"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:127
translate english arc2_hanna_quest1_1523fe20:

    # d "..."
    d "..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:128
translate english arc2_hanna_quest1_4f5e8f7c:

    # tkd "¡¿Y tú quién *HIP* carajos eres?!" with vpunch
    tkd "แ-แล้วแกเป็นห่* *เอื๊อก* ไหนวะเนี่ย?!" with vpunch

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:130
translate english arc2_hanna_quest1_842c6969:

    # mnn "(Está ebrio...)"
    mnn "(มันเมาอยู่นี่หว่า...)"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:131
translate english arc2_hanna_quest1_4afc4d9a:

    # mnn "(Será mejor no dejar que se acerque)"
    mnn "(อย่าปล่อยให้มันเข้าใกล้ดีกว่า)"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:132
translate english arc2_hanna_quest1_81299aa0:

    # mnn "(En ese estado no quiero saber de lo que es capaz)"
    mnn "(ในสภาพนี้ ไม่อยากจะคิดเลยว่ามันจะทำอะไรบ้าๆ ได้บ้าง)"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:134
translate english arc2_hanna_quest1_bcf90c75:

    # mn "Si no tienes nada que atender con Hanna te pido por favor que te marches"
    mn "ถ้าไม่มีธุระอะไรกับฮันนะแล้ว ก็เชิญไสหัวไปซะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:135
translate english arc2_hanna_quest1_d7f5b976:

    # d "*Hip*"
    d "*เอื๊อก*"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:136
translate english arc2_hanna_quest1_51b82c93:

    # tkd "Mmm... ¿Y qué te hace pensar que me iré...?"
    tkd "หึ... แล้วอะไรทำให้แกคิดว่าฉันจะไปกันล่ะ...?"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:137
translate english arc2_hanna_quest1_f736f508:

    # mn "Si no lo haces tendré que llamar a la Seguridad"
    mn "ถ้าไม่ไป ฉันคงต้องเรียกเจ้าหน้าที่รักษาความปลอดภัยแล้วล่ะนะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:138
translate english arc2_hanna_quest1_0cab1313:

    # mn "No creo que quieras pasar la noche tras las rejas"
    mn "ฉันว่าแกคงไม่อยากไปนอนในคุกหรอกมั้ง"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:139
translate english arc2_hanna_quest1_1523fe20_1:

    # d "..."
    d ".. "

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:141
translate english arc2_hanna_quest1_1912702e:

    # d "Tch..."
    d "ชิ..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:142
translate english arc2_hanna_quest1_4153b3bb:

    # tkd "Me iré por hoy... Pero Hanna... *Hip*"
    tkd "วันนี้ฉันจะยอมไปก่อนก็แล้วกัน... แต่ฮันนะ... *เอื๊อก*"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:143
translate english arc2_hanna_quest1_292cd857:

    # tkd "Recuérda esto... Haga lo que tenga que hacer, volverémos a estar juntos..."
    tkd "จำไว้ให้ดี... ไม่ว่าฉันจะต้องทำยังไง เราจะได้กลับมาอยู่ด้วยกันอีกแน่..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:144
translate english arc2_hanna_quest1_6794f145:

    # tkd "Quieras o no..."
    tkd "ไม่ว่าเธอจะต้องการมันหรือไม่ก็ตาม..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:147
translate english arc2_hanna_quest1_ebc21715:

    # n "El hombre desconocido se va, dejando a [MN] y Hanna solos"
    n "ชายปริศนาเดินจากไป ปล่อยให้ [MN] และฮันนะอยู่กันตามลำพัง"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:152
translate english arc2_hanna_quest1_e1d2c49b:

    # hn "..."
    hn "..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:155
translate english arc2_hanna_quest1_3101d4e7:

    # mn "*suspiro*... ¿Estás bien?" with dissolve1
    mn "*ถอนหายใจ*... เธอโอเคไหม?" with dissolve1

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:157
translate english arc2_hanna_quest1_31815e66:

    # hn "S-Si... Ahora estoy mejor..."
    hn "พ-ค่ะ... ตอนนี้ดีขึ้นแล้ว..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:158
translate english arc2_hanna_quest1_986991d7:

    # mn "Ven... Entrémos..."
    mn "ไป... เข้าข้างในกันเถอะ..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:159
translate english arc2_hanna_quest1_0bee17cd:

    # hn "Si..."
    hn "ค่ะ..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:162
translate english arc2_hanna_quest1_51ad4db7:

    # n "Luego de encontrarse con un tipo borracho, [MN] y Hanna entran a Ichiraku Ramen"
    n "หลังจากเจอเรื่องชายขี้เมา [MN] และฮันนะก็พากันเข้าไปในร้านราเม็งอิจิราคุ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:163
translate english arc2_hanna_quest1_09825817:

    # n "Después de pedir su órden y calmarse, Hanna está lista para contarle su historia a [MN]"
    n "หลังจากสั่งอาหารและสงบสติอารมณ์ลง ฮันนะก็พร้อมที่จะเล่าเรื่องของเธอให้ [MN] ฟังแล้ว"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:172
translate english arc2_hanna_quest1_2bdf44d2:

    # mn "¿Ya estás mejor?"
    mn "เธอรู้สึกดีขึ้นหรือยังล่ะ?"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:173
translate english arc2_hanna_quest1_abf6b53b:

    # hn "Si, ya lo estoy"
    hn "ค่ะ ดีขึ้นแล้วล่ะค่ะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:176
translate english arc2_hanna_quest1_35172669:

    # hn "Jeje, de verdad lamento mucho que tuvieras que presenciar eso..."
    hn "แหะๆ ต้องขอโทษด้วยจริงๆ นะคะที่ทำให้ต้องมาเห็นเรื่องแบบนั้น..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:179
translate english arc2_hanna_quest1_154a0c73:

    # hn "Pensé que ya se había ido de la aldea..."
    hn "ฉันนึกว่าเขาออกจากหมู่บ้านไปแล้วซะอีก..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:181
translate english arc2_hanna_quest1_dcdc0a0f:

    # mn "¿Quién es ese tipo?"
    mn "หมอนั่นเป็นใครเหรอ?"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:183
translate english arc2_hanna_quest1_e1d2c49b_1:

    # hn "..."
    hn "..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:185
translate english arc2_hanna_quest1_32c28024:

    # hn "Se llama {b}Takuya{/a}... Es un Ninja de Rango {b}Chunin{/a} y..."
    hn "เขาชื่อ {b}ทาคุยะ{/a} ค่ะ... เป็นนินจาระดับ {b}จูนิน{/a} แล้วก็..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:187
translate english arc2_hanna_quest1_2425acae:

    # hn "Es mi Ex..."
    hn "เขาเป็นแฟนเก่าของฉันเองค่ะ..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:189
translate english arc2_hanna_quest1_61aa4cac:

    # mn "¿Tu ex-novio?"
    mn "แฟนเก่าของเธอเหรอ?"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:191
translate english arc2_hanna_quest1_5b26836e:

    # hn "Si... Viví con el durante un tiempo..."
    hn "ค่ะ... ฉันเคยอยู่กินกับเขาอยู่พักหนึ่ง..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:193
translate english arc2_hanna_quest1_a598ddac:

    # hn "Pero desde hace unos meses terminé con él, porque lo encontré siéndome infiel"
    hn "แต่เมื่อไม่กี่เดือนก่อน ฉันบอกเลิกเขาเพราะจับได้ว่าเขานอกใจน่ะค่ะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:194
translate english arc2_hanna_quest1_5502cecb:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:196
translate english arc2_hanna_quest1_107f5e9a:

    # hn "Así que por eso lo terminé, pero desde entonces no ha dejado de acosarme"
    hn "ฉันเลยตัดสินใจตัดความสัมพันธ์ แต่ตั้งแต่นั้นมาเขาก็ตามรังควานฉันไม่เลิกเลยค่ะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:197
translate english arc2_hanna_quest1_84af5fe3:

    # hn "Pero ya tenía más de un mes sin hacerlo, así que pensé que ya se había cansado de molestarme"
    hn "แต่มันก็ผ่านมาเดือนกว่าแล้วนะที่เขาไม่ได้ทำอะไรแบบนั้น ฉันก็นึกว่าเขาจะเลิกรามือไปแล้วซะอีก"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:198
translate english arc2_hanna_quest1_bbaf4aaf:

    # mn "Pero parece que ha vuelto..."
    mn "แต่ดูท่าทางแล้วเขาจะกลับมาสินะ..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:199
translate english arc2_hanna_quest1_0bee17cd_1:

    # hn "Si..."
    hn "ค่ะ..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:200
translate english arc2_hanna_quest1_4099c8ff:

    # hn "A veces siento que no debería hablar de esto, pero..."
    hn "บางครั้งฉันก็รู้สึกว่าไม่ควรเอาเรื่องพวกนี้มาพูดเลย แต่ว่า..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:202
translate english arc2_hanna_quest1_0c79ad4a:

    # hn "Aunque he tratado de ser fuerte sola, hay momentos en que... Es simplemente demasiado"
    hn "ถึงฉันจะพยายามเข้มแข็งด้วยตัวเองมาตลอด แต่มันก็มีบางช่วงเหมือนกัน... ที่มันไม่ไหวจริงๆ น่ะค่ะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:204
translate english arc2_hanna_quest1_82f0e01d:

    # mn "No tienes que guardarte todo, es bueno desahogarse con alguien, ¿Sabes?"
    mn "เธอไม่ต้องเก็บทุกอย่างไว้คนเดียวหรอกนะ ระบายให้ใครฟังบ้างมันก็ดีไม่ใช่เหรอ?"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:206
translate english arc2_hanna_quest1_517685ed:

    # hn "¿Con quién...? Realmente no tengo a nadie que me escuche..."
    hn "กับใครล่ะคะ...? ฉันไม่มีใครคอยรับฟังเลยจริงๆ นะ..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:208
translate english arc2_hanna_quest1_8e0c0307:

    # hn "Ni familia, ni amigos... Nada..."
    hn "ไม่มีครอบครัว ไม่มีเพื่อน... ไม่มีเลยสักคน..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:209
translate english arc2_hanna_quest1_5502cecb_1:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:211
translate english arc2_hanna_quest1_62e4fe6e:

    # mn "Bueno, ahora me tienes a mí, ¿Entendido?"
    mn "งั้นตอนนี้ก็มีฉันแล้วนี่ เข้าใจไหม?"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:213
translate english arc2_hanna_quest1_7e814d3e:

    # hn "¿Eh?"
    hn "เอ๊ะ?"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:215
translate english arc2_hanna_quest1_a5186fe2:

    # mn "De veras, si en algún momento te sientes mal y quieres desahogarte, cuenta conmigo"
    mn "เอาจริงนะ ถ้าเมื่อไหร่ที่รู้สึกแย่แล้วอยากระบายล่ะก็ พึ่งพาฉันได้เลย"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:217
translate english arc2_hanna_quest1_4e500e61:

    # mn "Incluso si solo quieres hablar de cualquier cosa, cuenta conmigo"
    mn "ต่อให้แค่อยากคุยเรื่องอะไรเรื่อยเปื่อย พึ่งพาฉันได้เสมอนะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:219
translate english arc2_hanna_quest1_4897789c:

    # hn "Pero... ¿No será mucha molestia?"
    hn "แต่ว่า... มันจะไม่เป็นการรบกวนมากเกินไปเหรอคะ?"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:220
translate english arc2_hanna_quest1_c665d01b:

    # mn "Para nada, soy muy bueno escuchando"
    mn "ไม่เลยสักนิด ฉันเป็นผู้ฟังที่ดีนะจะบอกให้"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:223
translate english arc2_hanna_quest1_f68d8e5a:

    # hn "Bueno, si es así no puedo negarme jaja"
    hn "ถ้าอย่างนั้นล่ะก็ ฉันคงปฏิเสธไม่ลงแล้วล่ะค่ะ ฮ่าๆ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:226
translate english arc2_hanna_quest1_e1d2c49b_2:

    # hn "..."
    hn "..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:229
translate english arc2_hanna_quest1_a72d93e2:

    # hn "¿Sabes? También hay algo que no puedo evitar pensar... La mayoría del tiempo siento que fue mi culpa por haber estado con alguien así"
    hn "รู้ไหมคะ? มันยังมีอีกเรื่องหนึ่งที่ฉันอดคิดไม่ได้... ส่วนใหญ่แล้วฉันมักจะรู้สึกว่ามันเป็นความผิดของฉันเองที่ไปคบกับคนแบบนั้น"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:232
translate english arc2_hanna_quest1_f1118ba3:

    # hn "Como si, de alguna forma, yo hubiera provocado todo esto... Tal vez no fui suficiente para él, o hice algo mal..."
    hn "ราวกับว่า... ไม่ทางใดก็ทางหนึ่ง ฉันเป็นคนก่อเรื่องทั้งหมดนี้ขึ้นมาเอง... บางทีฉันอาจจะดีไม่พอสำหรับเขา หรือฉันอาจจะทำอะไรผิดไป..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:234
translate english arc2_hanna_quest1_bef1810c:

    # hn "No sé, a veces me siento atrapada en la idea de que si yo hubiera sido diferente, tal vez él no me habría traicionado..."
    hn "ก็ไม่รู้สินะคะ บางครั้งฉันก็รู้สึกเหมือนติดอยู่กับความคิดที่ว่า ถ้าฉันทำตัวแตกต่างออกไปอีกนิด เขากคงไม่หักหลังฉัน..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:235
translate english arc2_hanna_quest1_5502cecb_2:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:238
translate english arc2_hanna_quest1_e2aafbc3:

    # mn "Hanna, nada de esto es culpa tuya"
    mn "ฮันนะ เรื่องทั้งหมดนี้ไม่ใช่ความผิดของเธอเลยสักนิด"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:239
translate english arc2_hanna_quest1_2062e5a7:

    # mn "Lo que él hizo fue una decisión que tomó por sí mismo, sin pensar en ti y sin considerar lo que tenían juntos"
    mn "สิ่งที่เขาทำมันเป็นการตัดสินใจของเขาเอง โดยไม่นึกถึงเธอและไม่เห็นคุณค่าในสิ่งที่มีร่วมกันเลย"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:240
translate english arc2_hanna_quest1_b2c337c4:

    # mn "Eso no depende de lo que hicieras o dejaras de hacer"
    mn "เรื่องนั้นมันไม่ได้ขึ้นอยู่กับว่าเธอทำอะไรหรือไม่ได้ทำอะไรหรอกนะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:242
translate english arc2_hanna_quest1_b77b9697:

    # hn "Si... Eso es lo que me digo a mí misma... Pero no puedo dejar de pensar que si yo hubiera sido un poco más comprensiva, o más fuerte, tal vez habría sido diferente"
    hn "นั่นสินะคะ... ฉันก็บอกตัวเองแบบนั้นแหละ... แต่ก็อดคิดไม่ได้ว่า ถ้าฉันรู้จักเข้าใจให้มากกว่านี้อีกนิด หรือเข้มแข็งกว่านี้อีกหน่อย บางทีมันอาจจะต่างออกไปก็ได้"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:244
translate english arc2_hanna_quest1_d7a03793:

    # mn "Entiendo que te sientas así, pero no debes cargar con esa culpa. Quien te ama, te respeta y se compromete, no toma ese tipo de decisiones"
    mn "ฉันเข้าใจนะว่าเธอรู้สึกแบบนั้น แต่เธอไม่ควรแบกรับความรู้สึกผิดพวกนั้นไว้หรอก คนที่รักเธอ ให้เกียรติเธอ และซื่อสัตย์กับเธอ เขาไม่ตัดสินใจทำเรื่องแย่ๆ แบบนั้นหรอกนะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:246
translate english arc2_hanna_quest1_585d3e60:

    # mn "Fuiste valiente al dejarlo atrás, porque mereces estar con alguien que te valore de verdad y que no te haga dudar de ti misma"
    mn "เธอมีความกล้ามากนะที่ตัดสินใจเดินออกมาจากจุดนั้น เพราะเธอคู่ควรกับการได้อยู่กับคนที่เห็นคุณค่าในตัวเธออย่างแท้จริง และไม่ทำให้เธอต้องมานั่งสงสัยในตัวเองต่างหาก"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:247
translate english arc2_hanna_quest1_7007c208:

    # mn "Nadie merece que le traicionen, todos merecemos una relación basada en el respeto y la honestidad"
    mn "ไม่มีใครสมควรถูกหักหลังหรอกนะ พวกเราทุกคนต่างก็คู่ควรกับความสัมพันธ์ที่ตั้งอยู่บนพื้นฐานของความเคารพและความซื่อสัตย์ทั้งนั้นแหละ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:248
translate english arc2_hanna_quest1_26098c82:

    # mn "Él fue el que rompió esa confianza, no tú"
    mn "คนที่ทำลายความเชื่อใจนั้นคือเขา ไม่ใช่เธอ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:249
translate english arc2_hanna_quest1_7a6e1c64:

    # mn "Si realmente le importabas, habría hecho todo lo posible por cuidar lo que tenían, pero fue él quien decidió no hacerlo"
    mn "ถ้าเขาแคร์เธอจริงๆ เขาคงทำทุกวิถีทางเพื่อรักษาความสัมพันธ์ของพวกเธอไว้แล้ว แต่มันเป็นเขาเองต่างหากที่เลือกจะไม่ทำ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:252
translate english arc2_hanna_quest1_e1d2c49b_3:

    # hn "..."
    hn "..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:254
translate english arc2_hanna_quest1_57effbd6:

    # hn "Gracias... Escuchar a alguien más decir eso me hace sentir que quizá no esté tan equivocada al intentar seguir adelante"
    hn "ขอบคุณนะคะ... พอได้ยินคนอื่นพูดแบบนี้แล้ว ทำให้ฉันรู้สึกว่าสิ่งที่ฉันพยายามจะก้าวต่อไปข้างหน้านี่ มันอาจจะไม่ใช่เรื่องที่ผิดสินะคะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:255
translate english arc2_hanna_quest1_1fac2ff0:

    # hn "Aunque es difícil, me hace bien oírlo de alguien más"
    hn "ถึงมันจะยาก แต่พอได้ยินมาจากปากคนอื่นแล้วก็รู้สึกดีจังเลยค่ะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:258
translate english arc2_hanna_quest1_2dd3b889:

    # mn "Me alegra escuchar eso"
    mn "ดีใจที่ได้ยินแบบนั้นนะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:260
translate english arc2_hanna_quest1_8dbcf96f:

    # mn "Lo único que importa ahora eres tú, y asegurarnos de que él no vuelva a hacerte daño"
    mn "สิ่งที่สำคัญที่สุดตอนนี้คือตัวเธอเอง และต้องมั่นใจว่าเขาจะไม่มีทางทำร้ายเธอได้อีก"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:263
translate english arc2_hanna_quest1_7e814d3e_1:

    # hn "¿Eh?"
    hn "เอ๊ะ?"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:265
translate english arc2_hanna_quest1_85455efe:

    # mn "Si vuelve a molestarte, quiero que me lo digas. No dejaré que te toque ni un solo pelo"
    mn "ถ้ามันกล้ามา 2 รบกวนเธออีก ฉันอยากให้เธอบอกฉันนะ ฉันจะไม่ยอมให้มันได้แตะต้องตัวเธอแม้แต่นิดเดียวเลย"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:267
translate english arc2_hanna_quest1_62b8f381:

    # mn "Me comprometo a protegerte de cualquier peligro"
    mn "ฉันสัญญาว่าจะปกป้องเธอจากอันตรายทั้งปวงเอง"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:268
translate english arc2_hanna_quest1_3379d526:

    # hn "¿De verdad harías eso por mí?"
    hn "จะ... จะทำเพื่อฉันขนาดนั้นเลยเหรอคะ?"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:270
translate english arc2_hanna_quest1_a59bc282:

    # mn "Por supuesto, ¿Para qué entreno si no es para proteger a las personas de la Aldea de la Hoja?"
    mn "แน่นอนสิ ฉันฝึกฝนไปเพื่ออะไรล่ะถ้าไม่ใช่เพื่อปกป้องผู้คนในหมู่บ้านโคโนฮะน่ะ?"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:272
translate english arc2_hanna_quest1_e287f3c8:

    # mn "Y si eso incluye protegerte a ti, entonces cuenta conmigo para lo que sea"
    mn "และถ้ามันหมายถึงการได้ปกป้องเธอด้วยล่ะก็ พึ่งพาฉันได้ทุกเรื่องเลยนะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:274
translate english arc2_hanna_quest1_f1bbb337:

    # hn "Gracias [MN]... De verdad, no sabes cuánto significa para mí escuchar eso"
    hn "ขอบคุณนะคะ [MN]... จริงๆ นะ เธอไม่รู้หรอกว่าการได้ยินแบบนั้นมันมีความหมายกับฉันมากแค่ไหน"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:276
translate english arc2_hanna_quest1_ddc1eea6:

    # mn "Sin problema, de veras"
    mn "ไม่เป็นไรเลยจริงๆ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:279
translate english arc2_hanna_quest1_b50fce9b:

    # n "Luego de pasar un rato en Ichiraku disfrutando de la compañía y del Ramen, ambos salen sintiéndose más relajados"
    n "หลังจากใช้เวลาร่วมกันที่ร้านอิจิราคุเพลิดเพลินกับบรรยากาศและราเม็ง ทั้งสองก็แยกย้ายกันไปด้วยความรู้สึกที่ผ่อนคลายขึ้น"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:287
translate english arc2_hanna_quest1_8da8902a:

    # mn "Aaaah... Estuvo delicioso"
    mn "อ่า... อร่อยเป็นบ้าเลยแฮะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:289
translate english arc2_hanna_quest1_ef2ff2c3:

    # mn "No pensé que pudieras igualarme comiendo Ramen"
    mn "ไม่คิดเลยนะเนี่ยว่าเธอจะกินราเม็งสู้กับฉันได้สูสีขนาดนี้"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:290
translate english arc2_hanna_quest1_b78a76f2:

    # mn "Comiste la misma cantidad de tazones que yo"
    mn "เล่นซัดไปซะเท่ากับจำนวนชามที่ฉันกินเลย"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:292
translate english arc2_hanna_quest1_9993af8f:

    # hn "Jeje, no mentía cuando dije que el Ramen es mi comida favorita"
    hn "แหะๆ ฉันไม่ได้โกหกสักหน่อยตอนที่บอกว่าราเม็งคือของโปรดน่ะค่ะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:295
translate english arc2_hanna_quest1_ffdc2371:

    # mn "Eso veo jaja"
    mn "งั้นหรอกเหรอเนี่ย ฮ่าๆ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:298
translate english arc2_hanna_quest1_e1d2c49b_4:

    # hn "..."
    hn "..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:300
translate english arc2_hanna_quest1_40865022:

    # hn "¿Sabes?, Creo que no había tenido una noche tan... Tranquila en mucho tiempo"
    hn "รู้ไหมคะ? ฉันไม่ได้รู้สึกว่า... ได้ใช้เวลาในยามค่ำคืนที่สงบสุขแบบนี้มานานมากแล้วล่ะค่ะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:301
translate english arc2_hanna_quest1_f78fbdbd:

    # hn "Es algo que necesitaba..."
    hn "มันเป็นสิ่งที่ฉันต้องการจริงๆ..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:303
translate english arc2_hanna_quest1_e032de91:

    # hn "También me encantó tu compañía"
    hn "ฉันมีความสุขมากเลยนะคะที่ได้อยู่กับเธอ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:305
translate english arc2_hanna_quest1_4f842e46:

    # mn "A mí también me encantó"
    mn "ฉันก็มีความสุขเหมือนกัน"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:306
translate english arc2_hanna_quest1_5dc56536:

    # mn "Ahora, ¿Nos vamos ya? Se está haciendo un poco tarde"
    mn "งั้น... เรากลับกันเลยไหม? นี่ก็เริ่มดึกมากแล้วนะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:308
translate english arc2_hanna_quest1_ab445cc5:

    # hn "Eh, ¿Adónde?"
    hn "เอ๊ะ, ไปไหนเหรอคะ?"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:309
translate english arc2_hanna_quest1_b5f28d96:

    # mn "A tu casa"
    mn "ไปส่งที่บ้านเธอยังไงล่ะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:311
translate english arc2_hanna_quest1_7b20788f:

    # hn "¡¿A-A mi casa?!" with vpunch
    hn "ป... ไปส่งที่บ้านฉันเหรอคะ?!" with vpunch

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:312
translate english arc2_hanna_quest1_0bfade25:

    # mn "Si, no puedo dejarte sola a altas horas de la noche"
    mn "ใช่สิ จะให้ปล่อยให้เธอดึกดื่นขนาดนี้คนเดียวได้ยังไงล่ะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:314
translate english arc2_hanna_quest1_cce5eb63:

    # mn "Más si ese tipo anda por ahí"
    mn "ยิ่งไอ้เวรนั่นยังป้วนเปี้ยนอยู่แถวนี้ด้วยแล้ว"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:319
translate english arc2_hanna_quest1_24f1551b:

    # hn "Aah, si..."
    hn "อ่า... ค่ะ..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:321
translate english arc2_hanna_quest1_a1875168:

    # hn "Vamos entonces, es por aquí"
    hn "งั้นเราไปกันเถอะค่ะ ทางนี้เลย"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:324
translate english arc2_hanna_quest1_995d7aaf:

    # n "Hanna guía a [MN] a su Apartamento"
    n "ฮันนะพา [MN] เดินทางไปยังอพาร์ตเมนต์ของเธอ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:333
translate english arc2_hanna_quest1_b4f9a449:

    # hn "Ya llegamos, bienvenido a mi humilde morada"
    hn "ถึงแล้วค่ะ ยินดีต้อนรับสู่บ้านหลังเล็กๆ ของฉันนะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:335
translate english arc2_hanna_quest1_cf31c509:

    # hn "Lamento si es un Apartamento muy pequeño y no está muy amueblado"
    hn "ขอโทษด้วยนะคะที่ห้องมันเล็กแล้วก็แทบไม่มีเฟอร์นิเจอร์อะไรเลย"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:336
translate english arc2_hanna_quest1_7a409094:

    # hn "Me mudé hasta hace unas semanas"
    hn "ฉันเพิ่งย้ายเข้ามาอยู่ได้ไม่กี่สัปดาห์เองค่ะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:337
translate english arc2_hanna_quest1_0491fd0d:

    # mn "No te preocupes por eso"
    mn "ไม่ต้องคิดมากเรื่องนั้นหรอก"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:339
translate english arc2_hanna_quest1_98f1969c:

    # mn "Yo llevo ya unos años en la aldea y te juro que tengo menos que tú"
    mn "ฉันอยู่ในหมู่บ้านนี้มาหลายปีแล้ว แต่กล้าพูดเลยว่าข้าวของฉันมีน้อยกว่าเธอซะอีก"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:341
translate english arc2_hanna_quest1_e0d210e6_1:

    # hn "¿De verdad? Jajaja"
    hn "จริงเหรอคะ? ฮ่าๆๆ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:344
translate english arc2_hanna_quest1_e1d2c49b_5:

    # hn "..."
    hn "..."

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:348
translate english arc2_hanna_quest1_d7404718:

    # hn "[MN], quiero darte las gracias por todo lo de hoy"
    hn "[MN] ขอบคุณสำหรับทุกๆ อย่างในวันนี้จริงๆ นะคะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:350
translate english arc2_hanna_quest1_dab38d00:

    # mn "No es nada, solo hice lo que debía"
    mn "ไม่มีอะไรหรอก ฉันก็แค่ทำสิ่งที่ควรทำเท่านั้นเอง"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:351
translate english arc2_hanna_quest1_d25b46be:

    # hn "No, en serio. Me divertí mucho contigo esta noche, necesitaba un respiro de todo lo que ha estado pasando en mi vida"
    hn "เปล่านะคะ จริงๆ นะ วันนี้ฉันสนุกมากๆ เลยล่ะค่ะ ได้พักสมองจากเรื่องวุ่นๆ หลายอย่างในชีวิตไปได้เยอะเลย"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:353
translate english arc2_hanna_quest1_70a2458e:

    # mn "Me alegra haber ayudado un poco, yo también me divertí contigo, disfruté mucho tu compañia"
    mn "ดีใจที่ช่วยได้นิดหน่อยนะ ฉันเองก็สนุกเหมือนกัน เพลิดเพลินมากเลยที่ได้อยู่กับเธอเนี่ย"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:355
translate english arc2_hanna_quest1_9e7b2f67:

    # mn "¿Te gustaría que hiciéramos esto otra vez? Tal vez podríamos visitar otro lugar la próxima vez"
    mn "ไว้คราวหน้าเราไปเที่ยวกันอีกไหม? เผื่อคราวหน้าจะได้ลองไปที่อื่นดูบ้าง"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:357
translate english arc2_hanna_quest1_7e5cce89:

    # hn "Eso suena genial, estaría encantada de salir contigo de nuevo"
    hn "ฟังดูเข้าท่าเลยค่ะ ฉันอยากออกไปเที่ยวกับเธออีกจัง"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:359
translate english arc2_hanna_quest1_8de4b41c:

    # hn "También gracias por estar conmigo hoy, por escucharme y protegerme... Eso significa más de lo que imaginas"
    hn "แล้วก็... ขอบคุณนะคะที่อยู่เป็นเพื่อนฉันวันนี้ ขอบคุณที่คอยรับฟังแล้วก็ปกป้องฉัน... มันมีความหมายกับฉันมากเกินกว่าที่เธอจะจินตนาการได้เลยล่ะค่ะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:361
translate english arc2_hanna_quest1_426779e8:

    # hn "Puedes buscarme en el hospital siempre que quieras salir. Me encantaría verte más seguido"
    hn "ถ้าอยากชวนฉันไปไหน ก็มาหาฉันที่โรงพยาบาลได้เสมอนะคะ ฉันอยากเจอเธอให้บ่อยขึ้นเหมือนกัน"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:362
translate english arc2_hanna_quest1_cc48d7db:

    # hn "Mi turno termina a las {b}8:00 pm{/b}, así que no lo olvides"
    hn "กะเวลาเลิกงานของฉันคือ {b}20:00 น.{/b} นะคะ อย่าลืมล่ะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:363
translate english arc2_hanna_quest1_3aa3016c:

    # mn "Entendido, te visitaré siempre que pueda"
    mn "รับทราบ ไว้ว่างเมื่อไหร่จะแวะไปหาแล้วกัน"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:364
translate english arc2_hanna_quest1_58a9a46c:

    # mn "Ahora, creo que es hora de que me vaya"
    mn "งั้น... ฉันคงต้องขอตัวกลับก่อนล่ะนะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:365
translate english arc2_hanna_quest1_8cf16704:

    # hn "Cuídate en el camino, ¿Sí? No quiero que te pase nada"
    hn "เดินทางกลับดีๆ นะคะ? ฉันไม่อยากให้มีอะไรเกิดขึ้นกับเธอหรอกนะ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:367
translate english arc2_hanna_quest1_3d81a4fe:

    # mn "No te preocupes, muy pocos son capaces de hacerme algo de daño"
    mn "ไม่ต้องห่วง มีคนไม่กี่คนหรอกที่จะทำอันตรายฉันได้"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:370
translate english arc2_hanna_quest1_87ec08ef:

    # hn "Muy bien jajaja"
    hn "ก็ได้ค่ะ ฮ่าๆๆ"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:372
translate english arc2_hanna_quest1_698efa8e:

    # mn "Descansa, Hanna... Nos vemos pronto"
    mn "พักผ่อนเยอะๆล่ะ ฮันนะ... แล้วเจอกัน"

# game/scripts/History/SecundaryStory/Hanna/Arco2/arc2_hanna_quest1.rpy:377
translate english arc2_hanna_quest1_55fd25dc:

    # n "Luego de dejar a Hanna segura, [MN] sale y se dirige a su apartamento"
    n "หลังจากแน่ใจว่าฮันนะปลอดภัยแล้ว [MN] ก็เดินออกจากที่นั่นแล้วมุ่งหน้ากลับอพาร์ตเมนต์ของตัวเอง"

