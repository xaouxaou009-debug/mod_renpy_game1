# TODO: Translation updated at 2024-11-29 23:49

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2_1.rpy:11
translate english arc2_yuli_quest2_1_46877d2e:

    # mnn "¿Mmm?"
    mnn "อืม?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2_1.rpy:13
translate english arc2_yuli_quest2_1_4656017e:

    # mn "Un mensaje de Yuli, ¿A esta hora?"
    mn "ข้อความจากยูริ ในเวลานี้เนี่ยนะ?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2_1.rpy:22
translate english arc2_yuli_quest2_1_3854d094:

    # mnn "Mmmm..."
    mnn "อืม..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2_1.rpy:26
translate english arc2_yuli_quest2_1_de89add6:

    # mn "Está bien..."
    mn "เอาล่ะ..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2_1.rpy:27
translate english arc2_yuli_quest2_1_52639b1f:

    # mn "¿Qué se tiene la mamá de Yuna conmigo?"
    mn "แม่ของยูนะมีธุระอะไรกับฉันกันนะ?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2_1.rpy:28
translate english arc2_yuli_quest2_1_3660d29b:

    # mn "Desde que corté con Yuna ha estado muy..."
    mn "ตั้งแต่เลิกกับยูนะไป เธอก็ดูจะ..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2_1.rpy:29
translate english arc2_yuli_quest2_1_01186097:

    # mn "¿Coqueta?"
    mn "อ่อยฉันเหรอ?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2_1.rpy:32
translate english arc2_yuli_quest2_1_3485c2d9:

    # mn "No sé, se siente raro"
    mn "ก็ไม่รู้สิ รู้สึกแปลกๆ ยังไงก็ไม่รู้"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2_1.rpy:34
translate english arc2_yuli_quest2_1_cb082249:

    # mn "Igual, mi traje ya está listo, ya quiero verlo"
    mn "ช่างเถอะ ชุดสูทของฉันเสร็จแล้ว ฉันอยากไปดูตอนนี้เลย"

