

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:14
translate english ayame_quest3_c0a3bb6f:

    # mn "Hola Ayame, ¿qué tal estás?"
    mn "สวัสดีอายาเมะ เป็นยังไงบ้าง?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:17
translate english ayame_quest3_b62c00fa:

    # ay "[MN], todo bien, ¿Tú qué tal estás?"
    ay "[MN] ทุกอย่างเรียบร้อยดี แล้วเธอล่ะเป็นไงบ้าง?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:19
translate english ayame_quest3_bb274225:

    # ay "¿Cómo sigue tu ojo?"
    ay "ตาของเธอเป็นยังไงบ้างแล้วล่ะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:21
translate english ayame_quest3_d39d07f8:

    # mn "Pues, más o menos, como puedes ver ahora es amarillo..."
    mn "ก็... พอไหวล่ะนะ อย่างที่เธอเห็นตอนนี้มันเป็นสีเหลือง..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:24
translate english ayame_quest3_1878b0f4:

    # ay "A mí me gusta como se te ve"
    ay "ฉันชอบลุคนี้ของเธอนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:27
translate english ayame_quest3_3961cfdc:

    # mn "¿Te gusta?"
    mn "เธอชอบงั้นเหรอ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:30
translate english ayame_quest3_b064732e:

    # ay "Es diferente y muy llamativo, te hace ver como un tipo rudo"
    ay "มันดูแปลกตาแล้วก็สะดุดตาดีนะ ทำให้เธอดูเป็นพวกสตรีทตัวฉกาจเลยล่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:32
translate english ayame_quest3_490a7df3:

    # ay "Más antes..."
    ay "แถมก่อนหน้านี้...?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:34
translate english ayame_quest3_610b0db3:

    # ay "¿Te he dicho que traes un aura de chico malo?"
    ay "ฉันเคยบอกเธอรึยังนะว่าเธอดูมีออร่าแบดบอยน่ะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:37
translate english ayame_quest3_38c86c8e:

    # mn "¿Qué?"
    mn "หา?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:40
translate english ayame_quest3_8163b6c6:

    # ay "Deberías sacar ventaja de ello, a las chicas nos suelen gustar los chicos así"
    ay "เธอควรใช้ประโยชน์จากจุดนี้นะ พวกผู้หญิงมักจะชอบผู้ชายแนวนี้ซะด้วยสิ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:43
translate english ayame_quest3_e08fb962:

    # mn "¿Te refieres a los típicos chicos malos de carácter frío?"
    mn "หมายถึงพวกแบดบอยมานิ่ง ๆ คลูลๆ งั้นเหรอ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:46
translate english ayame_quest3_6c73e65f:

    # ay "Una actitud cerrada e independiente llama mucho la atención"
    ay "ท่าทีที่ดูเข้าถึงยากแล้วก็มีความเป็นตัวของตัวเองสูงเนี่ย มันดึงดูดสายตาได้ดีมากเลยนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:48
translate english ayame_quest3_fec7174c:

    # ay "Sin mencionar que cuando logramos estar con alguien así nos hace sentir protegidas"
    ay "แถมเวลาที่เราได้อยู่ใกล้คนที่ทำให้อารมณ์ประมาณนั้น มันยังทำให้เรารู้สึกปลอดภัยอีกด้วย"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:51
translate english ayame_quest3_d2805f6b:

    # mn "Mmm... ¿Tú te sientes protegida conmigo?"
    mn "อืม... แล้วเธอล่ะ รู้สึกปลอดภัยเวลาอยู่กับฉันรึเปล่า?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:54
translate english ayame_quest3_37f3f970:

    # ay "..."
    ay "..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:56
translate english ayame_quest3_9de4b2c6:

    # ay "Sígueme al callejón, y te lo diré..."
    ay "ตามฉันมาที่ตรอกนั่นสิ แล้วเดี๋ยวฉันจะบอกให้..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:59
translate english ayame_quest3_2ab0d582:

    # mn "Bueno..."
    mn "ก็ได้..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:62
translate english ayame_quest3_e9f246ce:

    # n "Sigues a Ayame hasta el callejón"
    n "คุณเดินตามอายาเมะไปที่ตรอก"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:74
translate english ayame_quest3_3741eaeb:

    # ay "Llegamos..."
    ay "ถึงแล้วล่ะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:79
translate english ayame_quest3_eae396c4:

    # mn "¿Ahora vas a contestarme lo que te pregunté antes?"
    mn "ทีนี้จะยอมตอบคำถามที่ฉันถามไปก่อนหน้านี้ได้รึยัง?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:81
translate english ayame_quest3_e09fad1d:

    # ay "Mmm, no sé de qué me hablas..."
    ay "อืม ฉันไม่เห็นรู้เลยว่าเธอพูดถึงอะไร..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:84
translate english ayame_quest3_64041954:

    # mn "¿Qué?, ¿Como qué no?"
    mn "หา? เธอไม่รู้จริง ๆ หรือเนี่ย?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:87
translate english ayame_quest3_6bc8037d:

    # ay "Tengo mala memoria..."
    ay "ฉันความจำไม่ค่อยดีซะด้วยสิ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:90
translate english ayame_quest3_df4d9999:

    # mn "Te pregunté si te sentías protegida conmigo..."
    mn "ฉันถามเธอไปต่างหากว่า รู้สึกปลอดภัยเวลาอยู่กับฉันรึเปล่า..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:93
translate english ayame_quest3_6ba72bff:

    # ay "Ah, eso..."
    ay "อ่า เรื่องนั้นเอง..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:95
translate english ayame_quest3_2f08ac05:

    # ay "Jajaja, sí, es solo que quería enseñarte otra cosa..."
    ay "ฮ่าๆ ใช่แล้ว พอดีฉันแค่อยากจะให้ดูอย่างอื่นด้วยน่ะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:98
translate english ayame_quest3_edf20453:

    # mn "¿Qué querías enseñarme?"
    mn "เธออยากจะให้ฉันดูอะไรล่ะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:101
translate english ayame_quest3_40ff2002:

    # ay "A bromear"
    ay "วิธีหยอกล้อน่ะสิ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:104
translate english ayame_quest3_5c02acf3:

    # mn "¿Bromear?"
    mn "เธออยากจะสอนวิธีหยอกล้อให้ฉันงั้นเหรอ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:107
translate english ayame_quest3_9b73a0ac:

    # ay "Sí, ya sabes, una pequeña broma nunca está demás"
    ay "ใช่แล้ว รู้ไหม การหยอกล้อกันนิด ๆ หน่อย ๆ มันไม่เสียหายหรอกนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:110
translate english ayame_quest3_86792780:

    # mn "Bromear, entiendo..."
    mn "การหยอกล้อ งั้นเหรอ... เข้าใจแล้ว..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:114
translate english ayame_quest3_6a356bb5:

    # mn "(Eso me recordó, a Yuna...)"
    mn "(นั่นทำให้ฉันนึกถึง... ยูนะเลย)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:115
translate english ayame_quest3_75abd175:

    # mn "(Bromeaba mucho, aunque a veces no podía distinguir cuando era broma y cuando lo decía en serio...)"
    mn "(เธอชอบหยอกเล่นบ่อย ๆ แม้ว่าบางครั้งฉันจะแยกไม่ออกเลยว่าอันไหนล้อเล่นหรืออันไหนพูดจริงก็ตาม...)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:119
translate english ayame_quest3_39348389:

    # ay "Y respecto a tu pregunta..."
    ay "ส่วนเรื่องคำถามของเธอน่ะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:122
translate english ayame_quest3_cc9bdd32:

    # mn "¿Sí?"
    mn "ว่าไงล่ะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:125
translate english ayame_quest3_60ab5a8e:

    # ay "Tú no solo me haces sentir protegida"
    ay "เธอไม่ได้แค่ทำให้ฉันรู้สึกปลอดภัยอย่างเดียวนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:127
translate english ayame_quest3_670df7b6:

    # ay "El que hayas aceptado estas prácticas conmigo me hizo sentir deseada de cierto modo"
    ay "การที่เธอยอมรับที่จะมาฝึกอะไรแบบนี้กับฉัน มันทำให้ฉันรู้สึกเหมือนว่าตัวเองเป็นที่ปรารถนาในอีกรูปแบบหนึ่งด้วยเหมือนกัน"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:130
translate english ayame_quest3_05fa778c:

    # mn "¿Por qué lo dices?"
    mn "ทำไมถึงพูดแบบนั้นล่ะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:133
translate english ayame_quest3_142a0bfb:

    # ay "Porque perfectamente pudiste no hacerlo"
    ay "ก็เพราะว่าเธอจะปฏิเสธไม่ทำมันเลยก็ได้นี่นา"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:135
translate english ayame_quest3_d44e24b9:

    # ay "Y es por eso quiero ayudarte"
    ay "และนั่นแหละคือเหตุผลที่ฉันอยากจะช่วยเธอน่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:138
translate english ayame_quest3_333c3b4a:

    # mn "Y yo te agradezco mucho por ello"
    mn "แล้วก็... ขอบคุณเธอมากจริง ๆ นะสำหรับเรื่องนั้น"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:140
translate english ayame_quest3_5d326d4d:

    # mn "Intento esforzarme al máximo para que esto no sea en vano"
    mn "ฉันพยายามทำให้ดีที่สุด เพื่อไม่ให้ความช่วยเหลือของเธอต้องสูเปล่า"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:143
translate english ayame_quest3_e01d6939:

    # ay "Me aseguraré que no"
    ay "ฉันจะทำให้แน่ใจว่ามันจะไม่สูเปล่าแน่"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:145
translate english ayame_quest3_55ca322d:

    # ay "Pasemos a la siguiente lección"
    ay "ไปลุยบทเรียนต่อไปกันเถอะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:148
translate english ayame_quest3_1e1caafe:

    # mn "¿Cuál es?"
    mn "บทเรียนไหนล่ะเนี่ย?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:151
translate english ayame_quest3_a216380d:

    # ay "Besarme"
    ay "จูบฉันสิ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:155
translate english ayame_quest3_31806a14:

    # mn "¡¿Besarte?!"
    mn "จูบเธองั้นเหรอ?!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:158
translate english ayame_quest3_988aad35:

    # ay "Quiero saber que tan bueno eres besando..."
    ay "ฉันก็แค่อยากรู้ว่าเธอน่ะจูบเก่งแค่ไหน..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:161
translate english ayame_quest3_36ebb4dd:

    # mn "Ehh, no soy tan bueno..."
    mn "โถ่ ฉันไม่ได้เก่งขนาดนั้นหรอก..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:164
translate english ayame_quest3_0f146fe8:

    # ay "Estoy aquí para enseñarte, ¿no?"
    ay "ฉันก็อยู่ตรงนี้เพื่อสอนเธอไงล่ะ จริงไหม?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:167
translate english ayame_quest3_ea3ea7c2:

    # mn "Sí, supongo que puedes ayudarme con eso..."
    mn "อื้ม ฉันเดาว่าเธอคงช่วยฉันเรื่องนั้นได้สินะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:169
translate english ayame_quest3_b3d1f2d3:

    # mn "Es sólo qué me sorprendió que me lo dijeras así de repente"
    mn "ก็แค่ตกใจนิดหน่อยที่เธอจู่ๆ ก็พูดออกมาแบบนั้นน่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:172
translate english ayame_quest3_e6aa4af1:

    # ay "Habrá ocasiones en dónde la chica puede ser muy directa, debes estar preparado para eso"
    ay "มันจะมีบางครั้งที่ผู้หญิงเขาอาจจะพูดตรงๆ เลยล่ะ นายควรจะเตรียมตัวรับมือไว้ด้วยนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:175
translate english ayame_quest3_1f708400:

    # mn "¿Tú crees?"
    mn "เธอคิดงั้นจริงๆ เหรอ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:178
translate english ayame_quest3_315477d7:

    # ay "Algunas podrían hacer algo como..."
    ay "บางคนก็อาจจะทำแบบ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:183
translate english ayame_quest3_3fe9be71:

    # ay "¡Esto!"
    ay "แบบนี้ไง!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:186
translate english ayame_quest3_5bd88f13:

    # mn "(¡S-Simplemente se lanzó!)"
    mn "(มะ-เธอจู่โจมเข้ามาดื้อๆ เลยแฮะ!)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:187
translate english ayame_quest3_56d827fb:

    # mn "(Joder, menudo deja vu acaba de venir a mi mente...)"
    mn "(บ้าเอ๊ย ความรู้สึกเดจาวูอะไรเนี่ย แวบเข้ามาในหัวฉันซะได้...)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:188
translate english ayame_quest3_ef9d4de1:

    # mn "(Yuna solía hacer este tipo de cosas)"
    mn "(ยูนะก็ชอบทำอะไรแบบนี้เหมือนกันแฮะ)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:189
translate english ayame_quest3_c5c7d749:

    # ay "¿No quieres hacer algo más?"
    ay "ไม่อยากทำอะไรอย่างอื่นต่อแล้วเหรอ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:190
translate english ayame_quest3_aa41ca90:

    # mn "(¿Algo más)"
    mn "(อย่างอื่นงั้นเหรอ)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:191
translate english ayame_quest3_1f459696:

    # mn "(Ah, tengo una idea, lo leí en un libro de {b}Haciéndolo en el Paraíso{/a})"
    mn "(โอ๊ะ ฉันมีไอเดียแล้วล่ะ เคยอ่านเจอในหนังสือเรื่อง {b}เมคกิง อิท อิน แพราไดซ์{/a} น่ะ)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:192
translate english ayame_quest3_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:193
translate english ayame_quest3_c2e8db38:

    # mn "(Puedo intentar eso...)"
    mn "(ลองดูหน่อยละกัน...)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:194
translate english ayame_quest3_e396b030:

    # mn "(Tan sólo espero que no se enoje, después de todo ella fue la que me incitó hacerlo)"
    mn "(หวังว่าเธอจะไม่โกรธนะ ก็เล่นเป็นคนบอกให้ฉันทำเองนี่นา)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:200
translate english ayame_quest3_d9688ec9:

    # ay "¡!"
    ay "!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:201
translate english ayame_quest3_38092938:

    # ay "Mmm, eso me gusta..."
    ay "อื้ม ฉันชอบนะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:202
translate english ayame_quest3_bd04fef3:

    # mn "¿Te gusta...?"
    mn "เหรอ...?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:203
translate english ayame_quest3_d73c1f32:

    # ay "Me encanta..."
    ay "ฉันชอบมากเลยล่ะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:205
translate english ayame_quest3_bf89b71c:

    # mn "(Bien, ya le estoy agarrando la onda a esto...)"
    mn "(โอเค เริ่มเข้าที่เข้าทางแล้วแฮะ...)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:206
translate english ayame_quest3_f851856f:

    # mn "(Tal vez si hubiera intentado esto con Yuna...)"
    mn "(ถ้าเกิดว่าลองทำแบบนี้กับยูนะตั้งแต่ตอนนั้นล่ะก็นะ...)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:207
translate english ayame_quest3_3a74f742:

    # mn "(Agh, al diablo con esa perra...)"
    mn "(เฮ้อ ช่างหัวอีเวรนั่นสิ...)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:213
translate english ayame_quest3_c3ec33a0:

    # ay "Bien, eso es todo por hoy"
    ay "งั้นวันนี้ก็พอแค่นี้แหละ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:216
translate english ayame_quest3_d67797b2:

    # mn "¿Como lo hice?"
    mn "ฉันทำเป็นยังไงบ้างล่ะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:219
translate english ayame_quest3_65390830:

    # ay "Lo hiciste bien, aunque aún debes mejorar mucho"
    ay "ทำได้ดีเลยล่ะ ถึงแม้ว่านายยังต้องพัฒนาอีกเยอะเลยก็เถอะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:222
translate english ayame_quest3_bc8f5663:

    # mn "¿Te gustó lo que hice? Pensé que te enojarías"
    mn "เธอชอบที่ฉันทำเมื่อกี้เหรอ? ฉันนึกว่าเธอจะโกรธซะอีก"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:225
translate english ayame_quest3_1bf735d2:

    # ay "Si me gustó, y solo por eso te ganaste una recompensa jeje"
    ay "ชอบสิ และเพราะเรื่องนั้นเลยทำให้นายได้รางวัลด้วยนะ ฮิๆ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:228
translate english ayame_quest3_d0f32ff4:

    # mn "¿Una recompensa?"
    mn "รางวัลเหรอ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:233
translate english ayame_quest3_bac9697f:

    # mn "¡O-Oye!"
    mn "ด-เดี๋ยวสî!"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:234
translate english ayame_quest3_8a12ff89:

    # mn "¿Q-Qué haces?"
    mn "ท-ทำอะไรน่ะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:235
translate english ayame_quest3_00cf0bfb:

    # ay "Relájate, estoy preparando tu recompensa"
    ay "ผ่อนคลายหน่อยสิ ฉันกำลังเตรียมรางวัลให้นายอยู่นะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:242
translate english ayame_quest3_3fb00182:

    # ay "Tarán..."
    ay "เซอร์ไพรส์..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:245
translate english ayame_quest3_37529391:

    # mn "¿Q-Qué?"
    mn "อ-อะไรนะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:248
translate english ayame_quest3_831996b0:

    # ay "Lo hiciste muy bien hoy, campeón"
    ay "วันนี้นายทำได้ดีมากเลยนะ แชมป์เปี้ยน"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:250
translate english ayame_quest3_5a109e44:

    # ay "No sé como se te ocurrió, pero..."
    ay "ไม่รู้หรอกนะว่าไปเอาไอเดียนั้นมาจากไหน แต่ว่า..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:253
translate english ayame_quest3_f3533c99:

    # ay "Esta es tu recompensa por ello"
    ay "นี่คือรางวัลสำหรับเรื่องนั้นไงล่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:256
translate english ayame_quest3_5f6bd335:

    # mn "¿Lo dices en serio?"
    mn "เอาจริงดิ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:259
translate english ayame_quest3_993f04c6:

    # ay "Para que pienses en mí..."
    ay "จะได้ให้นายเอาไว้คิดถึงฉันยังไงล่ะ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:264
translate english ayame_quest3_06ef63db:

    # mn "No estoy del todo seguro de esto pero, las aceptaré"
    mn "ฉันก็ไม่ค่อยแน่ใจเท่าไหร่หรอกนะ แต่... จะรับไว้ก็แล้วกัน"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:267
translate english ayame_quest3_b97fe7dd:

    # ay "Bien, es hora de irnos..."
    ay "โอเค ได้เวลาไปแล้ว..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:270
translate english ayame_quest3_91b32938:

    # mn "Bien, en la próxima lección me esforzaré el doble"
    mn "โอเค บทเรียนหน้าฉันจะพยายามให้หนักเป็นสองเท่าเลย"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:273
translate english ayame_quest3_8bc5c645:

    # ay "Más te vale, si lo sigues haciendo así de bien te seguiré recompensado"
    ay "ให้มันจริงเถอะ ถ้านายยังทำได้ดีแบบนี้อีก ฉันจะมีรางวัลให้เรื่อย ๆ เลยนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:276
translate english ayame_quest3_cae9aa1e:

    # mn "Claro jaja"
    mn "ได้เลย ฮ่าๆ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:279
translate english ayame_quest3_2b59152a:

    # ay "Adiosito"
    ay "บ่าย, บาย"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest3.rpy:283
translate english ayame_quest3_2e345f20:

    # mn "A-Adiós"
    mn "บ-บาย"
