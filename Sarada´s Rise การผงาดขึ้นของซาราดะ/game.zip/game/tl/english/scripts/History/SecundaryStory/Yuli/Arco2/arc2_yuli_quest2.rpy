# TODO: Translation updated at 2024-11-29 23:49

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:6
translate english arc2_yuli_quest2_1e93a833:

    # n "[MN] se dirige rápidamente a la tienda de Yuli"
    n "[MN] รีบมุ่งหน้าไปยังร้านของยูริอย่างรวดเร็ว"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:7
translate english arc2_yuli_quest2_609a2c75:

    # n "Fue corriendo lo más rápido posible, estaba emocionado por ver su nuevo traje"
    n "เขาออกวิ่งให้เร็วที่สุดเท่าที่จะทำได้ด้วยความตื่นเต้นที่จะได้เห็นชุดใหม่ของตัวเอง"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:8
translate english arc2_yuli_quest2_a8cc09ec:

    # n "Pero al entrar"
    n "แต่พอเดินเข้าไปในร้าน..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:10
translate english arc2_yuli_quest2_676fd0ab:

    # d "¡Aaah!" with vpunch
    d "อ๊าคา!" with vpunch

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:11
translate english arc2_yuli_quest2_a8f6f141:

    # mn "(Mierda, ¿Porqué siempre me pasa esto)"
    mn "(ให้ตายสิ ทำไมเรื่องแบบนี้ต้องเกิดขึ้นกับฉันอยู่เรื่อยเลยนะ)"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:12
translate english arc2_yuli_quest2_7ed4b20d:

    # mn "(Me estoy cansando, para ser un ninja siempre me toman por sorpresa)"
    mn "(เริ่มเบื่อหน่ายกับเรื่องแบบนี้เต็มทีแล้ว ในฐานะนินจาแต่ทำไมถึงปล่อยให้ตัวเองโดนโจมตีทีเผลออยู่ได้เรื่อยเลย)"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:13
translate english arc2_yuli_quest2_8d7ec0f3:

    # mn "(Debo disculparme rápido)"
    mn "(ต้องรีบขอโทษก่อนล่ะนะ)"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:14
translate english arc2_yuli_quest2_1793d183:

    # mn "L-Lo siento... No fue intencional..."
    mn "ผ-ผมขอโทษครับ... มันไม่ได้ตั้งใจ..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:15
translate english arc2_yuli_quest2_1309b137:

    # n "[MN] se disculpa con la persona frente a él, pero..."
    n "[MN] รีบกล่าวขอโทษคนที่อยู่ตรงหน้า แต่ทว่า..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:16
translate english arc2_yuli_quest2_94875c72:

    # mn "De verdad no era mi..."
    mn "มันไม่ได้ตั้งใจจริง ๆ นะ..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:21
translate english arc2_yuli_quest2_63457250:

    # yn "Tú... ¡IDIOTA!" with vpunch
    yn "แก... เจ้าบ้าเอ๊ย!" with vpunch

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:22
translate english arc2_yuli_quest2_a32bb617:

    # n "[MN] no pensó que se chocaría con la mismísima Yuna..."
    n "[MN] ไม่เคยคาดคิดเลยว่าคนที่จะเดินชนเข้าให้นั้นจะไม่ใช่ใครอื่นนอกจากยูนะ..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:23
translate english arc2_yuli_quest2_f6801202:

    # mn "Esto va a doler..."
    mn "(งานนี้เจ็บตัวแน่ ๆ...)"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:27
translate english arc2_yuli_quest2_05afc368:

    # n "Con un golpe de Yuna, [MN] quedó inconsciente"
    n "ด้วยหมัดเดียวจากยูนะ ทำให้ [MN] สลบเหมือดไปทันที"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:28
translate english arc2_yuli_quest2_bb2cf764:

    # n "..."
    n "..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:29
translate english arc2_yuli_quest2_40047495:

    # n "Y al despertar..."
    n "และเมื่อรู้สึกตัวตื่นขึ้นมา..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:30
translate english arc2_yuli_quest2_ecdfba4f:

    # mn "Mmmm..."
    mn "อืมมม..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:35
translate english arc2_yuli_quest2_8ec3043a:

    # d "Vaya vaya, ¿Ya despertaste?"
    d "แหม ๆ ในที่สุดก็ตื่นแล้วงั้นเหรอ?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:36
translate english arc2_yuli_quest2_9dd667b5:

    # mn "Mmm, ¿Qué?"
    mn "อืม อะไรนะ?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:37
translate english arc2_yuli_quest2_6a819e33:

    # mn "Mmmm... ¿Señora Yuli?"
    mn "อืม... คุณยูริเหรอครับ?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:38
translate english arc2_yuli_quest2_071d48ea:

    # yl "Buenos días Cariño, ¿Ya te encuentras mejor?"
    yl "อรุณสวัสดิ์จ่ะที่รัก รู้สึกดีขึ้นบ้างหรือยัง?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:39
translate english arc2_yuli_quest2_fe52b826:

    # mn "Eh, ¿Qué hago aquí?"
    mn "หา? ฉันมาทำอะไรที่นี่เนี่ย?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:40
translate english arc2_yuli_quest2_44897805:

    # mn "¿Qué pasó?"
    mn "เกิดอะไรขึ้นน่ะ?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:41
translate english arc2_yuli_quest2_964705f9:

    # yl "Cuando venías entrando a la tienda te chocaste ni más ni menos que con Yuna"
    yl "ตอนที่เธอเดินเข้ามาในร้าน เธอไปเดินชนเข้ากับยูนะเข้าพอดิบพอดีเลยล่ะ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:42
translate english arc2_yuli_quest2_71c093b1:

    # yl "Y a ella no le gustó para nada eso, y cuando vine estabas en el suelo desmayado"
    yl "แล้วเธอก็ไม่สบอารมณ์เอาซะเลย ตอนที่ฉันเดินไปดู เธอเนี่ยสลบเหมือดกองอยู่กับพื้นไปซะแล้ว"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:43
translate english arc2_yuli_quest2_1bb34dac:

    # mn "Entiendo..."
    mn "อย่างนี้นี่เอง..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:44
translate english arc2_yuli_quest2_2aafbbca:

    # yl "Debes tener más cuidado, es peligroso que vayas por ahí chocando con la gente, y más peligroso si chocas con Yuna"
    yl "เธอต้องระวังตัวให้มากกว่านี้นะ เดินไปชนคนอื่นสเปะสปะมันอันตรายนะ ยิ่งถ้าเป็นยูนะด้วยแล้วเนี่ย"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:45
translate english arc2_yuli_quest2_3adf90fd:

    # mn "Si... Ahora tendré más cuidado..."
    mn "ครับ... ต่อไปนี้ผมจะระวังตัวให้มากกว่านี้ครับ..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:46
translate english arc2_yuli_quest2_af4caa0d:

    # yl "Bien, espero que así sea"
    yl "ดีแล้วล่ะ ฉันก็หวังว่างั้นนะ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:47
translate english arc2_yuli_quest2_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:48
translate english arc2_yuli_quest2_3d995568:

    # mn "Señora Yuli..."
    mn "คุณยูริครับ..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:49
translate english arc2_yuli_quest2_70d8c278:

    # yl "Puedes llamarme solo Yuli Cariño"
    yl "เรียกฉันว่ายูริเฉย ๆ ก็ได้จ่ะที่รัก"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:50
translate english arc2_yuli_quest2_5bd3025b:

    # mn "Este... Yuli"
    mn "เอ่อ... ยูริ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:51
translate english arc2_yuli_quest2_599abf65:

    # yl "¿Si?"
    yl "จ๊ะ?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:52
translate english arc2_yuli_quest2_2245bffc:

    # mn "¿Y porqué estoy acostado así?"
    mn "ทำไมผมถึงนอนท่านี้อยู่ล่ะเนี่ย?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:53
translate english arc2_yuli_quest2_dc159c04:

    # yl "Solo te estoy cuidando, no podía dejarte tirado en el suelo ¿Verdad?"
    yl "ฉันก็แค่มารับดูแลเธอน่ะ จะให้ปล่อยให้นอนกองอยู่กับพื้นได้ยังไงจริงไหม?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:54
translate english arc2_yuli_quest2_51616156:

    # mn "Bueno... Ya me encuentro mejor, ya puedo levantarme"
    mn "เอ่อ... ผมรู้สึกดีขึ้นแล้วล่ะครับ ลุกขึ้นเองได้แล้ว"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:58
translate english arc2_yuli_quest2_88d476ca:

    # n "[MN] se levanta del regazo de Yuli"
    n "[MN] ลุกขึ้นจากตักของยูริ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:67
translate english arc2_yuli_quest2_7dec115b:

    # yl "Me alegro que ya estés bien"
    yl "ดีใจนะที่เธอรู้สึกดีขึ้นแล้ว"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:68
translate english arc2_yuli_quest2_20f4a826:

    # yl "Por Yuna no te preocupes, ya la regañé cuando se fue"
    yl "ไม่ต้องห่วงเรื่องยูนะหรอก ฉันตำหนิเธอไปเรียบร้อยแล้วตอนที่เธอกลับไปน่ะ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:69
translate english arc2_yuli_quest2_fc481257:

    # yl "Espero que ya no te vuelva a molestar"
    yl "หวังว่าเธอจะไม่มารบกวนเธออีกนะ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:71
translate english arc2_yuli_quest2_7addfc31:

    # mn "G-Gracias, o eso creo"
    mn "ข... ขอบคุณครับ ว่าแต่ก็นะ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:73
translate english arc2_yuli_quest2_103012e3:

    # yl "Ahora bien, a lo que has venido, ya tengo listo tu nuevo traje"
    yl "เอาล่ะ เข้าเรื่องที่เธอมาที่นี่กันดีกว่า ชุดใหม่ของเธอเสร็จเรียบร้อยแล้วล่ะ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:75
translate english arc2_yuli_quest2_230aa6de:

    # mn "Oh, cierto"
    mn "อ๋อ จริงด้วยสิครับ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:76
translate english arc2_yuli_quest2_161ded8b:

    # mn "¿Puedo probármelo?"
    mn "ผมลองสวมดูได้เลยไหมครับ?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:77
translate english arc2_yuli_quest2_518cda24:

    # yl "Claro, está en el vestidor"
    yl "ได้เลยจ่ะ มันอยู่ในห้องลองเสื้อแล้วล่ะ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:79
translate english arc2_yuli_quest2_3175b983:

    # yl "Si quieres puedo ayudarte..."
    yl "ถ้าเธอต้องการ ฉันช่วยเธอก็ได้นะ..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:81
translate english arc2_yuli_quest2_5502cecb:

    # mnn "..."
    mnn "..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:83
translate english arc2_yuli_quest2_cb95345a:

    # mnn "(No recordaba que Yuli fuera así...)"
    mnn "(จำได้ว่ายูริไม่ได้เป็นคนแบบนี้นี่นา...)"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:84
translate english arc2_yuli_quest2_ff233a39:

    # mnn "(Ha estado haciendo esos comentarios muy seguido)"
    mnn "(ช่วงหลังมานี้เธอค่อนข้างพูดจาทำนองนี้บ่อยซะด้วยสิ)"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:85
translate english arc2_yuli_quest2_a5488e07:

    # mnn "(La última vez incluso me tocó el pene...)"
    mnn "(ครั้งก่อนเธอถึงขั้นแตะต้องควยของฉันด้วยซ้ำ...)"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:88
translate english arc2_yuli_quest2_e9494c35:

    # mn "N-No es necesario..."
    mn "ไ-ไม่เป็นไรครับ..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:90
translate english arc2_yuli_quest2_9dc0a859:

    # yl "Oh, bueno, es una lástima"
    yl "อ่า น่าเสียดายจังนะ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:93
translate english arc2_yuli_quest2_4af80ef4:

    # n "[MN] entra al vestidor"
    n "[MN] เดินเข้าไปในห้องลองเสื้อ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:94
translate english arc2_yuli_quest2_baec2c9e:

    # n "Y cuando ya está listo, sale con su nuevo traje"
    n "และเมื่อแต่งตัวเสร็จ เขาก็เดินออกมาในชุดใหม่"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:118
translate english arc2_yuli_quest2_d0aa5e91:

    # mn "Wow... Es increíble..."
    mn "โห... สุดยอดไปเลย..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:119
translate english arc2_yuli_quest2_12ca23f9:

    # mn "Es tal y como lo pedí, y se nota que es de muy buena calidad"
    mn "ตรงตามที่ผมขอไว้เป๊ะเลย แถมยังแสดงให้เห็นถึงคุณภาพที่ยอดเยี่ยมด้วย"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:120
translate english arc2_yuli_quest2_ce8b1d66:

    # mn "Es resistente, y además de eso es muy ligero"
    mn "ทนทานแถมยังเบาสุด ๆ ไปเลยด้วย"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:121
translate english arc2_yuli_quest2_96bb09f8:

    # mn "La tela, la calidad, todo es muy superior, me encanta"
    mn "ทั้งเนื้อผ้าและคุณภาพ ทุกอย่างโดดเด่นมาก ผมชอบสุด ๆ เลยล่ะ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:130
translate english arc2_yuli_quest2_f96b2d3c:

    # yl "Me alegro que te guste cariño"
    yl "ดีใจที่เธอชอบนะจ๊ะที่รัก"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:131
translate english arc2_yuli_quest2_79d85fb0:

    # mn "Si... Me encanta"
    mn "ครับ... ผมชอบมากเลย"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:133
translate english arc2_yuli_quest2_6a746199:

    # yn "¡Mamá!" with vpunch
    yn "แม่คะ!" with vpunch

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:134
translate english arc2_yuli_quest2_46877d2e:

    # mnn "¿Mmm?"
    mnn "อืม?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:145
translate english arc2_yuli_quest2_6bed5d56:

    # mn "Yuna..."
    mn "ยูนะ..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:146
translate english arc2_yuli_quest2_d78a4d9c:

    # yn "Agh... ¿Sigues aquí?"
    yn "ฮึ่ย... นายยังอยู่อีกเหรอเนี่ย?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:147
translate english arc2_yuli_quest2_4aa78a1f:

    # yn "¿Y eso, al fin cambiaste los harapos que usabas?"
    yn "นี่มันอะไรเนี่ย? ในที่สุดก็ยอมทิ้งไอ้ชุดขี้ริ้วขี้เหร่ที่เคยใส่สะทีสินะ?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:150
translate english arc2_yuli_quest2_cf9f0ee1:

    # mn "¿Te gusta? Yuli me lo hizo a medida"
    mn "ชอบไหมล่ะ? ยูริตัดให้ผมเป็นพิเศษเลยนะ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:152
translate english arc2_yuli_quest2_aab846a7:

    # mn "Está increíble ¿No?"
    mn "สุดยอดเลยใช่ไหมล่ะ?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:153
translate english arc2_yuli_quest2_b62488db:

    # yn "Ya veo..."
    yn "งั้นเหรอ..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:157
translate english arc2_yuli_quest2_0d658d8c:

    # yn "Quizás así sobrevivas a los Exámenes"
    yn "บางทีคราวนี้อาจจะรอดจากการสอบไปได้ล่ะมั้ง"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:159
translate english arc2_yuli_quest2_9a082975:

    # yl "Yuna..."
    yl "ยูนะ..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:160
translate english arc2_yuli_quest2_f1d905cc:

    # mn "¿No puedes disimular más tu desprecio hacia mí?"
    mn "ช่วยเก็บอาการรังเกียจฉันหน่อยไม่ได้หรือไง?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:161
translate english arc2_yuli_quest2_52b5b82a:

    # mn "Ya sabes, estamos frente a tu madre..."
    mn "เธอก็รู้ว่าเราอยู่ต่อหน้าแม่เธอนะ..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:163
translate english arc2_yuli_quest2_4bd88c82:

    # yn "Bueno, ya tienes tu ropa, ya puedes irte"
    yn "เอาล่ะ ได้ชุดแล้วก็ไสหัวไปได้แล้วไป"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:164
translate english arc2_yuli_quest2_1da96a49:

    # yn "Tengo que habla con mi madre"
    yn "ฉันมีเรื่องจะคุยกับแม่"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:166
translate english arc2_yuli_quest2_cad4e68b:

    # mn "¿Algún problema?"
    mn "มีปัญหาอะไรรึเปล่า?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:167
translate english arc2_yuli_quest2_2704a020:

    # yn "Nada que te importe, ¿Puedes irte ya?"
    yn "ไม่ใช่เรื่องที่นายต้องรู้ ออกไปได้ยัง?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:168
translate english arc2_yuli_quest2_591c7707:

    # yn "Fuera, rápido"
    yn "ออกไปได้แล้ว ไปเร็วๆ เลย"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:170
translate english arc2_yuli_quest2_b640921f:

    # mn "Está bien, ya me voy, ya voy..."
    mn "โอเคๆ กำลังจะไปแล้วเนี่ย..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:173
translate english arc2_yuli_quest2_7ea7199e:

    # mn "Muchas gracias Yuli, de verdad te lo agradezco"
    mn "ขอบคุณมากนะยูริ ผมซาบซึ้งจริงๆ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:174
translate english arc2_yuli_quest2_0be1a82e:

    # yn "Oye, señora Yuli para tí"
    yn "นี่ แกต้องเรียกว่าคุณยูริต่างหากเล่า"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:176
translate english arc2_yuli_quest2_d4bd59f3:

    # yl "Sin problema Cariño"
    yl "ไม่เป็นไรจ้ะที่รัก"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:177
translate english arc2_yuli_quest2_f2308d90:

    # yl "Puedes volver siempre que quieras, cualquier servicio que necesites estaré encantada de ayudarte"
    yl "แวะมาได้ตลอดเลยนะ ต้องการบริการอะไรบอกได้ ยินดีช่วยเสมอจ้ะ"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:178
translate english arc2_yuli_quest2_e38415a3:

    # yn "¿Y desde cuándo se tratan de tú?"
    yn "แล้วตั้งแต่เมื่อไหร่กันที่สนิทกันจนเรียกชื่อเล่นเนี่ย?"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:180
translate english arc2_yuli_quest2_75b2ad2f:

    # n "[MN] sale de la tienda"
    n "[MN] เดินออกจากร้านไป"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:187
translate english arc2_yuli_quest2_b54b71e9:

    # yn "Tch..."
    yn "ชิ..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:188
translate english arc2_yuli_quest2_b9bbcde7:

    # yn "No sé porqué sigues hablando con él... Ya no tiene nada que ver con nosotras..."
    yn "หนูไม่เข้าใจเลยว่าแม่ยังจะคุยกับเขาอยู่ทำไม... เขาไม่ได้เกี่ยวข้องอะไรกับเราแล้วสักหน่อย..."

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:189
translate english arc2_yuli_quest2_6cc349bc:

    # yl "No puedo simplemente ignorarlo, además es un buen chico"
    yl "แม่จะทำเป็นเมินเฉยใส่เขาไม่ได้หรอก อีกอย่าง เขาก็เป็นเด็กดีออก"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:190
translate english arc2_yuli_quest2_6c5b4eae:

    # yl "De verdad no sé porqué lo dejaste ir"
    yl "แม่ไม่รู้จริงๆ ว่าทำไมแม่ถึงปล่อยเขาไปได้"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:191
translate english arc2_yuli_quest2_51927f46:

    # yn "Bueno ya, eso no te concierne"
    yn "เอาล่ะ นั่นไม่ใช่เรื่องที่ลูกต้องมาใส่ใจสักหน่อย"

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:194
translate english arc2_yuli_quest2_3ea33ad7:

    # n "[MN] sale de la tienda de Yuli"
    n "[MN] เดินออกจากร้านของยูริ"

translate english strings:

    # game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:201
    old "Ya puedes comprar ropa para [MN] en la Tienda de Yuli"
    new "ตอนนี้คุณสามารถซื้อเสื้อผ้าให้ [MN] ได้ที่ร้านของยูริแล้ว"

# TODO: Translation updated at 2024-12-20 07:52

# game/scripts/History/SecundaryStory/Yuli/Arco2/arc2_yuli_quest2.rpy:166
translate english arc2_yuli_quest2_eaf9a86e:

    # yn "Tengo que hablar con mi madre"
    yn "หนูมีเรื่องจะคุยกับแม่ค่ะ"
