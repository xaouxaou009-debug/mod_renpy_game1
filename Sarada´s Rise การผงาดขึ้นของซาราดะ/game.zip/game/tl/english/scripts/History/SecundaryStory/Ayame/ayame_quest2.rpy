

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:14
translate english ayame_quest2_233654cd:

    # mn "Ayame, aquí estoy tal y como prometí"
    mn "อายาะเมะ ผมมาตามสัญญาแล้วนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:16
translate english ayame_quest2_5442985d:

    # mn "Soy un hombre de palabra"
    mn "ผมเป็นคนรักษาคำพูดอยู่แล้ว"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:19
translate english ayame_quest2_82acd776:

    # ay "Me gusta ese tipo de hombres"
    ay "ฉันชอบผู้ชายแบบนั้นซะด้วยสิ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:22
translate english ayame_quest2_425dad15:

    # mn "Gracias, supongo jaja"
    mn "เอิ่ม ขอบคุณมั้งครับ ฮ่าๆ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:25
translate english ayame_quest2_46d36694:

    # ay "Esa fue otra lección, es bueno soltar algún halago cuando intentas coquetear con alguien"
    ay "นั่นก็เป็นอีกหนึ่งบทเรียน เวลาจีบใคร การพูดคำหวานๆ หยอดคำชมบ้างมันเป็นเรื่องที่ดีนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:27
translate english ayame_quest2_34a1680b:

    # mn "Aah, entiendo..."
    mn "อ่า ผมเข้าใจละ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:30
translate english ayame_quest2_45859fc1:

    # ay "Inténtalo, quiero ver lo mejor que se te ocurre"
    ay "ลองดูสิ ฉันอยากเห็นคำพูดที่ดีที่สุดเท่าที่นายจะคิดออกแล้วล่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:33
translate english ayame_quest2_6a7b1dfa:

    # mn "Mmm..."
    mn "อืม..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:35
translate english ayame_quest2_77c234c5:

    # mn "Eeh jaja"
    mn "อะ ฮ่าๆ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:37
translate english ayame_quest2_677e3a8a:

    # mn "T-Te ves bien con el cabello así"
    mn "พ-ทรงผมแบบนั้นก็ดูเข้ากับเธอดีนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:39
translate english ayame_quest2_f83cd5df:

    # mn "Te quedan muy bien las coletas"
    mn "ทรงผมแกะคู่แบบนั้นเหมาะกับเธอมากเลยนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:42
translate english ayame_quest2_9a4892fb:

    # ay "Oh, ¿Enserio lo crees?"
    ay "โอ้ คิดอย่างนั้นจริงๆ เหรอ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:45
translate english ayame_quest2_bf20205f:

    # mn "Si, se te ven bien"
    mn "ใช่แล้ว มันเข้ากับเธอดีนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:48
translate english ayame_quest2_e3954b8c:

    # ay "Gracias jaja, aprendes rápido"
    ay "ขอบใจนะ ฮ่าๆ นายเรียนรู้ไวดีนี่"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:51
translate english ayame_quest2_82332daf:

    # mn "¿Lo hice bien?"
    mn "ผมทำได้ไม่เลวใช่ไหมล่ะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:54
translate english ayame_quest2_0fdaa891:

    # ay "Sí, aunque podría mejorar"
    ay "ใช่ ถึงจะยังทำให้ดีกว่านี้ได้อีกก็เถอะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:57
translate english ayame_quest2_f83e1c8a:

    # ay "Tienes que ser más seguro de ti mismo"
    ay "นายต้องมีความมั่นใจในตัวเองมากกว่านี้หน่อยสิ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:60
translate english ayame_quest2_132d547c:

    # mn "No tengo que dudar, entiendo"
    mn "งั้นคราวนี้ผมจะไม่ลังเลแล้วล่ะ เข้าใจแล้ว"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:62
translate english ayame_quest2_c5f1c5c9:

    # ay "Ahora necesito que vengas conmigo a un sitio a solas"
    ay "ทีนี้ฉันอยากให้นายไปเป็นเพื่อนฉันที่ไหนสักแห่งตามลำพังหน่อย"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:65
translate english ayame_quest2_fbbb6818:

    # mn "¿A solas?"
    mn "ไปกันแค่สองคนเหรอ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:68
translate english ayame_quest2_b6d7303e:

    # ay "Si nos quedamos aquí la gente se hará ideas erróneas, y ni hablar si mi padre se entera"
    ay "ถ้าเรายังอยู่ตรงนี้ เดี๋ยวคนอื่นจะเข้าใจผิดกันหมด ยิ่งถ้าพ่อฉันรู้เข้าล่ะก็..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:71
translate english ayame_quest2_82055b13:

    # mn "Oh, claro"
    mn "อ่า ได้สิ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:73
translate english ayame_quest2_1e91498d:

    # mn "No quiero causarte problemas así que te sigo a dónde quieras"
    mn "ผมไม่อยากทำให้เธอเดือดร้อนหรอก งั้นผมจะไปกับเธอทุกที่ที่อยากไปเลย"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:76
translate english ayame_quest2_5c2aefdb:

    # ay "Gracias, ahora vamos"
    ay "ขอบใจนะ งั้นไปกันเถอะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:79
translate english ayame_quest2_1cf7772b:

    # n "Acompañas a Ayame a otro lado"
    n "คุณตามอายาเมะไปที่อื่น"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:91
translate english ayame_quest2_ae4fa051:

    # mn "¿Un callejón?"
    mn "ตรอกซอกซอยเนี่ยนะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:95
translate english ayame_quest2_b48688b2:

    # ay "Aquí estaremos a solas"
    ay "ตรงนี้เราจะได้อยู่กันตามลำพังสองคน"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:97
translate english ayame_quest2_49a7eaee:

    # ay "En un sitio así tanto tú como tu chica son libres de hacer y decir lo que quieran sin que alguien más los escuche o vea"
    ay "ในที่แบบนี้ ทั้งนายและคนที่นายชอบจะทำหรือพูดอะไรก็ได้ตามใจชอบ โดยที่ไม่มีใครอื่นมาได้ยินหรือเห็นพวกเรา"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:100
translate english ayame_quest2_743713b8:

    # mn "Aah, ahora entiendo"
    mn "อ่า ผมเข้าใจละ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:103
translate english ayame_quest2_689fc681:

    # mn "(Ahora pienso que realmente fue buena idea aceptar esto)"
    mn "(ตอนนี้ฉันคิดว่าการยอมรับข้อเสนอนี้เป็นความคิดที่ดีจริงๆ แฮะ)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:104
translate english ayame_quest2_121daa75:

    # mn "(Si todo esto funciona, me servirá de mucho en el futuro)"
    mn "(ถ้าทุกอย่างนี่ได้ผล มันคงช่วยผมได้เยอะเลยในอนาคต)"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:108
translate english ayame_quest2_1368a4d2:

    # ay "Bueno, pasemos con los gestos básicos"
    ay "งั้นเรามาเริ่มเรียนรู้ท่าทางพื้นฐานกันต่อเลย"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:111
translate english ayame_quest2_ee677d44:

    # mn "¿Gestos básicos?"
    mn "ท่าทางพื้นฐานเหรอ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:114
translate english ayame_quest2_44ef6ddc:

    # ay "Sí, una vez llegados a cierto nivel de confianza, puedes tomarte el atrevimiento de tomarla de la mano"
    ay "ใช่ เมื่อความไว้วางใจถึงระดับหนึ่งแล้ว นายก็กล้าพอที่จะจับมือเธอได้"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:118
translate english ayame_quest2_662ad6dc:

    # ay "Mira a la chica directo a los ojos"
    ay "มองตาผู้หญิงคนนั้นตรงๆ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:119
translate english ayame_quest2_0d6711a7:

    # ay "Dile algo bonito..."
    ay "แล้วก็พูดอะไรดีๆ..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:120
translate english ayame_quest2_32462c4b:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:121
translate english ayame_quest2_04b937ef:

    # ay "Y luego le das un abrazo..."
    ay "จากนั้นก็เข้าไปสวมกอด..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:126
translate english ayame_quest2_32462c4b_1:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:127
translate english ayame_quest2_c1732d5c:

    # mn "Esto se siente bien"
    mn "รู้สึกดีจังแฮะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:128
translate english ayame_quest2_d57710a9:

    # ay "Sí..."
    ay "อืม..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:129
translate english ayame_quest2_32462c4b_2:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:130
translate english ayame_quest2_8a4c460b:

    # mn "¿Estás bien con esto?"
    mn "แบบนี้... เธอโอเคใช่ไหม?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:131
translate english ayame_quest2_77c60aa4:

    # mn "Puede que estémos muy cerca"
    mn "พวกเราน่าจะตัวติดกันขนาดนี้แล้วมั้ง"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:132
translate english ayame_quest2_ec597924:

    # ay "Está bien, no me disgusta"
    ay "ก็... ไม่เป็นไรหรอ ชั้นไม่ได้เกลียดหรอกนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:133
translate english ayame_quest2_32462c4b_3:

    # mn "..."
    mn "..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:134
translate english ayame_quest2_55262dbe:

    # ay "Bien, creo que ya es suficiente"
    ay "อืม คิดว่าแค่นี้ก็น่าจะพอแล้วล่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:139
translate english ayame_quest2_65a787e4:

    # mn "¿Qué tal lo hice?"
    mn "ผมทำได้ดีไหม?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:142
translate english ayame_quest2_6a46e2bb:

    # ay "Muy bien, con el tiempo serás mejor en esto"
    ay "ดีมากเลย เดี๋ยวอีกหน่อยนายก็คงเก่งเรื่องพวกนี้ขึ้นเองแหละ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:144
translate english ayame_quest2_d1e7fe2d:

    # ay "También ayuda que pongas de tu parte"
    ay "แถมมันจะดียิ่งขึ้นไปอีก ถ้านายตั้งใจทำส่วนของตัวเองด้วยน่ะนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:147
translate english ayame_quest2_031220b1:

    # mn "Bueno.. Si alguien tan linda intenta ayudarme, lo mínimo que puedo hacer es hacer mi mayor esfuerzo jaja"
    mn "แหม... ถ้าคนน่ารักมาคอยช่วยทั้งที สิ่งที่ผมพอจะทำได้ อย่างน้อยก็คือต้องทำให้เต็มที่อยู่แล้วล่ะนะ ฮ่าๆ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:150
translate english ayame_quest2_6b613bb6:

    # ay "Gracias por el cumplido"
    ay "ขอบคุณสำหรับคำชมนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:153
translate english ayame_quest2_28e4d153:

    # mn "En verdad te lo agradezco mucho, estoy terminando de aprender este tipo de cosas contigo"
    mn "ผมซาบซึ้งจริงๆ นะที่ได้มาเรียนรู้เรื่องพวกนี้กับเธอน่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:156
translate english ayame_quest2_1f1251d9:

    # ay "No es nada, y si quieres seguir aprendiendo tendrás que volver mañana a visitarme cuando termine mi turno"
    ay "เรื่องแค่นี้เอง และถ้าอยากเรียนรู้ต่อล่ะก็ พรุ่งนี้เลิกงานแล้วแวะมาหาฉันอีกก็แล้วกันนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:158
translate english ayame_quest2_11e38cb7:

    # ay "Pero ya debemos irnos, se nos hará tarde a ambos"
    ay "แต่พวกเราต้องไปกันได้แล้ว เดี๋ยวจะดึกกันทั้งคู่เอาซะเปล่าๆ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:161
translate english ayame_quest2_0ef4d696:

    # mn "No pasa nada, puedo acompañarte hasta tu casa"
    mn "ไม่เป็นไรหรอ เดี๋ยวผมเดินไปส่งเธอที่บ้านเอง"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:164
translate english ayame_quest2_65fffb94:

    # ay "Eso sería muy lindo pero, ¿Recuerdas lo de no hacer que la gente tenga ideas raras?"
    ay "ก็ดีหรอกนะ แต่จำเรื่องที่เราคุยกันเรื่องไม่อยากให้คนอื่นคิดไปไกลได้ใช่ไหมล่ะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:166
translate english ayame_quest2_741469cb:

    # ay "No estamos en una relación de pareja, entonces es mejor así"
    ay "พวกเราไม่ได้เป็นอะไรกันสักหน่อย แยกกันแบบนี้แหละดีแล้วล่ะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:169
translate english ayame_quest2_07a379ea:

    # mn "Aah, cierto, tienes razón..."
    mn "อ่า จริงด้วยสินะ เธอพูดถูก..."

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:172
translate english ayame_quest2_d1c0f23c:

    # ay "¿Te veo mañana?"
    ay "พรุ่งนี้เจอกันนะ?"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:174
translate english ayame_quest2_2f77be27:

    # mn "Claro, ahí estaré"
    mn "แน่นอน ผมจะไปหาแน่นอน"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:176
translate english ayame_quest2_4b929f6d:

    # ay "Bien, entonces te estaré esperando"
    ay "งั้นฉันจะรอนะ"

# game/scripts/History/SecundaryStory/Ayame/ayame_quest2.rpy:180
translate english ayame_quest2_a32aed55:

    # mn "Claro, nos vemos luego"
    mn "ได้เลย ไว้เจอกันนะ"
