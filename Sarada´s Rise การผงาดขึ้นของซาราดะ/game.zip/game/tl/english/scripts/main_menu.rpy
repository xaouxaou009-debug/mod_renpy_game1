

translate english strings:

    # game/scripts/main_menu.rpy:13
    old "Nueva Partida"
    new "เริ่มเกมใหม่"

    # game/scripts/main_menu.rpy:15
    old "Cargar Partida"
    new "โหลดเกม"

    # game/scripts/main_menu.rpy:17
    old "Opciones"
    new "ตั้งค่า"

    # game/scripts/main_menu.rpy:23
    #old "¡Bienvenido! Espero que estes listo para trabajar duro"
    #new "Welcome! I hope you're ready to work hard"

    # game/scripts/main_menu.rpy:25
    #old "¿Que estas esperando? Entra ya, no tengo todo el dia"
    #new "What are you waiting for? Get in already, I don't have all day"

    # game/scripts/main_menu.rpy:27
    #old "¡Bienvenido a Konoha! Aqui empieza tu gran aventura, de veras"
    #new "Welcome to Konoha! This is where your great adventure truly begins"

    # game/scripts/main_menu.rpy:29
    old "Bienvenido cariño, no olvides pasar por mi tienda, tengo algo especial solo para ti"
    new "ยินดีต้อนรับนะที่รัก อย่าลืมแวะมาที่ร้านของฉันล่ะ ฉันมีของพิเศษเตรียมไว้ให้คุณโดยเฉพาะเลย"

    # game/scripts/main_menu.rpy:31
    #old "¡Bienvenido a Konoha! No olvides pasar por Ichiraku Ramen, ¡Te encantara!"
    #new "Welcome to Konoha! Don't forget to stop on Ichiraku Ramen, you'll love it!"

    # game/scripts/main_menu.rpy:33
    #old "¡Oh, hola! Espero que tengas un dia increible en Konoha"
    #new "Oh, hi! I hope you have an amazing day in Konoha"

    # game/scripts/main_menu.rpy:35
    old "!Bienvenido! ¿Sabias que los ninjas mas fuertes tambien saben apreciar de las mujeres mas bellas?"
    new "ยินดีต้อนรับ! รู้ไหมว่านินจาที่แข็งแกร่งที่สุดเขาก็รู้จักรสนิยมในการชื่นชมผู้หญิงที่สวยที่สุดด้วยเหมือนกันนะ?"

    # game/scripts/main_menu.rpy:37
    old "¡Bienvenido! Si necesitas el arma perfecta, estare encantada de ayudarte a elegir"
    new "ยินดีต้อนรับค่ะ! ถ้าคุณต้องการอาวุธที่คู่ควร ฉันยินดีช่วยคุณเลือกเองนะคะ"

    # game/scripts/main_menu.rpy:39
    old "Bienvenido! Espero que encuentres la paz que buscas aqui en Konoha"
    new "ยินดีต้อนรับ! หวังว่าคุณจะพบความสงบสุขที่ตามหาอยู่ที่โคโนฮะนี้นะ"

    # game/scripts/main_menu.rpy:41
    old "¿Buscas mas que un simple saludo? Puede que encuentres algo interesante si vienes a verme"
    new "กำลังมองหาอะไรมากกว่าคำทักทายธรรมดาๆ งั้นเหรอ? เผื่อว่าคุณจะเจออะไรน่าสนใจถ้าแวะมาหาฉันนะ"

    # game/scripts/main_menu.rpy:43
    old "Hola, bienvenido a Konoha. Espero que te sientas como en casa"
    new "สวัสดี ยินดีต้อนรับสู่โคโนฮะนะ หวังว่าจะทำตัวตามสบายเหมือนอยู่บ้านเลย"

    # game/scripts/main_menu.rpy:45
    old "¡Bienvenido! ¿Listo para explorar todo lo que Konoha tiene para ofrecer?"
    new "ยินดีต้อนรับ! พร้อมที่จะสำรวจทุกสิ่งทุกอย่างที่โคโนฮะมีให้แล้วหรือยังล่ะ?"

    # game/scripts/main_menu.rpy:47
    old "¡Hola! ¿Preparado para demostrar de qué estas hecho?"
    new "สวัสดี! พร้อมที่จะพิสูจน์ฝีมือตัวเองแล้วหรือยังล่ะ?"

    # game/scripts/main_menu.rpy:49
    old "Ah, un nuevo rostro... Bienvenido. Observa todo con atencion, nunca se sabe lo que puedes aprender aqui"
    new "อ่า ใบหน้าใหม่นี่เอง... ยินดีต้อนรับ ลองสังเกตดูให้ดีๆ ล่ะ เพราะไม่มีทางรู้หรอกว่าคุณจะได้เรียนรู้อะไรจากที่นี่บ้าง"

    # game/scripts/main_menu.rpy:61
    old "Puedes apoyar el juego en Patreon!"
    new "คุณสามารถสนับสนุนเกมนี้ได้ทาง Patreon!"
# TODO: Translation updated at 2024-12-20 07:52

translate english strings:

    # game/scripts/main_menu.rpy:23
    old "¡Bienvenido! Espero que estés listo para trabajar duro"
    new "ยินดีต้อนรับ! หวังว่าคุณจะพร้อมสำหรับการทำงานหนักนะ"

    # game/scripts/main_menu.rpy:25
    old "¿Qué estás esperando? Entra ya, no tengo todo el día"
    new "มัวรออะไรอยู่ล่ะ? รีบเข้ามาสิ ฉันไม่ได้มีเวลาว่างทั้งวันนะ"

    # game/scripts/main_menu.rpy:27
    old "¡Bienvenido a Konoha! Aquí empieza tu gran aventura, de veras"
    new "ยินดีต้อนรับสู่โคโนฮะ! ที่นี่คือจุดเริ่มต้นของการผจญภัยครั้งใหญ่ของคุณล่ะนะ เชื่อฉันสิ"

    # game/scripts/main_menu.rpy:31
    old "¡Bienvenido a Konoha! No olvides pasar por Ichiraku Ramen, ¡Te encantará!"
    new "ยินดีต้อนรับสู่โคโนฮะ! อย่าลืมแวะไปที่ร้านราเม็งอิจิราคุนะ รับรองว่าคุณต้องชอบแน่!"

    # game/scripts/main_menu.rpy:33
    old "¡Oh, hola! Espero que tengas un día increíble en Konoha"
    new "อ๋อ สวัสดีจ้า! หวังว่าคุณจะมีวันที่ยอดเยี่ยมในโคโนฮะนะ"

    # game/scripts/main_menu.rpy:35
    old "¡Bienvenido! ¿Buscas un lugar donde divertirte? Sígueme, te llevaré a conocer a unas cuantas chicas hermosas"
    new "ยินดีต้อนรับ! กำลังมองหาที่สนุกๆ อยู่หรือเปล่า? ตามฉันมาสิ เดี๋ยวฉันพาไปทำความรู้จักกับสาวสวยหลายคนเลย"

    # game/scripts/main_menu.rpy:37
    old "¡Bienvenido! Si necesitas el arma perfecta, estaré encantada de ayudarte a elegir"
    new "ยินดีต้อนรับค่ะ! ถ้าคุณต้องการอาวุธที่คู่ควร ฉันยินดีช่วยคุณเลือกเองนะคะ"

    # game/scripts/main_menu.rpy:39
    old "¡Bienvenido! Espero que encuentres la paz que buscas aquí en Konoha"
    new "ยินดีต้อนรับ! หวังว่าคุณจะพบความสงบสุขที่ตามหาอยู่ที่โคโนฮะนี้นะ"

    # game/scripts/main_menu.rpy:41
    old "¿Buscas más que un simple saludo? Puede que encuentres algo interesante si vienes a verme"
    new "กำลังมองหาอะไรมากกว่าคำทักทายธรรมดาๆ งั้นเหรอ? เผื่อว่าคุณจะเจออะไรน่าสนใจถ้าแวะมาหาฉันนะ"

    # game/scripts/main_menu.rpy:47
    old "¡Hola! ¿Preparado para demostrar de qué estás hecho?"
    new "สวัสดี! พร้อมที่จะพิสูจน์ฝีมือตัวเองแล้วหรือยังล่ะ?"

    # game/scripts/main_menu.rpy:49
    old "Ah, un nuevo rostro... Bienvenido. Observa todo con atención, nunca se sabe lo que puedes aprender aquí"
    new "อ่า ใบหน้าใหม่นี่เอง... ยินดีต้อนรับ ลองสังเกตดูให้ดีๆ ล่ะ เพราะไม่มีทางรู้หรอกว่าคุณจะได้เรียนรู้อะไรจากที่นี่บ้าง"
