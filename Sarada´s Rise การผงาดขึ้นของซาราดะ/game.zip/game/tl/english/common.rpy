

translate english strings:

    # renpy/common/00accessibility.rpy:28
    old "Auto-voz deshabilitada."
    new "ปิดใช้งานระบบเสียงอัตโนมัติแล้ว"

    # renpy/common/00accessibility.rpy:29
    old "Voz del portapapeles habilitada. "
    new "เปิดใช้งานระบบเสียงจากคลิปบอร์ดแล้ว"

    # renpy/common/00accessibility.rpy:30
    old "Self-voicing enabled. "
    new "เปิดใช้งานระบบเสียงอัตโนมัติแล้ว"

    # renpy/common/00accessibility.rpy:32
    old "bar"
    new "แถบ"

    # renpy/common/00accessibility.rpy:33
    old "selected"
    new "เลือกแล้ว"

    # renpy/common/00accessibility.rpy:34
    old "viewport"
    new "มุมมองหน้าต่าง"

    # renpy/common/00accessibility.rpy:35
    old "horizontal scroll"
    new "เลื่อนแนวนอน"

    # renpy/common/00accessibility.rpy:36
    old "vertical scroll"
    new "เลื่อนแนวตั้ง"

    # renpy/common/00accessibility.rpy:37
    old "activate"
    new "เปิดใช้งาน"

    # renpy/common/00accessibility.rpy:38
    old "deactivate"
    new "ปิดใช้งาน"

    # renpy/common/00accessibility.rpy:39
    old "increase"
    new "เพิ่ม"

    # renpy/common/00accessibility.rpy:40
    old "decrease"
    new "ลด"

    # renpy/common/00accessibility.rpy:138
    old "Font Override"
    new "แทนที่ฟอนต์"

    # renpy/common/00accessibility.rpy:142
    old "Default"
    new "ค่าเริ่มต้น"

    # renpy/common/00accessibility.rpy:146
    old "DejaVu Sans"
    new "DejaVu Sans"

    # renpy/common/00accessibility.rpy:150
    old "Opendyslexic"
    new "Opendyslexic"

    # renpy/common/00accessibility.rpy:156
    old "Text Size Scaling"
    new "ปรับขนาดตัวอักษร"

    # renpy/common/00accessibility.rpy:162
    old "Reset"
    new "รีเซ็ต"

    # renpy/common/00accessibility.rpy:168
    old "Line Spacing Scaling"
    new "ปรับระยะห่างบรรทัด"

    # renpy/common/00accessibility.rpy:180
    old "High Contrast Text"
    new "ข้อความคอนทราสต์สูง"

    # renpy/common/00accessibility.rpy:182
    old "Enable"
    new "เปิด"

    # renpy/common/00accessibility.rpy:186
    old "Disable"
    new "ปิด"

    # renpy/common/00accessibility.rpy:193
    old "Self-Voicing"
    new "ระบบเสียงอัตโนมัติ"

    # renpy/common/00accessibility.rpy:197
    old "Off"
    new "ปิด"

    # renpy/common/00accessibility.rpy:201
    old "Text-to-speech"
    new "แปลงข้อความ ายเป็นเสียง"

    # renpy/common/00accessibility.rpy:205
    old "Clipboard"
    new "คลิปบอร์ด"

    # renpy/common/00accessibility.rpy:209
    old "Debug"
    new "ดีบัก"

    # renpy/common/00accessibility.rpy:215
    old "Self-Voicing Volume Drop"
    new "ระดับเสียงลดลงเมื่อใช้เสียงอัตโนมัติ"

    # renpy/common/00accessibility.rpy:224
    old "The options on this menu are intended to improve accessibility. They may not work with all games, and some combinations of options may render the game unplayable. This is not an issue with the game or engine. For the best results when changing fonts, try to keep the text size the same as it originally was."
    new "ตัวเลือกในเมนูนี้มีไว้เพื่อปรับปรุงการเข้าถึงการใช้งาน แต่อาจใช้ไม่ได้กับทุกเกม และการตั้งค่าบางอย่างอาจทำให้เกมเล่นไม่ได้ ซึ่งไม่ใช่ปัญหาตัวเกมหรือเอนจิ้น เพื่อให้ได้ผลลัพธ์ที่ดีที่สุดเมื่อเปลี่ยนฟอนต์ พยายามรักษาขนาดข้อความให้เท่ากับค่าดั้งเดิม"

    # renpy/common/00accessibility.rpy:229
    old "Return"
    new "กลับ"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Monday"
    new "{#weekday}วันจันทร์"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Tuesday"
    new "{#weekday}วันอังคาร"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Wednesday"
    new "{#weekday}วันพุธ"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Thursday"
    new "{#weekday}วันพฤหัสบดี"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Friday"
    new "{#weekday}วันศุกร์"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Saturday"
    new "{#weekday}วันเสาร์"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Sunday"
    new "{#weekday}วันอาทิตย์"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Mon"
    new "{#weekday_short}จ."

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Tue"
    new "{#weekday_short}อ."

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Wed"
    new "{#weekday_short}พ."

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Thu"
    new "{#weekday_short}พฤหัสบดี"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Fri"
    new "{#weekday_short}ศุกร์"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Sat"
    new "{#weekday_short}เสาร์"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Sun"
    new "{#weekday_short}อาทิตย์"

    # renpy/common/00action_file.rpy:47
    old "{#month}January"
    new "{#month}มกราคม"

    # renpy/common/00action_file.rpy:47
    old "{#month}February"
    new "{#month}กุมภาพันธ์"

    # renpy/common/00action_file.rpy:47
    old "{#month}March"
    new "{#month}มีนาคม"

    # renpy/common/00action_file.rpy:47
    old "{#month}April"
    new "{#month}เมษายน"

    # renpy/common/00action_file.rpy:47
    old "{#month}May"
    new "{#month}พฤษภาคม"

    # renpy/common/00action_file.rpy:47
    old "{#month}June"
    new "{#month}มิถุนายน"

    # renpy/common/00action_file.rpy:47
    old "{#month}July"
    new "{#month}กรกฎาคม"

    # renpy/common/00action_file.rpy:47
    old "{#month}August"
    new "{#month}สิงหาคม"

    # renpy/common/00action_file.rpy:47
    old "{#month}September"
    new "{#month}กันยายน"

    # renpy/common/00action_file.rpy:47
    old "{#month}October"
    new "{#month}ตุลาคม"

    # renpy/common/00action_file.rpy:47
    old "{#month}November"
    new "{#month}พฤศจิกายน"

    # renpy/common/00action_file.rpy:47
    old "{#month}December"
    new "{#month}ธันวาคม"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jan"
    new "{#month_short}ม.ค."

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Feb"
    new "{#month_short}ก.พ."

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Mar"
    new "{#month_short}มี.ค."

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Apr"
    new "{#month_short}เม.ย."

    # renpy/common/00action_file.rpy:63
    old "{#month_short}May"
    new "{#month_short}พฤษภาคม"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jun"
    new "{#month_short}มิถุนายน"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jul"
    new "{#month_short}กรกฎาคม"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Aug"
    new "{#month_short}สิงหาคม"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Sep"
    new "{#month_short}กันยายน"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Oct"
    new "{#month_short}ตุลาคม"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Nov"
    new "{#month_short}พฤศจิกายน"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Dec"
    new "{#month_short}ธันวาคม"

    # renpy/common/00action_file.rpy:250
    old "%b %d, %H:%M"
    new "%b %d, %H:%M"

    # renpy/common/00action_file.rpy:363
    old "Save slot %s: [text]"
    new "บันทึกช่อง %s: [text]"

    # renpy/common/00action_file.rpy:444
    old "Load slot %s: [text]"
    new "โหลดช่อง %s: [text]"

    # renpy/common/00action_file.rpy:497
    old "Delete slot [text]"
    new "ลบช่อง [text]"

    # renpy/common/00action_file.rpy:576
    old "File page auto"
    new "หน้าไฟล์อัตโนมัติ"

    # renpy/common/00action_file.rpy:578
    old "File page quick"
    new "หน้าไฟล์ด่วน"

    # renpy/common/00action_file.rpy:580
    old "File page [text]"
    new "หน้าไฟล์ [text]"

    # renpy/common/00action_file.rpy:638
    old "Page {}"
    new "หน้า {}"

    # renpy/common/00action_file.rpy:638
    old "Automatic saves"
    new "บันทึกอัตโนมัติ"

    # renpy/common/00action_file.rpy:638
    old "Quick saves"
    new "บันทึกด่วน"

    # renpy/common/00action_file.rpy:779
    old "Next file page."
    new "หน้าไฟล์ถัดไป"

    # renpy/common/00action_file.rpy:851
    old "Previous file page."
    new "หน้าไฟล์ก่อนหน้า"

    # renpy/common/00action_file.rpy:912
    old "Quick save complete."
    new "บันทึกด่วนเสร็จสิ้น"

    # renpy/common/00action_file.rpy:930
    old "Quick save."
    new "บันทึกด่วน"

    # renpy/common/00action_file.rpy:949
    old "Quick load."
    new "โหลดด่วน"

    # renpy/common/00action_other.rpy:375
    old "Language [text]"
    new "ภาษา [text]"

    # renpy/common/00director.rpy:708
    old "The interactive director is not enabled here."
    new "ไม่เปิดใช้งานตัวควบคุมเชิงโต้ตอบที่นี่"

    # renpy/common/00director.rpy:1481
    old "⬆"
    new "⬆"

    # renpy/common/00director.rpy:1487
    old "⬇"
    new "⬇"

    # renpy/common/00director.rpy:1551
    old "Done"
    new "เสร็จสิ้น"

    # renpy/common/00director.rpy:1561
    old "(statement)"
    new "(คำสั่ง)"

    # renpy/common/00director.rpy:1562
    old "(tag)"
    new "(แท็ก)"

    # renpy/common/00director.rpy:1563
    old "(attributes)"
    new "(คุณลักษณะ)"

    # renpy/common/00director.rpy:1564
    old "(transform)"
    new "(การเปลี่ยนรูปแบบ)"

    # renpy/common/00director.rpy:1589
    old "(transition)"
    new "(การเปลี่ยนฉาก)"

    # renpy/common/00director.rpy:1601
    old "(channel)"
    new "(ช่องสัญญาณ)"

    # renpy/common/00director.rpy:1602
    old "(filename)"
    new "(ชื่อไฟล์)"

    # renpy/common/00director.rpy:1631
    old "Change"
    new "เปลี่ยน"

    # renpy/common/00director.rpy:1633
    old "Add"
    new "เพิ่ม"

    # renpy/common/00director.rpy:1636
    old "Cancel"
    new "ยกเลิก"

    # renpy/common/00director.rpy:1639
    old "Remove"
    new "ลบออก"

    # renpy/common/00director.rpy:1674
    old "Statement:"
    new "คำสั่ง:"

    # renpy/common/00director.rpy:1695
    old "Tag:"
    new "แท็ก:"

    # renpy/common/00director.rpy:1711
    old "Attributes:"
    new "คุณลักษณะ:"

    # renpy/common/00director.rpy:1729
    old "Transforms:"
    new "การเปลี่ยนรูปแบบ:"

    # renpy/common/00director.rpy:1748
    old "Behind:"
    new "ด้านหลัง:"

    # renpy/common/00director.rpy:1767
    old "Transition:"
    new "การเปลี่ยนฉาก:"

    # renpy/common/00director.rpy:1785
    old "Channel:"
    new "ช่องสัญญาณ:"

    # renpy/common/00director.rpy:1803
    old "Audio Filename:"
    new "ชื่อไฟล์เสียง:"

    # renpy/common/00gui.rpy:423
    old "¿Estas seguro?"
    new "คุณแน่ใจหรือไม่?"

    # renpy/common/00gui.rpy:424
    old "¿Estás seguro de que quieres eliminar este guardar?"
    new "คุณแน่ใจหรือไม่ว่าต้องการลบไฟล์บันทึกนี้?"

    # renpy/common/00gui.rpy:425
    old "¿Estás seguro de que quieres sobrescribir tu guardar?"
    new "คุณแน่ใจหรือไม่ว่าต้องการเขียนทับไฟล์บันทึกของคุณ?"

    # renpy/common/00gui.rpy:426
    old "La carga perderá el progreso no guardado.\n¿Estás seguro de que quieres hacer esto?"
    new "การโหลดจะทำให้ความคืบหน้าที่ไม่ได้บันทึกสูญหาย\nคุณแน่ใจหรือไม่ว่าต้องการทำเช่นนี้?"

    # renpy/common/00gui.rpy:427
    old "¿Estás seguro que quieres salir?"
    new "คุณแน่ใจหรือไม่ว่าต้องการออกจากเกม?"

    # renpy/common/00gui.rpy:428
    old "¿Estás seguro de que quieres volver al menú principal?\nSe perderá el progreso no guardado."
    new "คุณแน่ใจหรือไม่ว่าต้องการกลับสู่เมนูหลัก?\nความคืบหน้าที่ไม่ได้บันทึกจะสูญหาย"

    # renpy/common/00gui.rpy:429
    old "¿Seguro que quieres terminar la repetición?"
    new "คุณแน่ใจหรือไม่ว่าต้องการสิ้นสุดการเล่นซ้ำ?"

    # renpy/common/00gui.rpy:430
    old "¿Estás seguro de que quieres comenzar a saltar?"
    new "คุณแน่ใจหรือไม่ว่าต้องการเริ่มข้าม?"

    # renpy/common/00gui.rpy:431
    old "¿Estás seguro de que quieres saltar a la siguiente opción?"
    new "คุณแน่ใจหรือไม่ว่าต้องการข้ามไปที่ตัวเลือกถัดไป?"

    # renpy/common/00gui.rpy:432
    old "¿Está seguro de que desea saltar el diálogo invisible a la siguiente opción?"
    new "คุณแน่ใจหรือไม่ว่าต้องการข้ามบทสนทนาที่ยังไม่ได้อ่านไปจนถึงตัวเลือกถัดไป?"

    # renpy/common/00keymap.rpy:306
    old "Failed to save screenshot as %s."
    new "ไม่สามารถบันทึกภาพหน้าจอเป็น %s ได้"

    # renpy/common/00keymap.rpy:318
    old "Saved screenshot as %s."
    new "บันทึกภาพหน้าจอเป็น %s แล้ว"

    # renpy/common/00library.rpy:195
    old "Skip Mode"
    new "โหมดข้าม"

    # renpy/common/00library.rpy:281
    old "This program contains free software under a number of licenses, including the MIT License and GNU Lesser General Public License. A complete list of software, including links to full source code, can be found {a=https://www.renpy.org/l/license}here{/a}."
    new "โปรแกรมนี้มีซอฟต์แวร์เสรีภายใต้ใบอนุญาตหลายฉบับ รวมถึง MIT License และ GNU Lesser General Public License คุณสามารถดูรายชื่อซอฟต์แวร์ทั้งหมดพร้อมลิงก์ไปยังซอร์สโค้ดฉบับเต็มได้{a=https://www.renpy.org/l/license}ที่นี่{/a}"

    # renpy/common/00preferences.rpy:254
    old "display"
    new "การแสดงผล"

    # renpy/common/00preferences.rpy:266
    old "transitions"
    new "การเปลี่ยนฉาก"

    # renpy/common/00preferences.rpy:275
    old "skip transitions"
    new "ข้ามการเปลี่ยนฉาก"

    # renpy/common/00preferences.rpy:277
    old "video sprites"
    new "สไปรต์วิดีโอ"

    # renpy/common/00preferences.rpy:286
    old "show empty window"
    new "แสดงหน้าต่างเปล่า"

    # renpy/common/00preferences.rpy:295
    old "text speed"
    new "ความเร็วข้อความ"

    # renpy/common/00preferences.rpy:303
    old "joystick"
    new "จอยสติ๊ก"

    # renpy/common/00preferences.rpy:303
    old "joystick..."
    new "จอยสติ๊ก..."

    # renpy/common/00preferences.rpy:310
    old "skip"
    new "ข้าม"

    # renpy/common/00preferences.rpy:313
    old "skip unseen [text]"
    new "ข้าม [text] ที่ยังไม่ได้อ่าน"

    # renpy/common/00preferences.rpy:318
    old "skip unseen text"
    new "ข้ามข้อความที่ยังไม่ได้อ่าน"

    # renpy/common/00preferences.rpy:320
    old "begin skipping"
    new "เริ่มข้าม"

    # renpy/common/00preferences.rpy:324
    old "after choices"
    new "หลังการเลือก"

    # renpy/common/00preferences.rpy:331
    old "skip after choices"
    new "ข้ามหลังการเลือก"

    # renpy/common/00preferences.rpy:333
    old "auto-forward time"
    new "เวลาอ่านอัตโนมัติ"

    # renpy/common/00preferences.rpy:347
    old "auto-forward"
    new "อ่านอัตโนมัติ"

    # renpy/common/00preferences.rpy:354
    old "Auto forward"
    new "อ่านอัตโนมัติ"

    # renpy/common/00preferences.rpy:357
    old "auto-forward after click"
    new "อ่านอัตโนมัติหลังคลิก"

    # renpy/common/00preferences.rpy:366
    old "automatic move"
    new "การเคลื่อนที่อัตโนมัติ"

    # renpy/common/00preferences.rpy:375
    old "wait for voice"
    new "รอเสียงพากย์"

    # renpy/common/00preferences.rpy:384
    old "voice sustain"
    new "เล่นเสียงพากย์ต่อเนื่อง"

    # renpy/common/00preferences.rpy:393
    old "self voicing"
    new "ระบบอ่านออกเสียง"

    # renpy/common/00preferences.rpy:402
    old "self voicing volume drop"
    new "การลดระดับเสียงเมื่ออ่านออกเสียง"

    # renpy/common/00preferences.rpy:410
    old "clipboard voicing"
    new "ระบบอ่านออกเสียงคลิปบอร์ด"

    # renpy/common/00preferences.rpy:419
    old "debug voicing"
    new "ระบบอ่านออกเสียงสำหรับดีบัก"

    # renpy/common/00preferences.rpy:428
    old "emphasize audio"
    new "เน้นเสียง"

    # renpy/common/00preferences.rpy:437
    old "rollback side"
    new "ด้านที่ย้อนกลับ"

    # renpy/common/00preferences.rpy:447
    old "gl powersave"
    new "โหมดประหยัดพลังงาน GL"

    # renpy/common/00preferences.rpy:453
    old "gl framerate"
    new "อัตราเฟรม GL"

    # renpy/common/00preferences.rpy:456
    old "gl tearing"
    new "การฉีกขาดของภาพ GL"

    # renpy/common/00preferences.rpy:459
    old "font transform"
    new "การแปลงแบบอักษร"

    # renpy/common/00preferences.rpy:462
    old "font size"
    new "ขนาดแบบอักษร"

    # renpy/common/00preferences.rpy:470
    old "font line spacing"
    new "ระยะห่างบรรทัดแบบอักษร"

    # renpy/common/00preferences.rpy:478
    old "system cursor"
    new "เคอร์เซอร์ระบบ"

    # renpy/common/00preferences.rpy:487
    old "renderer menu"
    new "เมนูเรนเดอเรอร์"

    # renpy/common/00preferences.rpy:490
    old "accessibility menu"
    new "เมนูการเข้าถึง"

    # renpy/common/00preferences.rpy:493
    old "high contrast text"
    new "ข้อความความต่างสีสูง"

    # renpy/common/00preferences.rpy:512
    old "music volume"
    new "ระดับเสียงเพลง"

    # renpy/common/00preferences.rpy:513
    old "sound volume"
    new "ระดับเสียงเอฟเฟกต์"

    # renpy/common/00preferences.rpy:514
    old "voice volume"
    new "ระดับเสียงพากย์"

    # renpy/common/00preferences.rpy:515
    old "mute music"
    new "ปิดเสียงเพลง"

    # renpy/common/00preferences.rpy:516
    old "mute sound"
    new "ปิดเสียงเอฟเฟกต์"

    # renpy/common/00preferences.rpy:517
    old "mute voice"
    new "ปิดเสียงพากย์"

    # renpy/common/00preferences.rpy:518
    old "mute all"
    new "ปิดเสียงทั้งหมด"

    # renpy/common/00preferences.rpy:599
    old "Clipboard voicing enabled. Press 'shift+C' to disable."
    new "เปิดใช้งานระบบอ่านออกเสียงคลิปบอร์ดแล้ว กด 'Shift+C' เพื่อปิดใช้งาน"

    # renpy/common/00preferences.rpy:601
    old "Self-voicing would say \"[renpy.display.tts.last]\". Press 'alt+shift+V' to disable."
    new "ระบบอ่านออกเสียงจะอ่านว่า \"[renpy.display.tts.last]\" กด 'Alt+Shift+V' เพื่อปิดใช้งาน"

    # renpy/common/00preferences.rpy:603
    old "Self-voicing enabled. Press 'v' to disable."
    new "เปิดใช้งานระบบอ่านออกเสียงแล้ว กด 'V' เพื่อปิดใช้งาน"

    # renpy/common/_compat/gamemenu.rpym:198
    old "Empty Slot."
    new "ช่องว่าง"

    # renpy/common/_compat/gamemenu.rpym:355
    old "Previous"
    new "ก่อนหน้า"

    # renpy/common/_compat/gamemenu.rpym:362
    old "Next"
    new "ถัดไป"

    # renpy/common/_compat/preferences.rpym:428
    old "Joystick Mapping"
    new "การกำหนดปุ่มจอยสติ๊ก"

    # renpy/common/_developer/developer.rpym:38
    old "Developer Menu"
    new "เมนูผู้พัฒนา"

    # renpy/common/_developer/developer.rpym:43
    old "Interactive Director (D)"
    new "ผู้กำกับแบบโต้ตอบ (D)"

    # renpy/common/_developer/developer.rpym:45
    old "Reload Game (Shift+R)"
    new "โหลดเกมใหม่ (Shift+R)"

    # renpy/common/_developer/developer.rpym:47
    old "Console (Shift+O)"
    new "คอนโซล (Shift+O)"

    # renpy/common/_developer/developer.rpym:49
    old "Variable Viewer"
    new "ตัวดูตัวแปร"

    # renpy/common/_developer/developer.rpym:51
    old "Image Location Picker"
    new "ตัวเลือกตำแหน่งรูปภาพ"

    # renpy/common/_developer/developer.rpym:53
    old "Filename List"
    new "รายการชื่อไฟล์"

    # renpy/common/_developer/developer.rpym:57
    old "Show Image Load Log (F4)"
    new "แสดงบันทึกการโหลดรูปภาพ (F4)"

    # renpy/common/_developer/developer.rpym:60
    old "Hide Image Load Log (F4)"
    new "ซ่อนบันทึกการโหลดรูปภาพ (F4)"

    # renpy/common/_developer/developer.rpym:63
    old "Image Attributes"
    new "คุณสมบัติรูปภาพ"

    # renpy/common/_developer/developer.rpym:90
    old "[name] [attributes] (hidden)"
    new "[name] [attributes] (ซ่อนอยู่)"

    # renpy/common/_developer/developer.rpym:94
    old "[name] [attributes]"
    new "[name] [attributes]"

    # renpy/common/_developer/developer.rpym:143
    old "Nothing to inspect."
    new "ไม่มีอะไรให้ตรวจสอบ"

    # renpy/common/_developer/developer.rpym:154
    old "Hide deleted"
    new "ซ่อนรายการที่ลบ"

    # renpy/common/_developer/developer.rpym:154
    old "Show deleted"
    new "แสดงรายการที่ลบ"

    # renpy/common/_developer/developer.rpym:278
    old "Return to the developer menu"
    new "กลับไปยังเมนูผู้พัฒนา"

    # renpy/common/_developer/developer.rpym:443
    old "Rectangle: %r"
    new "สี่เหลี่ยม: %r"

    # renpy/common/_developer/developer.rpym:448
    old "Mouse position: %r"
    new "ตำแหน่งเมาส์: %r"

    # renpy/common/_developer/developer.rpym:453
    old "Right-click or escape to quit."
    new "คลิกขวาหรือกด Escape เพื่อออก"

    # renpy/common/_developer/developer.rpym:485
    old "Rectangle copied to clipboard."
    new "คัดลอกสี่เหลี่ยมไปยังคลิปบอร์ดแล้ว"

    # renpy/common/_developer/developer.rpym:488
    old "Position copied to clipboard."
    new "คัดลอกตำแหน่งไปยังคลิปบอร์ดแล้ว"

    # renpy/common/_developer/developer.rpym:506
    old "Type to filter: "
    new "พิมพ์เพื่อกรอง:"

    # renpy/common/_developer/developer.rpym:631
    old "Textures: [tex_count] ([tex_size_mb:.1f] MB)"
    new "เท็กซ์เจอร์: [tex_count] ([tex_size_mb:.1f] MB)"

    # renpy/common/_developer/developer.rpym:635
    old "Image cache: [cache_pct:.1f]% ([cache_size_mb:.1f] MB)"
    new "แคชรูปภาพ: [cache_pct:.1f]% ([cache_size_mb:.1f] MB)"

    # renpy/common/_developer/developer.rpym:645
    old "✔ "
    new "✔ "

    # renpy/common/_developer/developer.rpym:648
    old "✘ "
    new "✘ "

    # renpy/common/_developer/developer.rpym:653
    old "\n{color=#cfc}✔ predicted image (good){/color}\n{color=#fcc}✘ unpredicted image (bad){/color}\n{color=#fff}Drag to move.{/color}"
    new "\n{color=#cfc}✔ รูปภาพที่คาดการณ์ไว้ (ดี){/color}\n{color=#fcc}✘ รูปภาพที่ไม่ได้คาดการณ์ไว้ (ไม่ดี){/color}\n{color=#fff}ลากเพื่อย้าย{/color}"

    # renpy/common/_developer/inspector.rpym:38
    old "Displayable Inspector"
    new "ตัวตรวจสอบ Displayable"

    # renpy/common/_developer/inspector.rpym:61
    old "Size"
    new "ขนาด"

    # renpy/common/_developer/inspector.rpym:65
    old "Style"
    new "สไตล์"

    # renpy/common/_developer/inspector.rpym:71
    old "Location"
    new "ตำแหน่ง"

    # renpy/common/_developer/inspector.rpym:122
    old "Inspecting Styles of [displayable_name!q]"
    new "กำลังตรวจสอบสไตล์ของ [displayable_name!q]"

    # renpy/common/_developer/inspector.rpym:139
    old "displayable:"
    new "displayable:"

    # renpy/common/_developer/inspector.rpym:145
    old "        (no properties affect the displayable)"
    new "(ไม่มีคุณสมบัติส่งผลต่อ displayable)"

    # renpy/common/_developer/inspector.rpym:147
    old "        (default properties omitted)"
    new "(ละเว้นคุณสมบัติค่าเริ่มต้น)"

    # renpy/common/_developer/inspector.rpym:185
    old "<repr() failed>"
    new "<repr() ล้มเหลว>"

    # renpy/common/_layout/classic_load_save.rpym:170
    old "a"
    new "a"

    # renpy/common/_layout/classic_load_save.rpym:179
    old "q"
    new "q"

    # renpy/common/00iap.rpy:219
    old "Contacting App Store\nPlease Wait..."
    new "กำลังเชื่อมต่อกับแอปสโตร์\nกรุณารอสักครู่..."

    # renpy/common/00updater.rpy:391
    old "The Ren'Py Updater is not supported on mobile devices."
    new "ระบบอัปเดตของ Ren'Py ไม่รองรับบนอุปกรณ์มือถือ"

    # renpy/common/00updater.rpy:520
    old "An error is being simulated."
    new "กำลังจำลองข้อผิดพลาด"

    # renpy/common/00updater.rpy:704
    old "Either this project does not support updating, or the update status file was deleted."
    new "โปรเจกต์นี้ไม่รองรับการอัปเดต หรือไฟล์สถานะการอัปเดตถูกลบไปแล้ว"

    # renpy/common/00updater.rpy:718
    old "This account does not have permission to perform an update."
    new "บัญชีนี้ไม่มีสิทธิ์ในการดำเนินการอัปเดต"

    # renpy/common/00updater.rpy:721
    old "This account does not have permission to write the update log."
    new "บัญชีนี้ไม่มีสิทธิ์ในการเขียนบันทึกการอัปเดต"

    # renpy/common/00updater.rpy:746
    old "Could not verify update signature."
    new "ไม่สามารถตรวจสอบลายเซ็นการอัปเดตได้"

    # renpy/common/00updater.rpy:1013
    old "The update file was not downloaded."
    new "ไม่ได้ดาวน์โหลดไฟล์อัปเดต"

    # renpy/common/00updater.rpy:1031
    old "The update file does not have the correct digest - it may have been corrupted."
    new "ไฟล์อัปเดตมีค่าไดเจสต์ไม่ถูกต้อง - ไฟล์อาจเสียหาย"

    # renpy/common/00updater.rpy:1181
    old "While unpacking {}, unknown type {}."
    new "ขณะทำการแตกไฟล์ {} พบประเภทที่ไม่รู้จัก {}"

    # renpy/common/00updater.rpy:1553
    old "Updater"
    new "ระบบอัปเดต"

    # renpy/common/00updater.rpy:1560
    old "An error has occured:"
    new "เกิดข้อผิดพลาดขึ้น:"

    # renpy/common/00updater.rpy:1562
    old "Checking for updates."
    new "กำลังตรวจสอบการอัปเดต"

    # renpy/common/00updater.rpy:1564
    old "This program is up to date."
    new "โปรแกรมนี้เป็นเวอร์ชันล่าสุดแล้ว"

    # renpy/common/00updater.rpy:1566
    old "[u.version] is available. Do you want to install it?"
    new "มี [u.version] พร้อมใช้งาน คุณต้องการติดตั้งหรือไม่?"

    # renpy/common/00updater.rpy:1568
    old "Preparing to download the updates."
    new "กำลังเตรียมดาวน์โหลดการอัปเดต"

    # renpy/common/00updater.rpy:1570
    old "Downloading the updates."
    new "กำลังดาวน์โหลดการอัปเดต"

    # renpy/common/00updater.rpy:1572
    old "Unpacking the updates."
    new "กำลังแตกไฟล์การอัปเดต"

    # renpy/common/00updater.rpy:1574
    old "Finishing up."
    new "กำลังเสร็จสิ้น"

    # renpy/common/00updater.rpy:1576
    old "The updates have been installed. The program will restart."
    new "ติดตั้งการอัปเดตเรียบร้อยแล้ว โปรแกรมจะเริ่มต้นใหม่"

    # renpy/common/00updater.rpy:1578
    old "The updates have been installed."
    new "ติดตั้งการอัปเดตเรียบร้อยแล้ว"

    # renpy/common/00updater.rpy:1580
    old "The updates were cancelled."
    new "การอัปเดตถูกยกเลิกแล้ว"

    # renpy/common/00updater.rpy:1595
    old "Proceed"
    new "ดำเนินการต่อ"

    # renpy/common/00compat.rpy:327
    old "Fullscreen"
    new "เต็มจอ"

    # renpy/common/00gallery.rpy:590
    old "Image [index] of [count] locked."
    new "ภาพที่ [index] จาก [count] ถูกล็อกอยู่"

    # renpy/common/00gallery.rpy:610
    old "prev"
    new "ก่อนหน้า"

    # renpy/common/00gallery.rpy:611
    old "next"
    new "ถัดไป"

    # renpy/common/00gallery.rpy:612
    old "slideshow"
    new "สไลด์โชว์"

    # renpy/common/00gallery.rpy:613
    old "return"
    new "ย้อนกลับ"

    # renpy/common/00gltest.rpy:89
    old "Renderer"
    new "ระบบแสดงผล"

    # renpy/common/00gltest.rpy:93
    old "Automatically Choose"
    new "เลือกอัตโนมัติ"

    # renpy/common/00gltest.rpy:100
    old "Force GL Renderer"
    new "บังคับใช้ระบบแสดงผล GL"

    # renpy/common/00gltest.rpy:105
    old "Force ANGLE Renderer"
    new "บังคับใช้ระบบแสดงผล ANGLE"

    # renpy/common/00gltest.rpy:110
    old "Force GLES Renderer"
    new "บังคับใช้ระบบแสดงผล GLES"

    # renpy/common/00gltest.rpy:116
    old "Force GL2 Renderer"
    new "บังคับใช้ระบบแสดงผล GL2"

    # renpy/common/00gltest.rpy:121
    old "Force ANGLE2 Renderer"
    new "บังคับใช้ระบบแสดงผล ANGLE2"

    # renpy/common/00gltest.rpy:126
    old "Force GLES2 Renderer"
    new "บังคับใช้ระบบแสดงผล GLES2"

    # renpy/common/00gltest.rpy:132
    old "Gamepad"
    new "เกมแพด"

    # renpy/common/00gltest.rpy:136
    old "Enable (No Blocklist)"
    new "เปิดใช้งาน (ไม่มีบล็อกลิสต์)"

    # renpy/common/00gltest.rpy:150
    old "Calibrate"
    new "ปรับเทียบ"

    # renpy/common/00gltest.rpy:159
    old "Powersave"
    new "ประหยัดพลังงาน"

    # renpy/common/00gltest.rpy:173
    old "Framerate"
    new "เฟรมเรต"

    # renpy/common/00gltest.rpy:177
    old "Screen"
    new "หน้าจอ"

    # renpy/common/00gltest.rpy:181
    old "60"
    new "60"

    # renpy/common/00gltest.rpy:185
    old "30"
    new "30"

    # renpy/common/00gltest.rpy:191
    old "Tearing"
    new "ภาพฉีกขาด"

    # renpy/common/00gltest.rpy:207
    old "Changes will take effect the next time this program is run."
    new "การเปลี่ยนแปลงจะมีผลเมื่อเปิดโปรแกรมในครั้งถัดไป"

    # renpy/common/00gltest.rpy:214
    old "Quit"
    new "ออกจากเกม"

    # renpy/common/00gltest.rpy:242
    old "Performance Warning"
    new "คำเตือนด้านประสิทธิภาพ"

    # renpy/common/00gltest.rpy:247
    old "This computer is using software rendering."
    new "คอมพิวเตอร์เครื่องนี้กำลังใช้การเรนเดอร์ด้วยซอฟต์แวร์"

    # renpy/common/00gltest.rpy:249
    old "This game requires use of GL2 that can't be initialised."
    new "เกมนี้จำเป็นต้องใช้ GL2 ซึ่งไม่สามารถเริ่มต้นทำงานได้"

    # renpy/common/00gltest.rpy:251
    old "This computer has a problem displaying graphics: [problem]."
    new "คอมพิวเตอร์เครื่องนี้มีปัญหาในการแสดงผลกราฟิก: [problem]"

    # renpy/common/00gltest.rpy:255
    old "Its graphics drivers may be out of date or not operating correctly. This can lead to slow or incorrect graphics display."
    new "ไดรเวอร์กราฟิกอาจเก่าเกินไปหรือทำงานไม่ถูกต้อง ซึ่งอาจทำให้การแสดงผลกราฟิกช้าหรือผิดปกติ"

    # renpy/common/00gltest.rpy:259
    old "The {a=edit:1:log.txt}log.txt{/a} file may contain information to help you determine what is wrong with your computer."
    new "ไฟล์ {a=edit:1:log.txt}log.txt{/a} อาจมีข้อมูลที่ช่วยคุณตรวจสอบปัญหาที่เกิดขึ้นกับคอมพิวเตอร์ของคุณได้"

    # renpy/common/00gltest.rpy:264
    old "More details on how to fix this can be found in the {a=[url]}documentation{/a}."
    new "คุณสามารถดูรายละเอียดเพิ่มเติมเกี่ยวกับวิธีแก้ไขปัญหานี้ได้ใน {a=[url]}เอกสารประกอบ{/a}"

    # renpy/common/00gltest.rpy:269
    old "Continue, Show this warning again"
    new "ดำเนินการต่อ (แสดงคำเตือนนี้อีกครั้ง)"

    # renpy/common/00gltest.rpy:273
    old "Continue, Don't show warning again"
    new "ดำเนินการต่อ (ไม่ต้องแสดงคำเตือนนี้อีก)"

    # renpy/common/00gltest.rpy:281
    old "Change render options"
    new "เปลี่ยนตัวเลือกการเรนเดอร์"

    # renpy/common/00gamepad.rpy:32
    old "Select Gamepad to Calibrate"
    new "เลือกเกมแพดที่จะปรับเทียบ"

    # renpy/common/00gamepad.rpy:35
    old "No Gamepads Available"
    new "ไม่มีเกมแพดที่พร้อมใช้งาน"

    # renpy/common/00gamepad.rpy:54
    old "Calibrating [name] ([i]/[total])"
    new "กำลังปรับเทียบ [name] ([i]/[total])"

    # renpy/common/00gamepad.rpy:58
    old "Press or move the '[control!s]' [kind]."
    new "กดหรือเลื่อน '[control!s]' [kind]"

    # renpy/common/00gamepad.rpy:68
    old "Skip (A)"
    new "ข้าม (A)"

    # renpy/common/00gamepad.rpy:71
    old "Back (B)"
    new "ย้อนกลับ (B)"

    # renpy/common/_errorhandling.rpym:553
    old "Open"
    new "เปิด"

    # renpy/common/_errorhandling.rpym:555
    old "Opens the traceback.txt file in a text editor."
    new "เปิดไฟล์ traceback.txt ในโปรแกรมแก้ไขข้อความ"

    # renpy/common/_errorhandling.rpym:557
    old "Copy BBCode"
    new "คัดลอก BBCode"

    # renpy/common/_errorhandling.rpym:559
    old "Copies the traceback.txt file to the clipboard as BBcode for forums like https://lemmasoft.renai.us/."
    new "คัดลอกไฟล์ traceback.txt ไปยังคลิปบอร์ดในรูปแบบ BBCode สำหรับเว็บบอร์ด เช่น https://lemmasoft.renai.us/"

    # renpy/common/_errorhandling.rpym:561
    old "Copy Markdown"
    new "คัดลอก Markdown"

    # renpy/common/_errorhandling.rpym:563
    old "Copies the traceback.txt file to the clipboard as Markdown for Discord."
    new "คัดลอกไฟล์ traceback.txt ไปยังคลิปบอร์ดในรูปแบบ Markdown สำหรับ Discord"

    # renpy/common/_errorhandling.rpym:592
    old "An exception has occurred."
    new "เกิดข้อผิดพลาดขึ้น"

    # renpy/common/_errorhandling.rpym:615
    old "Rollback"
    new "ย้อนกลับ"

    # renpy/common/_errorhandling.rpym:617
    old "Attempts a roll back to a prior time, allowing you to save or choose a different choice."
    new "พยายามย้อนกลับไปยังเวลาก่อนหน้า เพื่อให้คุณสามารถบันทึกเกมหรือเลือกตัวเลือกใหม่ได้"

    # renpy/common/_errorhandling.rpym:620
    old "Ignore"
    new "ละเว้น"

    # renpy/common/_errorhandling.rpym:624
    old "Ignores the exception, allowing you to continue."
    new "ละเว้นข้อผิดพลาด เพื่อให้คุณดำเนินการต่อได้"

    # renpy/common/_errorhandling.rpym:626
    old "Ignores the exception, allowing you to continue. This often leads to additional errors."
    new "ละเว้นข้อผิดพลาด เพื่อให้คุณดำเนินการต่อได้ ซึ่งมักจะทำให้เกิดข้อผิดพลาดเพิ่มเติมตามมา"

    # renpy/common/_errorhandling.rpym:630
    old "Reload"
    new "โหลดใหม่"

    # renpy/common/_errorhandling.rpym:632
    old "Reloads the game from disk, saving and restoring game state if possible."
    new "โหลดเกมใหม่จากดิสก์ พร้อมบันทึกและกู้คืนสถานะเกมหากเป็นไปได้"

    # renpy/common/_errorhandling.rpym:635
    old "Console"
    new "คอนโซล"

    # renpy/common/_errorhandling.rpym:637
    old "Opens a console to allow debugging the problem."
    new "เปิดคอนโซลเพื่อตรวจสอบและแก้ไขปัญหา"

    # renpy/common/_errorhandling.rpym:650
    old "Quits the game."
    new "ออกจากเกม"

    # renpy/common/_errorhandling.rpym:671
    old "Parsing the script failed."
    new "การประมวลผลสคริปต์ล้มเหลว"

    # renpy/common/00console.rpy:492
    old "Press <esc> to exit console. Type help for help.\n"
    new "กด <esc> เพื่อออกจากคอนโซล พิมพ์ help เพื่อดูคำแนะนำ\n"

    # renpy/common/00console.rpy:496
    old "Ren'Py script enabled."
    new "เปิดใช้งานสคริปต์ Ren'Py แล้ว"

    # renpy/common/00console.rpy:498
    old "Ren'Py script disabled."
    new "ปิดใช้งานสคริปต์ Ren'Py แล้ว"

    # renpy/common/00console.rpy:747
    old "help: show this help"
    new "help: แสดงคำแนะนำนี้"

    # renpy/common/00console.rpy:752
    old "commands:\n"
    new "คำสั่ง:\n"

    # renpy/common/00console.rpy:762
    old " <renpy script statement>: run the statement\n"
    new "<คำสั่งสคริปต์ renpy>: รันคำสั่ง\n"

    # renpy/common/00console.rpy:764
    old " <python expression or statement>: run the expression or statement"
    new " <python expression or statement>: run the expression or statement"

    # renpy/common/00console.rpy:772
    old "clear: clear the console history"
    new "clear: clear the console history"

    # renpy/common/00console.rpy:776
    old "exit: exit the console"
    new "exit: exit the console"

    # renpy/common/00console.rpy:784
    old "load <slot>: loads the game from slot"
    new "load <slot>: loads the game from slot"

    # renpy/common/00console.rpy:797
    old "save <slot>: saves the game in slot"
    new "save <slot>: saves the game in slot"

    # renpy/common/00console.rpy:808
    old "reload: reloads the game, refreshing the scripts"
    new "reload: reloads the game, refreshing the scripts"

    # renpy/common/00console.rpy:816
    old "watch <expression>: watch a python expression\n watch short: makes the representation of traced expressions short (default)\n watch long: makes the representation of traced expressions as is"
    new "watch <expression>: watch a python expression\n watch short: makes the representation of traced expressions short (default)\n watch long: makes the representation of traced expressions as is"

    # renpy/common/00console.rpy:851
    old "unwatch <expression>: stop watching an expression"
    new "unwatch <expression>: stop watching an expression"

    # renpy/common/00console.rpy:886
    old "unwatchall: stop watching all expressions"
    new "unwatchall: stop watching all expressions"

    # renpy/common/00console.rpy:903
    old "jump <label>: jumps to label"
    new "jump <label>: jumps to label"

    # renpy/common/00console.rpy:919
    old "short: Shorten the representation of objects on the console (default)."
    new "short: Shorten the representation of objects on the console (default)."

    # renpy/common/00console.rpy:923
    old "long: Print the full representation of objects on the console."
    new "long: Print the full representation of objects on the console."

    # renpy/common/00console.rpy:927
    old "escape: Enables escaping of unicode symbols in unicode strings."
    new "escape: Enables escaping of unicode symbols in unicode strings."

    # renpy/common/00console.rpy:931
    old "unescape: Disables escaping of unicode symbols in unicode strings and print it as is (default)."
    new "unescape: Disables escaping of unicode symbols in unicode strings and print it as is (default)."

translate english strings:

    # renpy/common/00accessibility.rpy:28
    old "Self-voicing disabled."
    new "Self-voicing disabled."

    # renpy/common/00accessibility.rpy:29
    old "Clipboard voicing enabled. "
    new "Clipboard voicing enabled."

translate english strings:

    # renpy/common/00gui.rpy:423
    old "Are you sure?"
    new "Are you sure?"

    # renpy/common/00gui.rpy:424
    old "Are you sure you want to delete this save?"
    new "Are you sure you want to delete this save?"

    # renpy/common/00gui.rpy:425
    old "Are you sure you want to overwrite your save?"
    new "Are you sure you want to overwrite your save?"

    # renpy/common/00gui.rpy:426
    old "Loading will lose unsaved progress.\nAre you sure you want to do this?"
    new "Loading will lose unsaved progress.\nAre you sure you want to do this?"

    # renpy/common/00gui.rpy:427
    old "Are you sure you want to quit?"
    new "Are you sure you want to quit?"

    # renpy/common/00gui.rpy:428
    old "Are you sure you want to return to the main menu?\nThis will lose unsaved progress."
    new "Are you sure you want to return to the main menu?\nThis will lose unsaved progress."

    # renpy/common/00gui.rpy:429
    old "Are you sure you want to end the replay?"
    new "Are you sure you want to end the replay?"

    # renpy/common/00gui.rpy:430
    old "Are you sure you want to begin skipping?"
    new "Are you sure you want to begin skipping?"

    # renpy/common/00gui.rpy:431
    old "Are you sure you want to skip to the next choice?"
    new "Are you sure you want to skip to the next choice?"

    # renpy/common/00gui.rpy:432
    old "Are you sure you want to skip unseen dialogue to the next choice?"
    new "Are you sure you want to skip unseen dialogue to the next choice?"
# TODO: Translation updated at 2024-02-17 12:30

translate english strings:

    # renpy/common/00accessibility.rpy:215
    old "Voice Volume"
    new "ระดับเสียงพูด"

    # renpy/common/00action_other.rpy:721
    old "Open [text] directory."
    new "เปิดไดเรกทอรี [text]"

    # renpy/common/00director.rpy:1745
    old "Click to toggle attribute, right click to toggle negative attribute."
    new "คลิกเพื่อเปิด/ปิดคุณลักษณะ คลิกขวาเพื่อเปิด/ปิดคุณลักษณะด้านลบ"

    # renpy/common/00director.rpy:1768
    old "Click to set transform, right click to add to transform list."
    new "คลิกเพื่อตั้งค่าการแปลง คลิกขวาเพื่อเพิ่มลงในรายการการแปลง"

    # renpy/common/00director.rpy:1789
    old "Click to set, right click to add to behind list."
    new "คลิกเพื่อตั้งค่า คลิกขวาเพื่อเพิ่มลงในรายการด้านหลัง"

    # renpy/common/00gui.rpy:456
    old "This save was created on a different device. Maliciously constructed save files can harm your computer. Do you trust this save's creator and everyone who could have changed the file?"
    new "เซฟนี้ถูกสร้างขึ้นบนอุปกรณ์เครื่องอื่น ไฟล์เซฟที่ถูกดัดแปลงโดยประสงค์ร้ายอาจเป็นอันตรายต่อคอมพิวเตอร์ของคุณ คุณเชื่อถือผู้สร้างเซฟนี้และทุกคนที่อาจเคยแก้ไขไฟล์นี้หรือไม่?"

    # renpy/common/00gui.rpy:457
    old "Do you trust the device the save was created on? You should only choose yes if you are the device's sole user."
    new "คุณเชื่อถืออุปกรณ์ที่ใช้สร้างเซฟนี้หรือไม่? คุณควรเลือก “ใช่” เฉพาะเมื่อคุณเป็นผู้ใช้อุปกรณ์เครื่องนั้นเพียงคนเดียวเท่านั้น"

    # renpy/common/00preferences.rpy:519
    old "audio when minimized"
    new "เล่นเสียงเมื่อย่อหน้าต่าง"

    # renpy/common/00preferences.rpy:528
    old "audio when unfocused"
    new "เล่นเสียงเมื่อหน้าต่างไม่ได้โฟกัส"

    # renpy/common/00preferences.rpy:537
    old "web cache preload"
    new "โหลดแคชเว็บล่วงหน้า"

    # renpy/common/00preferences.rpy:552
    old "voice after game menu"
    new "เล่นเสียงพูดต่อเมื่อเข้าเมนูเกม "

    # renpy/common/00preferences.rpy:571
    old "main volume"
    new "ระดับเสียงหลัก"

    # renpy/common/00preferences.rpy:575
    old "mute main"
    new "ปิดเสียงหลัก"

    # renpy/common/00speechbubble.rpy:344
    old "Speech Bubble Editor"
    new "ตัวแก้ไขกล่องคำพูด"

    # renpy/common/00speechbubble.rpy:349
    old "(hide)"
    new "(ซ่อน)"

    # renpy/common/00sync.rpy:70
    old "Sync downloaded."
    new "ซิงค์ดาวน์โหลดแล้ว"

    # renpy/common/00sync.rpy:190
    old "Could not connect to the Ren'Py Sync server."
    new "ไม่สามารถเชื่อมต่อกับเซิร์ฟเวอร์ Ren'Py Sync ได้"

    # renpy/common/00sync.rpy:192
    old "The Ren'Py Sync server timed out."
    new "เซิร์ฟเวอร์ Ren'Py Sync หมดเวลาการเชื่อมต่อ"

    # renpy/common/00sync.rpy:194
    old "An unknown error occurred while connecting to the Ren'Py Sync server."
    new "เกิดข้อผิดพลาดที่ไม่ทราบสาเหตุขณะเชื่อมต่อกับเซิร์ฟเวอร์ Ren'Py Sync"

    # renpy/common/00sync.rpy:267
    old "The Ren'Py Sync server does not have a copy of this sync. The sync ID may be invalid, or it may have timed out."
    new "เซิร์ฟเวอร์ Ren'Py Sync ไม่มีข้อมูลซิงค์นี้ อาจเป็นเพราะ Sync ID ไม่ถูกต้อง หรือข้อมูลซิงค์หมดอายุแล้ว"

    # renpy/common/00sync.rpy:409
    old "Please enter the sync ID you generated.\nNever enter a sync ID you didn't create yourself."
    new "กรุณาป้อน Sync ID ที่คุณสร้างขึ้น\nอย่าป้อน Sync ID ที่คุณไม่ได้สร้างขึ้นเองโดยเด็ดขาด"

    # renpy/common/00sync.rpy:428
    old "The sync ID is not in the correct format."
    new "Sync ID มีรูปแบบไม่ถูกต้อง"

    # renpy/common/00sync.rpy:448
    old "The sync could not be decrypted."
    new "ไม่สามารถถอดรหัสข้อมูลซิงค์ได้"

    # renpy/common/00sync.rpy:471
    old "The sync belongs to a different game."
    new "ไม่สามารถถอดรหัสข้อมูลซิงค์ได้"

    # renpy/common/00sync.rpy:476
    old "The sync contains a file with an invalid name."
    new "ข้อมูลซิงค์มีไฟล์ที่ใช้ชื่อไม่ถูกต้อง"

    # renpy/common/00sync.rpy:529
    old "This will upload your saves to the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}.\nDo you want to continue?"
    new "การดำเนินการนี้จะอัปโหลดไฟล์เซฟของคุณไปยัง {a=https://sync.renpy.org}เซิร์ฟเวอร์ เรพาย {/a}\nคุณต้องการดำเนินการต่อหรือไม่?"

    # renpy/common/00sync.rpy:537
    old "Yes"
    new "Yes"

    # renpy/common/00sync.rpy:538
    old "No"
    new "No"

    # renpy/common/00sync.rpy:558
    old "Enter Sync ID"
    new "ป้อน Sync ID"

    # renpy/common/00sync.rpy:569
    old "This will contact the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}."
    new "การดำเนินการนี้จะเชื่อมต่อกับ {a=https://sync.renpy.org}เซิร์ฟเวอร์ Ren'Py Sync{/a}"

    # renpy/common/00sync.rpy:596
    old "Sync Success"
    new "ซิงค์สำเร็จ"

    # renpy/common/00sync.rpy:599
    old "The Sync ID is:"
    new "Sync ID คือ:"

    # renpy/common/00sync.rpy:605
    old "You can use this ID to download your save on another device.\nThis sync will expire in an hour.\nRen'Py Sync is supported by {a=https://www.renpy.org/sponsors.html}Ren'Py's Sponsors{/a}."
    new "คุณสามารถใช้ ID นี้เพื่อดาวน์โหลดไฟล์เซฟของคุณบนอุปกรณ์เครื่องอื่นได้\nข้อมูลซิงค์นี้จะหมดอายุภายในหนึ่งชั่วโมง\nได้รับการสนับสนุนโดย {a=https://www.renpy.org/sponsors.html}ผู้สนับสนุน Ren'Py{/a}"

    # renpy/common/00sync.rpy:609
    old "Continue"
    new "Continue"

    # renpy/common/00sync.rpy:631
    old "Sync Error"
    new "ข้อผิดพลาดในการซิงค์"
